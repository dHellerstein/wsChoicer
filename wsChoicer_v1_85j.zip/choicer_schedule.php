<?php
// works with schedule  page.

session_start() ;
ob_start();

// add some php functions
$curDir=getcwd();
$libfile=$curDir.'/choicer_lib.php';
require_once($libfile);


$todo=$_REQUEST['todo'];     //   updateRates is only one for now
 if ($todo=='save') {
      doSaveSchedule(1);
      exit;
  }

 exit;


//==============
// save this schedule
function doSaveSchedule($cuser) {
  $username=$_REQUEST['username'];
  $useProject=$_REQUEST['theProject'];
  $atime=time();
  $updateDate=date("Y-m-d H:i") ;
  $infos=$_REQUEST['list'];
  $entries=$infos['entries'];

  $formats=$_REQUEST['formats'];

  $amess="; a choicerSchedule save  \n";
  $amess.="; $updateDate \n";
  $amess.="Username: $username \n";
  $amess.="Date: $atime \n";

  $amess.="recoFrom: ".$_REQUEST['recoFrom']." \n";
  $amess.="recoList: ".$_REQUEST['recoList']." \n";   // will be a csv

  $amess.="Comment: ".strip_tags($_REQUEST['comment'])."\n";
  $schType= $_REQUEST['schedulerType'];
  $amess.="schedulerType:  ".$_REQUEST['schedulerType']." \n";

  $nChoices= $infos['nChoices'];
  $nBreaks=  $infos['nBreaks'];
  $startValueAll= $infos['startValueAll'];
  $endValueAll= $infos['endValueAll'];


  $amess.="nChoices:  $nChoices \n";
  $amess.="nBreaks:  $nBreaks \n";          // don't bother with  nEmpty or nRows

  $amess.="startValueAll: $startValueAll \n";
  $amess.="endValueAll: $endValueAll \n";

  $amess.="defValueUse: ".$infos['defValueUse']."\n";
  $amess.="defAddBefore: ".$infos['defAddBefore']."\n";

  if ($schType=='quantity') {
    $amess.="doAddComma: ".$formats['doAddComma']."\n";
    $amess.="doUseK: ".$formats['doUseK']."\n";
    $amess.="doPrefix: ".preg_replace("/\s+/"," ",$formats['doPrefix'])."\n";
    $amess.="doPostFix: ".preg_replace("/\s+/"," ",$formats['doPostFix'])."\n";
  }

  if ($schType=='time') {
    $amess.="doAmPm: ".$formats['doAmPm']."\n";
    $amess.="doShowDays: ".$formats['doShowDays']."\n";
    $amess.="doElapsed: ".$formats['doElapsed']."\n";
  }

  if ($schType=='date') {
    $amess.="doCalendar: ".$formats['doCalendar']."\n";
    $amess.="doShowWeek: ".$formats['doShowWeek']."\n";
    $amess.="doShowYear: ".$formats['doShowYear']."\n";
    $amess.="doShowWeekDay: ".$formats['doShowWeekDay']."\n";
  }
  if ($schType=='order') {
    $amess.="sortAsc: ".$formats['sortAsc']."\n";
    $amess.="sortDsc: ".$formats['sortDsc']."\n";
    $amess.="sortNumeric: ".$formats['sortNumeric']."\n";
  }

//  $amess.="alwaysDays: ".$formats['alwaysDays']."\n";
  $amess.="maxHeight: ".$formats['maxHeight']."\n";
  $aheader=$formats['Header'];
  $amess.='Header: '.preg_replace("/\s+/"," ",$aheader)."\n";

   $scVars=$formats['vars'];
  foreach ($scVars as  $var1=>$adesc) {
     $amess.='$scVar_'.$var1.': '.preg_replace("/\s+/"," ",$adesc)."\n";
  }
   $scVarsK=$formats['varsKeep'];
  foreach ($scVarsK as  $var1=>$adesc) {
     $amess.='$keep_'.$var1.': '.preg_replace("/\s+/"," ",$adesc)."\n";
  }

   $wideVars=$formats['colWidths'];
  foreach ($wideVars as  $var1=>$awide) {
     $amess.='$width_'.$var1.': '.preg_replace("/\s+/"," ",$awide)."\n";
  }


  $nwrites=0;
  foreach ($entries as $ith=>$stuff) {
      $amess.="\n";
      $amess.="Id: ".$stuff['Id']."\n";
      $amess.="Name: ".strip_tags($stuff['Name'])."\n";
      $amess.="isBreak: ". $stuff['isBreak']."\n";
      $amess.="entryValueA: ". $stuff['entryValueA']."\n";
      $amess.="Duration: ". $stuff['Duration']."\n";
      $amess.="Pause: ". $stuff['Pause']."\n";
      $amess.="useDefaultDuration: ". $stuff['useDefaultDuration']."\n";
      $amess.="gotEmphasis: ".strip_tags($stuff['gotEmphasis'])."\n";
      $amess.="Desc: ".strip_tags($stuff['Desc'])."\n";
      $nwrites++;
   }

   $curDir=getcwd();
   $afile=$curDir.'/data/'.$useProject.'/submits/schedule'.$atime.'.sch';
  $fp=fopen($afile,'a');
//  $fp=fopen('submits/schedule'.$atime.'.sch','a');

  fwrite($fp,$amess);
  fclose($fp);
   removeCacheFile($useProject);  // remove the .csh file

  $totEntries=$nBreaks+$nChoices;
  $epsMinutesAll=$endValueAll -$startValueAll  ;
  $asay= "Saved $nwrites entries from $username: with total duration of $epsMinutesAll [saved on  $updateDate] (@ $atime)";

  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($asay, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;


}
 

