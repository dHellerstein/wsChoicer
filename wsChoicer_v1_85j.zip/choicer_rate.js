// make ratings/categories/links-infoblurbs/descriptive notes
function makeRatingsTable(ii) {

// fill in header (ratingsDivMainHeader)
  let nRaters=basicStats['nRaters'];
  let nSubmitters=basicStats['nSubmitters'];
  let nSuggests=basicStats['nSuggests'];
  let amess='';
  amess+='<div  style="margin:1px .1em 1px 5px">';

  amess+='<div style="float:left;margin:-10px 1em 2px 1em;vertical-align:top">';

  amess+=' <input type="button" value="&neArr;" title="view rates in a new window" class="showInNewWindow"  ';
  amess+='       data-in_new_window_header="Rates, categories, links/infoBlurbs, and descriptive notes"  ';
  amess+='       data-in_new_window_find="#ratingsDivTableOuter"> ';

  amess+='<button   name="helpButtonMain"  class="cHelpButton "  onClick="wsurvey.wsShow.show(this)" ';
  amess+='   data-wsshow="#helpRatingDiv"  data-wsshow_alt="#helpRatingDiv2"   ';
  amess+='   title="Help for: Ratings, categories, and notes&#010;Or double click to see the details!"  ';
  amess+='   >&#10068;</button> ';

  amess+= '<b>&#127898;&#65039; Rate &amp; categorize <span name="choiceNameSay2">suggestions</span>, add Links, add descriptive notes</b> ';

    amess+='<span style="margin-left:2em">';
  amess+='<button class="bigButton"  id="isaveRateButton"  title="After you make a change: click here to save your new ratings, categtories, and links and information blurbs, and descriptive notes  " ';
  amess+='   onclick="saveRatesToServer(1)">Save your changes!</button> ';
   amess+='</span>';

  amess+='<span id="ratingsNChanges"  class="cratingsNChanges" data-changes="0">no changes</span>';

  amess+='<button id="ratingsReset" onClick="ratingsReset(this)" class="cratingsReset">Reset</button>';

//this is shown if any 3 or 4 "required" custom vars
  amess+='&nbsp;&nbsp; <button id="iShowHiddenColsRate" data-status="0" style="display:none;color:brown" onClick="showHiddenColsRate(this)"  ';
  amess+='  title="click to toggle view of hidden columns (less important attributes)">&#9199; vu</button> ';

  amess+=' <button id="selectCategoryButton" class="cselectCategoryButton" onclick="selectCategories(1)" title="read categories (from other people)">Read Categories</button>';

  amess+=' </div>';

  amess+='<div style="float:right;margin-right:2em;background-color:#dfdad6" title="Total # of ratings: '+basicStats['nTotalRatings']+'">'+basicStats['nChoicesRated'] +' '+choiceNameSay2+' rated by '+ basicStats['nRaters']+' people';
  amess+='</div>';

  amess+='</div><br clear="all">';

  $('#ratingsDivMainHeader').html(amess);


//   --- table of suggestions, with rate/category/notes input fiels: top row

amess='<table  id="ratingsDivTable" border="1" width="99%"   >';

// ::::::::::    The table header row ...  :::::::::::::

amess+='<tr class="permRow" > '

// :: submitter
amess+='<th name="c0" valign="top"  ><span class="whoSuggest" style="font-size:110%" title="who suggested this ">Who</span></th>';

// ::: name
amess+='<th name="c1"  valign="top" ><span style="font-style:oblique">   ';
amess+=' <span name="choiceNameSay">choice</span> name</span> ';
amess+='</th> ';

// :: category
amess+='<td name="c1b"  valign="top" ><span id="rateTableCategoryColHeader" title="Categories by: '+currentUserName+'" style="border-bottom:1px dotted blue">Category</span></td>  ';

// the zero or more customVar cols
let gotHiddens=0;
for (let cvar in customVarList) {
    let vAtt=customVarList[cvar];
    let arequired=vAtt[1];
    if (arequired!=3 && arequired!=4) {   // show these always
      amess+='<td name="customVarCol" valign="top"><span class="customVarColVal">'+cvar+'</span></td>';
    } else {
      let rhide = (arequired==3) ?  ' style="display:none" ' :  '  ' ;
      amess+='<td '+rhide+' class="hiddenCustomVarCol" name="customVarCol" valign="top"><span class="customVarColVal">'+cvar+'</span></td>';
      gotHiddens++;
    }
}
if (gotHiddens>0) $('#iShowHiddenColsRate').show();  // show the 'display hidden columns' button

// ::: rate   [data-helpbox],[data-infobox]

amess+='<th name="c3b" valign="top" > ';
amess+='<button  onClick="wsurvey.wsShow.show(this)" class="cHelpButton"  data-wsshow="#detailsRating" title="Details on rating">&#10068;</button> ';

amess+='<em>Your &Rscr;ate</em> </th>';

// ::: links/infoBlurbs
amess+='<th name="c4" valign="top" >';
amess+='<button  nClick="wsurvey.wsShow.showx(this)"   data-wsshow="#detailsAddLinks" title="Details on adding a Link">&#10068;</button> ';

amess+='  <span title="Add a link, or an information blurb ">Add  &Lscr;ink </span>';
amess+='  <span style="float:right;margin-right:1em">';
amess+='  </span>';
amess+='      ';
amess+='</th> ';

// ::: desc notes
amess+='<th align="top" name="c5" width="45%" >    '; //   <!-- note the _sortuse values are set to the summary_ranks on constructio -->
amess+=' <span title="Add a descriptive note   ">Add Descriptive &Nscr;otes </span> ';
amess+=' </th>';
amess+='</tr> ';

//====  one row for each suggestion  :::::::::::::::::::::::::::::::

for (let ij1 in choiceArray) {      // note: choiceArray is list of all non-Removed suggestions

  let aid=choiceArray[ij1 ];
  let asugg=choiceList[aid] ;

  let asubmit=asugg['submitBy'];

  let arow='<tr class="rateRow" data-choiceid="'+asugg['ID']+'">';

// ::: submitter
  arow+='<td><span _sortUse="'+asubmit+'"/><span class="whoSuggest">'+asubmit+'</span></td>';

// ::::: name
  let shtname=asugg['shortName'].replace(/[\s\,]+/g, "").toLowerCase().substr(0,14) ;
  arow+='<td><span _sortUse="'+shtname+'"/> '

  arow+='<button class="choiceReportButton" title="View details ... ('+shtname+') in a popup ...  " >&#129534;</button>';
  arow+=asugg['Name'];
  arow+='</td>';

// ::: category
  let catval= (asugg.hasOwnProperty('Category')) ? asugg['Category'] : '  ';
  let shtCat=catval.replace(/[\s]+/g, "").toLowerCase().substr(0,14);         // simplify for sorting purposes
  arow+='<td> <span _sortUse="'+shtCat+'"/>';
  arow+='<input type="text" size="10" title="Enter a one-word category" class="ratingCategoryInput" data-changed="0" data-orig="'+catval+'" name="aCategory" value="'+catval+'">';
  arow+='</td>';


// ::  zero or more custom vars

  for (let cvar in customVarList) {                                         // ::: zero or more custom cols
    let vAtt=customVarList[cvar];
    let arequired=vAtt[1];
    let ccval= (asugg.hasOwnProperty(cvar)) ? asugg[cvar] : 'n.a.';
    let vsht=fixString(ccval.toLowerCase(),1).substr(0,14);               // simplify for sorting purposes
    if (arequired!=3 && arequired!=4) {                // don't show!
      arow+='<td name="customVarCol" ><span _sortUse="'+vsht+'"/>'+ccval+'</td>';
    } else {
      let rhide = (arequired==3) ?  ' style="display:none" ' :  '  ' ;
      arow+='<td name="customVarCol" '+rhide+' class="hiddenCustomVarCol"   ><span _sortUse="'+vsht+'"/>'+ccval+'</td>';
    }
  }

// :::: rate selection

  let myrate= (asugg.hasOwnProperty('Rate')) ? asugg['Rate'] : '0';
  let rateX='';
  rateX+='<ul class="linearMenuRateChoice rateSelect " data-chosen="'+myrate+'"  data-changed="0" data-orig="'+myrate+'"> ';

  let isbolded= (myrate==1) ? ' isbolded ' :  ' ';
  rateX+='<li> <input type="radio" class="myRate2  "   title="Rate: blah (1)" name="cRate_'+aid+'" value="1" > ';
  rateX+='  <label class="myRate3 '+isbolded +'"  title="rating: (1) blah "  data-rate="1">blah</label></li> ';

  isbolded= (myrate==2) ? ' isbolded ' :  ' ';
  rateX+='<li> <input type="radio" class="myRate2 "   title="Rate: okay (2)" name="cRate_'+aid+'" value="2" > ';
  rateX+='   <label class="myRate3 '+isbolded +'" title="rating: (2) okay "  data-rate="2">okay</label></li> ';

  isbolded= (myrate==3) ? ' isbolded ' :  ' ';
  rateX+='<li> <input type="radio" class="myRate2 "   title="Rate: good (3)" name="cRate_'+aid+'" value="3"  > ';
  rateX+='   <label class="myRate3 '+isbolded +'" title="rating: (3) good " data-rate="3">good</label></li> ';

  isbolded= (myrate==4) ? ' isbolded ' :  ' ';
  rateX+='<li> <input type="radio" class="myRate2 "   title="Rate:great (4)" name="cRate_'+aid+'" value="4"  > ';
  rateX+='   <label class="myRate3 '+isbolded +'" title="rating: (4) Great " data-rate="4">great</label></li> ';
  rateX+=' </ul> ';

  let vsort2='<span _sortUse="'+myrate+'"/>';
  arow+='<td>'+vsort2+rateX+'</td>';

// :: links/info blurbs spec

  let nlink=  (asugg.hasOwnProperty('linkNotes')) ? asugg['linkNotes'].length : 0;
  arow+='<td><button class="showLinkMenuButton"  title="Specify a link, or an information blurb" >Add &Lscr;ink</button>';
  arow+='<span class="cShowLink_ncurrent showLinkMenuButton2" title="Current number of links and information blurbs">'+nlink+'</span> ';
  arow+='<div title="use `Add link` to change this " class="linkNoteshow"  > </div> ';
  arow+='<input type="hidden" data-changed="0" name="linkNoteValue" value=""> ';    // this gets updated by "save" on links/infoBlurb menu
  arow+='</td>';

// :: descriptive  notes spec

  let nnotes=  (asugg.hasOwnProperty('descNotes')) ? asugg['descNotes'].length : 0;
  arow+='<td><div>';
  arow+='<span class="cShowNotes_nCurrent" title="Click to view these descriptive notes">'+nnotes+'</span> ';
  arow+='<span style="display:inline-block"><textarea class="descNoteTextArea"  rows="1" cols="60"  data-changed="0" > </textarea></span> ';
  arow+='</div></td>';
  arow+='</tr>';

  amess+=arow;
}

amess+='</table>';

let erdo=$('#ratingsDivTableOuter');

erdo.html(amess);

   let sopts={};                 // add table sort stuff
     sopts['skipCols']=[8,9]  ;
//   sopts['rowNumberClass']=1,
   sopts['rowNumberSortableClass']='rankRowNumber',
   sopts['rowNumberSortableIcon'  ]='&Oscr;';
   sopts['sortNumeric']=-1;

   wsurvey.sortTable.init('ratingsDivTable',sopts)
   wsurvey.sortTable.rowColors('ratingsDivTable',['tan','#dffef4','#f1f8fe' ]);

   let c0= (rateTable_colWidths.hasOwnProperty('sort')) ?  rateTable_colWidths['sort'] : 2 ;
   let c1= (rateTable_colWidths.hasOwnProperty('who')) ?  rateTable_colWidths['who'] : 8 ;
   let c2= (rateTable_colWidths.hasOwnProperty('name')) ?  rateTable_colWidths['name'] : 15 ;
   let c2a= (rateTable_colWidths.hasOwnProperty('category')) ?  rateTable_colWidths['category'] : 8 ;
   let c3= (rateTable_colWidths.hasOwnProperty('rate')) ?  rateTable_colWidths['rate'] : 8 ;
   let c4= (rateTable_colWidths.hasOwnProperty('links')) ?  rateTable_colWidths['links'] : 15 ;
   let c5= (rateTable_colWidths.hasOwnProperty('notes')) ?   rateTable_colWidths['notes'] : 40 ;
   if (!jQuery.isNumeric(c0) || !jQuery.isNumeric(c1) || !jQuery.isNumeric(c2) ||  !jQuery.isNumeric(c2a) ||
          !jQuery.isNumeric(c3) ||   !jQuery.isNumeric(c4) || !jQuery.isNumeric(c5) ) {
       wsurvey.dumpObj(rateTable_colWidths,1,'Bad specification of  rateTable_colWidths') ;
       return 0
    }
   let colWidths=[c0,c1,c2,c2a];       // sort button, who, name, category (in ems?)
   for (let avar in  customVarList) {
       colWidths.push(parseInt(customVarList[avar][0])) ;    // [width,required ]
   }
   colWidths.push(c3);  // your rate
   colWidths.push(c4); // links/infoblurb
   colWidths.push(c5) ;  // notes


   let totwidth=0;
   for (let itt=0;itt<colWidths.length;itt++) totwidth+=parseInt(colWidths[itt]);

   for (let itt=0;itt<colWidths.length;itt++)  {
      let apct=parseInt(100*colWidths[itt]/totwidth);
      colWidths[itt]=apct+'%';
   }
   let foo=wsurvey.sortTable.setTableColWidths('#ratingsDivTable',colWidths,0);
   if (foo[0]===false) alert('Ratings table: '+foo[1]);
   
// fill in list of links/infoBlurb icon images
let frmlist='<form>' ;  // to ensure that radio buttons work
let idog=0;
for (let llname in linkIcons) {
    if (llname=='downloadlocal') continue ; // reserved from local downloads
   aimg=linkIcons[llname];
   idog++;
   let achecked=(llname=='wwwlink') ? ' checked ' :  ' ' ;
   frmlist+='<input type="radio" '+achecked+' dog="'+idog+'"  name="whatLink" value="'+llname+'"> ';
   frmlist+='  <img src="'+aimg+'" checked  width="35" height="15"> &#8286; ';
}
frmlist+='</form>';
$('#linkIcons_list').html(frmlist);



  return 1;

}

//==================
// show links and info resources report

function showLinkFor1(athis,ii) {
  let e1=$('#ishowLinkMenu_popupReportLinks');
  sayLinks='',mvname='';
  if (ii==0)  {e1.hide() ; return 1 };
  if (ii==1) {
     e1.toggle();
     if (!e1.is(':visible')) return 1;
  }

  let etarget=wsurvey.argJquery(athis);  // which row's button
  let etr=etarget.closest('tr');
  let mvid=etr.attr('data-choiceid');
  sayLinks+='<div>Currently specified <em>links and information blurbs</em> ';
  mvname=choiceList[mvid]['Name']  ;      // could check for existence of this choiceid, but probably will never be a problem
  sayLinks+=getlinkNotes(mvid,1);   // 1 to suppress activating links (download and other links will NOT be clickable)

  $('#ishowLinkMenu_popupReportLinks_name').html(mvname);
  efang=$('#ishowLinkMenu_popupReportLinks_content').html(sayLinks);

  wsurvey.wsShow.show('#ishowLinkMenu_popupReportLinks'); // id,noEsc,zindexCheck,keepOpen
  
}



//==================
// show links and info resources menu
// i=2 : specify a new link/info note (list below input fields), 22= show current link/info notes in a popup (list only)
function showLinkMenu(athis,ii) {
  let e1=$('#showLinkMenu');
  let etarget=wsurvey.argJquery(athis);
  sayLinks='',mvname='';
  if (ii==0)  {e1.hide() ; return 1 };
  if (ii==1) {
     e1.toggle();
     if (!e1.is(':visible')) return 1;
  }

  let etr=etarget.closest('tr');
  let mvid=etr.attr('data-choiceid');
  sayLinks+='<div>Currently specified <em>links and information blurbs</em> ';
  mvname=choiceList[mvid]['Name']  ;      // could check for existence of this choiceid, but probably will never be a problem
  sayLinks+=getlinkNotes(mvid,1);   // 1 to suppress activating links (download and other links will NOT be clickable)
  $('#ishowLinkMenu_name').html(mvname);
  $('#ishowLinkMenu_thisSuggestionlinks').html(sayLinks);
  e1.data('theTarget',etarget);        // used by showLinkMenu3  (to know what row to save entry to
  
   wsurvey.wsShow.show('#showLinkMenu'); 

}



//=============
// save the entered link or information blurb: text, private  downlaod spec, www download spec (several flavors)
function showLinkMenu3(ii) {
  let e1=$('#showLinkMenu');
  let useMe,useMeSay;
  if (ii==1)  {             // text  (information blurb)
    let e2=$('#showLinkMenu_text');
    let useMe0=jQuery.trim(e2.val());
    useMe0=fixString(useMe0,2);      // get rid of extraneous spaces
    useMe=wsurvey.removeAllTags(useMe0);
    useMeSay='Blurb: <tt>'+useMe[1]+'</tt>' ;
  }

  if (ii==2)  {             // private link
    let e2=$('#showLinkMenu_privateLink');
    let aval=jQuery.trim(e2.val());
    useMe='@download@'+aval;
    useMeSay='This site download:: <u>'+fixString(aval,2)+'</u>'
  }

  if (ii==3)  {             // public link
    let e2=$('#showLinkMenu_publicLink');
    let aval=jQuery.trim(e2.val());
    let eimgs=$('[name="whatLink"]');
    let arf=eimgs.filter(':checked');
    let aimg=arf.val();
    useMe='@'+aimg+'@'+aval;
    useMeSay='Link:' +aimg+' <u>'+fixString(aval,2)+'</u>'
  }

  let etarget=e1.data("theTarget");
  let etd=etarget.closest('td');
  let etext=etd.find('[name="linkNoteValue"]');
  etext.val(useMe);
  etext.attr('data-changed',1);

  let etext2=etd.find('.linkNoteshow');   // update what is shown
  etext2.html(useMeSay);

  let ecount=$('#ratingsNChanges');      // cumulative changes
  let ecountd=parseInt(ecount.attr('data-changes'));
  ecountd++ ;
  ecount.attr('data-changes',ecountd);
  ecount.html('<tt>'+ecountd+'</tt> changes');

  let esave1=$('#isaveRateButton');
  esave1.addClass('bigButton1');
  e1.hide();

}


///================
// click handler for ratings_category_notes page
function clickOnRatings(evt) {
  let atarget=event.target ;
  let atype=event.type.toLowerCase() ;  // click or change

  let etarget=wsurvey.argJquery(atarget);

  if (etarget.hasClass('myRate2') || etarget.hasClass('myRate3')) {     // selected a rate
    let etr=etarget.closest('tr');
    let mvid=etr.attr('data-choiceid');
    let eul=etarget.closest('ul');
    let etd=etarget.closest('td');
    let eli=etarget.closest('li');

    let etargetLabel=eli.find('label');
    let etargetInput=eli.find("input");
    let arate=etargetInput.val();

     let elabels=etd.find('.myRate3') ;
     elabels.removeClass('isbolded');
     etargetLabel.addClass('isbolded');

     eul.attr('data-chosen',arate);    // this will be looked for at submit time (if 0, no change)
     let didchange=eul.attr('data-changed');
     let ecountd=0;
     if (didchange==0) {                // first change of this rate (for this suggestion by this user)
        eul.attr('data-changed',1);
        let ecount=$('#ratingsNChanges');      // cumulative changes
        ecountd=parseInt(ecount.attr('data-changes'));
        ecountd++ ;
        ecount.attr('data-changes',ecountd);
        ecount.html('<tt>'+ecountd+'</tt> changes');
    }
    if (ecountd>0){
      let esaveButton=$('#isaveRateButton');
      esaveButton.addClass('bigButton1');
    }
  }     // myrate2 or myrate3


 if (etarget.hasClass('cShowNotes_nCurrent'))   {     // # of descriptive notes box clicke -- display all notes in popup
    let etr=etarget.closest('tr');
    let mvid=etr.attr('data-choiceid');
    let sayNotes='<div>';
    let mvname=choiceList[mvid]['Name'];
    $('#ishowLinkMenu_popupReportDesc_name').html(mvname);

    sayNotes+=getDescNotes(mvid );
    $('#ishowLinkMenu_popupReportDesc_content').html(sayNotes);
    let e1= $('#ishowLinkMenu_popupReportDesc');
    
    wsurvey.wsShow.show('#ishowLinkMenu_popupReportDesc');

    return 1 ;
 }    // # of descriptive notes

 if (etarget.hasClass('showLinkMenuButton'))   {     // specify links/infoblurbs menu, and info
      showLinkMenu(etarget,2);
      return 1 ;
 }
  if (etarget.hasClass('showLinkMenuButton2'))   {     // show links/infoblurbs info only
      showLinkFor1(etarget,2);
      return 1 ;
 }
  if (etarget.hasClass('choiceReportButton'))   {     // show report  rate
     let etr=etarget.closest('tr');
     let mvid=etr.attr('data-choiceid');
     displayChoiceReport(mvid,'#ratingsDivTable')    ;
     return 1 ;
  }        //  ============  choiceReportButton  =============


  if (atype!='change') return 0 ;   // only one click hangler -- several change handlers

  if (etarget.hasClass('ratingCategoryInput') && atype=='change'  ) {     // change a catetory
     let dval=jQuery.trim(etarget.val());
     let didchange=etarget.attr('data-changed');
     let ecountd=0;
     if (didchange==0) {                // first change of this rate (for this suggestion by this user)
        etarget.attr('data-changed',1);
        let ecount=$('#ratingsNChanges');      // cumulative changes
        ecountd=parseInt(ecount.attr('data-changes'));
        ecountd++ ;
        ecount.attr('data-changes',ecountd);
        ecount.html('<tt>'+ecountd+'</tt> changes');
    }
    if (ecountd>0) {
       let esaveButton=$('#isaveRateButton');
       esaveButton.addClass('bigButton1');
    }
  }    // change cateagory


    if (etarget.hasClass('linkNoteshow') ||  etarget.hasClass('descNoteTextArea')    ) {     // change an links/ionfoblurbs  or desc note
 
     let dval=jQuery.trim(etarget.val());
     if (dval=='') {
         etarget.attr('data-changed',0);       // empties are NOT treated as changes
         return 1 ;  // empty is not a change
     }
     let didchange=etarget.attr('data-changed');

     if (didchange==1) return 1      ;  // another change, so no need to augment counter

     etarget.attr('data-changed',1);
     let ecount=$('#ratingsNChanges');      // cumulative changes
     let ecountd=parseInt(ecount.attr('data-changes'));
     ecountd++ ;
     ecount.attr('data-changes',ecountd);
     ecount.html('<tt>'+ecountd+'</tt> changes');
     let esaveButton=$('#isaveRateButton');
     esaveButton.addClass('bigButton1');
  }    // change link/infoblurb or desc note

}

//=================
// reset ratings inputs
function ratingsReset(athis) {

    let etable=$('#ratingsDivTable');
    let ecats=etable.find('[name="aCategory"]');
    for (let iee=0;iee<ecats.length;iee++) {   // reset categories to origionall
        let aecat=$(ecats[iee]);
        let orig1=aecat.attr('data-orig');
        aecat.val(orig1);
    }
    let euls=etable.find('.rateSelect');           // reset rates to original
    for (let iee=0;iee<euls.length;iee++) {
        let aeul=$(euls[iee]);      // this ul contains this  rows rate selection radios
        let orig1=aeul.attr('data-orig');
        aeul.attr('data-chosen',orig1);
        aeul.attr('data-changed',0);
        let elabels=aeul.find('label');
        elabels.removeClass('isbolded');

        let eyes=elabels.filter('[data-rate="'+orig1+'"]');

        if (eyes.length==1) eyes.addClass('isbolded');

    }

    let elinks=etable.find('[name="linkNoteValue"]');
    for (let iee=0;iee<elinks.length;iee++) {
        let eav=$(elinks[iee]);      // this ul contains this  rows rate selection radios
        eav.attr('data-changed',0);
        eav.val('');
    }
    let elinks2=etable.find('.linkNoteshow');
    for (let iee=0;iee<elinks2.length;iee++) {
        let eav=$(elinks2[iee]);      // this ul contains this  rows rate selection radios
        eav.html('');
    }

    let enotes=etable.find('.descNoteTextArea');
    for (let iee=0;iee<enotes.length;iee++) {
        let eav=$(enotes[iee]);      // this ul contains this  rows rate selection radios
        eav.attr('data-changed',0);
        eav.val('');
    }


    $('#isaveRateButton').removeClass('bigButton1');
     let ecount=$('#ratingsNChanges');      // cumulative changes
     ecount.attr('data-changes',0) ;
     ecount.html('<tt>no changes</tt>');
     return 1;
}



//================
// save rates, categories,  links/infoBlurb, and descriptive notes
function saveRatesToServer(ii) {
  let newRates={},nnewRates=0,nnewCats=0,newCats={};
  let newNotes={},nnewNotes=0,newLinks={},nnewLinks=0;

  let etable=$('#ratingsDivTable');
  let etrs=etable.find('.rateRow');
  for (let itt=0;itt<etrs.length;itt++) {
     let atr=$(etrs[itt]);

     let mvid=atr.attr('data-choiceid');

     let ecat=atr.find('.ratingCategoryInput');     // check for changes in categories
     let ccat=ecat.val();
     newCats[mvid]=ccat;                    // store all of them, since either none or all are updated on server
     let ecatChange=jQuery.trim(ecat.attr('data-changed'));     // won't update if none of them have data-changed=1
     if (ecatChange==1)  nnewCats++;

     let erate=atr.find('.rateSelect');            // check for changes in rates (this is the ul that contains the rate buttons
     let erateChange=erate.attr('data-changed');            // check for changes in rates
     if (erateChange==1) {
        let crate=erate.attr('data-chosen');
        newRates[mvid]=crate;
        nnewRates++;
     }

     let elink=atr.find('[name="linkNoteValue"]');             // check for an link/infoblurbs ANY content
     let elinkChange=elink.attr('data-changed');            // check for changes in rates
     if (elinkChange==1) {
        let clink=jQuery.trim(elink.val()) ;
        newLinks[mvid]=clink;
        nnewLinks++;
     }

     let enote=atr.find('.descNoteTextArea');             // check for a desc note -- ANY content
     let enoteChange=enote.attr('data-changed');            // check for changes in rates
     if (enoteChange==1) {
        let cnote=jQuery.trim(enote.val()) ;
        newNotes[mvid]=cnote;
        nnewNotes++;
     }
   }
   let nallchanges=nnewCats+ nnewRates + nnewLinks + nnewNotes ;   // may not equal value in nRatingsChange

   if (nallchanges==0) {
       alert('You did not make any changes ');
       return 1;
   }

// something changed. Send all changes to server. Note that categories is a complete set. Rates are cumulative with replacement
// link/infoblurb and desc notes are cumulative without replacement.
// Thus: categories should be for all suggestions (even ones that did NOT change)
   let ddata={};
    ddata['theProject']=useProject ;

   ddata['username']=currentUserName ;
   ddata['nnewCats']=nnewCats ;
     if (nnewCats>0) ddata['newCats']=newCats ;
   ddata['nnewRates']=nnewRates ;
     if (nnewRates>0) ddata['newRates']=newRates ;
   ddata['nnewLinks']=nnewLinks ;
     if (nnewLinks>0) ddata['newLinks']=newLinks ;
   ddata['nnewNotes']=nnewNotes ;
     if (nnewNotes>0) ddata['newNotes']=newNotes ;

   ddata['username']=currentUserName;
   ddata['todo']='updateRates';    // $suggTableVars and
   $.ajax({
        url: 'choicer_rates.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function(response) {             // callback
        saveRatesToServer1(response);
    });

}
function  saveRatesToServer1(response) {

  let amess='Rates, etc saved ... '
  for (let mm=0;mm<response['results'].length;mm++) {
      let amm=response['results'][mm];
      amess+='<div class="cStatusMessageBlock">'+amm+'</div>';
  }
  amess+='  Please <button class="topRowButtonOther2" onclick="doReload()">Reload </button> to see these changes ';
  writeStatusMessage(amess,1,0,1);
  return 1;
}



//===================
// compute rate stuff,
// modifes global basicStats
// and  return object of average rating, # raters (for all rated cnoices), object of raters=# rated
// uses global  allRates[username][ id=rate]

function computeRateStats(ii) {

  let raterList={} ;
  let movieRates={};
  let  nTotalRatings=0,nChoicesRated=0,nRaters=0;
  let nRatings=0;
  for (auser in allRates) {
     let mDidRate=0;
     for (let aid in allRates[auser]) {
         let arate=allRates[auser][aid];
         mDidRate++;         // # rated by this user
         if (!movieRates.hasOwnProperty(aid)) {
            movieRates[aid]=[];
            nChoicesRated++;          // number of choices rated
         }
         movieRates[aid].push(parseInt(arate));
         nTotalRatings++;               // # ratings across all users and all choices
     }   // this users list of rates
     raterList[auser]=mDidRate ;
     nRaters++;
  }
  basicStats['nRaters']=nRaters;
  basicStats['nTotalRatings']= nTotalRatings ;
  basicStats['nChoicesRated']= nChoicesRated ;
  basicStats['raterList']=raterList ;

// now compute averages and # in denom for all movies
  let movieAvgRates={};
  for (let aid2 in movieRates) {
     let marray=movieRates[aid2];
     let asum=0;
     let mlen=marray.length;
     for (im=0;im<mlen;im++) asum+=marray[im];
     let anAvg=asum/mlen;
     av1=[anAvg,mlen];
     movieAvgRates[aid2]=av1;
  }
  
  return  movieAvgRates ;
}



//================
// show hidden columns (those with suggTableVarRequired=3 or 4
function showHiddenColsRate(athis) {
  let ethis=wsurvey.argJquery(athis);
  let istatus=parseInt(ethis.attr('data-status'));
  let etable=$('#ratingsDivTable');
  let ehides=etable.find('.hiddenCustomVarCol');
  if (istatus==0) {     //  currently hidden (or on first call, 3's are hidden, 4's are shown
    ehides.show();
  } else {
     ehides.hide();
  }
  istatus=1-istatus;
  ethis.attr('data-status',istatus);
}



// ================================ category stuff  ==============
//=============================
// select which categories to use (from list provided by the server)
function selectCategories(alist,cuser) {

  let catStuff={};
// stats on all specified categoryLists (one or zero per user
  for (let aname in allCategories['all'] ) {
    let daCats=allCategories['all'][aname] ;
    let catList={},nCats=0;
    for (let mvid in daCats) {
        if (!choiceList.hasOwnProperty(mvid)) continue  ; // probably a removed suggestion (or discarded)
        let acat=jQuery.trim(daCats[mvid]);
        if (acat=='') continue ;            // not assigned a category
        acat=fixString(acat,1).toLowerCase();  // categories must be one word,  no fancy characters
        if (!catList.hasOwnProperty(acat)) {
           catList[acat]=0;
           nCats++;
        }
        catList[acat]++;
    }
    catStuff[aname]={'list':catList,'nCats':nCats};

  }

 // wsurvey.dumpObj(catStuff,1,'catstu');
  let nCatsC= (catStuff.hasOwnProperty(currentUserName)) ? catStuff[currentUserName]['nCats'] : 0 ;
  let amess=nCatsC+' unique categories are used  (by '+currentUserName+')    ';
  amess+='<br>Select a person: &nbsp;&nbsp;';
  let a1='' ;
  a1+='<select   size="1"   required id="iPeopleWithCatList">';
  if (arguments.length<2) cuser=currentUserName;

  if (nCatsC==0) {
       a1+='<option disabled selected value="'+currentUserName+'" title="You have not saved any categories!">'+cuser+'</option>';
  } else {
     a1+='<option selected value="'+currentUserName+'">'+currentUserName+' ('+nCatsC+' categories)</option>';
  }
  for (let aname0 in catStuff ) {
      if (aname0==currentUserName) continue;        // current user is always first in list (don't repeat)
      let nCatsO=catStuff[aname0]['nCats'] ;
      if (nCatsO==0) continue ;          // probably won't happen, bit might
      a1+='<option value="'+aname0+'">'+aname0+' ('+nCatsO+' categories)</option>';
   }
   a1+='</select>';
   a1+=' and then <button onClick="selectCategoriesOther(this)">apply their categories!</button>&nbsp;&hellip; ';

   amess+=a1;

// show list of current categories (not necessarily saved)
   let curCats={};
   let eview=$('#ratingsDivTable');
   etrs=eview.find('.rateRow');
   for (let iet=0;iet<etrs.length;iet++) {
     let aetr=$(etrs[iet]);
     let ecat=aetr.find('[name="aCategory"]');
     let acat=jQuery.trim(ecat.val());
     if (acat=='') continue ;  // ignore emptys
     if (!curCats.hasOwnProperty(acat)) curCats[acat]=0;
     curCats[acat]++;
   }
   let cmess='';
   cmess+='<div style="width:95%;background-color:tan;z-index:23;margin-top:2em"> ';
   cmess+='<em>The current categories (and number of '+choiceNameSay2+' assigned to them):</em><p>';
   for (let aacat in curCats) {
     let incat=curCats[aacat];
     cmess+='<span   class="categoryShow" >'+aacat+'=<tt>'+incat+'</tt> </span>   ';
   }
   cmess+='<break clear="all"/></div>';

   amess+=cmess;

   writeStatusMessage(amess,1,1,1);
   return 1;

}

//==========
// a user chosen list of categories (in category drop down) ... apply  them
function selectCategoriesOther(athis) {

   let e1=$('#iPeopleWithCatList');
  let e2=e1.find("option");
  let aa=e2.filter(":selected");
  if (aa.length==0) return 0 ;   // should not hppen
  let aname=$(aa[0]).val();
  if (!allCategories['all'].hasOwnProperty(aname)) return 0;

  let usecats=allCategories['all'][aname];

// change 'Category' in choiceList.  Note that a '' category (in usecats) is used, unless skipBlankCategories=1
// (set in choice_params.js

  for (let mvid in choiceList) {
     if  (usecats.hasOwnProperty(mvid) && jQuery.trim(usecats[mvid])!='') {
         newCat=usecats[mvid];
     } else {
         if (skipBlankCategories==0) {
            newCat='';
         } else {
           continue   ;   // not specified, or =''... don't change
         }
     }
     choiceList[mvid]['Category']=newCat
  }


// replace value of category in several tables;
//  view: existingEntriesTable  tr: .suggRow . spanBox : .categoryInViewTable
// rates (where category is specified) ratingsDivTable: tr :.rateRow, input box .ratingCategoryInput or name=aCategory
// ranks: theRankingsTable: tr: .rankRow   spanBox categoryInRankTable

 let eview=$('#existingEntriesTable');
 let etrs=eview.find('.suggRow');
 for (let iet=0;iet<etrs.length;iet++) {
    let aetr=$(etrs[iet]);
    let mvid=aetr.attr('data-choiceid');
    if (!choiceList.hasOwnProperty(mvid)) continue ;  // should never happen
    let ecat=aetr.find('.categoryInViewTable');
    let acat=choiceList[mvid]['Category'] ;  // set above!
    ecat.html(acat);
 }

 eview=$('#theRankingsTable');
 etrs=eview.find('.rankRow');
 for (let iet=0;iet<etrs.length;iet++) {
    let aetr=$(etrs[iet]);
    let mvid=aetr.attr('data-choiceid');
    if (!choiceList.hasOwnProperty(mvid)) continue ;  // should never happen
    let ecat=aetr.find('.categoryInRankTable');
    let acat=choiceList[mvid]['Category'] ;  // set above!
    ecat.html(acat);
 }

  eview=$('#ratingsDivTable');
 etrs=eview.find('.rateRow');
 for (let iet=0;iet<etrs.length;iet++) {
    let aetr=$(etrs[iet]);
    let mvid=aetr.attr('data-choiceid');
    if (!choiceList.hasOwnProperty(mvid)) continue ;  // should never happen
    let ecat=aetr.find('.ratingCategoryInput');
    let acat=choiceList[mvid]['Category'] ;  // set above!
    ecat.val(acat);
 }

 eview=$('#theRecommendationsTable');
 etrs=eview.find('.recoRow');
 for (let iet=0;iet<etrs.length;iet++) {
    let aetr=$(etrs[iet]);
    let mvid=aetr.attr('data-choiceid');
    if (!choiceList.hasOwnProperty(mvid)) continue ;  // should never happen
    let ecat=aetr.find('.categoryInViewTable');
    let acat=choiceList[mvid]['Category'] ;  // set above!
    ecat.html(acat);
 }


 allCategories['current']=aname;
 let bmess='Categories specified by <tt>'+aname+'</tt> have been applied.<br>';
 bmess+='They have not been saved! If you want to use these in the future, use <button>Save your changes</button>';

 $('#rateTableCategoryColHeader').attr('title','Categories by: '+aname);
 writeStatusMessage(bmess,2,0);

}
