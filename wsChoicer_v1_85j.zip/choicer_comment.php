<?php
// save a general comment

session_start() ;
ob_start();

// add some php functions
$curDir=getcwd();
$libfile=$curDir.'/choicer_lib.php';
require_once($libfile);


$useProject=$_REQUEST['theProject'];
$username=$_REQUEST['username'];
$todo=$_REQUEST['todo'];     //   updateRates is only one for now
 if ($todo=='saveComment') {
      doSaveComment($username,$useProject);
      exit;
  }
 exit;

function doSaveComment($cuser,$useProject) {
 $atime=time();
 $updateDate=date("Y-m-d H:i") ;
 $curDir=getcwd();

 $comment=$_REQUEST['comment'];
 $ares=checkValidHtml($comment) ;

 if ($ares!==true)  {  // html problem
  $amess='There are HTML errors. Please resubmit.<br>Hint: make sure to use self closing tags (such as <tt>&lt;br /&gt;</tt>)';
  foreach ($ares as $i1=>$aline) {
    $amess.='<div style="border:1px solid red;margin:3px 2em">'.$aline.'</div>';
   }
  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;
}       // problem

// comment is valid
 $amess='';
 $amess="; general comment  \n";
 $amess.="username: $cuser \n";
 $amess.="date: $updateDate \n";
 $amess.="comment: $comment \n";

 $curDir=getcwd();
 $doFile=$curDir.'/data/'.$useProject.'/submits/comment'.$atime.'.cmt';
 $fp=fopen($doFile,'w');

// $fp=fopen('submits/comment'.$atime.'.cmt','a');
 fwrite($fp,$amess);
 fclose($fp);
 removeCacheFile($useProject);  // remove the .csh file

  $asay="Saved ".strlen($comment )." bytes comment  @ $updateDate ";

  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($asay, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;

 }


