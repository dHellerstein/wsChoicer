//=============    retrieve info from server; and create various pages
// retrieve suggestions, etc from server. And display content.
// This calls getInfoFromServer, which does an ajax call
// If a relogon or reload, resetAll (and to be safe closeAllContent) should be called BEFORE calling this!
//
// ido=1 : add/revise suggetions,etc     3: show schedule
//  noalerts: optional. If 1, do NOT autshow alerts (used by doReload0
//
// Terminology note:
//  member : a member of this decision making group.  3 March 2023: someone who has contriburted at least one
//          suggestion,rating,ranking, or recommendation.  Might modify this to be everyone in validNames,
//          even if they have not done anything?
//  user :  synonymous with "visitor". Someone viewing the site. They had to enter a name, but they may not be
//          members. Their access may be limited (using several admin configurable parameters)

function getInfoFromServerStart(ido,noalerts) {
  if (arguments.length<2) noalerts=0 ;

  getInfoFromServer(ido,noalerts); // get suggestions, rankings, etc from server! getInfoFromServer2 callback uses this info to create content

  return 1;
}

//====================
// retrieve and format all suggestions
// The getInfoFromServer2 uses stuff returned by the server to create content, etc

function getInfoFromServer(ido,noalerts) {

  let ddata={};
  ddata['todo']='getData';     // not currently used (choicer_getData does one thing)
  ddata['theProject']=useProject ;

  ddata['username']=currentUserName;  // global   -- is used by checkValidNames

  $.ajax({
        url: 'choicer_getData.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function (response) {
       getInfoFromServer2(response,ido,noalerts ) ;
    });

}

//==================
// callback for  getInfoFromServer
// Create content (view suggestions, rating, ranking, recommendation, etc pages) using inforreturned from by server
// Or, show a schedule
// ido=1 : create conternt,  3= show schddule

function getInfoFromServer2(existList,ido,noalerts ) {
  let doDump1=0;      // set to 1 to dump variables  returned from server (as is AND after processing)

  if (doDump1==1) {           // debug
     let t0=wsurvey.dumpObj(existList,'var','getInfoFromServer2   ');
     wsurvey.displayInNewWindow(0,{'content':'<pre>'+t0+'</pre>'});
  }  else {

    if (typeof(existList)=='object') {
        if (existList.hasOwnProperty('responseText')) {
            let t0=wsurvey.dumpObj(existList,'var','Problem getting info from server:   ');
           wsurvey.displayInNewWindow(0,{'content':'<pre>'+t0+'</pre>'});
           return 1;
        }
    }
  } //  info ffrom server... debug or error check

// failure?
  let gotErr=existList['goterr'] ;
  if (gotErr!==0)   { // failure ...  bad username
      alert(existList['statusMessage']);
      doLogon(2);  // reshow logon screen
      return 0 ;
  }

  if (existList.hasOwnProperty('error')) {
      let gotErr2=existList['error'] ;  // if 'error' exists, a problem
      alert(gotErr2);
      doLogon(2);  // reshow logon screen
      return 0 ;
  }


// success... extract data into globals

  if (typeof(existList['responseText'])!='undefined')  {
     if (existList['responseText'].substr(0,1)=='0')  {  // error!
        let fooError=existList['responseText'].substr(1);
        fooError= wsurvey.removeAllTags(fooError);
        alert(fooError);
        return 0;
     }
  }

// ::: save some globals -- they are used to display content


  memberPassword=existList['memberPassword'];
  localDownloadKeycode=existList['localDownloadKeycode'] ;

  actualMemberName=existList['actualMemberName'] ; // could be ''
  actualMemberName=jQuery.trim(actualMemberName.toLowerCase()) ; // probably overkill

  checkValidNames=existList['checkValidNames'] ;
  validNamesList=existList['validNamesList'] ;
  validNamesLookup={};
  for (let ivv=0;ivv<validNamesList.length;ivv++) {
     let tname=validNamesList[ivv];
     validNamesLookup[tname]=ivv;
  }


  choiceList=existList['choiceList'];       // information on chooices, indexed by choice id -- used to build viewSuggestions table
  removeChoices=existList['removeChoices'];

  discardedChoices=existList['discardedSugg'];
//  wsurvey.dumpObj(discardedChoices,1,'dississ');

// indices are short versions of choice names (commas after spaces remove, no multiple spaces)
  choiceNames=existList['choiceNames'];   // -- value of each   is an array of choiceIds with this name (usually of length 1)

  choiceArray=existList['choiceArray'];     // used as index array when building viewSuggestions
  choiceArrayOrig=existList['choiceOrderOrig'];     // used as index array when building viewSuggestions

  customVarList=existList['varList_custom'];      // list of custom variables (varnames as indices [required,length,desc]
  if (customVarList===null) customVarList={};

  membernameList=existList['membernameList'];    // all members ['nsuggest'=>0,nrate'=>0,'nrank'=>0,'nrecommend'=>0];
  basicStats=existList['basicStats'];      // list of custom variables (varnames as indices, with length as values)

  repeats=existList['repeats'];         // list of movieid whose name matches a prior movie name

  modifieds=existList['modified'];         // list of movieid whose name matches a prior movie name

  allRecos={};
  allRecos['current']=existList['recos']['recList'] ;   //  recommendations BY USER

  allRecos['userDiscards']= existList['recos']['userDiscards'] ;
  allRecos['nRecoUsersDiscard']= existList['recos']['nRecoUsersDiscard'] ;
  allRecos['nRecosDiscard']= existList['recos']['nRecosDiscard'] ;

  allRecos['draft']=existList['recos']['recListDraft'] ;   //   draft recommendations  BY USER
  allRecos['topRow']=existList['recos']['recoTopRow'] ;
  allRecos['comments']=existList['recos']['comment'] ;

  allCategories['all']=existList['categories'];     // all users who categorized (all choices)
  allCategories['current']=currentUserName ;

  allRates=existList['rates'];               // all users (variable set of choices)
  nMissingRates=existList['nMissingRates'];      // not really used (just reported to admin)

  allRanks=existList['ranks'];            // all users (variable set of choices)

  allScheds=existList['schedules'];      // list of schedules (up to one per user). Each scheduleL

  privateDownloadLink=existList['privateDownloadLink'] ; // set in choicer_params.php
  downloadUsers=existList['downloadUsers'] ; // set in choicer_params.php
  siteIntro=existList['siteIntro'];

  schedulerType=existList['schedulerType'] ;    // the type of schedule to create (time,date,quantity,order)
  schedulerShow=existList['schedulerShow'] ;       // what variables to show in formated  schedule

  schedulerNoShow=existList['schedulerNoShow'] ;       // what variables to show in formated  schedule
  if (schedulerNoShow==null) schedulerNoShow={};

  schedulerShowAddAll=existList['schedulerShowAddAll'] ;   // include all possible schedulerShow (as non-included)

//  :::::::::   do some prcoessing of the information returned from the server

// insert links/infoBLurbs and descriptive notes into choiceList
 let allLinks=existList['links'];          // links and information blurbs (by choice, array with note and submitter)
 let allNotes=existList['notes'];          // descriptive notes (by choice, array with note and submitter)
  for (let mvid0 in choiceList) {                    // over all suggestions (which do NOT vary over users)
     let thisNotes= (allNotes.hasOwnProperty(mvid0)) ? allNotes[mvid0] : [] ;
     let thisLinks= (allLinks.hasOwnProperty(mvid0)) ? allLinks[mvid0] : [] ;
      choiceList[mvid0]['descNotes']=thisNotes;      // an array or notes, each row is [text,submitter]
      choiceList[mvid0]['linkNotes']=thisLinks;
   }

// insert user's  rating into choiceList   (rating for currentUserName for all choices (0 if no rating made)
  let myRates= (allRates.hasOwnProperty(currentUserName)) ? allRates[currentUserName] :  {} ;  // for currentuser
  for (let mvid0 in choiceList) {
      let thisRate= (myRates.hasOwnProperty(mvid0)) ?  jQuery.trim(myRates[mvid0]) : '0' ;  // could be 0 if newer suggestions added
      choiceList[mvid0]['Rate']=thisRate;
  }
// insert average rates, and list of rates ...
  let rstats=computeRateStats(1)  ;        // uses globals  allRates and membernameList, modifies basicStats
  choiceList_rates(rstats);               // fix up   choiceList (globals)

//  compute some rank stats  (and save to basicStats)
   choiceList_ranks(1);  // fix up   choiceList (globals)
   computeRankStats(1)  ;        // uses globals  allRanks and membernameList, modifies basicStats

// compute some recommendation stats (and save to basicStats)
  choiceList_recos(1);  // fix up allRecos and choiceList (globals)
   computeRecoStats(1)  ;        // uses globals  allRates and membernameList, modifies basicStat


// insert user's categoryies  into choiceList
  let myCategories= (allCategories['all'].hasOwnProperty(currentUserName)) ? allCategories['all'][currentUserName] :  {} ;  // for currentuser
  for (let mvid0 in choiceList) {          // over all suggestions (which do NOT vary over users)
      let thiscat= (myCategories.hasOwnProperty(mvid0)) ?  jQuery.trim(myCategories[mvid0]) : '' ;  // could be created before new suggestions added
      choiceList[mvid0]['Category']=thiscat;     // can be changed if someone else's categories are read
      choiceList[mvid0]['OwnCategory']=thiscat;  // this is what is saved on server  (for currentusername)
  }

 let missMessages=[];

// cleanup currentUserName, and display logonname stuff
  let elogn=$('[name="logonNameSay"]') ;
  if (actualMemberName!=='') {
      elogn.html(actualMemberName );
      if (actualMemberName!=currentUserName) {
         elogn.attr('title','You logged on using a nickname: '+myLogonName   );  // may not be the actual memberName
         currentUserName=actualMemberName;  // use this global  everywhere!
      }
  }     // if '', no changes  (is a non-member)

// :::::  create html pages ...   (view Suggestions, rates, ranks,...)
//   Almost all of these are hidden (user action is needed to display them)



  makeNewSuggestions(1) ;    // make the new suggestions table (and addable row)

  makeViewSuggestions(1);       // uses choiceList  to build the viewSuggesions page (choicer_viewer.js)   -- uses choiceList

// since ratings are suggestion specific, don't have to report if a removed suggestion was rated (or had links, categories, or notes added)
  makeRatingsTable(1);       // build the add ratings,categories, links/infoBlurgs. and descriptive notes (choicer_rates.js)
  let nfoo=makeRankTable(1);          // build the rankings table  -- and detect remvoes
  let nMissRank=nfoo[0];
  let nNoRankRound=nfoo[1];          // build the rankings table  -- and detect remvoes
  if (nMissRank>0) missMessages.push(nMissRank+' rankings are no longer available. Please examine and update your &real;ankings!');
  if (nNoRankRound>0) missMessages.push(nNoRankRound+' '+choiceNameSay2+' are not subject to ranking. Please examine and update your &real;ankings!');

  let nMissReco=makeRecoTable(1);          // build the recoomendations table
  if (nMissReco>0) missMessages.push(nMissReco+' '+choiceNameSay2+' are no longer available. Please examine and re-Save your &#127479;ecommendations! ');


  if (typeof(makeSchedule)=='function') makeSchedule(1);           // build the schedule stubs

  makeCommentsBox(existList['comments']) ;       // write all comments to general comments container

  writeMemberStats(0) ;        // write user stats summary table (in popup window)

  doOtherStartup(1,noalerts) ;   // other startup actions (after all content written);


  if (doDump1==1) {           // debug
     let t0=wsurvey.dumpObj(existList,'var','choiceList -- after further processing   ');
     let t1=wsurvey.dumpObj(removeChoices,'var','removeChoices -- after further processing   ');
     wsurvey.displayInNewWindow(0,{'content':'<pre>'+t0+' <hr>'+t1+'</pre>'});
}
  if (missMessages.length>0) {
      let mmess='<div style="border:1px solid gray;margin:2px">'+missMessages.join('</div><div style="border:1px solid gray;margin:2px">')+'</div>';
      writeStatusMessage(mmess,2,0,1);
  }

  if (existList.hasOwnProperty('cacheMessage')) {
      writeStatusMessage(existList['cacheMessage'],0,1,0);
  }
  $('.cTopRowButton').fadeIn(50);
  return 1;

}


//===================
// fix up   choiceList (globals)
function   choiceList_ranks(rnkstats) {

   let defNoRankReason='<tt>not subject to ranking</tt>';  // used if '' noRankReason (and noRank=1)

   for (let mmid in choiceList) {
     choiceList[mmid]['summary_rank']= (allRanks['trancheList'].hasOwnProperty(mmid)) ? allRanks['trancheList'][mmid] : 7 ;

     let myRank=3;     // larger numbers for worse ranking
     let ntops=0,nnexts=0;    // number of top or next ranks this movie got
     if (allRanks['userTops'].hasOwnProperty(currentUserName)) {
         myRank= (jQuery.inArray(mmid,allRanks['userTops'][currentUserName])>-1) ? 1 : 3 ;
     }
     if (myRank==3)   {  // was not in top, maybe in next?
        if (allRanks['userNexts'].hasOwnProperty(currentUserName)) {
           myRank= (jQuery.inArray(mmid,allRanks['userNexts'][currentUserName])>-1) ? 2 : 3 ;
        }
     }
     choiceList[mmid]['myRank']=myRank ;
     choiceList[mmid]['topRank']=[];
     choiceList[mmid]['nextRank']=[]
     if (allRanks['choiceRanks'].hasOwnProperty(mmid)) {
         if (allRanks['choiceRanks'][mmid].hasOwnProperty('top9')) choiceList[mmid]['topRank']= allRanks['choiceRanks'][mmid]['top9'];
         if (allRanks['choiceRanks'][mmid].hasOwnProperty('next9'))  choiceList[mmid]['nextRank']= allRanks['choiceRanks'][mmid]['next9'];
     }
     choiceList[mmid]['ntopRank']=choiceList[mmid]['topRank'].length ;
     choiceList[mmid]['nnextRank']= choiceList[mmid]['nextRank'].length ;
     choiceList[mmid]['nbothRank']=  choiceList[mmid]['ntopRank'] +choiceList[mmid]['nnextRank'] ; // used in reco custom sort
   }


// tweak noRank stuff in the choiceList global
   for  (let aaid in choiceList) {
      let acc=choiceList[aaid];
      let nora=(acc.hasOwnProperty('noRankThis')) ? acc['noRankThis'] : 0 ;
      choiceList[aaid]['noRankThis']=nora;          // cleanup
      if (nora==1)  {
         let zzmess=(acc.hasOwnProperty('noRankReason') && jQuery.trim(acc['noRankReason'])!='') ? jQuery.trim(acc['noRankReason']) : defNoRankReason ;
         choiceList[aaid]['noRankReason']=zzmess;
      }
      //wsurvey.dumpObj(choiceList[aaid],1,' xxacc2 for '+aaid);

   }         // foreach
   return 1 ;
}

//=======================
// fix up   choiceList (globals)
function  choiceList_rates(rstats) {

// add this avg rate info(in rstats) to choiceList
   for (let mmid in choiceList) {
       if (!rstats.hasOwnProperty(mmid)) {   // no rates for this  (note that mmids in rstats that are not in choiceList are ignored
         choiceList[mmid]['avgRate']=0
         choiceList[mmid]['navgRate']=0
     } else {
         let arr=rstats[mmid];
         choiceList[mmid]['avgRate']=arr[0] ;
         choiceList[mmid]['navgRate']=arr[1] ;
     }
     choiceList[mmid]['allRates']={} ; // filled below
     let nRatersAll=basicStats['nRaters'];
     if (nRatersAll==0) {
       choiceList[mmid]['impRate']= 0 ;  // avoid divide by 0
     }else {
       let t1=choiceList[mmid]['avgRate']*choiceList[mmid]['navgRate'] ; // sum of rates
       let t2=(nRatersAll-choiceList[mmid]['navgRate'])*defaultRate ;
       choiceList[mmid]['impRate']=  (t1+t2)/nRatersAll ;
     }
   }     // mmid


// add everyone's rates for each choice
  for (let zuser in allRates) {
     for (let mvidR in allRates[zuser] ) {
        let zrate=allRates[zuser][mvidR];
        if (!choiceList.hasOwnProperty(mvidR)) continue ; // should never happen
        choiceList[mvidR]['allRates'][zuser]=zrate;   // only one rating per user per choice
     }
  }
  return 1;
}


//==================
// fix up allRecos and choiceList (globals)
function choiceList_recos(i1) {
  allRecos['nCurrent']={}  ;     // count of all recommenations     BY USER
  allRecos['whoRecos']={};        //    users who made recommendations : BY CHOICEID
  for (let au in  allRecos['current']) {
      let blist=allRecos['current'][au].split(',');
      let blist2={};
      for (let jj in blist) {
         let kid=blist[jj];
         blist2[kid]=jj;
         if (!allRecos['whoRecos'].hasOwnProperty(kid)) allRecos['whoRecos'][kid]=[];
         allRecos['whoRecos'][kid].push(au) ;
      }
      allRecos['current'][au]=blist2;
      allRecos['nCurrent'][au]=blist.length;
  }

  allRecos['nDraft']={}  ;             // count  of all draft recommendations     BY USER
  allRecos['whoRecosDraft']={};         //  users who made draft recommendations : BY CHOICEID
  for (let au in  allRecos['draft']) {
      let blist=allRecos['draft'][au].split(',');
      let blist2={};
      for (let jj in blist) {
         let kid=blist[jj];
         blist2[kid]=jj;
         if (!allRecos['whoRecosDraft'].hasOwnProperty(kid)) allRecos['whoRecosDraft'][kid]=[];
         allRecos['whoRecosDraft'][kid].push(au) ;
      }
      allRecos['draft'][au]=blist2;       // converted into object
      allRecos['nDraft'][au]=blist.length;
  }

  let recoUser='',recoDraft=0;        // what is being used for own recommendations
  if (allRecos['current'].hasOwnProperty(currentUserName)) {
       recoUser=currentUserName;
       recoDraft=0;
  } else {
     if (allRecos['draft'].hasOwnProperty(currentUserName)) {
       recoUser=currentUserName;
       recoDraft=1;
     }
  }

// insert own recommendations, and total recommendations, into choiceList -- for current and draft
  let myRecos= (allRecos['current'].hasOwnProperty(currentUserName)) ? allRecos['current'][currentUserName] : {} ;
  let myRecoWs= (allRecos['draft'].hasOwnProperty(currentUserName)) ? allRecos['draft'][currentUserName] : {} ;
  for (let mvid0 in choiceList) {          // over all suggestions
     choiceList[mvid0]['myReco']= (myRecos.hasOwnProperty(mvid0)) ? (1+parseInt(myRecos[mvid0])) :  0 ;
     choiceList[mvid0]['useReco']= choiceList[mvid0]['myReco'] ;    // useReco and myReco start as the same
     choiceList[mvid0]['myRecoDraft']= (myRecoWs.hasOwnProperty(mvid0)) ?  (1+ parseInt(myRecoWs[mvid0])) :  0 ;
     choiceList[mvid0]['whoRecos'] = (allRecos['whoRecos'].hasOwnProperty(mvid0)) ? allRecos['whoRecos'][mvid0] : [] ;
     choiceList[mvid0]['whoRecosDraft'] = ( allRecos['whoRecosDraft'].hasOwnProperty(mvid0)) ? allRecos['whoRecosDraft'][mvid0] : [] ;
  }

  let nRR=0;
  for (let oof in myRecos) nRR++ ;
  
  allRecos['using']=[recoUser,recoDraft,nRR] ;   // using recommendations of [0=usename,1 : 0=current, 1=draft]


  return 1;
}

//===================
// custom strings replacment -- as specified in params/choicer_params.js
// see params/choicer_params_orig.js for a description

function  doCustomReplace(xx) {
   let oof=$('[name="welcomeGroupName"]');
   for (let ioof=0;ioof<oof.length;ioof++) {
       let  aoof=$(oof[ioof]);
       aoof.html(welcomeGroupName);
   }

   let oofSite=$('[name="thisSiteName"]');
   for (let ioof=0;ioof<oofSite.length;ioof++) {
       let  aoof=$(oofSite[ioof]);
       aoof.html(thisSiteName);
   }


   let oof4=$('[name="choiceNameSay"]');
   for (let ioof=0;ioof<oof4.length;ioof++) {
       let aoof=$(oof4[ioof]);
       aoof.html(choiceNameSay);
   }

   let oof5=$('[name="choiceNameSay2"]');
   for (let ioof=0;ioof<oof5.length;ioof++) {
       let aoof=$(oof5[ioof]);
       aoof.html(choiceNameSay2);
   }

   let oof5s=$('[name="choiceNameSays"]');
   for (let ioof=0;ioof<oof5.length;ioof++) {
       let aoof=$(oof5[ioof]);
       aoof.html(choiceNameSay2);
   }

   let oof5a=$('[name="siteAdminContact"]');
   for (let ioof=0;ioof<oof5a.length;ioof++) {
       let aoof=$(oof5a[ioof]);
       aoof.html(siteAdminContact);
   }

   let oof5b=$('[name="thisSiteName"]');
   for (let ioof=0;ioof<oof5b.length;ioof++) {
       let aoof=$(oof5b[ioof]);
       aoof.html(thisSiteName);
   }

}



//================
// build user stats and save to memberInfoDiv. Uses
 // memberNameList is "active members" . 
 //     If checkValidNames=0, can be anyone who submitted something.
 //     If 1, must be in $validNames and submited somethign

function writeMemberStats(i) {

  let amess='';

  let raterStats=basicStats['raterStats'];

// basic stats
  amess+='<div id="usageStats_basic" class="cmemberInfoDivMore">';
  amess+='<table  align="center" cellpadding="4" rules="rows">';
  amess+='<caption></b>Basics</b></caption>';
  amess+='<tr><th>'+choiceNameSay+' suggestions</th></th><td>';
  amess+='<tt>'+basicStats['nSuggests']+'</tt> suggestions, from  <tt>'+basicStats['nSubmitters']+'</tt> individuals';
  amess+='<tr><th>&Rscr;atings</th></th><td>';
  amess+='<tt>'+basicStats['nChoicesRated']+'</tt> suggestions have been rated, using <tt>';
  amess+=       basicStats['nTotalRatings']+'</tt> ratings made by  <tt>'+basicStats['nRaters']+'</tt> individuals</tt></td></tr>';
  amess+='<tr><th>&real;ankings</th></th><td>';
  amess+='<tt>'+basicStats['nChoicesRanked']+'</tt> suggestions have been ranked (in the top9 or next9), using <tt>';
  amess+=     basicStats['nTotalRankings']+'</tt>  rankings from by  <tt>'+basicStats['nRankers']+'</tt> individuals</td></tr>';

  amess+='<tr><th>&#127479;ecommendations</th></th><td>';
  amess+='<tt>'+basicStats['nChoicesRecommended']+'</tt> suggestions have been recommended, using <tt>';
  amess+=     basicStats['nTotalRecommendations']+'</tt> recommendations  from by  <tt>'+basicStats['nRecommenders']+'</tt> individuals</td></tr>';
  amess+='</tr> ';

  amess+='</table>';
  amess+='</div> ' ;                               // usageStats_basic

// member stats
  amess+='<div id="usageStats_members"  class="cmemberInfoDivMore"> ';
//wsurvey.dumpObj(validNamesList,1,'vvv ');
  let bmess='';
  bmess+='<div id="iDefineMember" style="display:none;margin:2px 4em 5px 4em;background-color:#f1f2f3;padding:5px;border-radius:5px">';
  bmess+='An <em>active member</em> is someone who has contributed information. Either by making a suggestion, rating at least one suggestion, ranking, or making recommendations.';
  if (checkValidNames==1) {
     bmess+='<br>Thus: Members (even if they frequently visit) who have <b>not</b> done any of the above are <b>not</b> <em>active members!</em> ';
  } else {
     bmess+='<br>Thus: visitors (even frequent ones, even if they are included in the memberList) who have <b>not</b> done any of the above are <b>not</b> members! ';
  }
  bmess+='</div>';

   bmess+='<table  width="96%" cellpadding="5" rules="rows">';

  bmess+='<caption><em>By  '+basicStats['nMembers']+' <em>active</em> members ...</em>  ';
   if (checkValidNames==1) bmess+=' <tt>out of '+validNamesList.length+' members</tt> ' ;



//  bmess+=' <span title="# of members" style="background-color:#dfdadf">'+basicStats['nMembers'] +'</span>';
  bmess+=' <input type="button" value="?" title="What is an active member?" onClick="$(\'#iDefineMember\').toggle()"> ';

  bmess+='</caption>  ';

  bmess+='<tr><th width="15%">Who </th><th width="15%">#submissions</th><th width="15%">#ratings</th>';
  bmess+='<th width="15%">Ranking done? </th><th width="15%">Recommendations made?</th></tr>';

  for (let aname in membernameList) {
     let aname1=membernameList[aname];
     bmess+='<tr><td align="center" >'+aname+'</td>';
     bmess+='<td align="center" ><tt>'+aname1['nsuggest']+'</tt></td>';
     let ddrate=(aname1['nrate']!=0) ? '<tt> '+aname1['nrate']+'</tt>' : '<span style="color:#8e4806;weight:800"> '+ aname1['nrate']+'</span>';
     bmess+='<td align="center" >'+ddrate+'</td>';
     if (aname1['nrank']==0) {
         ddr='<span style="color:red">No</span> ' ;
     } else {
         ddr='&#10003; &#124;  '+aname1['nRankTop']+' in top9   &#124; '+aname1['nRankNext']+' in next 9' ;
     }

     bmess+='<td align="center" >'+ddr+'</td>';

     bmess+='<td align="center" >'+aname1['nrecommend']+'</td>';
     bmess+='</tr>';
  }
  bmess+='</table>';
  amess+=bmess;
   amess+='</div>';

// choice stats
  amess+='<div id="usageStats_choices" class="cmemberInfoDivMore"> ';
   amess+='<div style="margin:3px 15% 3px 15%;font-style:oblique">'+choiceNameSay+' statistics </div>';
  let cmess='';
   cmess+='<div id="myRecommendationsListDiv_compress" class="cmyRecommendationsListDiv_compress">';
   cmess+='<ul class="thinList">';
   cmess+='<li> <tt>'+basicStats['nChoicesRated']+'</tt> '+choiceNameSay2+' received at least one rating. With '+basicStats['nTotalRatings']+' ratings (over all people and choices)';
   cmess+='<li> <tt>'+basicStats['nChoicesRanked']+'</tt> received at least one top or next rank. ';
   cmess+= basicStats['nRankers']+' <em>rankers</em> submitted '+ basicStats['nTotalRankings']+' ranks covering '+basicStats['nChoicesRanked']+' unique choices';

   cmess+='<li> <tt>'+basicStats['nChoicesRecommended']+'</tt> received at least one recommendation. ';
   cmess+= basicStats['nRecommenders']+' <em>recommenders</em> submitted '+ basicStats['nTotalRecommendations']+' recomendations.  ';

   cmess+='</ul>';
   cmess+='</div>';

// category summary
   let cate1={};
   let catWho=allCategories['current'];
   let myCategories= (allCategories['all'].hasOwnProperty(catWho)) ? allCategories['all'][catWho] :  {} ;

   for (let aid in myCategories) {
       if (!choiceList.hasOwnProperty(aid)) continue ;  // probably a category assigned to removed suggestion
       let acat=jQuery.trim(myCategories[aid]);
       if (acat=='') continue;
       if (!cate1.hasOwnProperty(acat)) cate1[acat]=0;
       cate1[acat]++ ;
   }
   let catmess=[];
   for (let acat in cate1) {
     catmess.push(acat+': '+cate1[acat]);
   }

   let mmess='<div id="categorySummary" class="ccategorySummary" >';
    mmess+=catmess.length+' Categories (<em>from <tt>'+catWho+'</tt></em>). <tt>categoryName</tt>  : <tt># with this category</tt>';
    mmess+='<ul class="linearMenu22Pctb"><li>';
   mmess+=catmess.join('<li>')+'</ul>';
   mmess+='</div>';

    cmess+=mmess ;     // categories summary

// note the notRanked
    let noRankChoices=[],noRankChoiceMessages=[];
    for (let zid in choiceList) {
        let achoice=choiceList[zid];
        if (achoice['noRankThis']==1)   {
           noRankChoices.push(zid);
           let zmess=(achoice.hasOwnProperty('noRankReason')) ? achoice['noRankReason'] : 'n.a. ';
           noRankChoiceMessages[zid]=zmess;
       }
    }
    if (noRankChoices.length>0) {
      let rmess='<div class="cnoRankChoicesList">';
      rmess+=' <ul class="cnoRankChoicesListUl">';
      rmess+='<li>The following '+choiceNameSay2+' are <b>not</b>  subject to ranking!</li>';
      for (let imm=0;imm<noRankChoices.length;imm++) {
          let mvid2=noRankChoices[imm];
          mvid2Name=choiceList[mvid2]['Name'];
          tmess=noRankChoiceMessages[mvid2];
          rmess+='<li><span title="Reason for not ranking: '+wsurvey.removeAllTags(tmess)+'">';
          rmess+=mvid2Name+'</span>';
      }
      rmess+='</ul> ';
      rmess+='</div>'

// removes?
     let arf1=[];
     for (let fooid in removeChoices) {
        let arf2=removeChoices[fooid];
        arf1.push('<tt>'+arf2['Name']+'</tt> : <em> ' +arf2['removeReason']+'</em>');
     }
     if (arf1.length>0) {          // there are removes
        rmess=='<div class="cnoRankChoicesList">';
        rmess+=' The following '+choiceNameSay2+' were <b>removed</b> <em>by the admin</em>';
        rmess+=' <ul class="boxList">';
        for (let ii=0;ii<arf1.length;ii++) {
            rmess+='<li>'+arf1[ii];
        }
        rmess+='</ul>';
        rmess+='</div>'
     }


      rmess+='</div>'   //myRecommendationsListDiv_compress

      cmess+=rmess;
   }        // noRankChoices

  amess+=cmess;

//  amess+=' suggestions, etc go here ';
  amess+='</div>';

  $('#memberInfoDiv_content').html(amess);


 }


//==================
// write comments to comment container
function makeCommentsBox(commentList) {       // write all comments to general comments container


 let commentStuff='';

 commentStuff+='<div class="cRankingComments">General comments:</div>';
 commentStuff+='<ul class="cRankingCommentsUL" >';
  for (var i1=0;i1<commentList.length;i1++) {
    let cc=commentList[i1];
    let auser=cc[0],adate=cc[1],atext=cc[2];
    if (jQuery.trim(atext)=='') continue;
    let  cc2=wsurvey.parseAt(cc,':');
    commentStuff+='<li><span class="whoSuggest" title="Submitted by, on '+adate+'">'+auser+'</span>: '+atext;
  }
  commentStuff+='</ul>';

  commentStuff+='<div class="cRankingComments">Ranking comments ... (only a member`s most recently saved rankingComments are displayed)</div> ';
  commentStuff+='<ul class="cRankingCommentsUL">  ';
  let rnkComments=allRanks['comments'] ;
  for (var i1=0;i1<rnkComments.length;i1++) {
    let cc=rnkComments[i1];

    let auser=cc[0],adate=cc[1],atext=cc[2];
    if (jQuery.trim(atext)=='') continue;
    let  cc2=wsurvey.parseAt(cc,':');
    commentStuff+='<li><span class="whoSuggest" title="Submitted by, on '+adate+'">'+auser+'</span>: '+atext;
  }
  commentStuff+='</ul>';
  commentStuff+='</div>';

  commentStuff+='<div class="cRecoComments">Recommendation comments ... (only a member`s most recently saved recommendationComments are displayed)</div> ';
  commentStuff+='<ul class="cRecoCommentsUL">  ';
  let recoComments=allRecos['comments'] ;
  for (let auser in  recoComments) {
    let rcomment=recoComments[auser];
    commentStuff+='<li><span class="whoSuggest" title="Submitted by">'+auser+'</span>: '+rcomment;
  }
  commentStuff+='</ul>';
  commentStuff+='</div>';


  commentStuff+='<hr><em>end of comments </em>';

  $('#genericCommentsInner').html(commentStuff);


  return 1;
}



// ================================================================================
//=====================
// called after info retrieved from server and content written
// ido=1 : show suggestions or other such page    ,  3= show scehdule

function doOtherStartup(ido,noalerts) {
   if (arguments.length<2) noalerts=0;

  doCustomReplace(1) ;  // do custom text relacements

  enableChanges(1);          ; // allow changes -- might be disabled below

// a view / makeChanges logon

  startup_disableSugg(disableNewSuggestions)   ;   // disable adding new suggestions
  startup_disableDownloadLocal(1) ; // disable local download buttons?

// assign show in new whidow
  let emainsHelp=$('.showInNewWindow');

  emainsHelp.on('click',showInNewWindow);

  $('#helpBox_otherLinks').html(helpBox_otherLinks);  // global var: string of "other links" (customizable)  -- for basic help box

  let etrig=$('[data-dotrigger]');      // buttons that invoke other buttons
  etrig.on('click',doTrigger);


  if (noSubmitterInNotes>0) {
    let nii=$('.noteLineI');
    nii.hide();    // suppress display of member name in notes (on the viewSuggestions Page)
  }


// newUser checks (allow, allow with message, allow but no changes, do not allow)
  let qstop=doCheckNewUser(1);                // show new user alert message? .. 3 return means "members only"

  if (qstop==0 || qstop==1) {                  // existing memnber, or new users allowed to view and change
      $('.topRowButtonOther').show();
      $('.topRowButtonOther2').show();
      let suppSave= (qstop==2) ? 1 : 0 ; // 1 means hide all save buttons

 } else if (qstop==2) {                      //   new users   allowed to view ... but not change
       disableChanges(1);
       $('.topRowButtonOther').show();
       $('.topRowButtonOther2').show();
       startup_disableSugg(1,1)  ;   // no point in allowing one to try to add a new suggestion
       noChangesAllowed=true      ;   // mar 3  not used: global variable (disable any attempt to change add sugestions, rate,rank,recommend, etc

 } else {                      //   new users NOT allowed to view ... hide all the stuff you just made !

       $('.cTopRowButton').fadeOut(5);         //  hide all the stuff you just made !
       $('.topRowButtonOther').fadeOut(5);
       $('.topRowButtonOther2').fadeOut(5);  // the popup allows the user to try again (or visit some other site
 }   // new user check



  let goo= wsurvey.makeHtmlSafe(siteIntro,1) ;   //strip out bad or dangerous html
  let siteFix=goo[1];   // mgiht have become e plain text (if html errors)

  $('#siteIntroCustom').html(siteFix);

  if (isAdminUser) {     // admin -- show admin menu
    showAdminMenu(2);
  } else {
    if (qstop!=3) {         // if a new user, and no new uers allowed, don't show this

     do_showFirst(lastToDo )    ; // and then sopen  the admin settable "initial" page (enterToDo), or the last page seen prior to logoff

     if (noalerts!=1) {
       if (autoShowHelp ==1) {
         showMainHelp(2);  // show main help on logon?
       } else if (autoShowHelp>2) {
          showMainHelp(autoShowHelp) ; // fade out
       }

       if (autoShowIntro==1) {
          wsurvey.wsShow.show('#showIntroduction');
       } else if (autoShowIntro>2) {
          wsurvey.wsShow.show('#showIntroduction');
       }
     }  // noalerts
    }          // qstop 3

    if (qstop==1 || qstop==2)  {  // new user -- show a message (hello, or hello with no changes)
       if (noalerts!=1) wsurvey.wsShow.show('#inewUserMessage');

   } else if (qstop==3) {                      // new user not allwoed
       if (noalerts!=1) wsurvey.wsShow.show('#inewUserMessage');
   }

   if (noalerts!=1 && qstop!=3) {
      let qshow=doShowUserAlerts(1)   ;  // if true, status messages were displayed (so no need to check autoStatusMessages)
      if (qshow===false && autoStatusMessages>1) {
         let iauto= autoStatusMessages ;
         if (iauto==1.5)  {  // special case of 2  -- is there anything to display?
            let eUL=$('#istatusMessageUL');
            let eLI=eUL.find("li");
            if (eLI.length==0)  {
                iauto=0;
            } else {
               iauto=2;
            }
         }
         if (iauto>0 ) showStatusMessage(iauto) ;
      }       // qshot and autostats
    }          // qstop ne 3
  }           // adminuser

  startup_setHeights(1);      // record original heights of various tables (used when cycling through sizes)
                                 // and fit them to window

  return 0;          // the setup is complete  .. user interaction can begin (in particular, ask for logon name)

}

// ===========     =============================

// ===============
// disable new suggestions . THis can be due to global var disableNewSuggestions=1 being set, or a new user with
// enableNewUserCheck=2

function   startup_disableSugg(doDisable,quickStatus) {
  if (arguments.length<2) quickStatus=0;
  if (isAdminUser) return 1 ;     // admin can always add a new suggestion

  if (doDisable>0) {               // mgiht support a value of 2
    let ed1=$('#topRowButton_add');
    if (ed1.length>0)  {                    // should always be true
       ed1.prop('disabled',true);
       ed1.css({'opacity':'0.5'});
       ed1.addClass('cNewSuggestionsAreDisabled');
    }
    if (quickStatus==0) {
       writeStatusMessage('Creating new suggestions is <b>Disabled</b>',700);
    } else {
       writeStatusMessage('Creating new suggestions is <b>Disabled</b>',0);  // no displayfs
    }
  }


// Deprecated   if (doDisable==2)     writeStatusMessage('Creating new suggestions, or modifying existing ones, is <b>Disabled</b>',500);

  return 1;
}

///===========
//    disable local stream buttons?
function  startup_disableDownloadLocal(xx)  {  //

 let suppressD= suppressLocalDownload ;

 if (suppressD==0) return 1;               // do not disable
 let ee=$('[name="downloadLocalLink"]');

 if (suppressD==1)  {                      // full suppression
    ee.hide();
    return 1;
 }
// otherwise, require a keycode entry when a localDownload link is clicked

  ee.on('click',checkDownload);


// suppressD=md5 are handled by checkOk2() -- a prompt allows entry of keycode, whose md5 can be compare to suppressD


}



//-==--------------
// page to show on logon
// noSavEbuttons : if 1, hide all save buttons
function   do_showFirst(whatShow ) {

  if (arguments.length<2) noSaveButtons=0;

  closeAllContent('doShowFirst');   // close everything

//  if (doSchedule==3) {                         //1 means suggetions,etc
//     showSchedule(0);
//     return 1;
//  }

// not schedule... perhaps open a specific tab
  if (whatShow.substr(0,4)=='none') {
             // do nothing
  } else if (whatShow.substr(0,4)=='rate') {
      showRatings(2);

  } else if (whatShow.substr(0,4)=='rank') {
      showRankings(2);

  } else if (whatShow.substr(0,4)=='reco') {
     showRecommendations(2);

  } else if (whatShow.substr(0,4)=='comm') {
      showComments(2);

  } else if (whatShow.substr(0,4)=='sugg' || whatShow.substr(0,4)=='view') {
      showCurrentSuggestions(2);

  } else if (whatShow.substr(0,3)=='new') {
      showNewSuggestions(2);

  } else if (whatShow.substr(0,4)=='sche') {
      showSchedule(2);

   } else {                                  // default is to show suggestions
      showCurrentSuggestions(2);
   }

   return 1;

 }

//========
// set original heights of various content containing divs (such as outer containers of view suggestion table)
// save to document.data

//object(6): {
// example of heights measures
//   viewSugg:  number: 450
//   rate:  number: 450
//   rankingChosen:  number: 126
//   rankingList:  number: 450
//   recoChosen:  number: 126
//   recoList:  number: 450

function startup_setHeights(ii) {

   let heights={};

   let eview=$('#existingEntriesDivTableOuter');
     heights['viewSugg']=parseInt(eview.height());

   let erate=$('#ratingsDivTableOuter');
     heights['rate']=parseInt(erate.height());

   let erankChosen=$('#myRankingsListDiv');
     heights['rankingChosen']=parseInt(erankChosen.height());

   let erankList=$('#rankingsDivTableOuter');
     heights['rankingList']=parseInt(erankList.height());

   let erecoChosen=$('#myRecommendationsListDiv');
     heights['recoChosen']=parseInt(erecoChosen.height());

   let erecoList=$('#theRecommendationsTableOuter');
     heights['recoList']=parseInt(erecoList.height());

   $(document).data('contentHeights',heights);

   return 1;
 
}






