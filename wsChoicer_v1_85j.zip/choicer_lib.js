// misc js functions used by choicer (not specific to a single page)

//========================
// extract a column from choiceList.
// return object with [choiceId]=columnVal
// if avar is not a property of choiceList[choiceId], use defval (default = false)
// Note: will be returned in  choiceArray order (the order displayed in the viewSuggestions table
// avar must be exact (case-sensitive) name of a proprty of choiceList[choideId]
// avar="#" is special -- it means return the row number (basically, the inverse of choiceArray
// avar="=" is special -- it means use the defval for all values (i.e. ('=',3)  would use 3 for all values)

function extractFromChoiceList(avar,defval) {
  if (arguments.length<2) defval=false;
  avar=jQuery.trim(avar);
  let gotVals={};
  let avalSet=false ;
  for (let ij1 in choiceArray) {
    let aid=choiceArray[ij1 ];
    let asugg=choiceList[aid] ;

// special cases
    if (avar=='#') {
       gotVals[aid]=ij1;
       continue;
    }
    if (avar=='=') {
        gotVals[aid]=defval;
        continue;
    }

// else, get [avar], if it exists
    if (!asugg.hasOwnProperty(avar)) {
       gotVals[aid]=defval;
       continue;
    }
    gotVals[aid]=asugg[avar];
    
  }
  return gotVals;
}


//=======================
// create a span with tranche level and appropriate css class, given choiceId (uses choiceList global)
// mvid: id of choice (must have entry in choiceList
// prec : precision of summary_rank shown (default =2)
// showTranches. array, with indices between 0 and 7, of classes to use. If not specified, or '', use dfeault
// naSay : string to return if choiceList does not have mvid  Default= '&empty;';
// Note use of showTheseRanks as  class. It can be used for "page specific" event handlers
// (so even if different "pages" use this function, the resulting elements can be uniquely identified)

function make_summary_rank_span(mvid,prec,showTranches,naSay) {
   if (arguments.length<2) prec=2 ;
   if (arguments.length<3) showTranches=false ;
   if (arguments.length<4) naSay='&empty;' ;
   
   if (showTranches===false || showTranches==0 || showTranches==''  ||!jQuery.isArray(showTranches) ) {
      showTranches=['','cTranche1','cTranche2','cTranche3','cTranche4','cTranche56','cTranche56','cTranche7'];
   }

   if (!choiceList.hasOwnProperty(mvid)) return naSay ;   // should never happen

   if (!jQuery.isNumeric(prec)) prec=2;
   prec=parseInt(prec);

   let asugg=choiceList[mvid];
   let smrank0=(asugg.hasOwnProperty('summary_rank')) ? asugg['summary_rank'] : 7 ;  // 7 means "no top9 or next9 rankings
   let ismrank=parseInt(smrank0);
   if (prec==0) {
      smrank=ismrank;
   } else {
     smrank=limitDecimalsWithoutRounding(smrank0,prec);
   }
 
   let nRankersThis=asugg['ntopRank']+ asugg['nnextRank']  ;
   let smrankSay='<span class="'+showTranches[ismrank]+' showTheseRanks">'+smrank+'</span>';
   let spanRscore='<span  class="showTheseRanks" title="from: '+nRankersThis+' rankings " style="color:#6a6861;">'+smrankSay+'</span>';
   return spanRscore ;
}

// toFixed without rounding
//https://stackoverflow.com/questions/4187146/truncate-number-to-two-decimal-places-without-rounding
function limitDecimalsWithoutRounding(val, decimals){
    let parts = val.toString().split(".");
    if (parts.length==1) return val.toFixed(1);
    return parseFloat(parts[0] + "." + parts[1].substring(0, decimals));
}

//=============
// move this row (that contains a clicked on event) toward center of div?
function centerAtRow(athis,aopts) {
  let aopts0=aopts;
  if (arguments.length<2) aopts0={'duration':3300};
    let ethis=$(athis);
    let ethis1=ethis.closest('tr');
   let arf= wsurvey.centerInParent(ethis1,aopts);
   return 1
}

//=============
// replace all " , ' characters  with ' '
// nospaces: 1=remove all internal spaces (and breaks), 2=multiple spaces replace with 1 space, otherwise no space messing with
function fixString(astring,nospaces) {
   let bstring=jQuery.trim(astring);
   bstring=bstring.replace(/"|'|,/g," ");
   if (nospaces==1) bstring= bstring.replace(/\s+/g,"");
   if (nospaces==2) bstring= bstring.replace(/\s+/g," ");
   return jQuery.trim(bstring);

}


//============
// save a status message (to list of status messages)
//  amessage: the message
//  ishow:  if >0, showStatusMessage is called after adding amessage
//            1 or 2 = toggle show status messages,
//            >2 = show and then  fadeout (milliseconds)
// onlyOnce: if 1, then this message is only shown if it is most  recent.
//              After the next message is written, this will be not shown
// justThis     if 0/1: if ishow>0 then immediately  show ONLY this message. If show=0, this has no effect

function writeStatusMessage(amessage,ishow,onlyOnce,justThis) {
   if (arguments.length<2) ishow=0;
   if (arguments.length<3) onlyOnce=0;
   if (arguments.length<4) justThis=0;

    let nowtime=wsurvey.get_currentTime() ;
   let a1={'message':amessage,'onlyOnce':onlyOnce,'time':nowtime};
   statusMessageList.push(a1)
   if (ishow==1) ishow=2 ; // don't toggle (just show)
   if (ishow>0) showStatusMessage(ishow,justThis) ;

}




 //================
// create a string with a div of a choice's descriptive notes
// mvid : the choiceId (in choiceList) containing the notes
// to use
// useDiv : place around the string. If not specified, a default is used.
//          if false (or ''), string returned as is
//          if true (logical true), use the default
//          If specified, a </div> is ALWAYS added at the end of the string
// noContent: use this string if there are no notes (either firstNote, or later descNotes)
// noName : if 1 (or true), do NOT display choiceName above the notes. Default is false (derfault is to DISPLAY the choice name)
//  The default is:     '<div class="cGetDescNotes"  >';


function  getDescNotes(mvid,useDiv,noContent,noName) {

  if (arguments.length<2 || useDiv===true) useDiv='<div class="cGetDescNotes"  >';
  if (arguments.length<3) noContent='';
  if (arguments.length<4 ) noName=false;
  if (noName!==false &&  jQuery.trim(noName)=='1'  ) noName=true;

  if (jQuery.trim(useDiv)=='') useDiv=false;

  let gline=choiceList[mvid];
  let choiceName=gline['Name'];
  let firstNote=jQuery.trim(gline['Notes']);
  let danotes=gline['descNotes'];
  let descNotes=[];
  for (let ifoo=0;ifoo<danotes.length;ifoo++) descNotes.push(danotes[ifoo]);  // clone it
  if (firstNote!='') {
    let arf=[firstNote,gline['submitBy']] ;
    descNotes.unshift(arf);
  }

  let stuffOuter=(useDiv===false) ?  '' : useDiv ;
  let stuff0=''

  if (noName!==true) stuff0='<span class="cGetDescNote_name" title="'+choiceNameSay+' descriptive notes">'+choiceName+'</span>';
  if (descNotes.length==0) {
     stuff0+=noContent;
  } else {
     stuff0+='<ul style="margin:2px 2px 2px -8px ;list-style-type:none">';
     for (let ii=0 ; ii<descNotes.length;ii++) {
         let goo=descNotes[ii];
         let goo1='<span class="noteLineI" data-goo="getDescNotes" >From '+goo[1]+'</span> ';
         stuff0+='<li  class="myRankingsListDiv_notesLi"  >'+goo1+' '+goo[0]+'</li>'  ;
    }
    stuff0+='</ul>';
  }
  if (useDiv!==false) {
     stuff0=useDiv+stuff0+'</div>';
  }

  return stuff0 ;
}


//=======
// create html of links/infoBLurbs  for a choiceId
// note use of linkIcons global
// nolinks=1 means "just img and descsription, no <a> ..</a>
//      2: just the info links  <a> and <img> only , 3: just the info blurbs
// noneSPecified: text string to display if no links were specified. Default is 'none specified'

 function getlinkNotes(aid,nolinks,noneSpecified ) {

   if (arguments.length<2) nolinks=0;
   if (arguments.length<3) noneSpecified='none specified';

  if (!choiceList.hasOwnProperty(aid))  return 'n.a.';   // should never happen
  let asugg=choiceList[aid] ;

  if(!asugg.hasOwnProperty('linkNotes')) return 'n.a. '; // should never happen

  let listNotes1=asugg['linkNotes'];   ;
//    wsurvey.dumpObj(listNotes1,1,'lihnkssk');
  let nlinks=listNotes1.length;
  if (nlinks==0) return noneSpecified ;
  let vvmess='';
  for (let ivv=0;ivv<nlinks;ivv++) {
     let av1=listNotes1[ivv];
     let av1Text=jQuery.trim(av1[0]);
     let av1Who=av1[1];

    if (nolinks<2) vvmess+='<div   class="linksLine2" style="display:block" title="From: '+av1Who+'">';

// boo1 (for each link/blurb);
//   If a link: [0] <a>...,  [1] <img , [2] target for <a> .. </a>
//   If a blurb : [0] <span> with blurb icon  , [1] '', [2] Test for <span> </span>
     let boo1=makeIconFromLink(av1Text,ivv);


// return a subset?
     if (nolinks ==2) {        // lijnks only <a><img></a>
         if (boo1[1]=='') continue;
         vvmess+=boo1[0]+boo1[1]+'</a>'+"\n";
         continue;
     }
     if (nolinks ==3  ) {      // blurbs only
         if (boo1[1]!=='') continue ;
         vvmess+='<div title="from: '+av1Who+'">'+boo1[0]+boo1[2]+"</div>\n" ;
         continue ;
     }

// nolinks<2 return all of them (noLink controls what is included)
     vvmess+='<span   style="color:brown ">'+av1Who+'</span> '    ;

     if (boo1[1]=='')  {  // blurb   -- bubble icon: text (never a <a>.</a>
        vvmess+=boo1[0]+boo1[2]+'</div>'+"\n    ";
     } else {
        if (nolinks==1) {   // no link -- image and text only
          vvmess+= boo1[1]+  boo1[2]+'</div>'+"\n    ";
        } else {
          vvmess+=boo1[0]+boo1[1]+'</a>'+boo1[2]+' </div>'+"\n   ";
        }
     }         // boo1[1]

  }      // for
  return vvmess;
}

///=====================
// return the "currently active" list of recommendations
// returns  {'submitter':recoSubmitter,'list':recoList,'lookup':recoList}
//   submitter : memberName (who created this list of recommendations)
//   list : array containing list of recommenations :  values are choiceIds. Order is in descending qualiyt (1 is best)
//   lookup : object whose properties are choiceIds  : values are quality (0 is best) -- and pointer to location in list
// If no currently active list, submmiter===false, recoList=[], lookup={}
// Note:  ifoo not currently used

function get_currentRecos(ifoo) {

   let recoList=[],recoLookup={},recoUser=false ;

   let recoUse={'submitter':recoUser,'lookup':recoLookup,'list':recoList};

  let rUsing=allRecos['using'];

   if (rUsing[2]==0) return  recoUse ;

   let awhich = (rUsing[1]==0)  ? 'current' : 'draft';
   let auser=rUsing[0];
   recoLookup=allRecos[awhich][auser];
   for (let aaid in recoLookup) {       // make an array
       let ii=recoLookup[aaid];
       recoList[ii]=aaid;
   }
   recoUse['submitter']=auser;  ;
   recoUse['lookup']=recoLookup ;
   recoUse['list']=recoList   ;
   return recoUse ;

}

//
// =====================
// create a <a> <img></a> from a "link or blurb" text
// or just crate a link (or a span)
// returns [img (with or without <a>..</a>, true or false] true if link, false if blurb
// ivv used for click handler on spans (to find and display the text of this blurb)

function makeIconFromLink(av1Text,ivv) {

   if (arguments.length<2) imgOnly=false ;

// add to the  buttons list (prepended afater this loop ends)
   if (av1Text.substr(0,1)!='@')   {    // might be a @key@xxx spec
       let n10=av1Text.substr(0,10);
       let sayLink='<span title="information blurb:'+n10+'" class="showBlurb" data-which="'+ivv+'">&#128172;</span>';
       return [sayLink,'',av1Text] ;  // just a blurb, so no <a>
   }

// a link speci
   let nextat=av1Text.indexOf('@',1);
   if (nextat<0) return false                    // misspecified

   let useimg='';
   let daword=jQuery.trim(av1Text.substr(1,nextat-1));
   if (daword=='') daword='download' ;   // @@ is a shortcut for @download@
   if (daword=='download') daword='downloadlocal' ;  // not same as downloadword or download_other
   if (linkIcons.hasOwnProperty(daword)) {
          useimg=linkIcons[daword];
   } else {                            // if no match (shouldn't happen)
          useimg='imgs/download_other.gif';
   }


   let daurl=av1Text.substr(nextat+1);
   let islash=daurl.lastIndexOf('/');
   let useName=daurl.substr(islash+1);
   let ahref,aimg;

   if (daword=='downloadlocal') {
      let useLink=privateDownloadLink+daurl;
      ahref=' <a  name="downloadLocalLink" href="'+useLink+'" target="download" title="retrieve from this site`s server (if available):  '+useName+'">';
      aimg=' <img src="'+useimg+'" width="30" height="20" alt="download link">';
   } else  if (daword=='wwwlink') {
      ahref=' <a href="'+daurl+'" title="retrieve from web: '+useName+'" target="retrieve">';
      aimg='<img src="'+useimg+'"  width="30" height="20"  alt="www link">';
   } else   {       // not use of no match (so always a useimg
      ahref=' <a href="'+daurl+'" title="retrieve: '+useName+'" target="retrieve">';
      aimg='<img src="'+useimg+'"  width="30" height="20"  alt="Retrieve ...">';
    }           // flavors of @xx@
     return [ahref,aimg,useName] ;
}

// ========
// write a string   to "notes" small-box inside a container box
// Note: the defaults (args 3 and beyond) assume writing to rankings Page
//
// anId: the "id" of this string (used to determine if this is a double click)
//       If anId=false, skip these checks (and don't update noteBox to indicate what is being displayed)
// astring: string to write
// emt: jquery object of the container that contains the note box  -- it will be scrolled
// emm : jquery object of the note box within the container   -- where to write aNote
// noShowClass : class to add when not showing (double click), remove when showing.  If false or '', don't bother
// showClass: class to add when showing (remove when not showing). If false of '', don't bother
//  duration: duration of scroll. Default is 300 (milliseconds).
// Note: use true (logical true) in emt,emm,noShowClass,  showClass, or duration to use defaults
//
// Special case: if aNote=false (logical false)
//    if anId matches the current id -- scroll to top of currentRankings container, and return true
//    if not a match, return false
//    In either case, do NOT clear the notebox
//               This is a useful way of avoiding building content if it won't be written

function writeToNotesBox(anId,aNote,emt,emm,noShowClass,showClass,duration) {
  if (arguments.length<3 || emt===true) emt= $('#myRankingsListDiv');     // the currentRankings continaer
  if (arguments.length<4 || emm===true) emm =$('#viewNotes_rankList');   // notes box inside of currentRankings container
  if (arguments.length<5 || noShowClass===true)  noShowClass='cviewNotes_rankList0';
  if (arguments.length<6 || showClass===true)  showClass='cviewNotes_rankList0';
  if (arguments.length<7 || duration===true)  duration=300;

  if (noShowClass===false || jQuery.trim(noShowClass)=='') noShowClass=false;
  if (showClass===false  || jQuery.trim(showClass)=='') showClass=false;
  if (!jQuery.isNumeric(duration)) duration =300;
  if (duration<0) duration=0;

 let anIdShowing ;
  if (anId!==false) anIdShowing=emm.attr('data-usingid');    // the choiceid now being displayed in this notes box

// special case. if anId=false, unpredictable what will happen
   if (aNote===false)   {
     if (anIdShowing==anId) {       // next click would clear
         emt.animate({'scrollTop':'0px'},duration);    // scroll list-=of=rankings to its top
         return true ;
     } else {
        return false ;
     }
   }

// not a special case

   if (anId!==false && anIdShowing==anId) {       // a double click (no suppression of checking) ?
      emm.html(' ');               //   clear notes box at bottom of list-of-rankings-container
      emm.attr('data-usingid',0);  //   note box is not empty
      if (noShowClass!==false) emm.addClass(noShowClass);   // use noView-this class
      if (showClass!==false) emm.removeClass(showClass);   // get rid of  view-this class
      emt.animate({'scrollTop':'0px'},duration);    // scroll list-=of=rankings to its top
      return 0;
    }

  if (anId!==false)  emm.attr('data-usingid',anId);       // flag that this choiceid is now being displayed

  emm.html(aNote);                 // write to notes box!

  if (noShowClass!==false) emm.removeClass(noShowClass);   // remove noView this class
  if (showClass!==false) emm.addClass(showClass);   // add viewThis class

  let e2h=parseInt(emt.prop('scrollHeight'));    // scroll container to more or less top of notes box
  let e1h=parseInt(emm.prop('scrollHeight'));
  let ido=e2h-e1h;
  emt.animate({'scrollTop':ido+'px'},duration);

  return 1;
}



//=================
// Event handler (possibly inline) for a "trigger some other button"
// uses the data-dotrigger attribute to specify what elment to trigger.
// Thus, data-dotrigger must be a valid jQUery selector string (such as '#mymainButton')
// 2nd arg could be used to specify other event (for example, 'change')

function doTrigger(evt,anevent) {
   if (arguments.length<2 || anevent===false || anevent==0) anevent='click';
   let etarget=wsurvey.argJquery(evt);
   let awhere=etarget.wsurvey_attrCi('data-dotrigger',false);
   if (awhere===false) {
      alert('doTrigger error: no data-dotrigger attribute. '+etarget.prop('outerHTML'));
      return 0;
   }
   let ewhere=$(awhere);
   if (ewhere.length==0) {
      alert('doTrigger error: no data-dotrigger does not yield a jQuery object:  '+awhere);
      return 0;
   }
   ewhere.trigger('click');
   return 1;
}

//--------------------
// close all top level content
function closeAllContent(asay) {
//  writeStatusMessage('closeallContent '+asay);  // enable for debugging

  let ehelps=$('[data-helpbox]');
    ehelps.hide();
  let einfos=$('[data-infobox]');
    einfos.hide();
  let emains=$('[name="mainContainer"]');
    emains.hide();
  let eothers=$('[data-otherbox]');
     eothers.hide();
  let eadmin=$('#myScheduleAdmin_alert');
  eadmin.html('').hide();
  
 $('#topRowButton_admin').hide();


  return 1;
}

//==============
// suppress all save buttons
function disableChanges(ii) {

      let ed1=$('#topRowButton_add');
       ed1.prop('disabled',true);
       ed1.css({'opacity':'0.5'});
       ed1.addClass('cNewSuggestionsAreDisabled');

       ed1.prop('disabled',true);
       ed1.css({'opacity':'0.5'});
       ed1.addClass('cNewSuggestionsAreDisabled');
       $('#isaveRateButton').prop('disabled',true);
       $('#isaveRateButton').addClass('cAllChangesDisbled') ;
       $('#isaveMyRankings').prop('disabled',true);
       $('#isaveMyRankings').addClass('cAllChangesDisbled')  ;
       $('#isaveMyRankings2').prop('disabled',true);
       $('#isaveMyRankings2').addClass('cAllChangesDisbled')  ;
       $('#iSaveRecommendationsButton').prop('disabled',true);
       $('#iSaveRecommendationsButton').addClass('cAllChangesDisbled') ;
       $('#iSaveRecommendationsButton2').prop('disabled',true);
       $('#iSaveRecommendationsButton2').addClass('cAllChangesDisbled') ;
       $('#iaddGeneralComments').prop('disabled',true);
       $('#iaddGeneralComments').addClass('cAllChangesDisbled') ;

  return 1;
}

//==============
// suppress all save buttons
function enableChanges(ii) {

        let ed1=$('#topRowButton_add');
         ed1.prop('disabled',false);
         ed1.css({'opacity':'1.0'});
         ed1.removeClass('cNewSuggestionsAreDisabled');
         
       $('#isaveRateButton').prop('disabled',false);
       $('#isaveRateButton').removeClass('cAllChangesDisbled') ;
       $('#isaveMyRankings').prop('disabled',false);
       $('#isaveMyRankings').removeClass('cAllChangesDisbled')  ;
       $('#isaveMyRankings2').prop('disabled',false);
       $('#isaveMyRankings2').removeClass('cAllChangesDisbled')  ;
       $('#iSaveRecommendationsButton').prop('disabled',false);
       $('#iSaveRecommendationsButton').removeClass('cAllChangesDisbled') ;
       $('#iSaveRecommendationsButton2').prop('disabled',false);
       $('#iSaveRecommendationsButton2').removeClass('cAllChangesDisbled') ;
       $('#iaddGeneralComments').prop('disabled',false);
       $('#iaddGeneralComments').removeClass('cAllChangesDisbled') ;
 
  return 1;
}

//========================
// display content in a new window
 //====================
function showInNewWindow(evt) {
  let etarget=wsurvey.argJquery(evt);
  let ahdr=etarget.attr('data-in_new_window_header');
  let awhere=etarget.attr('data-in_new_window_find');
  let awheres=awhere.split(',');

  for (let aw in awheres) {        // check for validity
     let awhere1=awheres[aw];
     let eget=$(awhere1);
     if (eget.length!=1) {
      alert('Unable to find (one-element) using: '+awhere1);
      return 0;
     }
  }
  let dd1=wsurvey.get_currentTime(31,1);

  let adiv='<div style="font-size:120%;padding:5px;margin:2px 3em 1em 3em; background-color:#dbf6f2;">';
  adiv+='<tt>'+dd1+'</tt>.  Current user: <u>'+currentUserName+'</u> : '+ahdr;
  adiv+='</div>';

  let acontent='';
  for (let aw in awheres) {
     let awhere1=awheres[aw];
     let eget=$(awhere1);
     let stuff1=eget.html();
     acontent+='<div title="from: '+awhere1+'" style="border:1px solid lightblue;padding:1em;margin:5px 1em 5px 1em">';
     acontent+=stuff1;
     acontent+='</div>';
  }

  let opts={} ;
  opts['content']=acontent;
  opts['header']=adiv;
  opts['title']='Info on suggestions';
  opts['name']='viewer';
  wsurvey.displayInNewWindow(awhere,opts);
}


//=====================
// find the choiceId of suggestion being displayed in the report box
// and find next or prior (in the table) -- using     $(document).data('showingMain )  [eUse,todoName,viewmode];
function viewTable_vuReport(athis,idire) {
   nowTable=$(document).data('showingMain');
   let etarget=wsurvey.argJquery(athis);
   let arf1=etarget.closest('[data-which]');
   let mvid=arf1.attr('data-which');

   let etable=etarget.closest('[name="mainContainer"]');
   let etr=etable.find('[data-choiceid="'+mvid+'"]');
   let etr0;
   if (idire==-1) {
     etr0=etr.prev();
   } else {
     etr0=etr.next();
   }

   if (etr0.length==0) return 1 ;// at beginning or end
   let erb=etr0.find('.toggleNotesHeaderButton');
   if (erb.length==1) erb.trigger('click')  ; // click the button to show the report

}

// ========================
// display a "choice report" -- all info in choiceList -- for a given choiceId
function displayChoiceReport(mvid,atable) {
  let etable=wsurvey.argJquery(atable);      // table could be a valid jQuery selector string

//  alert('atttt '+atable);
  if (etable.length!=1) {
     alert('displayChoiceReport error: no such table: '+atable);
     return 0;
  }

  let asugg=(choiceList.hasOwnProperty(mvid)) ? choiceList[mvid] : false ;
  if (asugg===false) {
     alert('displayChoiceReport error: no such choiceId: '+mvid);
     return false ;
  }

  let epopup=$('#choiceReport');           // same fixed div (child of body) used regardless of page (view,rate,rank,reco)
  let currentId=epopup.data('currentId');
  let currentTable=epopup.data('currentTable');
  if (currentId==mvid && currentTable==atable) {
          epopup.data('currentId','');
          epopup.data('currentTable','');
          return 1;
  }

  epopup.data('currentId', mvid );
  epopup.data('currentTable',atable);

  let ahdr=' <span title="Id: '+asugg['ID']+'">'+asugg['Name']+'</span> ';
  $('#choiceReport_name').html(ahdr);

 let areport=displayChoiceReport_build(mvid);   // uses choiceList


 $('#choiceReport_content').html(areport);

// keep open -- closing is done above
   wsurvey.wsShow.show('#choiceReport',2);

//  epopup.show();      // show the parent of _name and _content
  epopup.animate({'scrollTop':'0px'},122);

 return 1;
}

//======================
// create a report on all the infromation in choiceList, about this choice (mvid)
function displayChoiceReport_build(mvid) {
  asugg=choiceList[mvid];

  let descnotes='',linkNotes='';
  let amess='';
  amess+='<table xrules="rows" style="width:96%" border="1" cellpadding="4" style="width:95%">';

  let a1='...';
  let a2='';

  a2+='<span class="whoSuggest"><em>Submitted by:</em>:<tt> '+asugg['submitBy']+'</tt></span>';

  a2+='<span class="report_category">';

  let acat=(jQuery.trim(asugg['Category'])=='') ? '&empty;' : asugg['Category']   ;
  let aown=(jQuery.trim(asugg['OwnCategory'])=='') ? '&empty;' : asugg['OwnCategory']  ;

  a2+='<span class="report_categoryUse" title="using this category (the retrieved category)"><em>Category</em>:<tt> '+acat+'</tt></span>';
  a2+='<span class="report_categoryOwn"><em>Own category</em>:<tt> '+aown+'</tt></span>';
  a2+='</span>';

  let note1=asugg['Notes'];
  a2+='<span title="short note" class="report_firstNote">'+note1+'</span>';

  amess+='<tr><th width="18%">'+a1+'</th><td width="85%">'+a2+'</td></tr>' ;

  a1='customVars';
  let goon={'required':[],'other':[]  };
  for (let cvar in customVarList ) {          // [length,required,desc]
    let cvals=customVarList[cvar];
     let kval=[cvar,cvals[2]];

     if (cvals[1]==1 || cvals[1]==11) {
         goon['required'].push(kval);
     } else {
         goon['other'].push(kval);
     }
   }
   a2='';
   if (goon['required'].length>0) {
      for (let ig=0;ig<goon['required'].length;ig++) {
          agoon=goon['required'][ig];
          let ccvar=agoon[0];
          let aspan='<li><span title="required custom var"  ><u>'+ccvar+'</u>: <tt>'+asugg[ccvar]+'</tt></span> ';
          a2+=aspan;
      }
   }
   if (goon['other'].length>0) {
      for (let ig=0;ig<goon['other'].length;ig++) {
          agoon=goon['other'][ig];
          let ccvar=agoon[0];
          let aspan='<li><span  title="optional custom var"  ><u>'+ccvar+'</u>: <tt>'+asugg[ccvar]+'</tt></span> ';
          a2+=aspan;
      }
   }
   amess+='<tr><th >'+a1+'</th><td><ul class="linearMenu16Pct">'+a2+'</ul></td></tr>' ;

   let showTranches=['','cTranche1','cTranche2','cTranche3','cTranche4','cTranche56','cTranche56','cTranche7'];

   a1='Your scores';
   let myrate0=asugg['Rate'];
   let myrate='<span class="'+rateClass[myrate0]+'" title="'+rateSays[myrate0]+'">'+rateIcons[myrate0]+'</span>';

   let myrank0=asugg['myRank'] ;
   let myrank='<span class="'+rankClass[myrank0]+'" title="'+rankSays[myrank0]+'">'+rankIcons[myrank0]+'</span>';
   let myreco0=asugg['myReco'];
   let myreco= (myreco0==0) ?  '&hellip;' : myreco0;
   let usereco0=asugg['useReco'];
   let usereco= (usereco0==0) ? '&hellip;' : usereco0;
   a2= '<li><b>Rate: </b> '+myrate;
   a2+= '<li><b>Rank: </b> '+myrank;
   a2+= '<li><b>Recommend: </b> <span class="creco_numRecos2" title="The currently used (retrieved) recommendation">'+usereco+'</span>';
   a2+= '  <span class="report_ownreco creco_numRecos2a" title="Your recommendation">'+myreco+'</span>' ;

   amess+='<tr><th >'+a1+'</th><td><ul class="linearMenu16Pct">'+a2+'</ul></td></tr>' ;

   a1='Summary scores ';

   a2='<li><b>avgRate</b>= <tt>'+asugg['avgRate'].toFixed(2)+ '</tt> <span title="# of ratings for this suggestion" class="report_navgrate">'+asugg['navgRate']+'</span>';
   a2+='<li><b>adjAvgRate</b>= <tt>'+asugg['impRate'].toFixed(2)+'</tt>' ;

   let norank=asugg['noRankThis'];
   if (norank==0) {
      let sumRank0=parseInt(asugg['summary_rank']);
       let sumRank='<span title="the summary_rank (1 is best, 7 worst)" class="'+showTranches[sumRank0]+'">'+sumRank0+'</span> ';
       a2+='<li><span class="report_summaryRankSay">summaryRank</span> = '+sumRank ;
   } else {
      let norankMess=asugg['noRankReason'];
      a2+='<li>&#128721; <b>not</b> ranked</span>';
   }
   amess+='<tr><th >'+a1+'</th><td><ul class="linearMenu16Pct">'+a2+'</ul></td></tr>' ;

   a1='Rate details';
   a2='';
   for (let awho in  asugg['allRates']) {
     let arate0=asugg['allRates'][awho];
     let arate='<span class="'+rateClass[myrate0]+'" title="'+rateSays[myrate0]+'">'+rateIcons[myrate0]+'</span>';
     a2+='<li><span class="report_rateDetailWho">'+awho+'</span>: <span class="report_rateDetailVal">'+arate+'</span>';
   }

   amess+='<tr><th >'+a1+'</th><td><ul class="linearMenu16Pct">'+a2+'</ul></td></tr>' ;

   a1='Rank details  ';
   if (norank==1) {

      a2='&#9940; <b>not</b> ranked: <span class="report_norankMessage"> '+asugg['noRankReason']+'</span>';
   } else {
      let nbothRank='<span title="# of top9 + next9 ranks" class="report_nbothranks">'+asugg['nbothRank']+'</span>';
      a1+=nbothRank;

      a2='<ul  class="linearMenu16Pct" title="Who ranked this in top9">';
      a2+='<li class="report_rankDetails1"> <span class="'+rankClass[1]+'" title="'+rankSays[1]+'">'+rankIcons[1]+'</span>';
      a2+='';
      for (let ir1=1; ir1<asugg['topRank'].length;ir1++) {
       awho=asugg['topRank'][ir1];
       a2+='<li><span class="report_rateDetailWho">'+awho+'</span> '
      }
      a2+='</ul>'
      a2+='<ul class="linearMenu16Pct" title="Who ranked this in next9">';
      a2+='<li class="report_rankDetails1"> <span class="'+rankClass[2]+'" title="'+rankSays[2]+'">'+rankIcons[2]+'</span>';
      a2+='';
      for (let ir1=1; ir1<asugg['nextRank'].length;ir1++) {
        awho=asugg['nextRank'][ir1];
        a2+='<li><span class="report_rateDetailWho">'+awho+'</span> '
      }
      a2+'</ul>'
   }     //norank

   amess+='<tr name="rankDetailsRow"><th >'+a1+'</th><td><ul class="linearMenu16Pct">'+a2+'</ul></td></tr>' ;

   a1='Recommenders';
   a2='';
   for (let ir2=0;ir2<asugg['whoRecos'].length;ir2++) {
       let awho=asugg['whoRecos'][ir2];
       a2+='<li><span class="report_rateDetailWho">'+awho+'</span>' ;
   }
   amess+='<tr><th >'+a1+'</th><td><ul class="linearMenu16Pct">'+a2+'</ul></td></tr>' ;

   descNotes=getDescNotes(mvid,true,'none specified',true);
//   descNotes=getDescNotes(mvid ) ;
   linkNotes=getlinkNotes(mvid,1) ;
   amess+='<tr><th>Descriptive notes</th><td>'+descNotes+'</td></tr>';
   amess+='<tr><th>Link &amp; blurbs</th><td>'+linkNotes+'</td></tr>';

   amess+='</table>';

   return amess ;

}


// ===
// display report of the ext or prior ... given where the current choiceId is being displayed.
// Thus, sort of the table WILL determine what is next and what is prior
// If the next is after the last tr (given current sort), or prior is before the first row -- nothing happens
// (for now, we do NOT cycle   to top or bottom)

function choiceReport_next(athis,idire) {
  let epopup=$('#choiceReport');           // same fixed div (child of body) used regardless of page (view,rate,rank,reco)
  let currentId=epopup.data('currentId');
  let currentTable=epopup.data('currentTable');
  let etr ;
   if (currentTable!='#scheduleDivTable') {
       let etable=$(currentTable);
       etr=etable.find('[data-choiceid="'+currentId+'"]');
   } else {
       let etable=$('#scheduleListDiv');
       let eb=etable.find('[name="nschedule_recoList"]');
       let ec=eb.find('[data-mvid="'+currentId+'"]');
       etr=ec.closest('li');
   }
   if (etr.length==0) return 1 ;// at beginning or end

   let etr0;
   for (let foo=1;foo>0;foo++) {  // do forever -- to skip breaks and empty rows
     if (idire==-1) {
        etr0=etr.prev();
     } else {
        etr0=etr.next();
     }
     if (etr0.length==0) return 1 ;// at beginning or end
     let nowid ;
     if (currentTable!='#scheduleDivTable') {
        nowid=etr0.attr('data-choiceid');
        if (nowid<=0) {
           etr=etr0;
           continue ;       // break or empty row
        }
     } else {
         let ec=etr0.find('[data-mvid]');
         nowid=ec.attr('data-mvid');
         if (nowid<=0){
            etr=etr0;
            continue ;       // break or empty row
         }
      }

     if (typeof(nowid)=='undefined') return 0;   // at beginning (prior is the header row)

     q=displayChoiceReport(nowid,currentTable) ;
     if (q===false) return 0                          // other error
     return 1;
  }        // forever loop

}


//================
// submit data to a form, using either post or get. NOT AJAX -- so opens in this window
// this creates a form on the fly, populates its attributes and creates hidden elements, and then submits (return to a target if specified)
//http://stackoverflow.com/questions/5524045/jquery-non-ajax-post
// input should be an object of 'varname':value elements
// If arrays are to used as values, they should first be 'varname':JSON.stringify(avar);
// and on the php end, use json_decode($_REQUEST['varname'],1);

 function submitQuickForm(action, method, input,target) {
    "use strict";
    var form;

    if (arguments.length<4) target="_self";
// attachments | standalone | MAIL_MERGE | afrom | aacct | asubject | acontent | isforward | hcontent | hcontentMedium |
// _useaccts_ | acontentOrig | atocc | ato | areplyall | #replyDateUse | messageid | _decode_ | message |
// username | isforward_text | isforward_html | isforward_attach
   form = $('<form />', {
        'action': action,
        'method': method,
        'target': target ,
        'style': 'display: none;'
    });


    if (typeof input !== 'undefined') {
        $.each(input, function (name, value) {  // note: if input is an array of arrays, value will be CSV string
            $('<input />', {
                type: 'hidden',
                name: name,
                value: value
            }).appendTo(form);

        });         // each
    }      // typeof

    form.appendTo('body').submit();
    return 1;

}



