// build the view suggestions page, using information gotten from server  (immediately after logon)

//==========================
// make the view suggestions page (in  suggestionsDiv
function makeViewSuggestions(ii) {
      
let espot=$('#existingEntriesDivTableOuter');  // table written inside here

amess='<table  id="existingEntriesTable" border="1" width="99%"   >';

// The header row ...
amess+='<tr class="permRow" > '

// the who submitted col
amess+='<td name="c0" valign="top"  ><span class="whoSuggest" style="font-size:110%" title="who suggested this ">Who</span></td>';

// The name column
amess+='<td name="c1"  valign="top" ><span style="font-style:oblique">   ';
amess+='<button class="toggleNotesHeaderButton"  > &#129534;</button>';    // :hover used to display title specified in itoggleNotesHeaderButton2 -->
amess+='<span id="itoggleNotesHeaderButton2" class="toggleNotesHeaderButton2">Click  &#129534; to view details in a popup  </span>';
amess+=' <span name="choiceNameSay">choice</span> name</span> ';
amess+='</td> ';

<!-- &#129534; scroll, 9432- circle i -->

// category col
amess+='<td name="c1b"  valign="top" >Category</td>  ';

// the zero or more customVar cols
let gotHiddens=0;
for (let cvar in customVarList) {
    let vAtt=customVarList[cvar];
    let arequired=vAtt[1];
    if (arequired!=3 && arequired!=4) {   // show these always
      amess+='<td name="customVarCol" valign="top"><span class="customVarColVal">'+cvar+'</span></td>';
    } else {
      let rhide = (arequired==3) ?  ' style="display:none" ' :  '  ' ;
      amess+='<td '+rhide+' class="hiddenCustomVarCol" name="customVarCol" valign="top"><span class="customVarColVal">'+cvar+'</span></td>';
      gotHiddens++;
    }
}

if (gotHiddens>0) $('#iShowHiddenCols').show();  // show the 'display hidden columns' button

// the your rate col
amess+='<td name="c3b" valign="top" ><span class="crateViewList" title="Your rating. larger values for better ratings"  style="font-style:oblique">&#127898;&#65039; &Rscr;ate [avg]</span> </td>';

// the your rank col
amess+='<td name="c3c" valign="top" ><span class="crankViewList" title="Your ranking: top 9 or Next 9 ranking&#010;Or not subject to ranking?"  style="font-style:oblique"> &#8811; &real;ank [summary]</span> </td>';

// the retrieved recommendations  col
amess+='<td name="c3d" valign="top" ><span class="crecoViewList" title="In retrieved recommendations? In your current recommendations?"  style="font-style:oblique">&#127479;eco [own]</span> </td>';

// the links and informatinoal blurbs  col
amess+='<td name="c4" valign="top" >';
amess+='  <em>&Lscr;inks</em>';
amess+='  <span style="float:right;margin-right:1em">';
amess+='     <input type="button" value="&#128476;" title="Expand (or compress) display of: links and information blurbs "';
amess+='         id="itoggleLink" data-status="0"  onClick="toggleLink(this)">';
amess+='  </span>';
amess+='      ';
amess+='</td> ';

// the notes, and stats, column
amess+='<td name="c5" width="45%" data-lastsort="nNotes">    '; //   <!-- note the _sortuse values are set to the summary_ranks on constructio -->
amess+=' <button title="Expand (or compress) display of: notes" ';
amess+='            id="itoggleNotes" data-status="0"  onClick="toggleNotes(this)"> &#128476; &Nscr;otes</button> ';
amess+='<span  class="csuggTable_saySort">You can sort by &hellip; </span>';
amess+='   <span  class="csuggTable_avgRate cSuggCustomSort " ';
amess+='         data-howsort="avgRate" data-dire="0" ';
amess+='         title="Sort by: average rating(higher scores are better)   ">avgRate [#raters]</span> ';
amess+='   <span class="csuggTable_sumrank    cSuggCustomSort " ';
amess+='         data-howsort="summary_rank"  data-dire="0" ';
amess+='         title="Sort by: Summary_rank(lower scores are better) ">summary<br>rank</span> ';
amess+='   <span class="csuggTable_sumrank    cSuggCustomSort " ';
amess+='         data-howsort="myReco"  data-dire="0" ';
amess+='         title="Sort by: your `current` recommendation">your reco</span> ';

amess+=' ';
amess+=' </td>';
amess+='</tr> ';

// ......... End of header row ...... 

// ==  ... Begin the suggestions rows ...

 for (let ij1 in choiceArray) {

  let aid=choiceArray[ij1 ];
  let asugg=choiceList[aid] ;

  let asubmit=asugg['submitBy'];

  let arow='<tr class="suggRow" data-choiceid="'+asugg['ID']+'">';

// ::: submitrer
  arow+='<td><span _sortUse="'+asubmit+'"/><span class="whoSuggest">'+asubmit+'</span></td>';        // ::: submitted by

// ::::: Name

  let shtname=asugg['shortName'].replace(/[\s\,]+/g, "").toLowerCase().substr(0,14);       // :::: even shorter short name
  arow+='<td><span _sortUse="'+shtname+'"/> '
  arow+='<button class="choiceReportButton" title="View details in a popup  " >&#129534;</button>';
  let awarning='';
  if (repeats.hasOwnProperty(aid)) {       // there is more than one entry with this name  (or something like it)
    let dasht=repeats[aid];
    let repeatList=choiceNames[dasht];
    awarning='<span class="cRepeatWarning" title="There are '+repeatList.length+' suggestions with this (or a similar) name!">&#9888;</span>';
 }

  arow+='<span class="'+choiceNameClass+'" title="ChoiceId='+aid+'">'+awarning+' '+asugg['Name']+'</span>';
  arow+='</td>';

// ::: category

  let catval= (asugg.hasOwnProperty('Category')) ? asugg['Category'] : ' ';     // :: Category
  let shtCat=catval.replace(/[\s]+/g, "").toLowerCase().substr(0,14);         // simplify for sorting purposes
  arow+='<td><span _sortUse="'+shtCat+'" class="categoryInViewTable"  >'+catval+'</span></td>';

// ::  zero or more custom vars

  for (let cvar in customVarList) {                                         // ::: zero or more custom cols
    let vAtt=customVarList[cvar];
    let arequired=vAtt[1];
    let ccval= (asugg.hasOwnProperty(cvar)) ? asugg[cvar] : 'n.a.';
    let vsht=fixString(ccval.toLowerCase(),1).substr(0,14);               // simplify for sorting purposes
    if (arequired!=3 && arequired!=4) {                // don't show!
      arow+='<td name="customVarCol" ><span _sortUse="'+vsht+'"/>'+ccval+'</td>';
    } else {
      let rhide = (arequired==3) ?  ' style="display:none" ' :  '  ' ;
      arow+='<td name="customVarCol" '+rhide+' class="hiddenCustomVarCol"   ><span _sortUse="'+vsht+'"/>'+ccval+'</td>';
    }
  }

//  ::: rate

  let catvalRate= (asugg.hasOwnProperty('Rate')) ? asugg['Rate'] : '';      // :::::: own rate
  let catvalRate2=0;
  if (catvalRate!='') catvalRate2=parseInt(catvalRate);
  if (catvalRate2<0 || catvalRate2>4) catvalRate2=0;  // should never happen

  let avgRate=asugg['avgRate'];
  let navgRate=asugg['navgRate'] ;
  let avgRateUse= (navgRate==0) ? '&nbsp;' : avgRate.toFixed(1);
  let spanavg='<span  class="showTheseRates " title="the average rate (from '+navgRate+' raters)\nClick for details..." style="color:#6a6861;">'+avgRateUse+'</span>';

  let sayRate=rateSays[catvalRate2];
  let sayIcon=rateIcons[catvalRate2];
  let sayClass=rateClass[catvalRate2];
  arow+='<td><span  _sortUse="'+catvalRate2+'"  style="float:left;margin:2px 3px 2px 6px" class="'+sayClass+'" title="'+sayRate+'">';
  arow+=sayIcon+ '</span>';
  arow+='<span style="float:right;margin:2px 7px 2px 3px">';
  arow+='<button title="View all ratings for this" class="showTheseRates showTheseRatesButton ">'+spanavg+'</button>';
  arow+='</span></td>';

//  ::: rank
  let tmp2;

  let noRank= (asugg.hasOwnProperty('noRankThis')) ? asugg['noRankThis'] : 0 ;      // :::::: no rank
  if (noRank==1)   {   // trumps own ranking (own ranking is ignored if this suggestion is a noRank)
        tmp2='<div class="cselectRank_noRank" title="This '+choiceNameSay+' is not subject to ranking!">&#128721; No ranking </div>';
         tmp2+='<span _sortuse="'+0+'" />';
  } else {
    let myRank= (asugg.hasOwnProperty('myRank')) ? asugg['myRank'] : 3 ;      // :::::: own rank
    if (myRank!='') myRank=parseInt(myRank);
    if (myRank<0 || myRank>3) myRank=0;  // should never happen
    let sayRank2=rankSays[myRank];
    let sayIcon2=rankIcons[myRank];
    let sayClass2=rankClass[myRank];

    let rankSay=make_summary_rank_span(aid,1) ;

    tmp2='<span _sortuse="'+myRank+'" />';
    tmp2+='<span style="float:left;margin:2px 3px 2px 6px" class="'+sayClass2+'" title="'+sayRank2+'">'+sayIcon2+'</span>';

    tmp2+='<button title="View all rankings for this" class="showTheseRanks showTheseRatesButton " style="float:right">'+rankSay+'</button>';
  }   // norank

  arow+='<td>'+tmp2+'</td>';

//  ::: reco

   let isReco= (asugg.hasOwnProperty('useReco')) ? asugg['useReco'] :  basicStats['nSuggests']+2  ;
   let isMyReco= (asugg.hasOwnProperty('myReco')) ? asugg['myReco'] :  0;
   let sayIsMyReco= (isMyReco >0 ) ? isMyReco : '&empty;' ;
   let recogoo='';
   if (isReco>0) {
     recogoo+='<span _sortUse="'+isReco+'"></span>';
     recogoo+='<span class="csugg_useReco" title="In most recently retrieved recommendation">';
     recogoo+='&#9745;&#65039;'+isReco+'</span>';
   } else {
     recogoo+='<span _sortUse="11111111"> </span>';   // a large number
     recogoo+='<span class="csugg_useReco" title="Not in most recently retrieved recommendations."> </span>';
   }
   if (isMyReco>0 ){
    recogoo+='<span class="csugg_ownReco" title="Your current recommendation:"> '+sayIsMyReco+'</span>';
   } else {
     recogoo+='<span class="csugg_ownReco" title="Not one of your current recommendations">'+sayIsMyReco+'</span> ';
   }
   arow+='<td class="suggTable_recoCol">'+recogoo+'</td>';


// :::: links and information blurbs

  let listLinks= (asugg.hasOwnProperty('linkNotes')) ?  asugg['linkNotes']  : [];    // :::::::: links and information blurbs
   let nna=listLinks.length;
  let  gotLinksButton='',vvmess='';
  let naLinks=0,naBlurbs=0,nlinks=0;

  for (let ivv=0;ivv<nna;ivv++) {
     let av1=listLinks[ivv];
     let av1Text=jQuery.trim(av1[0]);
     let av1Who=av1[1];
     let sayLink2=makeIconFromLink(av1Text,ivv);     //[link,icon,text] .. link does NOT have a trailing </a>
     if (sayLink2===false) continue ; // skip if misspecified

     let avvmess='';

     avvmess+='<div  class="linksLine" title="From: '+av1Who+'"  data-blurb="'+ivv+'">';
     avvmess+='<span  class="linksLineI" style="color:brown ">'+av1Who+'</span> '
     if (sayLink2[1]=='') {              // blurb
       avvmess+=sayLink2[0]+' '+sayLink2[2];
     } else {
       avvmess+=sayLink2[1]+' '+sayLink2[2];
     }
     avvmess+='</div>';
     vvmess+=avvmess ;      // have it here so continue (on misspecified @) works

     let sayImg=sayLink2[1],sayLink='';
     if (sayImg==='')   {  //  no img (so is a blurb)
        naBlurbs++ ;
        sayLink=sayLink2[0];
     } else {
        naLinks++;
        sayLink=sayLink2[0]+sayLink2[1]+'</a>';
     }
     nlinks++ ;
     gotLinksButton+=sayLink;
  }

  let prefix='';
  let nlinksIcon='&#128454;' ;  // empty  page
  if (nlinks==1) {
      nlinksIcon='&#128457;' ;   // single   page
  } else if (nlinks>1) {
      nlinksIcon='&#128458;' ;     // a notepad
  }
  if (nlinks>0) {
    prefix='<input type="button" title="view  '+naLinks+' links and '+naBlurbs+' information blurbs" class="viewList_showLinks" value="'+nlinksIcon+'"> ';
  } else {              // no links/infoBlurbs to show, so not clickable
    prefix='<input type="button" title="no links, or information blurbs " class="viewList_showLinksNone" value="'+nlinksIcon+'"> ';
  }


  arow+='<td><span _sortUse="'+nlinks+'"/>'+prefix+gotLinksButton+vvmess+'</td>';

//  ::::  descriptive notes: both first (specified at addSuggestion) and others.
//        And div for all rates, and for all the ranks. And alternate sort buttons

  let firstNote= (asugg.hasOwnProperty('Notes')) ? jQuery.trim(asugg['Notes'])  : '';    // :::: descriptive supoplied when suggestion made
  let listNotes= (asugg.hasOwnProperty('descNotes')) ?  asugg['descNotes']  : [];    // :::::::: desc notes added later
  let nNotes=listNotes.length;
  if (firstNote!='') nNotes++;
  let nnotesIcon='&#128454;' ;  // empty
  if (nNotes==1) {
      nnotesIcon='&#128457;' ;   // single note page
  } else if (nNotes>1) {
      nnotesIcon='&#128458;' ;     // notepad
  }
  let gotNotesButton;
  if (nNotes>0) {
     gotNotesButton='<input type="button" title="view  '+nNotes+' notes" class="viewList_showDescs" value="'+nnotesIcon+'"> ';
  } else {
     gotNotesButton='<input type="button" title="no desciptive notes" class="viewList_showDescsNone" value="'+nnotesIcon+'"> ';
  }

  let line1Note='';
  if (firstNote!='') {
      line1Note='<div class="noteLineFirst" title="Submitted by: '+asubmit+'">'+gotNotesButton;
      line1Note+='<span class="noteLineFirstMessage">'+firstNote+'</span></div>';
  } else {
       line1Note=gotNotesButton ;
  }
  let vvmess2=line1Note;
  for (let ivv=-1;ivv<listNotes.length;ivv++) {
     let av1Text,av1Who;
     if (ivv==-1) {    // first note?
        if (firstNote=='') continue;     // no first note, so skip
        av1Text=firstNote;            // got first note, included i
        av1Who=asubmit ;
     } else    {       // not a first note
        let av1=listNotes[ivv];
        av1Text=jQuery.trim(av1[0]);
        av1Who=av1[1];
    }
     vvmess2+='<div  class="noteLine" title="From: '+av1Who+'">';          // the toggleable notes
     vvmess2+='<span  class="noteLineI" style="color:brown " data-goo="makeViewSuggestions">'+av1Who+'</span> '
     vvmess2+=av1Text+'</div>';
   }
   arow+='<td><span _sortUse="'+nNotes+'" _sortUseName="1" />'+ vvmess2   ; // "1" signals "use <tr data-choiceid "

// add in rates by individual (div below notes, initially hidden)
   let ratesI=asugg['allRates'];
   let rrsay='<div class="cRateDetails"><ul class="cRateDetailsUl"> ';
   let nrateThis=0,rThisList='';
   for (let ruser1 in ratesI) {
        nrateThis++;
        rate1=ratesI[ruser1];
        rThisList+='<li>'+ruser1+'=<tt>'+rate1+'</tt></li>';
   }
   rrsay+='<li  style="max-width:9em;background-color:#e1e2ea"><em>'+nrateThis+' ratings from:</li>   ';
   rrsay+=rThisList ;
   rrsay+='</ul></div>';
   arow+=rrsay ;

// add in top9 and next 9 ranks individual (div below notes, initially hidden)
   let top9=asugg['topRank'],next9=asugg['nextRank'];
   rrsay='<div class="cRankDetails"><span style="display:inline-block;float:left;margin:1px 3px">Rankings: </span> ';
   rrsay+='<ul class="cRankDetailsUl">';   // top 9

   rThisList='';
   for (let irr1 in top9) {
        let ruser=top9[irr1];
        rThisList+=' | '+ruser+' ' ;
   }
   rrsay+='<li  style="max-width:9em;background-color:#e1e2ea"><em>'+asugg['ntopRank']+' top9:  </li>  ';
   rrsay+='<li>'+rThisList+'</li>'; ;

   rThisList='';
   for (let irr1 in next9) {
        let ruser=next9[irr1];
        rThisList+=' | '+ruser ;
   }
   rrsay+='<li  style="max-width:9em;background-color:#e1e2ea"><em>'+asugg['nnextRank']+' next9:  </li> ';
   rrsay+='<li>'+rThisList+'</li>'; ;

   rrsay+='</ul>';
   rrsay+=' </div>';

   arow+=rrsay ;

   arow+='</td>';


  amess+=arow+'</tr>';
}

amess+='</table>   ';

// now save, tweak, add sort stuff, fix col with
espot.html(amess);

   let sopts={};                 // add table sort stuff
//    sopts['skipCols']=[5]  ;
//   sopts['rowNumberClass']=1,
   sopts['rowNumberSortableClass']='rankRowNumber',
   sopts['rowNumberSortableIcon'  ]='&Oscr;';
   sopts['sortNumeric']=-1;

   wsurvey.sortTable.init('existingEntriesTable',sopts)
   wsurvey.sortTable.rowColors('existingEntriesTable',['tan','#dffef4','#f1f8fe' ]);
   let c0= (suggestTable_colWidths.hasOwnProperty('sort')) ?  suggestTable_colWidths['sort'] : 2 ;
   let c1= (suggestTable_colWidths.hasOwnProperty('who')) ?  suggestTable_colWidths['who'] : 8 ;
   let c2= (suggestTable_colWidths.hasOwnProperty('name')) ?  suggestTable_colWidths['name'] : 15 ;
   let c2a= (suggestTable_colWidths.hasOwnProperty('category')) ?  suggestTable_colWidths['category'] : 8 ;
   let c3= (suggestTable_colWidths.hasOwnProperty('rate')) ?  suggestTable_colWidths['rate'] : 8 ;
   let c3a= (suggestTable_colWidths.hasOwnProperty('rank')) ?  suggestTable_colWidths['rank'] : 8 ;
   let c3b= (suggestTable_colWidths.hasOwnProperty('reco')) ?  suggestTable_colWidths['reco'] : 8 ;
   let c4= (suggestTable_colWidths.hasOwnProperty('links')) ?  suggestTable_colWidths['links'] : 15 ;
   let c5= (suggestTable_colWidths.hasOwnProperty('notes')) ?   suggestTable_colWidths['notes'] : 40 ;
   if (!jQuery.isNumeric(c0) || !jQuery.isNumeric(c1) || !jQuery.isNumeric(c2) ||  !jQuery.isNumeric(c2a) ||
          !jQuery.isNumeric(c3) || !jQuery.isNumeric(c3a) ||    !jQuery.isNumeric(c3b) ||
          !jQuery.isNumeric(c4) || !jQuery.isNumeric(c5) ) {
       wsurvey.dumpObj(suggestTable_colWidths,1,'Bad specification of  suggestTable_colWidths') ;
       return 0
    }


   let colWidths=[c0,c1,c2,c2a];       // sort button, who, name,category (in ems?)
   for (let avar in  customVarList) {         // set aside space for all, even those who are initiallly hidden
       colWidths.push(parseInt(customVarList[avar][0])) ;    // [width,required ]
   }
   colWidths.push(c3);
   colWidths.push(c3a);
   colWidths.push(c3b);
   colWidths.push(c4);
   colWidths.push(c5) ;


   let totwidth=0;
   for (let itt=0;itt<colWidths.length;itt++) totwidth+=parseInt(colWidths[itt]);

   for (let itt=0;itt<colWidths.length;itt++)  {
      let apct=parseInt(100*colWidths[itt]/totwidth);
      colWidths[itt]=apct+'%';
   }
   let foo=wsurvey.sortTable.setTableColWidths('#existingEntriesTable',colWidths,0);
   if (foo[0]===false) alert('Existing entries table: '+foo[1]);

// add some icons to links list in help header
   let imgz='';
   for (let glink in linkIcons) {
      if (glink=='downloadlocal' || glink=='download' || glink=='wwwlink' || glink=='downloadword'   ) continue;
      imgz+='<span style="margin:1px 3px 1px 4px" title="For '+glink+'"><img height="29" width="40" src="'+linkIcons[glink]+'"></span>';
   }
   $('#linkIconsSay_suggHelpHeader').html(imgz);
// and to list of links in detailed help
   let ul3list=$('#viewHelp_iconList');
   for (let glink in linkIcons) {
      if (glink=='downloadlocal' || glink=='download' || glink=='wwwlink' || glink=='downloadword' ) continue;
      let oof='<li> <img height="22" width="22" src="'+linkIcons[glink]+'"> Retrieve from <tt>'+glink+'</tt>';
      ul3list.append(oof);
   }

// add user info summary
   let esheader=$('#suggestionsBasicInfo');

   let nRaters=basicStats['nRaters'];
   let nSubmitters=basicStats['nSubmitters'];
   let nSuggests=basicStats['nSuggests'];
   esheader.html('<span xclass="canCompress">'+nSuggests+' '+choiceNameSay2+' (from '+nSubmitters+' people).');

   return 1;

}



//=======================
// click handler for the view suggestions table
// check for class (on target of click) to determine action
function clickOnViewSugg(event) {

//  let atarget=event.target ;
  let etarget=wsurvey.argJquery(event);
  let etr=etarget.closest('tr');

  if (etarget.hasClass('choiceReportButton')) {   // a "show report on a suggestion"

     let etr=etarget.closest('tr');
     let mvid=etr.attr('data-choiceid');
     displayChoiceReport(mvid,'#existingEntriesTable')    ; // row (and choiceId) and table read from event. #choiceReport data is used to save table and last shown record
     return 1 ;

  }        //  ============  choiceReportButton  =============


  if (etarget.hasClass('cSuggCustomSort')) {   // a "custom sort" button
     clickOnViewSugg_sort(etarget);
     return 1;
  }

  if (etarget.hasClass('showTheseRates')) {   // a "show allrates" button
    let etr=etarget.closest('tr');
    let err=etr.find('.cRateDetails');
    err.toggle();
    return 1;
  }

  if (etarget.hasClass('showTheseRanks')) {   // a "show allrates" button
    let etr=etarget.closest('tr');
    let err=etr.find('.cRankDetails');
    err.toggle();
    return 1;
  }


  if (etarget.hasClass('viewList_showDescs')) {   // a "show notes" button
    let etd=etarget.closest('td');
    let enotes=etd.find('.noteLine');
    enotes.toggle();
    let enote1=etd.find('.noteLineFirstMessage');
    enote1.toggle();
    return 1;
  }


  if (etarget.hasClass('viewList_showLinks')) {   // a "show links & blurbs" button

    let etd=etarget.closest('td');
    let enotes=etd.find('.linksLine');
    let istate=etarget.wsurvey_attrCi('data-showit',0);
    if (istate==0) {
        enotes.show();
        etarget.attr('data-showit',1);
    } else {
        enotes.hide();
        etarget.attr('data-showit',0);
    }
    return 1;
  }

  if (etarget.hasClass('showBlurb')) {   // a "show a particular blurb" button
    let etd=etarget.closest('td');
    let elinks=etd.find('.linksLine');
    let wblurb=etarget.attr('data-which');
    let enote1=etd.find('[data-blurb="'+wblurb+'"]');
    elinks.hide();
    enote1.show();
    return 1;
  }


// else, let it go
}


// ===
// custom sort
// short
function clickOnViewSugg_sort(etarget) {
   let etd=etarget.closest('td,th');
   let lastsort=etd.attr('data-lastsort');
   let howSort=etarget.attr('data-howsort');

    if (howSort==lastsort)  {  // no need to reset _sort use .. just sort
      let eboo=etd.find('[name="wsurvey_sortTable_button"]');
      eboo.trigger('click');            //  custom sort (view table) ... click the wsurvey.sortTable sort button (no need to reset _sortuse in cells)
      return 1;
   }

// reset the _sortUse attributes..
// sortusename always =1 (in the last col of table), so will look in <tr> for data-choiceid

    let nsugg2=basicStats['nSuggests']+2;
    let newSortVals=extractFromChoiceList(howSort);
    for (let oo in newSortVals) {
       if (newSortVals[oo]==0) newSortVals[oo]=nsugg2;
    }
    let res1=wsurvey.sortTable.set_sortuse('#existingEntriesTable',newSortVals,'[_sortusename]','data-choiceid');

    if (res1===false || res1['nOk']==0) return 1 ;   // failure, give up

    let esay1=etd.find('.csuggTable_saySort');
    esay1.html('sortBy: '+howSort+' &vellip; or &hellip;  ');
    let eboo=etd.find('[name="wsurvey_sortTable_button"]');

    eboo.trigger('click');               //  custom sort (view table) ... click the wsurvey.sortTable sort button (after resetting _sortuse in cells)

    return 1;


}


//=======   =========================================
// toggle view of  descriptive notes (view suggestions table) , and rate and ranking details
function toggleNotes(athis) {
  let eto=$('#existingEntriesDivTableOuter');
  let ethis=wsurvey.argJquery(athis);
  let istatus=ethis.attr('data-status');
  let e1=eto.find(".noteLine");
  let e2=eto.find('.noteLineFirstMessage');
  let e3=eto.find('.cRateDetails');
  let e4=eto.find('.cRankDetails');
  if (istatus==0){
     ethis.attr('data-status',1);
     e1.show();
     e2.hide();
     e3.show();
     e4.show();
  } else {
     ethis.attr('data-status',0);
     e1.hide();
     e2.show();               // just show firstLine (note entered when suggestion created)
     e3.hide();
     e4.hide();
  }
}

//================
// show hidden columns (those with suggTableVarRequired=3 or 4
function showHiddenCols(athis) {
  let ethis=wsurvey.argJquery(athis);
  let istatus=parseInt(ethis.attr('data-status'));
  let etable=$('#existingEntriesTable');
  let ehides=etable.find('.hiddenCustomVarCol');
  if (istatus==0) {     //  currently hidden (or on first call, 3's are hidden, 4's are shown
    ehides.show();
  } else {
     ehides.hide();
  }
  istatus=1-istatus;
  ethis.attr('data-status',istatus);
}



//===
// toggle view of the links and information blurbs
function toggleLink(athis) {
  let ethis=wsurvey.argJquery(athis);
  let istatus=ethis.attr('data-status');
  let e1=$(".linksLine");
  if (istatus==0){
     ethis.attr('data-status',1);
     e1.show();
  } else {
     ethis.attr('data-status',0);
     e1.hide();
  }
}



//===================
// function to ask for the localDownload keycode. If not entered correctly, no download
///=============
// click handler for local stream buttons
// uses the md5 in global localDownloadKeycode
// also checks the   downloadUsers global 

function checkDownload(evt ) {
  let downOk=downloadUsers ;

  if (isAdminUser===true) return true ;  // admin always alliwoed

  if (suppressLocalDownload ==1) return false ;        // should not happen (since buttons are hidden)


// known users only?

  if (downOk.hasOwnProperty(currentUserName)) {     // if name match, MUST be explicitly allwoed
      if (downOk[currentUserName]==0) {
         writeStatusMessage('Sorry, downloading has been disabled ',1,0,1) ;
         return false ;  // explicitily not allowed
      }
  } else {               // no name match. check for *
     if (!downOk.hasOwnProperty('*') || downOk['*']==0) {
         writeStatusMessage('Sorry, downloading has been disabled ... ',1,0,1) ;
         return false ;  // explicitily not allowed
     }
  }

// if either matches a name that has value of 1, or if no match to any name, ['*']==1 is specified
// so now ask for keycode


  if (suppressLocalDownload==2) {        // should be md5 of the keycode (to be mached by the prompt)
     let dans=jQuery.trim(prompt('Please contact us for further information','okay'));
     if (dans=='okay' || dans=='') {  // someone gave up and just clicked enter
        alert('Thank you.');
        return false; // g ive up
     }
     dans=dans.toLowerCase();             // use trimmed lowercase of entered keycode
     let dansMd5=md5(dans);
     if (dansMd5!==localDownloadKeycode) {       // hash of codekey is stored in choicer_params.js
        alert('This does not seem to be correct.');
        return false; // give up
     }
  }

// valid keycode (or open access to local server (suppressLocalDownload=0). Start the download...

  etarget=wsurvey.argJquery(evt);
  let etr=etarget.closest('tr');
  let mvid=etr.attr('data-choiceid');
  let mvname=(choiceList.hasOwnProperty(mvid)) ? choiceList[mvid]['Name'] : false ;
  if (mvname===false) {              // should never happen
     alert('Problem finding matching suggestion ');
     return 0;
  }
  writeStatusMessage('Download (<em>'+mvname+'</em>) should commence soon -- check your browser`s download tab for progress!',1,1,1);
    window.setTimeout(function() {
        trackDownload(mvname,1);      // March 2023 .. doesn't do anything yet. Might implement some kind of server side communiation
   },50);

   return true ;                       // good to go!

}

//=====================
// track download
function trackDownload(afile,nth) {
  return 1;

//     let foo=Cookies.get();
//     for (m=1;m<1000;m++) {
//       wsurvey.dumpObj(foo,1,'cookies');
//       qq=confirm('again ');
//       if (!qq) break;
//     }
}


//=============
