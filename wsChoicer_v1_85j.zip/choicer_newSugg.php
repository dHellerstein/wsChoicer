<?php
// works with suggestions tables: new suggestions and view existing
// build "add new suggetions" table
// add to suggestions list (response from use of new suggestions table)
//
// view list of existing suggestions (supplied info on suggestions, and stats on rating, etc
// AND also build ranking/rating/etc tables
// The view list is ALWAYS called just after logon. It also provides vars with info on suggestions, users, etc
//

session_start() ;
ob_start();

// add some php functions
$curDir=getcwd();
$libfile=$curDir.'/choicer_lib.php';
require_once($libfile);


$useProject=$_REQUEST['theProject'];
$paramsFile=$curDir.'/data/'.$useProject.'/params/choicer_params.php';   // customVars, etc ...
if (!file_exists($paramsFile)) {
    ob_end_clean();   // remove prints and other crap
    $amess="Error: missing parameters file: $paramsFile ";
    $stuff=['error'=>$amess];
   $vsuggests=json_encode($stuff, JSON_UNESCAPED_UNICODE);  // encode for web transmission
   print $vsuggests;
   exit;
}


//$curDir=getcwd();
//$paramsFile=$curDir.'/params/choicer_params.php';   // customVars, customVarsLength customVarsRequired are needed

require($paramsFile);

$username=$_REQUEST['username'];
 $todo=$_REQUEST['todo'];

// new suggestion(s) to be added
 if ($todo=='newSuggestionsAdd') {
    addNewSugg($useProject);
    exit;
 }

// default is build new suggestions table

  $astring='';
  $astring.=' <button class="bigButton bigButton1" style="margin-left:10em"  id="isaveSuggestions"  onclick="saveNewSuggestionsToServer(1)" ';
  $astring.='     title="After you make a change: click here to save your new suggestions" >Add this ' ;
  $astring.='   <span name="choiceNameSay">suggestion</span> </button>';
  $astring.='<table  id="newEntriesTable" rules="rows" class="cNewEntriesTable">';
  $astring.='<tr class="headerRow">';
  $astring.='<td  ><button title="Click to add a new row" onClick="addARow(0)">Add</button></td>';
  $astring.='<th  > <span name="choiceNameSay">Name</span></th>';

  $varList=['choiceName'=>[30,1]];

  foreach ($customVars as $avar=>$adesc) {
   $adesc2=strip_tags($adesc);
   $avar2=strip_tags($avar);
   $avar2 = preg_replace("/(\W)+/", "", $avar2);    // alphanumerics only
   $avar2=strToLower($avar2);

   $awidth= (array_key_exists($avar,$customVarsLength)) ? $customVarsLength[$avar] : 6 ;
   if (!is_numeric($awidth)) $awidth=6;
   $arequired= (array_key_exists($avar,$customVarsRequired)) ? trim($customVarsRequired[$avar]) : 0 ;   // default is not required
   if ($arequired!='1' && $arequired!='2' && $arequired!='11'  && $arequired!='3' && $arequired!='4') $arequired=0;
   $arequired=intval($arequired);
   $varList[$avar2]=[$awidth,$arequired];
   $astring.='<th  ><span title="'.$adesc2.'">'.$avar2.'</span></th>';
  }
  $astring.='<th  >Short description</th>';

  $varList['descNote']=[40,0];

  $astring.='</tr>';

// now add an entry line
  $aline='<tr class="entryRow"><td>';
  $aline.='<input type="button" value="&#8998;" title="click to remove this  " onclick="removeEntry(this)"> ';
  $aline.='</td><td>';
  $aline.='<textarea cols="30" rows="1" data-required="1" title="Enter the name " name="aName" ></textarea>'; // required!
  $aline.='</td>';

  foreach ($varList as $avar=>$goo1) {
     if ($avar=='descNote' || $avar=='choiceName') continue ;  // don't do em again
     $awidth=$goo1[0];
     $canHide=' ';
     $arequired=trim($goo1[1]);
     if ($arequired==3 || $arequired==4) {   // not currentlyi used, but maybe in the future
         $canHide=' data-canHide="1" ';
         $arequired=0;
     }
     if ($arequired!=1  && $arequired!=2 && $arequired!=11) $arequired=0;   
     $aline.='<td '.$canHide.'><input type="text" data-required="'.$arequired.'" size="'.$awidth.'"  ';     // might be required, or encouraged
     $aline.='  name="avar" data-varname="'.$avar.'" value="">';
     $aline.='</td>';
  }
  $aline.='<td>';
  $aline.='<textarea cols="40" rows="1"  data-required="0" title="Short description. Longer descriptive notes can be added using the `Rates` page" name="aNote"></textarea> ';
  $aline.='</td>';
  $aline.='</tr>';

  $astring.=$aline;
  $astring.='</table>';

  $rets=['table'=>$astring,'entryrow'=>$aline,'varlist'=>$varList];
  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($rets, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;

// print "Unknown action in choicer_newSugg: $todo ";
// exit;



//======================
// add a new suggestion
function addNewSugg($useProject) {
  $username=$_REQUEST['username'];
  $dalist=$_REQUEST['list'];
  $atime=time();
  $theDate=date("Y-m-d H:i") ;

 $curDir=getcwd();
 $doFile=$curDir.'/data/'.$useProject.'/submits/sug'.$atime.'.sug';
 $fp=fopen($doFile,'w');

//   $fp=fopen('data/'.$useProject.'/submits/sug'.$atime.'.sug','w');

  $amess=';suggestion file @ '.$theDate."\n";
  $amess.="username: $username \n";
  $amess.="date: $atime \n";
  foreach ($dalist as $ith=>$vlist) {
     $amess.="\n";
     $mvid=rand(1,1000000000);    // generate a new id
     $amess.="id: $mvid \n";
     foreach ($vlist as $avar=>$aval) {
         $avar2=trim($avar);
         $qq=checkValidHtml($aval);
         if ($qq!==true) $aval=strip_tags($aval,'<br><p>');       // no error message, just strip tags
         $str = preg_replace( "/\s+/", " ", $aval ) ;
         $amess.="$avar2:  $str \n";
     }
  }
  
  $nbytes=fwrite($fp,$amess."\n\n");
  fclose($fp);
  removeCacheFile($useProject);  // remove the .csh file

  $bmess="From <tt>$username</tt>: ".count($dalist)." new suggestions were saved (@ $atime, using $nbytes bytes).  ";

   ob_end_clean();   // remove prints and other crap
   $tt=[];
   $tt['message']=$bmess;
   $tt['okay']=1;
  $vsuggests=json_encode($tt, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;

}


