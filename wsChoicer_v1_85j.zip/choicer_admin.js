// admin functions

// =====
// edit all the suggetions: name,  sortDescription, and the customVars
function  admin_editSugg(ifoo) {

 let eAdminAlert=$('#myScheduleAdmin_alert');
 eAdminAlert.hide();

 let esugg=$('#myadminMenu_edit') ;
 if (ifoo==0) {
   esugg.hide();
   return 1;
 }

 if (ifoo==1) {
    if (esugg.is(':visible')) {
       esugg.hide();
       return 1;
    }
 }


 let amess='';
 amess+='<div style="border-top:3px solid black; background-color:#e2effa;margin:6px 3px 3px  6px">';
  amess+='<input type="button" value="x" onClick="admin_editSugg(0)"> ';
  amess+='<span style="margin:3px 1em 3px 2em;">';
  amess+='<a name="adminParams_set0"><b>Edit the custom variables for all suggestions </b> ';
  amess+='  <span id="iadmin_editSuggSubmit"  >  ';
  amess+=' <button onClick="admin_editSuggSubmit(1)" class="cadmin_suggSubmitButton">Submit <span id="iadmin_editSuggSubmitN">0</span> changes</button>';
  amess+='</span>';

  amess+='</span>';
 amess+='</div>';
  amess+='<div id="admin_editSuggTableOuter">';
   amess+='<table border="1"  class="cadmin_editSuggTable" width="95%" id="admin_editSuggTable"> ';
 amess+='<tr>';
 amess+='<th width="8%"><span title="sort by: Remove">Id</span></th> ';
 amess+='<th width="8%"><span title="sort by: noRank">Remove &vellip; noRank</span></th> ';
 amess+='<th width="15%">Name</th>  ';
 amess+='<th width="6%">Submitter</th>';
 for (let avar in customVarList) {
    let aa=customVarList[avar];
    amess+='<th width="8%">'+avar+'</th>'
 }
 amess+='<th width="34%">Short description </th>';
 amess+='</tr>';
 for (let ijj in choiceArrayOrig ) {
   let mvid=choiceArrayOrig[ijj] ;
   let achoice;

   if (choiceList.hasOwnProperty(mvid)) {
      achoice=choiceList[mvid];
      achoice['removeThis']=0;    // just to be sure
   } else {
      if (removeChoices.hasOwnProperty(mvid)) {
         achoice=removeChoices[mvid];
         achoice['removeThis']=1;    // just to be sure
      } else {
         alert('suggestion '+mvid+' not in current or removed choices');
         return 0;
      }
   }

   if (removeChoices.hasOwnProperty(mvid)){
      achoice=removeChoices[mvid]  ;  // for admin ... include in list
   }
   
   let doRemove= (achoice.hasOwnProperty('removeThis')) ?  achoice['removeThis'] : 0 ;
   let noRank= (achoice.hasOwnProperty('noRankThis')) ?  achoice['noRankThis'] : 0 ;

   amess+='<tr class="adminRow">';
   let editX='<input title="To edit this row`s values: check this! " type="checkbox" value="1" class="admin_doThis">';
   amess+='<td><div style="white-space: nowrap;">';
   amess+='<span _sortUse="'+doRemove+'"></span>';
   amess+=' <span class="admin_suggRowId" data-mvid="'+mvid+'"  ></span>';
   amess+='   <label>'+editX+mvid+'</label>';
   amess+='</div></td>';

   let removeChecked= (doRemove==1) ? ' checked  '  :  ' ';
   let noRankChecked= (noRank==1) ? ' checked  '  :  ' ';
   let removeX='<input disabled  '+removeChecked+' class="admin_removeButton" type="checkbox" name="editSugg" data-name="removeThis" title="To remove this entry: check this! "  value="1"  >';
   let noRankX='<input disabled  '+noRankChecked+' class="admin_noRankButton" type="checkbox" name="editSugg" data-name="noRankThis" title="To not rank (and automatically include in recommendations) :  check this! "   value="1"  >';
   amess+='<td>'
   amess+='<span _sortUse="'+noRank+'"></span>';
   amess+='<div style="white-space: nowrap;border-bottom:1px solid black;margin-bottom:2px;">';
   amess+=' <span class="admin_suggRowId"  ></span>';
   amess+='   <label  class="admin_removeButtonLabel admin_editSuggLabel"  >'+removeX+' Remove</label>';
   amess+='</div>  ';
   amess+='<div style="white-space: nowrap;">';
   amess+=' <span class="admin_suggRowId"   ></span>';
   amess+='   <label  class="admin_noRankButtonLabel admin_editSuggLabel"   >'+noRankX+' noRank</label>';
   amess+='</div>    ';

   amess+='</td>';

   let aname=achoice['Name'];
   let shtName=achoice['shortName'];
   let anameX='<input disabled  type="text" size="30" name="editSugg" data-name="Name" value="'+aname+'"> ';
   amess+='<td><span _sortUse="'+shtName+'"></span>'+anameX+'</span></td>';

   let whoSubmit=achoice['submitBy'];
   let whoSubmitX='<input disabled  type="text" size="14" name="editSugg" data-name="Who" value="'+whoSubmit+'">';
   amess+='<td><span _sortUse="'+whoSubmit+'"/</span>'+whoSubmitX+'</span></td>';

   for (let avar in customVarList) {
     let aval= (achoice.hasOwnProperty(avar)) ? achoice[avar] : '' ;

     let avalX='<input disabled type="text" size="10" name="editSugg" data-name="'+avar+'" value="'+aval+'"> ';
     amess+='<td><span _sortUse="'+aval+'"></span>'+avalX+'</span></td>';
   }

   let adesc=achoice['Notes'];
   let nmods=achoice['nModified'];
   amess+='<td title="# modifications: '+nmods+'"><span _sortUse="'+nmods+'"></span>';

     amess+='<textarea title="Short description (no HTML)" disabled  rows="1.2" cols="60" name="editSugg" data-name="aNote">'+adesc+'</textarea>';
   
     let removeReason=(achoice.hasOwnProperty('removeReason')) ? achoice['removeReason'] : ' ';
     let noRankReason=(achoice.hasOwnProperty('noRankReason')) ? achoice['noRankReason'] : ' ';

     let removeStyle=(doRemove==1) ? ' '  : ' style="display:none" ' ;
     let noRankStyle=(noRank ==1) ? ' '  : ' style="display:none" ' ;

     amess+='<div class="admin_removeComment admin_editSuggLabel" '+removeStyle+'">';
     amess+='Why remove: <input type="text"  disabled size="50" name="editSugg" data-name="removeReason" value="'+removeReason+'"> ';
     amess+='</div>';
     amess+='<div class="admin_noRankComment admin_editSuggLabel" '+noRankStyle+'>';
     amess+='Why noRank: <input type="text"  disabled size="50" name="editSugg" data-name="noRankReason" value="'+noRankReason+'"> ';
     amess+='</div>';

     amess+='</td>';


  amess+='</tr>';

 } // mvid    _sortU




 amess+='</table>';
 amess+='</div>'

 esugg.html(amess);
 esugg.show();

 
//======== add sort stuff
  let sopts={};                 // add table sort stuff
 //    sopts['skipCols']=[8,9]  ;
//   sopts['rowNumberClass']=1,
  sopts['rowNumberSortableClass']='rankRowNumber',
  sopts['rowNumberSortableIcon'  ]='&Oscr;';
  sopts['sortNumeric']=-1;
  wsurvey.sortTable.init('admin_editSuggTable',sopts)
  wsurvey.sortTable.rowColors('admin_editSuggTable',['tan','#dffef4','#f1f8fe' ]);

  let c0=1  ;  // sort button
  let c1= 8 ; // id
  let c2=15 ; // name;
  let c3= 6  ; // submitetr
   let colWidths=[c0,c1,c2,c3];       // sort button, who, name, category (in ems?)
   for (let avar in  customVarList) {
     colWidths.push(customVarList[avar][0]) ;    // [width,required ]
   }
   let c4=34;
   colWidths.push(c4);  // aNote


   let totwidth=0;
   for (let itt=0;itt<colWidths.length;itt++) totwidth+=colWidths[itt];

   for (let itt=0;itt<colWidths.length;itt++)  {
      let apct=parseInt(100*colWidths[itt]/totwidth);
      colWidths[itt]=apct+'%';
   }
   let foo=wsurvey.sortTable.setTableColWidths('#admin_editSuggTable',colWidths,0);
   if (foo[0]===false) alert('Admin (edit suggestions) table: '+foo[1]);

   $('#admin_editSuggTableOuter').on('click',admin_editSuggHandler) ;   // add handler to newly added to content (to avoid adding handlers multiple times)
}

//============
// event handler for admin_editSugtg
function  admin_editSuggHandler(evt) {
  let eThis=wsurvey.argJquery(evt);
 
  let q2=eThis.hasClass('admin_removeButton');
  if (q2) {
     let etr=eThis.closest('.adminRow');
     let ecomment=etr.find('.admin_removeComment');
     let qcheck=eThis.prop('checked') ;
     if (qcheck) {
        ecomment.show();
     } else {
       ecomment.hide();
     }
     return 1;
   }

  let q3=eThis.hasClass('admin_noRankButton');
  if (q3) {
      let etr=eThis.closest('.adminRow');
     let ecomment=etr.find('.admin_noRankComment');
     let qcheck=eThis.prop('checked') ;
     if (qcheck) {
        ecomment.show();
     } else {
       ecomment.hide();
     }
     return 1;
   }

 
  let q=eThis.hasClass('admin_doThis');

   if (!q ) return 1;   // no other elements have event handlers

  let enumber=$('#iadmin_editSuggSubmitN');
  let inum=enumber.text();

  let isOn=eThis.prop('checked');

  let etr=eThis.closest('.adminRow');
  let einputs=etr.find('[name="editSugg"]');
  if (isOn==1) {   // now checked
    einputs.prop('disabled',false);
    let ecbuttons=etr.find('.admin_editSuggLabel')  ;
    ecbuttons.css({'opacity':1.0});
    inum++;
    enumber.html(inum);
  } else {
    einputs.prop('disabled',true);
    let ecbuttons=etr.find('.admin_editSuggLabel')  ;
    ecbuttons.css({'opacity':0.5});

    Math.max(0,inum--);
    enumber.html(inum);
  }

  return 1;

}

//===========
// submit the edits to suggestions
function admin_editSuggSubmit(ifoo) {
    let esugg=$('#myadminMenu_edit') ;
    let erows=esugg.find('.admin_doThis');
    let eclicked=erows.filter(':checked');
    if (eclicked.length==0) {
       alert('You did not make any changes ');
       return 1;
    }
    
   let daEdits={};
   for (let ie=0;ie<eclicked.length;ie++) {
       let ae1=$(eclicked[ie]);
       let etr1=ae1.closest('.adminRow');
       let e2=etr1.find('.admin_suggRowId');
       let anid=e2.attr('data-mvid');

       daEdits[anid]={};
       let efields=etr1.find('[name="editSugg"]');
       for (let ief=0;ief<efields.length;ief++) {
           let afield=$(efields[ief]);
           let atype=afield.attr('type');
           let davar=afield.attr('data-name');
           let myval;
           if (atype=='checkbox')  {
               myval= (afield.prop('checked')) ? 1 : 0;
           } else {
             myval=jQuery.trim(afield.val());
           }
           daEdits[anid][davar]=fixString(wsurvey.removeAllTags(myval),2);   // get rid of tags and extra spaces/crlfs/etc
       }
   }
   let ddata={};
   ddata['pwd']=theAdminPassword;
   ddata['todo']='modify';
   ddata['theProject']=useProject ;
   ddata['changes']=daEdits;

   $.ajax({
        url: 'choicer_admin.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function(response) {             // callback
       if (typeof(response['error'])!='undefined')  {
          alert(response['error']);
          return 0;
       }

       let astatus=response['okay'];
       if (astatus!='1') {
          alert(astatus);
       } else {
          let amess=response['message'];
            amess+='<br>Please <button class="topRowButtonOther2" onclick="doReload()">Reload </button> to see changes ';
          $('#mySchedule_alert').html(amess).show();
          $('#admin_editSuggTableOuter').html('').hide();

       }
    });



}

//================
// choose which published schedules to display on home page
function admin_displayScheduleMenu(ifoo) {

  let esugg=$('#myadminMenu_edit') ;
  esugg.hide();

 let ddata={'todo':'getPubs'};
 ddata['pwd']=theAdminPassword;
 ddata['theProject']=useProject ;

  $.ajax({
        url: 'choicer_admin.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function(response) {             // callback
       if (typeof(response['error'])!='undefined') {
          alert(response['error']);
          return 0;
       }

      admin_displayScheduleMenu2(response) ;
  });


}

//============
// callback
function  admin_displayScheduleMenu2(response) {
  let amess='';

 //wsurvey.dumpObj(response,1,'proror33');
  amess+='<div style="border-top:3px solid black; background-color:#e2effa;margin:6px 3px 3px  6px">';
  amess+='<input type="button" value="x" title="hide this menu" onClick="$(\'#myScheduleAdmin_alert\').hide()">  ';
  amess+=' <b>Display (on the home page) one or more of the <u>publish final schedules</u> </b> ';
  amess+='</div>';

  amess+='<ul class="linearMenu24Pct">  ';
  amess+='<li style="width:18%"><input type="button" value="Delete" title="Delete selected schedules" onClick="admin_displayScheduleMenuDel(1)"> ';
  amess+='     <u>published</u> schedule(s) ';

  amess+='<li>Select 1 <u>published</u> schedule, ';
  amess+=' and   <button onClick="admin_displayScheduleMenu3(1)">Preview it</button> ';
  amess+='<li> <span style="padding:1px 5px;font-size:110%;font-weight:600;font-style:oblique">  </span> ';
  amess+=' Select several  <u>published</u> schedules and   ';
  amess+=' <button onClick="admin_displayScheduleMenu3(2)">Preview them </button>  ';
  amess+='<li> <button onClick="admin_displayScheduleMenu3(3)">Do not display a schedule</button>  (with optional message)  ';
  amess+='</ul>';

  amess+='<div id="admin_scheduleMenuBox2" class="cadmin_scheduleMenuBox" style="display:none">';
  amess+='</div>';

  amess+='<div id="iadmin_displayScheduleMenu2" style="margin:2px 4em;border:3px dotted gray;display:none">messages</div>';


  amess+='<div style="border:1px solid cyan;margin:2px 2em 2px 2em" title="Useful html entities">FYI: ';
  amess+='  &nbsp;    &#128253; &nbsp;  <tt>&amp;#128253;</tt> &nbsp; &VerticalLine; ';    //    movie projector  (b/w)
  amess+=' &nbsp;  &#128083;  &nbsp;  <tt>&amp;#128083;</tt>  &nbsp; &VerticalLine; ';       //    blue eyeglasses
  amess+='&nbsp;      &#128270; &nbsp;   <tt>&amp;#128270;</tt>  &nbsp;&VerticalLine; ';    //  blue magnifiying
  amess+=' &nbsp;    &#128374; &nbsp;  <tt>&amp;#128374;</tt>  &nbsp;&VerticalLine; ';     // dark sunglasses
  amess+=' &nbsp;    &#128065; &nbsp;  <tt>&amp;#128065;</tt>  &nbsp;&VerticalLine; ';    //  b/w eyeball
  amess+=' &nbsp;   &#128065;&#65039; &nbsp;  <tt>&amp;#128065;&amp;#65039;</tt>  &nbsp;&VerticalLine; ';    //  rec eyeball
  amess+='&nbsp;     &#9678; &nbsp;  <tt>&amp;#9678;</tt> &nbsp;&VerticalLine;  ';       // simple bullseye
  amess+=' &nbsp;    &#9673; &nbsp;  <tt>&amp;#9673;</tt> &nbsp;&VerticalLine; ';        //  simple fisheye
  amess+='</div>';

  amess+='<ul class="boxList">';

  for (let irr in response) {

     let aresponse=response[irr];
     let bmess='';
     bmess+='<label>';
     bmess+='<input type="checkbox" name="admin_displaySchedule" data-pubfile="'+aresponse['Filename']+'" value="'+aresponse['Html']+'"> ';
     bmess+='<span class="dispScheduleTitle" title="types of schedule & date" style="border:1px dotted gray;font-size:90%;font-style:oblique">';
     bmess+=aresponse['Type']+' @ '+aresponse['Date']+'</span>';
     bmess+='</label>';
     bmess+='  <span class="dispScheduleComment"><input  title="You can modify the message" type="text" size="70" name="ndispScheduleComment" value="'+aresponse['Comment']+'"></span>';
     amess+='<li>'+bmess;
  }
  amess+='</ul>'
  $('#myScheduleAdmin_alert').html(amess).show();

  return 1;
}

//-----------------
// which schedules to display
// iwhich: 1 : just one schedule; 2: sevearl
function admin_displayScheduleMenu3(iwhich) {
    let epubs= $('#myScheduleAdmin_alert');
    let einputs=epubs.find('input');
    let echose=einputs.filter(':checked');

    let eshow=$('#admin_scheduleMenuBox2');
    eshow.show();

    if (iwhich==3) {   // message only

         let cmess='';
         cmess+='<div style="background-color:#edecde;margin:2px 2em"> ';
         cmess+='<input type="button" value="x" title="hide this menu" onClick="$(\'#admin_scheduleMenuBox2\').hide()">  ';

         cmess+='<span style="color:blue"> <u>published</u> schedules will not be displayed</span><br>';
         cmess+=' You can specify an <em>  an explanatory message </em> for inclusion on the home page (for public display):';
         cmess+='<p><span style="font-size:80%">leave empty to suppress display  of the <em>or... </em> row on the home page</span>';
         cmess+='<br><input type="text" size="80" name="scheduleDisplay_message" title="No schedules -- just this message" > ';
         cmess+= '<p><button class="cSaveParams"  onclick="admin_displayScheduleMenu4(1)">Save this explantory message </button>  ';
         cmess+='</div>';
         eshow.html(cmess);

         $('#iadmin_displayScheduleMenu2').hide();
          return 1;
     }

    if (echose.length==0) {
       $('#iadmin_displayScheduleMenu2').html('You did not chose a schedule!').show();
        return 0;
    }
    if (iwhich==1 && echose.length!=1) {
       $('#iadmin_displayScheduleMenu2').html('Please chose just <b>one</b> schedule!').show();
       return 0
    }

//     &#128253; : movie projector  (b/w)
//  &#128083;  : blue eyeglasses
//     &#128270; blue magnifiying
//    &#128374; dark sunglasses
//     &#128065; ; b/w eyeball
//    &#9678; simple bullseye
//    &#9673; simple fisheye

    let doems=[];
    for (let ie=0;ie<echose.length;ie++) {
       let e1=$(echose[ie]);
       let ahtml=e1.val();
       let eli=e1.closest('li');
       let espan=eli.find('.dispScheduleTitle');
       let atitle=espan.text();
       let ecomment=eli.find('[name="ndispScheduleComment"]');
       let acomment=ecomment.val();
       acomment=wsurvey.removeAllTags(acomment);
       acomment=fixString(acomment,2);
       let oof='<a href="'+ahtml+'" title="'+atitle+'" target="viewer">'+acomment+'</a> ';
       doems.push(oof);
    }

    let cmess='';
    cmess+='<div style="background-color:#edecde;margin:2px 2em"> ';
      cmess+='<div style="border:1px solid cyan" title="Useful html entities">FYI: ';
      cmess+='  &nbsp;    &#128253; &nbsp;  <tt>&amp;#128253;</tt> &nbsp; &VerticalLine; ';    //    movie projector  (b/w)
      cmess+=' &nbsp;  &#128083;  &nbsp;  <tt>&amp;#128083;</tt>  &nbsp; &VerticalLine; ';       //    blue eyeglasses
      cmess+='&nbsp;      &#128270; &nbsp;   <tt>&amp;#128270;</tt>  &nbsp;&VerticalLine; ';    //  blue magnifiying
      cmess+=' &nbsp;    &#128374; &nbsp;  <tt>&amp;#128374;</tt>  &nbsp;&VerticalLine; ';     // dark sunglasses
      cmess+=' &nbsp;    &#128065; &nbsp;  <tt>&amp;#128065;</tt>  &nbsp;&VerticalLine; ';    //  b/w eyeball
      cmess+=' &nbsp;   &#128065;&#65039; &nbsp;  <tt>&amp;#128065;&amp;#65039;</tt>  &nbsp;&VerticalLine; ';    //  rec eyeball
      cmess+='&nbsp;     &#9678; &nbsp;  <tt>&amp;#9678;</tt> &nbsp;&VerticalLine;  ';       // simple bullseye
      cmess+=' &nbsp;    &#9673; &nbsp;  <tt>&amp;#9673;</tt> &nbsp;&VerticalLine; ';        //  simple fisheye
    cmess+='</div>';

    if (iwhich==2) {
       cmess+='<div style="margin:1em 5px 1em 5px;background-color:#edfbd2">';

       cmess+='<input type="button" value="x" title="hide this menu" onClick="$(\'#admin_scheduleMenuBox2\').hide()">  ';

       cmess+='<em>If this is acceptable</em>, ';
       cmess+='<button class="cSaveParams" onclick="admin_displayScheduleMenu4(0)">Save them </button> to the home page (for public display).';
       cmess+='</div>';

       cmess+='<p><span style="font-size:80%">you can change this short message (simple HTML is okay). Or click a link to preview the formatted schedule</span>... ';
       cmess+='<p><input type="text" size="80" name="scheduleDisplay_message" ';
       cmess+='   title="Display this next to display-schedule lines" value="Would you like to view one of these schedules ... " >' ;

       cmess+='<div style="margin:1em" name="scheduleDisplay_theList">';
       cmess+='<ul   class="boxList">';
       for (let iz=0;iz<doems.length;iz++) {
         let a1=doems[iz];
         cmess+='<li>'+a1;
       }
       cmess+='</ul>';
       cmess+='</div>';

    } else {       // just one

       cmess+='<div style="margin:1em 5px 1em 5px;background-color:#edfbd2">';
       cmess+='<input type="button" value="x" title="hide this menu" onClick="$(\'#admin_scheduleMenuBox2\').hide()">  ';
       cmess+='<em>If this is acceptable</em>, ';
       cmess+='<button class="cSaveParams" onclick="admin_displayScheduleMenu4(0)">Save it </button> to the home page (for public display).';
       cmess+='</div>';
       cmess+='<span style="font-size:80%">you can change this short message (simple HTML is okay). Or click the link to preview the formatted schedule</span>... ';
       cmess+='<p><input type="text" size="50" name="scheduleDisplay_message" title="Display this next to display-schedule lines" value="Would you like to view this schedule: " >' ;
       cmess+='<span style="margin:1em" name="scheduleDisplay_theList">';
       cmess+=doems[0];
       cmess+='</span>';
    }

    cmess+='</div>';

   eshow.html(cmess);

   $('#iadmin_displayScheduleMenu2').hide();

    return 1;
}

//=============
// save "view this/these scheduels to server
function admin_displayScheduleMenu4(imessOnly) {
   let astuff;
   let epubs= $('#myScheduleAdmin_alert');
   let emessage=epubs.find('[name="scheduleDisplay_message"]');;
   let amessage=emessage.val();
   let bmessage0=wsurvey.makeHtmlSafe(amessage,1);
   let bmessage=bmessage0[1];
   if (imessOnly==1) {
      astuff='';
   } else {
      let elist=epubs.find('[name="scheduleDisplay_theList"]');
      astuff=elist.html();
   }

   let  asay='<em>Saving ...</em><br>'+bmessage ;
   $('#iadmin_displayScheduleMenu2').html(asay).show();

   let ddata={'todo':'displayPubs'};
   ddata['pwd']=theAdminPassword;
   ddata['message']=bmessage ;
   ddata['list']=astuff;
   ddata['theProject']=useProject ;

    $.ajax({
        url: 'choicer_admin.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function(response) {             // callback
       if (typeof(response['error'])!='undefined') {
          alert(response['error']);
          return 0;
       }

        $('#myScheduleAdmin_alert').html('<div style="background-color:tan;margin:3px 3em">'+response+'</div>').show();

  });
 }

//=============
// delete all checked published scheduels (from publish/)
function admin_displayScheduleMenuDel(ifoo) {
    let e1=$('#myScheduleAdmin_alert');
    let einputs=e1.find('[name="admin_displaySchedule"]');
    let esel=einputs.filter(':checked');

    let dels=[];
    for (let ie=0;ie<esel.length;ie++) {
       asel=$(esel[ie]);
       dels.push(asel.attr('data-pubfile'));
    }
    let q=confirm('Are you sure you want to remove '+dels.length+' published schedules? ');
    if (!q) return 1;

   let ddata={'todo':'delPubs'};
   ddata['pwd']=theAdminPassword;
   ddata['list']=dels;
   ddata['theProject']=useProject ;

   $.ajax({
        url: 'choicer_admin.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
   }).always(function(response) {             // callback
       if (typeof(response['error'])!='undefined') {
          alert(response['error']);
          return 0;
       }
       let goo=wsurvey.dumpObj(response,'var','Deleteing published schedules ...');
       $('#myScheduleAdmin_alert').html('<div style="background-color:tan;margin:3px 3em"><pre>'+goo+'</pre></div>').show();
   });

}

//-----------------
// make a proposed schedule the final schedule
function admin_makeScheduleMenu(ifoo) {

  let esugg=$('#myadminMenu_edit') ;
  esugg.hide();

   let daScheds=allScheds['schedules']

   let nSchedules=daScheds.length;
   let amess='';


 amess+='<div style="border-top:3px solid black; background-color:#e2effa;margin:6px 3px 3px  6px">';
  amess+='<input type="button" value="x" title="hide this menu" onClick="$(\'#myScheduleAdmin_alert\').hide()"> ';
  amess+='<span style="margin:3px 1em 3px 2em;">';
  amess+='<a name="adminParams_set0"><b>Publish (save to server) any of the available <u>formatted</u> schedules -- either as Html or Js </b> ';
  amess+='</div>';

//  amess+='<input type="button" value="x" title="hide this menu" onClick="$(\'#myScheduleAdmin_alert\').hide()"> ';
   amess+= '<table border="1" cellpadding="5">';

   amess+='<tr><th width="10%" valign="top" > ';
   amess+=' Select a schedule: <div style="font-size:90%"><tt> submitted by</tt><br> <tt>(`schedule type`</tt><br><em>details</em>)';
   amess+='</th>';

   amess+='<td  width="22%" valign="top">';
   let a1='';
   a1+='<select   size="4"   required id="iPeopleWithSchedList2" title="Select a member (# of` entries in schedule` in parenthesis)">';
      for (let aname in daScheds ) {
       let  nBreaks1=parseInt(daScheds[aname]['nBreaks']);
       let  nChoices1=parseInt(daScheds[aname]['nChoices']);
       let datype=daScheds[aname]['schedulerType'];
       let nEntries1=nBreaks1+nChoices1;
       a1+='<option value="'+aname+'">'+aname+' (`'+datype+'` w/'+nChoices1+' entires & '+nBreaks1+' breaks)</option>';
   }
   a1+='</optgroup>';
    a1+='</select>';
   amess+=a1;
   amess+='</td>';

   let dtime=new Date();
   let dtime1=parseInt(dtime.valueOf()/1000);
   let fname='pub_'+dtime1;
   amess+='<td width="70%" >'
   amess+='   <div name="publish_adminOptions" style="background-color:tan;margin:1em;padding:6px;border-bottom:2px solid gray">';
   amess+='   <ul class="boxList">';
   amess+='    <li >Filename (of the <tt>.js and .html</tt> files to be saved): ';
   amess+='      <input type="text" size="25" name="publish_admin_filename" value="'+fname+'">';
   amess+='     <li  > Comment: <input type="text" size="65" name="publish_admin_comment">';
   amess+='  </ul>';
   amess+='</td>';
   amess+='</tr>';

   amess+='<td> and then ... </td>';
   amess+='<td> <button class="cSaveParams" onClick="schedule_publish_adminSave(1)"  name="publish_admin_save">Save HTML and JS file </button>';
   amess+=' <em>to </em> <tt>publish/</tt>  ';
   amess+='</tr>';

   amess+='</table>';
   
   amess+='<div id="myScheduleAdmin_saveStatus" class="cmyScheduleAdmin_saveStatus"> </div>';

   $('#myScheduleAdmin_alert').html(amess).show();

}

//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// choose to create an html file from the formatted schedule, or xml or csv file  containing the specs
function schedule_publish_adminSave(ifoo) {

   if (typeof(schedule_makeHtmlStuff)!='function')  {    // load library and call again
      let daJs='choicer_sched.js';
      $.getScript(daJs)
       .done(function(a,b,c) {
         schedule_publish_adminSave(ifoo)
         return 0;
     })
     .fail(function(a,b,c) {
        initJsReadFail(a,b,c,daJs);
        return 1;
     });
   }

   let epp=$('#myScheduleAdmin_alert');
   let estatusA=$('#myScheduleAdmin_saveStatus');
   let epname=epp.find('[name="publish_admin_filename"]');
     let fname= epname.val() ;
     fname=jQuery.trim(fixString(fname,2));

   if (fname=='') {
       estatusA.html('You did not provide a <u>one-word</u> file name');
       return 0;

   }
   let epcmt=epp.find('[name="publish_admin_comment"]');
     let acmt=epcmt.val();
     acmt=jQuery.trim(fixString(acmt,2));

   let e1=$('#iPeopleWithSchedList2');
   let e2=e1.find("option");
   let aa=e2.filter(":selected");
   if (aa.length==0) {
       estatusA.html('You did not select a  <em>saved schedule</em>');
       return 0;
   }
   let aname=$(aa[0]).val();
   if (!allScheds['schedules'].hasOwnProperty(aname)) {      // could happen if explciti call
       estatusA.html('No entry for '+aname+' in saved schedules ');
       return 0;
   }
   let schList=allScheds['schedules'][aname];


   let ddataHtml=schedule_makeHtmlStuff(aname,1);

   let ddataJson=schedule_makeJsonStuff(aname,acmt,fname,1)

   let ddata={'mname':aname,'comment':acmt,'fname':fname,'htmlStuff':ddataHtml,'jsonStuff':ddataJson,'todo':'adminSave'}  ;
   ddata['theProject']=useProject ;
   ddata['pwd']=theAdminPassword;
   ddata['title']=documentTitle ;
   
    estatusA.html('Saving schedule using <tt>publish/'+fname+'</tt>');

   $.ajax({
        url: 'choicer_admin.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function(response) {             // callback
  //  wsurvey.dumpObj(response,1,'reppe2');
       if (typeof(response['error'])!='undefined') {
          alert(response['error']);
          return 0;
       }

       estatusA.append('<hr>Saving schedule: '+response['message']);
       estatusA.append('<div style="font-size:120%;background-color:#d6efdf">Use <button>Dispay final schedule</button> to display these through the home page</div>');
   });

   return 1;



}

//==============
// view and edit admin  parameters -- in choicer_admin.js and choicer_admin.php
//  set in .php
//$checkValidNames=0;
//$validNames=[];
// $downloadUsers
// $privateDownloadLink='';
// $customVars=[
// $customVarsLength=[
// $customVarsRequired=[
// $customSchedulerVar='duration' ;
// $customSchedulerDefault=2 ;
// $schedulerType='time';
// $schedulerShow=[
// $schedulerNoShow="var1,.."
// $scheduleTopHeader="
// $siteIntro="

function admin_params(ifoo) {

  if (suppress_admin_edit!=0) {
     alert('Online parameter editing is disabled');
     return 0;
  }

 let esugg=$('#myadminMenu_edit') ;
 esugg.hide();

  let ddata={'todo':'getVars'};
   ddata['pwd']=theAdminPassword;  
  ddata['theProject']=useProject ;

   $.ajax({
        url: 'choicer_admin.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function(response) {             // callback
 
       if (typeof(response['error'])!='undefined') {
          alert(response['error']);
          return 0;
       }
       admin_params_1(response) ;
   });
   return 0;

}
//=======
// callback from admin_params
function admin_params_1(phpVars) {
 
    if (suppress_admin_edit!=0) {
     alert('Online parameter editing is disabled');
     return 0;
  }

// 'varname']='type,'description','example']
// types:
//  0 : no changes allowed -- display only (must change in index.php)
//  ny : no/yes (0/1)
//  012 : 0, 1, or 2
//  123 : 0, 1, 2, or 3
//  0123 : 0, 1, 2, 3, or 4
//  abc  : a, b, or c
//  text    : a string. Html not allowed (tags will be removed)
//  html : a string, html   allowed

  let globalVars={};
  globalVars['useProject']=[0,'The current project.','Selected via a menu, or with a <tt>?project=projectName</tt> (in the URL)<br>If no <tt>?project=...</tt> , use <tt>$defaultProject</tt> in <tt>params/choicer_inits.php</tt>'];
  globalVars['adminPwd']=['0','md5 of admin pwd. Set in <tt>params/choicer_inits.php</tt>','Example: <tt>5f4dcc3b5aa765d61d8327deb882cf99</tt> for <tt>password</tt>'];
  globalVars['autoShowHelp']=['ny','Display general help on logon.',' 0:no, 1:yes' ];
  globalVars['autoShowIntro']=['ny','Display the introduction on logon.',' 0:no, 1:yes' ];
  globalVars['autoStatusMessages']=['number','Display status messages on logon',' 0:no, 1: yes, 2: display if messages were written, n&gt;2: display and fadeout in n milliseconds'];
  globalVars['compressHeaderRow']=['ny','Display compressed main-header row.',' 0:no, 1:yes'];

  globalVars['$checkValidNames']=['ny','Enable use of $validNames ... as a logon control (based on username). <br>This complements  passwordUse',' 0:disable (no logon check), 1:yes (logon check)' ];

  globalVars['defaultRate']=['1234','When calculating impRate: the rating assigned when a Rate was not specified.','1:blah, 2:okay, 3: good, 4:great'];

  globalVars['disableNewSuggestions']=['ny','Disable new suggestions.',' 0:no (suggestions can be added), 1:yes (suggestions can NOT be added'];

  globalVars['enableAlertRate']=['number','Show alert if no rates specified (by a member).',' 0:no, n>0: if less than this many rates'];
  globalVars['enableAlertRank']=['number','Show alert if no ranks specified (by a member).',' 0:no, n>0: if less than this many ranks'];
  globalVars['enableNewUserCheck']=['0123','Enable new user check.',' 0:do not check if new user, 1:if new user -- display alert and allow entry, 2:if new user -- allow entry but do NOT allow changes,3: new user denied entry'];

  let foo=['none','rate','rank','reco','comm','view','sugg','new','sche'];
  let foo2='<tt>none, rate, rank, reco<em>mmendations</em>, comm<em>ents</em>,  view<em>Suggestions</em>, new<em>Entry</em>, sche<em>dule</em>  ';
  globalVars['enterToDo']=['startPage','What page to show at logon (view is default).','Pages that can be show on logon: '+foo2];

  globalVars['linkIcons']=['0textArray','Icons used for Links.<br> Set in index.php.',' Array, each row is  <tt> linkName:imgs/imagefile.gif </tt> '];

  globalVars['noSubmitterInNotes']=['ny','Display the name of the submitter in infoBlurbs.',' 0:no, 1:yes'];
  globalVars['passwordUse']=['ny','Require  a password to enter site. <br>This complements $checkValidNames',' 0:no, 1:yes.<br> MD5 of password is set in  <tt>data/projectName/params/choicer_passwords.php</tt>'];

  globalVars['$privateDownloadLink']=['wordlong2','String: a url used in the <em>private download</em> Links.','Example: <tt>http://www.mySite.org/ourClub/src/choicerGet.php?todo=</tt>.<br>The file to be downloaded is appended to this. '];

  globalVars['memberPassword']=['helpMd5','The MD5 of the member password (same for all members). Set in <tt>data/projectName/params/choicer_passwords.php</tt>. ','Example: <tt>5d41402abc4b2a76b9719d911017c592</tt> if password=<tt>hello</tt><br>Used if <tt>passwordUse</tt> is enabled. '];

  globalVars['rankingsLinearMenu']=['abc','How display  top9 and next9 rankings.',' 1: full text, 2: somewhat compressed, 3: more compressed'];

  globalVars['reco_ranksOn_1Line']=['012','Display of top9 and next9 (on reco page).',' 0:use 2 lines, 1: use one line, 2: try to use one line'];

  globalVars['skipBlankCategories']=['ny','When reading a set of saved categories: what do if none specified for a suggestion.',' 0:set to empty, 1: retain currently specified'];
  globalVars['suppressLocalDownload']=['012b','Suppress local-downloads.','0:allow, 1: suppress, 2: require keycode <br>If require keycode, uses localDownloadKeycode' ];
  globalVars['localDownloadKeycode']=['0','The keycode for local downloads. Set in <tt>data/projectName/params/choicer_passwords.php</tt><br>Used if supppresLocalDownload=Require Keycode',' Example of a saved keycode: <tt>22ee71e9dcc9ca12fc313c6e1ce3f806</tt>  if keyCode=<tt>allowed</tt>'];

  globalVars['verNumber']=['0','Version number. Set in index.php.','Example: <tt>1.81b</tt>'];

   globalVars['$schedulerType']=['time','The type of schedule','Allowed values: <tt>time</tt>, <tt>date</tt>, <tt>quantity</tt>, and <tt>order</tt>'];
   globalVars['$customSchedulerDefault']=['number','Value used if a suggestion does not have a <u>cheduler variable</u> value','Example: <tt>90</tt> (90 minutes if <tt>time</tt> type)'];


// Some text strings: to customize headers, etc
  globalVars['choiceNameSay']=['text','String: short textOnly string used when displaying what is being chosen.','Example: <tt>book</tt>..<br>  No html allowed'];
  globalVars['choiceNameSay2']=['text','String: short textOnly string used when displaying plural of  what is being chosen.',' Example: <tt>books</tt>..<br>  No html allowed'];
  globalVars['documentTitle']=['text','String: one-sentence string used as the document title (top bar of browser).','Example: <tt>Our book club</tt>..<br> No html allowed'];
  globalVars['siteAdminContact']=['html','String: the contact info for the site administrator.','Example: <tt>Joe B at theman@foobar.com</tt>..<br> Html allowed -- be sure it is correctly specified.'];
  globalVars['thisSiteName']=['html','String: the name of this site. Used when displaying the name of the local server (typically in technical notes).','Example: <tt>Our club site</tt>. Html allowed -- be sure it is correctly specified.'];
  globalVars['welcomeGroupName']=['html','String: the name of this group. Displayed on welcome screens.  ',' Example: <tt>The &lt;b&gt;2023&lt;/b&gt; book choices</tt>.<br> Html allowed -- be sure it is correctly specified. Should be less than 20 characters.'];
  globalVars['logonBox_otherLinks']=['html','String: zero, one, or more full specified links to related sites. Displayed at top of logon box','Example: <tt>&lt;a&nbsp;href="http:/hisSite.com/"&gt;Another club&lt;/a&gt;  </tt>. .<br>Be sure links are correctly specified. '];
  globalVars['helpBox_otherLinks']=['html','String: zero, one, or more full specified links to related sites. Displayed at bottom of main help box','Example: <tt>&lt;a&nbsp;href="http:/hisSite.com/"&gt;Another club&lt;/a&gt; &amp;nbsp;  &lt;a&nbsp;href="http:/herSite.com/&gt;And one more &lt;/a&gt;</tt>..<br>Html allowed -- be sure HTML, and links, are correctly specified. '];

  globalVars['$scheduleTopHeader']=['html','String: header used when displaying <u>published</u> schedules.','Example: <tt>24 hr schedule for the &lt;b&gt;movies&lt;/b&gt;</tt><br>HTml is okay,  be sure it is correctly specified'];

  let amess='<div style="border-top:3px solid black; background-color:#e2effa;margin:6px 3px 3px  6px">';
  amess+='<div style="margin:5px 0.2em 5px 0.2em;padding:5px">';
  amess+='<input type="button" value="x" onClick="$(\'#myScheduleAdmin_alert\').hide()"> ';
  amess+='<span title="Top" class="cgoDownButton"><a href="#adminParams_set1">&uArr; General</a></span>' ;
  amess+='<span title="Jump to customVars parameters" class="cgoDownButton"><a href="#adminParams_set2">&dArr; custom</a></span>' ;
  amess+='<span title="Jump to scheduler parameters" class="cgoDownButton"><a href="#adminParams_set3">&dArr; schedule </a></span>' ;
  amess+='<span title="Jump to validNames" class="cgoDownButton"><a href="#adminParams_set4">&dArr; validNames </a></span>' ;
  amess+='<span title="Jump to downloadUsers" class="cgoDownButton"><a href="#adminParams_set5">&dArr; downloadUsers </a></span>' ;
  amess+='<span title="Jump to Intro Text " class="cgoDownButton"><a href="#adminParams_set6">&dArr; Intro </a></span>' ;

  amess+='<span style="margin:3px 1em 3px 2em;">';
  amess+='<a name="adminParams_set0"><b>Set various parameters</b></a>';
  amess+=' <button class="cSaveParams" onClick="admin_params2(1)">Save changes</button>';
  amess+='</span>';
  amess+='<span style="float:right;margin-right:1em">';
  amess+=' <a href="params/choicer_params_js.txt" target="viewer">Details</a> (js parameters)</a>  || ';
  amess+=' <a href="params/choicer_params_php.txt" target="viewer">Details</a> (php parameters)</a>';
  amess+='</span><br clear="all">';
  amess+='</div>'
  amess+='</div>'

  amess+='<div id="adminParams_errors" style="display:none;margin:5px 3em 5px 3em;padding:5px;background-color:yellow">errors</div>';

// ------- the div that is scrolled to view different types of parametesr
  amess+='<div style="overflow:auto;border:1px dotted black;height:65vh;position:relative;">';

// the simpler js and php parameters

  amess+='<div style="font-weight:700;background-color:cyan;border-top:3px solid black;border-radius:3px;margin:1em 3px"> ';
  amess+='<a name="adminParams_set1"> general parameters</a>';
  amess+='</div>';
  amess+='<table id="adminParams_general" cellpadding="3" rules="cols"  width="95%" class="cadmin_paramsTable">';

  amess+='<tr> <th width="10%">parameter name</th><th width="39%">Value</th><th width="20%">Description </th><th width="30%" >Example</th></tr>';
  for (let vname in globalVars) {
     let aglobal=globalVars[vname];
     let m1='',aval;   // inside of the <tr>

     m1+='<td><u>'+vname+'</u></td>';
     if (vname.substr(0,1)=='$')   {   // a php var
       let v1=vname.substr(1);
       aval=phpVars[v1];
     } else {               // js variable
       aval=window[vname];
     }
     let atype=aglobal[0];

     let m0  ;
     if (atype=='0') {
        gtype=0;      // skip
        m0='<span style="font-family:monospace;opacity:0.7">'+aval+'</span>';

     } else if (atype=='helpMd5') {
         gtype=0;      // skip
         m0='<span style="font-family:monospace;opacity:0.7">'+aval+'</span>';
         m0+='Generate MD5: <input type="text" title="Enter value, and then clickToView its md5" name="imd5Generate" onChange="doMd5Generate(this)"> ';
         m0+='<span style="background-color:lime;border:1px solid black" id="imd5Generate2" title="the md5">clickToView</span>';

     } else if (atype=='ny') {
         gtype='radio';   // radios
         let isNo= (aval==0) ? ' checked ' : ' ' ;
         let isYes= (aval==1) ? ' checked ' : ' ' ;
         m0='<label class="cAdmin_params_radioLabel"">';
         m0+='<input '+isNo+' type="radio" name="admin_aParam_'+vname+'" value="0">No ';
         m0+='</label>';
         m0+='<label class="cAdmin_params_radioLabel">   ';
         m0+='<input '+isYes+' type="radio" name="admin_aParam_'+vname+'" value="1">Yes ';
         m0+='</label>';


     } else if (atype=='number') {
         gtype='number';   // text   (no html)
         m0='<input class="isText" type="text"  title="Enter a number" name="admin_aParam_'+vname+'" size="5" value="'+aval+'">';


     } else if (atype=='word') {
         gtype='word';   // 1 word
         m0='<input class="isText" type="text"  name="admin_aParam_'+vname+'" size="15" value="'+aval+'">';

     } else if (atype=='wordlong') {
         gtype='word';   // 1 word
         m0='<input class="isText" type="text"  name="admin_aParam_'+vname+'" size="35" value="'+aval+'">';

     } else if (atype=='wordlong2') {
         gtype='word';   // 1 word
         m0='<input class="isText" type="text"  name="admin_aParam_'+vname+'" size="65" value="'+aval+'">';


     } else if (atype=='012') {
         gtype='radio';   // radios
         let is0= (aval==0) ? ' checked ' : ' ' ;
         let is1= (aval==1) ? ' checked ' : ' ' ;
         let is2= (aval==2) ? ' checked ' : ' ' ;
         m0='<label class="cAdmin_params_radioLabel">';
           m0+='<input '+is0+' type="radio" name="admin_aParam_'+vname+'" value="0">Two lines ';
         m0+='</label>';
         m0+='<label  class="cAdmin_params_radioLabel">   ';
           m0+='<input '+is1+' type="radio" name="admin_aParam_'+vname+'" value="1">One line ';
         m0+='</label>';
         m0+='<label class="cAdmin_params_radioLabel">   ';
           m0+='<input '+is2+' type="radio" name="admin_aParam_'+vname+'" value="2">One line if fits  ';
         m0+='</label>';

     } else if (atype=='012b') {
         gtype='radio';   // radios
         let is0= (aval==0) ? ' checked ' : ' ' ;
         let is1= (aval==1) ? ' checked ' : ' ' ;
         let is2= (aval==2) ? ' checked ' : ' ' ;
         m0='<label class="cAdmin_params_radioLabel">';
           m0+='<input '+is0+' type="radio" name="admin_aParam_'+vname+'" value="0">Allow ';
         m0+='</label>';
         m0+='<label  class="cAdmin_params_radioLabel">   ';
           m0+='<input '+is1+' type="radio" name="admin_aParam_'+vname+'" value="1">Disallow';
         m0+='</label>';
         m0+='<label class="cAdmin_params_radioLabel">   ';
           m0+='<input '+is2+' type="radio" name="admin_aParam_'+vname+'" value="2">Require keycode  ';
         m0+='</label>';

     } else if (atype=='abc') {
         gtype='radio';   // radios

         let is0= (aval=='a') ? ' checked ' : ' ' ;
         let is1= (aval=='b') ? ' checked ' : ' ' ;
         let is2= (aval=='c') ? ' checked ' : ' ' ;
         m0='<label class="cAdmin_params_radioLabel">';
           m0+='<input '+is0+' type="radio" name="admin_aParam_'+vname+'" value="a">Full ';
         m0+='</label>';
         m0+='<label class="cAdmin_params_radioLabel">   ';
           m0+='<input '+is1+' type="radio" name="admin_aParam_'+vname+'" value="b">Compressed ';
         m0+='</label>';
         m0+='<label class="cAdmin_params_radioLabel">   ';
           m0+='<input '+is2+' type="radio" name="admin_aParam_'+vname+'" value="c">More compressed ';
         m0+='</label>';


     } else if (atype=='0123') {
         gtype='radio';   // radios
         let is0= (aval==0) ? ' checked ' : ' ' ;
         let is1= (aval==1) ? ' checked ' : ' ' ;
         let is2= (aval==2) ? ' checked ' : ' ' ;
         let is3= (aval==3) ? ' checked ' : ' ' ;
         m0='<label class="cAdmin_params_radioLabel">';
           m0+='<input '+is0+' type="radio" name="admin_aParam_'+vname+'" value="0">No check ';
         m0+='</label>';
         m0+='<label class="cAdmin_params_radioLabel">   ';
           m0+='<input '+is1+' type="radio" name="admin_aParam_'+vname+'" value="1">Alert ';
         m0+='</label>';
         m0+='<label class="cAdmin_params_radioLabel">   ';
           m0+='<input '+is2+' type="radio" name="admin_aParam_'+vname+'" value="2">No changes ';
         m0+='</label>';
         m0+='<label class="cAdmin_params_radioLabel">   ';
           m0+='<input '+is3+' type="radio" name="admin_aParam_'+vname+'" value="3">No entry ';
         m0+='</label>';

     } else if (atype=='1234') {
         gtype='radio';   // radios
         let is1= (aval==1) ? ' checked ' : ' ' ;
         let is2= (aval==2) ? ' checked ' : ' ' ;
         let is3= (aval==3) ? ' checked ' : ' ' ;
         let is4= (aval==4) ? ' checked ' : ' ' ;
         m0='<label class="cAdmin_params_radioLabel">';
           m0+='<input '+is1+' type="radio" name="admin_aParam_'+vname+'" value="1">Blah ';
         m0+='</label>';
         m0+='<label class="cAdmin_params_radioLabel">   ';
           m0+='<input '+is2+' type="radio" name="admin_aParam_'+vname+'" value="2">Okay ';
         m0+='</label>';
         m0+='<label class="cAdmin_params_radioLabel">   ';
           m0+='<input '+is3+' type="radio" name="admin_aParam_'+vname+'" value="3">Good ';
         m0+='</label>';
         m0+='<label class="cAdmin_params_radioLabel">   ';
           m0+='<input '+is4+' type="radio" name="admin_aParam_'+vname+'" value="4">Great ';
         m0+='</label>';


     } else if (atype=='startPage') {
         gtype='radio';   // 1 word
         m0='';
        let candos=['none','rate','rank','reco','comm','view','sugg','new','sche'];
         for (let ii=0;ii<candos.length;ii++) {
           let acan=candos[ii];
           let ischecked=(acan==aval) ? ' checked ' : '  ';
           m0+=' <label class="cAdmin_params_radioLabel">   ';
           m0+='<input '+ischecked+' type="radio"  name="admin_aParam_'+vname+'"   value="'+aval+'">';
           m0+=acan+'</label>';
         }
     } else if (atype=='time') {
         gtype='radio';   // radios
         let is1= (aval=='time') ? ' checked ' : ' ' ;
         let is2= (aval=='date') ? ' checked ' : ' ' ;
         let is3= (aval=='quantity') ? ' checked ' : ' ' ;
         let is4= (aval=='order') ? ' checked ' : ' ' ;
         m0='<label class="cAdmin_params_radioLabel">';
           m0+='<input '+is1+' type="radio" name="admin_aParam_'+vname+'" value="time">Time ';
         m0+='</label>';
         m0+='<label class="cAdmin_params_radioLabel">   ';
           m0+='<input '+is2+' type="radio" name="admin_aParam_'+vname+'" value="date">Date ';
         m0+='</label>';
         m0+='<label class="cAdmin_params_radioLabel">   ';
           m0+='<input '+is3+' type="radio" name="admin_aParam_'+vname+'" value="quantity">Quantity ';
         m0+='</label>';
         m0+='<label class="cAdmin_params_radioLabel">   ';
           m0+='<input '+is4+' type="radio" name="admin_aParam_'+vname+'" value="order">Order ';
         m0+='</label>';

     } else if (atype==='html') {
         gtype='html';   // html allowed text
         m0='<textarea class="isText" title="HTML tags allowed -- be sure HTML is valid"  name="admin_aParam_'+vname+'" rows="2" cols="46">'+aval+'</textarea>';

     } else if (atype==='asis') {
         gtype='asis';   // html allowed text
         m0='<textarea class="isText" title="HTML tags allowed -- be sure HTML is valid"  name="admin_aParam_'+vname+'" rows="2" cols="46">'+aval+'</textarea>';

     } else if (atype=='text') {
         gtype='text';
         m0='<textarea class="isText" title="HTML tags will be removed" name="admin_aParam_'+vname+'" rows="2" cols="46">'+aval+'</textarea>';

     } else if (atype=='0textArray') {
         gtype='0';   // notchangeable
        let  m0s=[];
        for (let ifoo in aval) {
           let avalA=wsurvey.htmlspecialchars(aval[ifoo]);
           m0s.push('<tt>'+ifoo+':'+avalA+'</tt>');
        }
        m0=m0s.join('<br>')  ;

     } else {
        gtype='bad';
        m0=atype+ ' unknown format! <tt>'+aval+'</tt>';
     }

     m1+='<td>'+m0+'</td>';
     m1+='<td>'+aglobal[1]+'</td>';
     m1+='<td><div style="font-size:90%">'+aglobal[2]+'</div></td>';
     
     m1='<tr class="adminParamsRow" data-name="'+vname+'" data-type="'+gtype+'">'+m1+'</tr>';


     amess+=m1;
  }
  amess+='</table>';

// ======= custom variables ::::::::

  let customVars=phpVars['customVars'];
  let customVarsRequired=phpVars['customVarsRequired'];
  let customVarsLength=phpVars['customVarsLength'];
  let customSchedulerVar=phpVars['customSchedulerVar'];

  amess+='<div style="font-weight:700;background-color:cyan;border-top:3px solid black;border-radius:3px;margin:1em 3px"> ';
  amess+='<span title="Jump to top of page" class="cgoDownButton"><a href="#adminParams_set1">&uArr;</a></span>' ;
  amess+='<a name="adminParams_set2">  customVars  </a>  -- variables that can be specified (and viewed) for all suggestions. ';
  amess+='<span style="font-weight:500">One variable <b>should</b> be the <u>scheduler variable</u> -- it`s used to build ';
  amess+='schedules. For example, in <tt>time</tt> mode: the entry`s duration (in minutes).';
  amess+='</div>';

  amess+='<table id="adminParams_customVars" cellpadding="3" rules="cols"  width="95%" class="cadmin_paramsTable">';
  amess+='<tr  >  ';
  amess+='<td width="3%"><button style="color:red"   title="remove a variable">&#8998; Del</button></td>';

  amess+=' <th width="12%"> ';
  amess+='<button style="color:green" onClick="$(\'#adminParams_customVars_rowAdd1\').toggle()" ';
  amess+= '       title="Add a row (to specify a new custom variable)">&#10133;</button>';
  amess+=' Name ';
  amess+='<div id="adminParams_customVars_rowAdd1" class="adminParamsAddRow" style="background-color:tan;display:none">';
  amess+='  Enter varName:<br> <input type="text" size="11" value="">';
  amess+='<br>and then <br><button onClick="admin_params_addRow(this)">add row</button>';
  amess+='</div>';
  amess+='</th> ';

  amess+='<th width="23%">Desc </th> ';
  amess+=     '<th width="7%">Width </th>';

  amess+='<td width="40%"><button onClick="$(\'#admin_customVars_requiredNote\').toggle()">?</button><b> Required </b>';
  amess+='<div id="admin_customVars_requiredNote" style="display:none">Is this variable <em>required</em> when a new '+choiceNameSay+' is entered?';
  amess+=' <ul class="boxList">  ';
  amess+='  <li> <tt>required</tt>: value <b>must</b> be entered   ';
  amess+='  <li><tt>requiredNumber</tt>: a numeric value <b>must</b> be entered ';
  amess+='  <li>  <tt>Recommended</tt>: a value should be entered (an alert is displayed if it no value is entered) ';
  amess+='  <li>  <tt>optional</tt> : a value does not have to be entered ';
  amess+='  <li>  <tt>optional_hidden</tt> : a value does not have to be entered ;';
  amess+='</ul>';
  amess+='<br>This setting also controls display of custom variables on the various pages. See the details for the details!';
  amess+='</div>';
  amess+='</td>';

  amess+=' <th width="10%">Scheduler variable?</th>';
  amess+='</tr>';

  for (let cvar in customVars) {
      let a1='';
      let adesc=wsurvey.removeAllTags(customVars[cvar]);

      a1+='<td><button style="color:red" onClick="admin_params_delRow(this)" title="remove this custom variable">&#8998;</button></td>';
      a1+='<th><input type="text" size="10" title="Custom variable name" name="admin_aParam_customVarName" disabled value="'+cvar+'"></th>'
      a1+='<td> <input type="text" size="35" class="customVarDesc" title="Short description (no Html)" value="'+adesc+'"> </td>'

      let awide= (customVarsLength.hasOwnProperty(cvar)) ? parseInt(customVarsLength[cvar]) :  6 ;
      a1+='<td><input class="customVarLength" title="Width of columns displaying this variable (in % of screen width)" type="text" size="3" value="'+awide+'" > </td>'

      let arequired= (customVarsRequired.hasOwnProperty(cvar)) ? parseInt(customVarsRequired[cvar]) :  3 ;
       let is1= (arequired==1) ? ' checked ' : ' ' ;
       let is11= (arequired==11) ? ' checked ' : ' ' ;
       let is2= (arequired==2) ? ' checked ' : ' ' ;
       let is3= (arequired==3 || arequired<0 || arequired>11) ? ' checked ' : ' ' ;
       let is4= (arequired==4) ? ' checked ' : ' ' ;
       let m0='<label style="padding:2px;margin:2px;background-color:#dfdfdf;font-size:85%">';
           m0+='<input '+is1+' type="radio" name="admin_customRequired_'+cvar+'"  class="requiredCustomVar" value="1">Required ';
         m0+='</label>';
         m0+='<label style="padding:2px;margin:2px;background-color:#dfdfdf;font-size:85%">   ';
           m0+='<input '+is11+' type="radio" name="admincustomRequired_'+cvar+'" class="requiredCustomVar"  value="11">requiredNumber ';
         m0+='</label>';
         m0+='<label style="padding:2px;margin:2px;background-color:#dfdfdf;font-size:85%">   ';
           m0+='<input '+is2+' type="radio" name="admin_customRequired_'+cvar+'" class="requiredCustomVar"  value="2">Recommended ';
         m0+='</label>';
         m0+='<label style="padding:2px;margin:2px;background-color:#dfdfdf;font-size:85%">   ';
           m0+='<input '+is4+' type="radio" name="admin_customRequired_'+cvar+'" class="requiredCustomVar" value="4">optional ';
         m0+='</label>';

         m0+='<label style="padding:2px;margin:2px;background-color:#dfdfdf;font-size:85%">   ';
           m0+='<input '+is3+' type="radio" name="admin_customRequired_'+cvar+'" class="requiredCustomVar" value="3">optional_hidden ';
         m0+='</label>';

         a1+='<td>'+m0+'</td>';

        let a2;
        if (cvar==customSchedulerVar) {
               a2='<label title="Use as `scheduler variable` (to create times/dates/running sums)?" style="font-size:80%"> <input type="radio" checked value="1"  name="admin_customScheduleVar"><u>Scheduler?</u></label> ';
        } else {
               a2='<label title="Use as `scheduler variable` ( to create times/dates/running sums)?"  style="font-size:80%"><input type="radio"   value="1"  name="admin_customScheduleVar"><u>Scheduler?</u></label>';
        }
        a1+='<td>'+a2+'</td>';

        amess+='<tr class="adminParamsRow" data-name="'+cvar+'">'+a1+'</tr>';
   }
  amess+='</table>';

// ======== scheduler stuff   :::::

   schedulerShow=phpVars['schedulerShow'];
   schedulerNoShow=phpVars['schedulerNoShow'] ;
   let t1=schedulerNoShow.split(',');

   let sNoShow={}; // lookups for "include but do not auto show" schedule variables
   for (it1 in t1) {
      let at1=jQuery.trim(t1[it1]);
      sNoShow[at1]=1;
   }

   let sVars={};
   sVars['Name']= [15,'The name of the suggestions. If not specified, it will be added!'];
   sVars['Start']=[9,'Formatted (am/pm, calendar date, quantity) starting value for an entry  (sum of totalDuration of prior entries  + begin value). For `order` mode: the values used when sorting '];
   sVars['totalDuration']=[7,'Sum of <tt>Duration/Quantity</tt> and <tt>Pause</tt>. Not used in `order` mode'];
   sVars['Links']=[20,'The <tt>Links</tt> (specified on the Rate page)   -- as <tt>&lt;a ..&gt;&tl;img&gt;&lt;/a&gt;</tt> (no text)'];
   sVars['Desc']=[20,'The description (as specified when the entry was added to the schedule)'];

   sVars['rowNumber']=[2,' Include a row number (starting at 1)'];
   sVars['rowNumberChoice']=[1,'Similar to <tt>rowNumber</tt>, but do <b>not</b> put a number on "break" rows'];

   sVars['Duration']=[5,' An entry specific value (duration or quantity, or an `order` value) specified in the chosen <u>scheduler variable</u> (or specified when the entry was added to the schedule)'];
   sVars['Pause']=[5,' The <tt>pause before</tt> (specified when the entry was added to the scheduled). Not used in `order` mode'];
   sVars['Elapsed']=[9,' Elasped time, days, or running sum -- of prior entries. Similar to <tt>Start</tt> -- but does not use <tt>begin time</tt>. Can be slightly formatted.  Not used in `order` mode'];
   sVars['entryValueA']=[6,'Same as <tt>Start</tt>, but <b>not</b> formatted. Not used in `order` mode' ];
   sVars['firstNote']=[30,' The short note (no html). Specified on the Add suggestions page'];
   sVars['descNotes']=[40,' The descriptive notes (specified on the Rate page). Also includes the firstNote'];
   sVars['infoBlurbs']=[20,'The <u>information blurbs</u> (specified on the Rate page)'];
   sVars['allLinks']=[20,'The <u>Links</u> and the <u>infoBlurbs</u>'];

   for (let cvar in customVars) {
      let ilen= (customVarsLength.hasOwnProperty(cvar)) ? customVarsLength[cvar] : 6 ;
      let cdesc=customVars[cvar];
      sVars[cvar]=[ilen,'<tt>(customVar)</tt> '+ cdesc];
   }

  amess+='<div style="font-weight:700;background-color:cyan;border-top:3px solid black;border-radius:3px;margin:1em 3px"> ';
  amess+='<span title="Jump to top of page" class="cgoDownButton"><a href="#adminParams_set1">&uArr;</a></span>' ;
  amess+='<a name="adminParams_set3">  scheduler parameters </a>';
  amess+='<span style="font-weight:500"> <u>Include</u> variables are available to a schedule maker. ';
  amess+=' <u>noShow</u> are available, but are <b>not</b> automatically included in a schedule (they can be manually included).' ;
  amess+='</span>';
  amess+='</div>';

  amess+='<table id="adminParams_scheduleVars" cellpadding="3" rules="cols"  width="95%" class="cadmin_paramsTable">';
  amess+='<tr ><th width="7%" >Include</th><th width="10%">Name</th ><th width="5%">Width</th> ';
  amess+='    <th width="55%">Description</th><th width="18%">noShow</th></tr>';


  let showOrder=[];
  for (let a1 in schedulerShow) {
      showOrder.push(a1);
  }
  for (let svv in sVars) {
      if (schedulerShow.hasOwnProperty(svv)) continue ;
      showOrder.push(svv);
  }

//  for (let svar in sVars) {

   for (let ijj=0;ijj<showOrder.length;ijj++) {
     svar=showOrder[ijj];
     amess+='<tr class="adminParamsRow" data-name="'+svar+'">  ';
     if (!sVars.hasOwnProperty(svar))  {   // an error!
       amess+='<td colspan="4"><tt>'+svar+'</tt> is not available. It will be removed from the list of scheduleVars </td> </tr>';
       continue;
    }
     let asvar=sVars[svar];

     let achecked= (schedulerShow.hasOwnProperty(svar)) ? ' checked ' : ' ' ;
     amess+='<td>';
      amess+=' <button title="move this row up" class="schedule_moveUp moveCursor">&#9040;</button> ';
      amess+=' <button title="move this row down" class="schedule_moveDown  moveCursor">&#9047;</button> ';
     amess+='<input title="Check to make this variable available to a schedule maker" type="checkbox" '+achecked ;
     amess+='    name="admin_scheduleVars_include" value="1" class="pointerCursor" >';
     amess+='</td>';

     amess+='<td><u>'+svar+'</u></td>';

     amess+='<td><input  class="crosshairCursor" type="text" size="4" name="admin_scheduleVars_length" title="Width of column (in %)" value="'+asvar[0]+'"></td>';
     amess+='<td><em>'+asvar[1]+'</em></td>';

     let bchecked=(sNoShow.hasOwnProperty(svar)) ? ' checked ' : ' ';
     amess+='<td><label><input   class="pointerCursor" type="checkbox" '+bchecked+' name="admin_scheduleVars_noShow" value="1">Check to <u>not</u> auto show</label></td>';
     amess+='</tr>';
  }
  amess+='</table>';



// ======== validnames stuff   :::::

  amess+='<div style="font-weight:700;background-color:cyan;border-top:3px solid black;border-radius:3px ;margin:1em 3px"> ';
  amess+='<span title="Jump to top of page" class="cgoDownButton"><a href="#adminParams_set1">&uArr;</a></span>' ;
  amess+='<a name="adminParams_set4">  validNames </a>';
  amess+='<span style="font-weight:500">';
  amess+='Nicknames are optional. If specified, use a space delimited list of 1-word (lowercase) logon names. They can be used as an alternative to the member name .';
  amess+='</span>';
  amess+='</div>';

  let validNames=phpVars['validNames'];
  let vNames0={};
  for (let avname in validNames)  {
      let mName=validNames[avname];
      if (!vNames0.hasOwnProperty(mName)) {
         vNames0[mName]={} ;  // list of nicknames always includes own name
         vNames0[mName][avname]=1;
      }
      vNames0[mName][avname]=1;  // could be redundant but so what
  }
  amess+='<table id="adminParams_validNames" cellpadding="3" rules="cols"  width="95%" class="cadmin_paramsTable">';
  let abutton='<button style="color:green" onClick="admin_validNames_addRow(this)"  ';
  abutton+= '       title="Add a new member">&#10133;</button> ';
  amess+='<tr ><th width="2%" >Del</th><th width="15%">'+abutton+' memberName</th >';
  amess+='<th width="66%">nickNames';
  amess+=' <span style="font-weight:500;font-size:80%;padding-left:2em"> To change existing nicknames: specify in a new row, and delete existing</span>';
  amess+='</th></tr>';
  for (let mname in vNames0) {
      let a1='<tr class="adminParamsRow" data-name="'+mname+'">';
      a1+='<td><button style="color:red" onClick="admin_params_delRow(this)" title="remove this member">&#8998;</button></td>';
      a1+='<td><span>'+mname+'</span></td>';

      let vname1=vNames0[mname];
      let oof=[];
      for (let vav in vname1) oof.push(vav);
      let a2=oof.join(',');
      a1+='<td><span class="validNicknames" style="font-family:monospace">'+a2+'</span></td>';

      amess+=a1+'</tr>';
  }
  amess+='</table>';


// ======== downloadUsers stuff   :::::
// ['daniel'=>0,'susan'=>1,'bill'=>1,'peter'=>1,'leslie'=>1,'david'=>1,'*'=>0];
  amess+='<div style="font-weight:700;background-color:cyan;border-top:3px solid black;border-radius:3px ;margin:1em 3px"> ';
  amess+='<span title="Jump to top of page" class="cgoDownButton"><a href="#adminParams_set1">&uArr;</a></span>' ;
  amess+='<a name="adminParams_set5">  downloadUsers </a>';
  amess+='<span style="font-weight:500">';
  amess+='Members (or users if open access) who are allowed to download from local server.';
  amess+='</span>';
  amess+='</div>';
  
  let downloadUsers=phpVars['downloadUsers'];

 amess+='<table id="adminParams_downloadUsers" cellpadding="3" rules="cols"  width="95%" class="cadmin_paramsTable">';
  let bbutton='<button style="color:green" onClick="admin_downloadUsers_addRow(this)"  ';
  bbutton+= '       title="Add a new username">&#10133;</button> ';
  amess+='<tr ><th width="2%" >Del</th><th width="15%">'+bbutton+' memberName</th ><th width="66%">Can download?</th></tr>';
  let allOk=0;
  if (downloadUsers.hasOwnProperty('*')) {
     allOk=downloadUsers['*'];
     let a1='<tr class="adminParamsRow" data-name="*">';
      a1+='<td><button style="color:red" onClick="admin_params_delRow(this)" title="remove this downloadUser entry">&#8998;</button></td>';

    is0= (allOk==0) ? ' checked ' : ' ' ;
    is1= (allOk==1) ? ' checked ' : ' ' ;
    let m0A='<label style="padding:2px;margin:2px;background-color:#dfdfdf;font-size:85%">';
           m0A+='<input '+is0+' type="radio" class="admin_downLoadUserRadio" name="admin_aParam_downloadUserDef" value="0">Not allowed'
         m0A+='</label>';
         m0A+='<label style="padding:2px;margin:2px;background-color:#dfdfdf;font-size:85%">   ';
           m0A+='<input '+is1+' type="radio" class="admin_downLoadUserRadio"  name="admin_aParam_downloadUserDef" value="1">Allowed ';
         m0A+='</label>';

     a1+='<td>Default</td><td>'+m0A+'</td></tr>';

     amess+=a1;
   }       // default

  for (let mname in downloadUsers) {
      if (mname=='*') continue ; // did this above
      let a1='<tr class="adminParamsRow" data-name="'+mname+'">';
      a1+='<td><button style="color:red" onClick="admin_params_delRow(this)" title="remove this downloadUser entry">&#8998;</button></td>';
      a1+='<td><span>'+mname+'</span></td>';

     let isOkay=downloadUsers[mname];

     is0= (isOkay==0) ? ' checked ' : ' ' ;
     is1= (isOkay==1) ? ' checked ' : ' ' ;
     let m0A='<label style="padding:2px;margin:2px;background-color:#dfdfdf;font-size:85%">';
           m0A+='<input '+is0+' type="radio" class="admin_downLoadUserRadio"  name="admin_aParam_downloadUser_'+mname+'" value="0">Not allowed'
         m0A+='</label>';
         m0A+='<label style="padding:2px;margin:2px;background-color:#dfdfdf;font-size:85%">   ';
           m0A+='<input '+is1+' type="radio" class="admin_downLoadUserRadio"  name="admin_aParam_downloadUser_'+mname+'" value="1">Allowed ';
         m0A+='</label>';
       m0A+='<label style="padding:2px;margin:2px;background-color:#dfdfdf;font-size:85%">   ';
       m0A+='<input   type="radio" class="admin_downLoadUserRadio"  name="admin_aParam_downloadUser_'+mname+'"" value="2">Use default '  ;
       m0A+='</label>';

      a1+= '<td>'+m0A+'</td></tr>';

      amess+=a1;

  }   // for mameer in downloadUsers


  amess+='</table>';


// ======== siteIntro stuff   :::::
  amess+='<div style="font-weight:700;background-color:cyan;border-top:3px solid black;border-radius:3px ;margin:1em 3px"> ';
  amess+='<span title="Jump to top of page" class="cgoDownButton"><a href="#adminParams_set1">&uArr;</a></span>' ;
  amess+='<a name="adminParams_set6">  Site Introduction </a>';
  amess+='<span style="font-weight:500">';
  amess+='Enter a site introduction. Can be several sentences long. Can have Html (make sure it is valid HTML). It is displayed when the visitor clicks the Intro button';
  amess+='</span>';
  amess+='</div>';

  amess+='<textarea style="margin:5px 2em 5px 2em;padding:5px" name="adminVar_siteIntro" rows="10" cols="140">'+phpVars['siteIntro']+'</textarea>';

//  ...... display all of the above ......
 amess+='</div>';
  amess+='<hr><p>&nbsp;  ';
  $('#myScheduleAdmin_alert').html(amess).show();

// add event handlers
let eT1=$('#adminParams_scheduleVars');
 eT1.on('click',admin_params_events) ;

  return 1;
}

//==============
// generate md5
function doMd5Generate(athis) {
  let ethis=wsurvey.argJquery(athis);
  let aval=ethis.val();
  aval=jQuery.trim(aval.toLowerCase());
  let md5a=md5(aval);
  $('#imd5Generate2').html(md5a);
  return 1 ;
}

//===========
// event handler for scheduleVars
function admin_params_events(evt) {

   let etarget=wsurvey.argJquery(evt);
   let qup=etarget.hasClass('schedule_moveUp');
   let qdown=etarget.hasClass('schedule_moveDown');
   if (!qup && !qdown) return 0 ; // clicked on whatevers

   let etable=etarget.closest('#adminParams_scheduleVars');
   let etrss=etable.find('.adminParamsRow');
   etrss.removeClass('cMoveThisRow');

   if (qup) {     // move row up one
     let etr=etarget.closest('tr');
     let before=etr.prev();
     if (before.length==0) return 0  ; // at top
     if (!before.hasClass('adminParamsRow'))  return 0 ;  // before row is the header
     etr.addClass('cMoveThisRow');
     etr.fadeOut(100,function() {;
         etr.insertBefore(before);
         etr.fadeIn(300, function() {
             before.removeClass('cMoveAroundThisRow');
         });
     });
     return 1;
  }
   if (qdown)  {     // move  row down one
     let etr=etarget.closest('tr');
     let after=etr.next();
     if (after.length==0) return 0 ;      // don't go past end of table
     after.addClass('cMoveAroundThisRow');
     etr.addClass('cMoveThisRow');
     etr.fadeOut(300,function() {;
        etr.insertAfter(after);
        etr.fadeIn(300, function() {
            after.removeClass('cMoveAroundThisRow');
        });
     });
     return 1;
  }
 

   return 1;
}

//==========
// delete this row
function admin_params_delRow(athis) {
   let ethis=wsurvey.argJquery(athis) ;
   let etr=ethis.closest('.adminParamsRow');
   etr.remove();
}

//==========
// add this row
function admin_params_addRow(athis) {

   let ethis=wsurvey.argJquery(athis) ;
   let ediv=ethis.closest('.adminParamsAddRow');
   let einput=ediv.find('input');
   let cvar=einput.val();
   ediv.hide();
   cvar=wsurvey.removeAllTags(cvar);
   cvar=fixString(cvar,1);
   cvar=cvar.toLowerCase();

   let et1=$('#adminParams_customVars');
   let a1='';
   let amess='';

      a1+='<td><button style="color:red" onClick="admin_params_delRow(this)" title="remove this custom variable">&#8998;</button></td>';
      a1+='<th><input type="text" size="10" title="Custom variable name" name="admin_aParam_customVarName" disabled value="'+cvar+'"></th>'
      a1+='<td> <input class="customVarDesc" type="text" size="35" title="Short description (no Html)" value=""> </td>'
      a1+='<td><input class="customVarLength" title="Width of columns displaying this variable (in % of screen width)" type="text" size="3" value="6" > </td>'
      let m0='<label style="padding:2px;margin:2px;background-color:#dfdfdf;font-size:85%">';
           m0+='<input class="requiredCustomVar" type="radio" name="admin_aParam_customRequired_'+cvar+'" value="1">Required ';
         m0+='</label>';
         m0+='<label style="padding:2px;margin:2px;background-color:#dfdfdf;font-size:85%">   ';
           m0+='<input  class="requiredCustomVar" type="radio" name="admin_aParam_customRequired_'+cvar+'" value="11">requiredNumber ';
         m0+='</label>';
         m0+='<label style="padding:2px;margin:2px;background-color:#dfdfdf;font-size:85%">   ';
           m0+='<input class="requiredCustomVar" type="radio" name="admin_aParam_customRequired_'+cvar+'" value="2">Recommended ';
         m0+='</label>';
         m0+='<label style="padding:2px;margin:2px;background-color:#dfdfdf;font-size:85%">   ';
           m0+='<input  class="requiredCustomVar" type="radio" name="admin_aParam_customRequired_'+cvar+'" value="4">optional ';
         m0+='</label>';
         m0+='<label style="padding:2px;margin:2px;background-color:#dfdfdf;font-size:85%">   ';
           m0+='<input class="requiredCustomVar" checked  type="radio" name="admin_aParam_customRequired_'+cvar+'" value="3">optional_hidden ';
         m0+='</label>';

         a1+='<td>'+m0+'</td>';

         let a2;
         a2='<label title="Use as schedulerVar variable (to create times/dates/running sums)?" style="font-size:80%"> ';
         a2+='<input type="radio" class="admin_customScheduleVar"    value="1"  name="admin_customScheduleVar"><u>Scheduler?</u></label> ';
        a1+='<td>'+a2+'</td>';

        amess+='<tr class="adminParamsRow" data-name="'+cvar+'">'+a1+'</tr>';

        et1.append(amess);
     return 1;
}


//=======
// add a new row to validnames
function admin_validNames_addRow(athis) {
   let etable=$('#adminParams_validNames');

   let a1='<tr class="adminParamsRow" data-name="">';
   a1+='<td><button style="color:red" onClick="admin_params_delRow(this)" title="remove this member">&#8998;</button></td>';
   a1+='<td><span><input type="text" title="enter a memberName: lower case, just one word" size="15" name="validNames_name" value=""></td>';
   a1+='<td><span><input type="text" title="enter a list of nicknames (seperated by spaces): lower case, each nickname is just one word\nThe actual member name is always included, so do NOT enter it here!"  size="65" name="validNames_nicknames" value=""></td>';
   a1+='</tr>';
   etable.append(a1);

}

//=======
// add a new row to downloadUsers
function admin_downloadUsers_addRow(athis) {
   let etable=$('#adminParams_downloadUsers');

    let foo=jQuery.trim(Math.random());
    let foo2=foo.substr(3,8);
   let a1='<tr class="adminParamsRow" data-name="">';
   a1+='<td><button style="color:red" onClick="admin_params_delRow(this)" title="remove this downloadUser">&#8998;</button></td>';
   a1+='<td><span><input type="text" title="enter a memberName (or username): lower case, just one word" size="15" name="downloadUser_name" value=""></td>';

  let m0='<label style="padding:2px;margin:2px;background-color:#dfdfdf;font-size:85%">';
    m0+='<input   type="radio" class="admin_downLoadUserRadio"  name="admin_aParam_downloadUser_'+foo2+'" value="0">Not allowed'
    m0+='</label>';
    m0+='<label style="padding:2px;margin:2px;background-color:#dfdfdf;font-size:85%">   ';
    m0+='<input   type="radio" class="admin_downLoadUserRadio" name="admin_aParam_downloadUser_'+foo2+'" value="1">Allowed ';
    m0+='</label>';
    m0+='<label style="padding:2px;margin:2px;background-color:#dfdfdf;font-size:85%">   ';
    m0+='<input   type="radio" class="admin_downLoadUserRadio"  name="admin_aParam_downloadUser_'+foo2+'" value="2">Use default ' ;
    m0+='</label>';

   a1+='<td>'+m0+'</td>';
   a1+='</tr>';
   etable.append(a1);

}

//==========
// read parameters values from <inputs> and send to server

function admin_params2(ifoo) {

  if (suppress_admin_edit!=0) {
     alert('Online parameter editing is disabled');
     return 0;
  }
  let  errs=[];
  let phpVals={},jsVals={};

  $('#adminParams_errors').html('').hide(); // assume no errors

  let eGeneral=$('#adminParams_general');
  let etrs=eGeneral.find('.adminParamsRow');

  for (let ie1=0;ie1<etrs.length;ie1++) {

     let aval=false;
     let aetr=$(etrs[ie1]);
     aetr.removeClass('admin_errorFound');
     let vname=aetr.attr('data-name');
     let gtype=aetr.attr('data-type');

     if (gtype=='0') continue ; // a display only row

     if (gtype=='number') {              // NUMBER input
        let eread=aetr.find('.isText');
        aval=eread.val();
        aval=jQuery.trim(aval);  // always trim
        if (!jQuery.isNumeric(aval)) {
           errs.push('A non-numeric value: '+vname);
           aetr.addClass('admin_errorFound');
        }
     }

     if (gtype=='text' || gtype=='word' || gtype=='html' || gtype=='asis' ) {  // TEXT input -- different variants
        let eread=aetr.find('.isText');
        aval=eread.val();
        aval=jQuery.trim(aval);  // always trim
        aval=fixString(aval,2);  // remove extra spaces etc

        if (gtype!='html') {
             bval=wsurvey.removeAllTags(aval);  // remove all html tags
             if (bval.length!=aval.length) {
                errs.push('HTML tags removed: '+vname);
                aetr.addClass('admin_errorFound');
             }
             aval=bval;
        }

        if (gtype=='word') {
              let bval=wsurvey.removeAllTags(aval);  // remove all html tags
              bval=fixString(aval,1);  // remove all spaces
              if (bval.length!=aval.length){
                  errs.push('Not a single word (or HTML tags removed): '+vname);
                  aetr.addClass('admin_errorFound');
              }
              aval=bval;
        }
        if (gtype=='html') {
             let bval=wsurvey.makeHtmlSafe(aval,1);
             if (bval[0]==0) {
                errs.push('Unallowed, or poorly formed, HTML removed from '+vname);
                aetr.addClass('admin_errorFound');
              }

             aval=bval[1];
        }          // note:  asis  has no processing done

     }       // txt type of input


     if (gtype=='radio') {                           // radio input -- find check button
        let eradios=aetr.find('input');
        let er1=eradios.filter(':checked');
        aval='';
        if (er1.length==0)  {
           errs.push('No button was checked: '+vname);
           aetr.addClass('admin_errorFound');

        } else {
           aval=er1.val();
        }
     }

     if (aval===false) alert('Bad gtype for : '+vname);

     if (vname.substr(0,1)=='$') {
        let tmp1=vname.substr(1);
        phpVals[tmp1]=aval;
     } else {
         jsVals[vname]=aval;
     }
  }       // trs

  if (errs.length>0) {
      let errmess='General variables have '+errs.length+' errors ';
      errmess+='<ol><li>';
      errmess+=errs.join('<li>');
      errmess+='</ol>';
      $('#adminParams_errors').html(errmess).show();
      return 1;
  }

// do customvars      ......

  let customVars={}  ; // [name]={'desc','length','required'
  let customSchedulerVar='';

  let ecustom=$('#adminParams_customVars');
  etrs=ecustom.find('.adminParamsRow');

  for (let ie=0;ie<etrs.length;ie++) {
     let aetr=$(etrs[ie]);

     let cvarname=aetr.attr('data-name');     // NAME

     aetr.removeClass('admin_errorFound');

     let ep1=aetr.find('.customVarDesc');                         // DESC
     let adesc0=ep1.val();

     let adesc=wsurvey.removeAllTags(adesc0);
     if (adesc0.length != adesc.length) {
        errs.push('custom var description should not have html: '+cvarname);
        aetr.addClass('admin_errorFound');
     }
     if (jQuery.trim(adesc)=='') {
        errs.push('custom var description is empty: '+cvarname);
        aetr.addClass('admin_errorFound');
     }

     let ep2=aetr.find('.customVarLength');                     // LENGTH
     let alength=ep2.val();
     if (!jQuery.isNumeric(alength) || alength<1 ) {
        errs.push('customVar length not a number gt 0: '+cvarname);
        aetr.addClass('admin_errorFound');
     }
     alength=parseInt(alength)

     let epcc=aetr.find('.requiredCustomVar');              // REQUIRED
     let epcc1=epcc.filter(':checked');
     let arequired=3;
     if (epcc1.length!=1) {
        errs.push('customVar required not selected: '+cvarname)
        aetr.addClass('admin_errorFound');
     } else {
       arequired=epcc1.val();
     }

     ep3=aetr.find('[name="admin_customScheduleVar"]');     // SCHEDULER VAR?
     if (ep3.is(':checked')) customSchedulerVar=cvarname;

     customVars[cvarname]={'desc':adesc,'length':alength,'required':arequired };

   }    // a custom var row

   if (customSchedulerVar=='') {
        errs.push('None of the custom vars was designated to be the <u>schedulerVariable</u>') ;
   }

   if (errs.length>0) {
      let errmess='Custom variables have '+ errs.length+' errors ';
      errmess+='<ol><li>';
      errmess+=errs.join('<li>');
      errmess+='</ol>';
      $('#adminParams_errors').html(errmess).show();
      return 1;
  }


// .... scheduler vars ...
  let esTable=$('#adminParams_scheduleVars');
  etrs=esTable.find('.adminParamsRow');
  let schedulerVars={};  //  ['name']={'width','noshow']

  for (let ie=0;ie<etrs.length;ie++) {
    let aetr=$(etrs[ie]);
    let svarname=aetr.attr('data-name');     // NAME

    aetr.removeClass('admin_errorFound');

     let ep0=aetr.find('[name="admin_scheduleVars_include"]');        // INclude?

     if (!ep0.prop('checked')) continue ;  // skip if this is NOT included


    let ep1=aetr.find('[name="admin_scheduleVars_length"]');
    let alength=jQuery.trim(ep1.val());
    if (!jQuery.isNumeric(alength) || alength<0)  {      // length=0 is an alternative way of specifying a "noShow"
       errs.push('Schedule var length is not numeric: '+svarname);
       aetr.addClass('admin_errorFound');
    }
    alength=parseInt(alength);

    let ep2=aetr.find('[name="admin_scheduleVars_noShow"]');
    let noShow=(ep2.prop('checked')) ? 1  :  0;

    schedulerVars[svarname]={'length':alength,'noShow':noShow};
  } // tr

   if (errs.length>0) {
      let errmess='Schedule variables have '+ errs.length+' errors ';
      errmess+='<ol><li>';
      errmess+=errs.join('<li>');
      errmess+='</ol>';
      $('#adminParams_errors').html(errmess).show();
      return 1;
  }

// .... validNames (for access control)
  let evTable=$('#adminParams_validNames');
  etrs=evTable.find('.adminParamsRow');
  let validNames={};
  let validNames_nick={};
  let nicks={};

  for (let ie=0;ie<etrs.length;ie++) {
    let aetr=$(etrs[ie]);
    let daNicks,daMember;
    aetr.removeClass('admin_errorFound');

    let daMemberRow=aetr.attr('data-name');     // NAME

    if (daMemberRow!=='')  {                     // existing!
        daMember=jQuery.trim(daMemberRow) ;
        let ep2=aetr.find('.validNicknames');
        daNicks=jQuery.trim(ep2.text());
    }   else {                           // NEW
        let ep1=aetr.find('[name="validNames_name"]');
        daMember=jQuery.trim(ep1.val());
        let ep2=aetr.find('[name="validNames_nicknames"]');
        daNicks=jQuery.trim(ep2.val());
    }

// cleanup (not necessary if pre existing, but wth
    let daMember0=daMember ;
    if (daMember=='') {
        errs.push('validNames: member name not specified');
        aetr.addClass('admin_errorFound');
        daMember='';
    }   else {
       daMember=wsurvey.removeAllTags(daMember);
       daMember=fixString(daMember,1);
       daMember=daMember.toLowerCase();
       if (daMember0.length!= daMember.length) {
          errs.push('validNames name is not a single word: '+daMember0);
          aetr.addClass('admin_errorFound');
       }
    }

    if (nicks.hasOwnProperty(daMember)) {
          errs.push('validNames: memberName conflicts with a prior nickname: '+daMember);
          aetr.addClass('admin_errorFound');
          continue;
    }
    nicks[daMember]=daMember;     // member name is always a nickname

    let t1=daNicks.split(/[\s,]+/);      // spaces and commas are splitters  (, , is skipped)

    for (let it1=0;it1<t1.length;it1++) {
       let anick1=jQuery.trim(t1[it1].toLowerCase());
       if (anick1==='') continue ;  // should never happen
       let anick2=wsurvey.removeAllTags(anick1);
       if (anick1.length!=anick2.length)  {
          errs.push('validNames nickname has html tags: '+daNicks);
          aetr.addClass('admin_errorFound');
       }
       if (anick2!==daMember)  { // own name as a nickname dealt with above
          if (nicks.hasOwnProperty(anick2)) {
            errs.push('validNames: nickname is already in use: '+anick2);
            aetr.addClass('admin_errorFound');
            continue;
         }
         nicks[anick2]=daMember;   // might overwrite own name, but so what
       }
     }         // for it1
  }    // tr

//     let nicknames=[];
//     for (let anick in nicks) nicknames.push(anick);
//     let nickNamesUse=nicknames.join(',');
//
//     validNames[vvarname]=nickNamesUse;
//  }   // tr

    validNames=nicks;
    if (errs.length>0) {
      let errmess='validNames variables have '+ errs.length+' errors ';
      errmess+='<ol><li>';
      errmess+=errs.join('<li>');
      errmess+='</ol>';
      $('#adminParams_errors').html(errmess).show();
      return 1;
    }    // error


/// ========
// downloadUsers
  let edTable=$('#adminParams_downloadUsers');
  etrs=edTable.find('.adminParamsRow');
  let downloadUsers={};

  for (let ie=0;ie<etrs.length;ie++) {
    let aetr=$(etrs[ie]);
    aetr.removeClass('admin_errorFound');

    let duser,vvarname0,allowed=0;

    let vvarnameRow=aetr.attr('data-name');     // NAME

    if (vvarnameRow!=='')  {                     // existing!
        vvarname0=jQuery.trim(vvarnameRow) ;
    }   else {                           // NEW
        let ep1=aetr.find('[name="downloadUser_name"]');
        vvarname0=jQuery.trim(ep1.val());
        if (vvarname0=='*') {
          errs.push('downloadUsers: * can not be used as a name');
          aetr.addClass('admin_errorFound');
       }

        if (vvarname0=='') {
          errs.push('downloadUsers: name not specified');
          aetr.addClass('admin_errorFound');
       }
    }
    let vvarname=wsurvey.removeAllTags(vvarname0,1);
    vvarname=fixString(vvarname,1);
    vvarname=vvarname.toLowerCase();

    if (vvarname.length != vvarname0.length) {
          errs.push('downloadUsers: name was not a single (non-html) word: '+vvarname0);
          aetr.addClass('admin_errorFound');
    }

    let eradios=aetr.find('.admin_downLoadUserRadio');
    let eradio=eradios.filter(':checked');
    if (eradio.length!=1) {
          errs.push('downloadUsers: A canDownload option was not checked: '+vvarname0);
          aetr.addClass('admin_errorFound');
    } else {
       allowed=eradio.val();
    }

    downloadUsers[vvarname]=allowed;
  }     // tr
  if (errs.length>0) {
      let errmess='validNames variables have '+ errs.length+' errors ';
      errmess+='<ol><li>';
      errmess+=errs.join('<li>');
      errmess+='</ol>';
      $('#adminParams_errors').html(errmess).show();
      return 1;
  }

// ==== the site intro
   let eIntro=$('[name="adminVar_siteIntro"]');

   let siteIntro0=jQuery.trim(eIntro.val());
   eIntro.removeClass('admin_errorFound');

  let s1=wsurvey.makeHtmlSafe(siteIntro0,1);
  if (s1[0]==0) {
      errs.push('siteIntro: unallowed or misspecified HTML');
      eIntro.addClass('admin_errorFound');
  }
  
    if (errs.length>0) {
      let errmess='Site Introduction problem ';
      errmess+='<ol><li>';
      errmess+=errs.join('<li>');
      errmess+='</ol>';
      $('#adminParams_errors').html(errmess).show();
      return 1;
  }
  siteIntro=s1[1];
 
// NOW ready to save to server!
 let ddata={};
 ddata['phpVars']=phpVals;
 ddata['jsVars']=jsVals;
 ddata['theProject']=useProject ;
 ddata['pwd']=theAdminPassword;
 ddata['customVars']=customVars;
 ddata['customSchedulerVar']=customSchedulerVar;
 ddata['schedulerVars']=schedulerVars;
 ddata['validNames']=validNames;
 ddata['downloadUsers']=downloadUsers;
 ddata['siteIntro']=siteIntro;

 ddata['todo']='saveParams';

    $.ajax({
        url: 'choicer_admin.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function(response) {             // callback
       if (typeof(response['error'])!='undefined') {
          alert(response['error']);
          return 0;
       }
       admin_params2a(response);
    });

}
//=--------
// callback
function  admin_params2a(response) {
  if (typeof(response)=='object')  wsurvey.dumpObj(response,1,' return from servers ');
   let amess=response ;
   amess+='<br><button title="click to logoff"  onclick="doLogon(3)">reLoad the page (and relogon) to see use the revised parameter settings';
   $('#adminParams_errors').html(amess).show();
   return 1;

}


//====================
// create a projecdt
function admin_project(ifoo) {
  let e1=$('#myadminMenu_edit');
  let amess='';
  amess+='<div style="background-color:#dfcfdf"> <span style=font-weight:700">Create a new project!</span>';

  let daprojects=[];
  for (let aa in choicerProjects) {
     daprojects.push(aa);
  }
  amess+='<span style="margin-left:4em"> <em>To modify one of the '+daprojects.length+' existing project:</em> chose the project (from the list-of-projects menu on the home page), and logon as <tt>admin</tt></em></span>';
  amess+='</div>';

  amess+='<table style="margin:5px 3em;border:3px solid gray" id="admin_newProjectCreate" cellpadding="3" rules="rows">';
  amess+='<caption>Specify a new project, and then <input type="button" value="Save it" onClick="admin_project_2(this)"> </caption>';
  amess+='<tr><td>1 word name:</td><td> <input type="text" name="aname" size="15" title="one word name (will be converted to lower case"> </td></tr>';
  amess+='<tr><td>Short description (no html)</td><td> <input name="adesc" type="text" size="65" title="Short description"> </td></tr>';
  amess+='</table>';
  
  amess+='<div id="admin_projectCreate_result" style="display:none;margin:1em 5em;border:3px solid blue">...</div>';
 e1.html(amess).show();
}

//============
// read new projects specs
function admin_project_2(athis) {
   ethis=wsurvey.argJquery(athis);
   let etable=ethis.closest('#admin_newProjectCreate');
   let ename=etable.find('[name="aname"]');
   let aname=ename.val();
   let aname2= fixString(aname,1);
   if (aname=='' || aname.length!=aname2.length) {
      alert('The project name must be a single word');
      return 0;
   }
   let projectName=aname2.toLowerCase();

   let edesc=etable.find('[name="adesc"]');
   let adesc=jQuery.trim(edesc.val());
   if (adesc=='') {
      alert('Please enter a project description');
      return 0;
   }

   adesc=wsurvey.removeAllTags(adesc);

   let adate=wsurvey.get_currentTime(31,1);

   let ddata={};
   ddata['name']=projectName;
   ddata['pwd']=theAdminPassword;
   ddata['desc']=adesc;
   ddata['created']=adate;
   ddata['todo']='createProject';

   $.ajax({
        url: 'choicer_admin.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function(response) {             // callback
//      wsurvey.dumpObj(response,1,'asfasf');
     $('#admin_projectCreate_result').html(response).show();
    });

}

//=-===================
// copy the default parameter files
function admin_project_3(athis) {
  let ethis=wsurvey.argJquery(athis);
  let projectName=ethis.attr('data-pname');
   let ddata={};
   ddata['name']=projectName;
   ddata['pwd']=theAdminPassword;
   ddata['todo']='copyParameters';

   $.ajax({
        url: 'choicer_admin.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function(response) {             // callback
     useProject=projectName ;   // save to global
     $('#admin_projectCreate_result').html(response).show();

    });

}

//=============
// reload with this project.
// 6 april 2023: its a hack to reload, but its a pain to read the choicer_parmas files.
// Could do some kind of auto logon (but how to avoid sending password ...
function admin_project_4(athis) {
  let ethis=wsurvey.argJquery(athis);
  let pname=ethis.attr('data-pname');

 let asearch='?project='+pname+'&user=admin';
  let oof=window.location.protocol + "//" + window.location.host + window.location.pathname + asearch;

  window.location.href = oof;
}



//===================
// cleanup old (hence unused) files in submit/ (for this project)
// .ctg,   rnk  rcm   rcw   sch files have this feature (new versions are used instead of newer ones -- by user and project
// first step: report how many
function adminProjects_cleanup(athis)  {

   let ddata={};
   ddata['theProject']=useProject;
   ddata['pwd']=theAdminPassword;
   ddata['todo']='cleanup';

   $.ajax({
        url: 'choicer_admin.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function(response) {             // callback
      if (!response.hasOwnProperty('Retains')) {
         wsurvey.dumpObj(response,1,'error in cleanup' );
         return 1;
      }
      let nRetains=response['Retains'].length;
      let nDels=response['Dels'].length;
      let nErrs=response['Errs'].length;
      let amess='<b>Cleanup of project</b>  <tt>'+useProject+'</tt>: <em>.ctg, .rnk, .rcm, rcw, and .sch files</em>';
      amess+='<br> There will be: ';
        amess+='<ul> ';
        amess+='<li>Retained files: <tt>'+nRetains+'</tt>';
        amess+='<li>Deleted files: <tt>'+nDels+'</tt>';
        amess+='<li>Unable to delete: <tt>'+nErrs+'</tt>';
        amess+='</ul>';
        amess+='<button onClick="adminProjects_cleanupGo(1)">Do the cleanups!</button>';
       let eshow=$('#myScheduleAdmin_alert');

       eshow.html(amess).show();
    });


}

//==========
// and do the cleanup
function adminProjects_cleanupGo(athis) {
  
     let ddata={};
   ddata['theProject']=useProject;
   ddata['pwd']=theAdminPassword;
   ddata['todo']='cleanupDel';

   $.ajax({
        url: 'choicer_admin.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function(response) {             // callback

       let eshow=$('#myScheduleAdmin_alert');
       eshow.prepend('<div style="margin:1em;border:1px solid lime">'+response+'</div>').show();
    });

}

//===================
// archvie submit/
// step 1: check for ZipArchive and submits/backups
function adminProjects_submitZip(ifoo) {
    let ddata={};
   ddata['theProject']=useProject;
   ddata['pwd']=theAdminPassword;
   ddata['todo']='zipSubmits';
   $.ajax({
        url: 'choicer_admin.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function(response) {             // callback
   // wsurvey.dumpObj(response,1,'step1');
       let eshow=$('#myScheduleAdmin_alert');
       eshow.html('<div style="margin:1em;border:1px solid lime">'+response+'</div>').show();
    });

}

//===================
// archvie submit/
// step 2: make the backup
function adminProjects_submitZipGo(athis) {
   let ethis=wsurvey.argJquery(athis);
   let useProject=ethis.attr('data-project');

    let ddata={};
   ddata['theProject']=useProject;
   ddata['pwd']=theAdminPassword;
   ddata['todo']='zipSubmitsGo';
   $.ajax({
        url: 'choicer_admin.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function(response) {             // callback
    //wsurvey.dumpObj(response,1,'step2');
       let eshow=$('#myScheduleAdmin_alert');
       eshow.prepend('<div style="margin:1em;border:1px solid lime">'+response+'</div>').show();
    });

}

//===========
// list current projects
function adminProjects_projectList(athis) {
    let ddata={};
   let e1=$('#myScheduleAdmin_alert');
   if (e1.is(':visible')) {
      e1.hide();
      return 1 ;
   }
   ddata['theProject']=useProject;
   ddata['pwd']=theAdminPassword;
   ddata['todo']='projectList';
   $.ajax({
        url: 'choicer_admin.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function(response) {             // callback

       adminProjects_projectList2(response);
    });
}

//=========
// callback
function adminProjects_projectList2(response) {
     //  wsurvey.dumpObj(response,1,'stepxx3');
 let checks=['&#8709;' ,'&#9989;'];
 let dlist=['cache','params','publish','submits','backup'];
 let amess='<b>Project list</b>';
 amess+='<table cellpadding="5" rules="rows">';
 amess+='<tr><th width="15%">Name</th>  <th>cache dir?</th> <th>params dir?</th> ';
 amess+='      <th>publish dir?</th> <th>submits dir?</th> <th>submits/backup dir?</th><th>Init.txt</th> ';
 amess+='</tr>';
 for (let aa in response['projects']) {
    let aproj=response['projects'][aa];
    if (aproj['name']==useProject) {
      amess+='<tr><td title="currently selected project"><b>'+aproj['name']+'</b></td>';
    } else {
       amess+='<tr><td><u>'+aproj['name']+'</u></td>';
    }
    for (let im=0;im<dlist.length;im++) {
       let adname='got_'+dlist[im];
       let yup= aproj[adname];
       amess+='<td>'+checks[yup]+'</td>';
    }
    if (aproj['gotInit']==0) {
       amess+='<td><div style="font-size:80%">&#9940;</div></td>';
    } else {
      let tt1=aproj['init_text'];
      tt1=tt1.replace(/\n+/g, "<br>") ;
      amess+='<td><div style="font-size:80%">'+tt1+'</div></td>';
    }
    amess+='</tr>';
 }
 amess+='</table>';
 amess+='<hr><u>Project header:</u> <tt>'+fixString(response['introFile'],2)+'</tt>';
 amess+='<br><em>The project header is specified in data/projectIntro.html</em>';

 let eshow=$('#myScheduleAdmin_alert');
 eshow.html('<div style="margin:1em;border:1px solid lime">'+amess+'</div>').show();

 return 1;
}
