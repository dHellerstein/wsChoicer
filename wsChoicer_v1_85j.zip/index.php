<!DOCTYPE HTML>

<html><head><title> wsChoicer: you can solicit suggestions ... rate ... rank ...  recommend  ... schedule! </title>
<meta charset="utf-8">

<!-- For small groups (<40) of people to collect, consider, and choose a mid sized set of choices (<100) -->

<script type="text/javascript" src="lib/jquery-3.6.0.min.js"></script>
<script type="text/javascript" src="lib/md5b.js"></script>
<script type="module" src="lib/js.cookie.js"></script>
<script type="text/javascript" src="lib/keyShortcut.js"></script>

<script type="text/javascript" src="lib/wsurvey.sortTable.js"></script>
<script type="text/javascript" src="lib/wsurvey.utils1.js">  </script>
<script type="text/javascript" src="lib/wsurvey.wsShow.js">  </script>

<script type="text/javascript" src="choicer.js"></script>
<script type="text/javascript" src="choicer_1.js"></script>
<script type="text/javascript" src="choicer_shows.js"></script>
<script type="text/javascript" src="choicer_lib.js"></script>
<script type="text/javascript" src="choicer_viewer.js"></script>
<script type="text/javascript" src="choicer_newSugg.js"></script>
<script type="text/javascript" src="choicer_rate.js"></script>
<script type="text/javascript" src="choicer_rank.js"></script>
<script type="text/javascript" src="choicer_reco.js"></script>

<!-- 8 april 2023: load when needed (in showSchedule(), ... ) -->
<!-- <script type="text/javascript" src="choicer_sched.js"></script> -->
<!-- <script type="text/javascript" src="choicer_sched2.js"></script> -->

<script type="text/javascript">

// ========================== Define   global variables =====================

// read md5 passwords from php include file
// This sets the adminPwd  global (its md5 hash), using value read from params/choicer_init.php

<?php
   $curDir=getcwd();
   $getPwdsFile=$curDir.'/params/choicer_init.php';

   if (!file_exists($getPwdsFile)) {
      $amess="Problem: <tt>$getPwdsFile</tt> does not exist. You might need to re-install wsChoicer.";
      $amess.=" <br>Hint: you can use choicer_init_orig.php ";
      ob_end_clean();   // remove prints and other crap
      print $amess ;
      exit;
   }

   require_once($getPwdsFile);
   if (!isset($adminPwd)) $adminPwd=false;
   if ($adminPwd===false  )  {    // first open of wsChoicer -- initialiaze!
      $doInitFile=$curDir.'/includes/choicer_doInit.php';
      if (!file_exists($doInitFile)) {
         $amess="Problem: <tt>$doInitFile</tt> does not exist. You might need to re-install wsChoicer.";
         ob_end_clean();   // remove prints and other crap
         print $amess ;
         exit;
      }
      require_once($doInitFile);
      exit;
   }


   
// else, not first-open initialization
   print 'var adminPwd=\''.$adminPwd.'\' ; '."\n";

// will be filled from useProject/params/choicer_passwords.php
   print "var memberPassword='' ; \n";
   print "var localDownloadKeycode=''  ; \n";

   $arf=isset($defaultProject);
   if (!$arf) $defaultProject='*';

   $qq=checkProject($defaultProject);  // read project, or produce a list to bhoose vom
   if ($qq===false) exit;
?>

// ::::::::::::::::::: Some admin configurable  global  parameters  :::::::::::

// Note that a number of admin  settable parrameters are read from src/choicer_params.js (read by init())

// version number.
var verNumber='1.85j';


// set to 1 to disable online edit-admin-parameters tool. If set, admin must edit files to change parametesr
// set to 0 to enable online tools.
var suppress_admin_edit=0  ;

//  These are less likely to be changed ...

// xx_colWidths are used to specify column widths to use on various table.
// size is "roughly" in em -- it will be normalized to be % (after adding in custom variable widths)
// Custom variable widths are set in choicer_params.php

var suggestTable_colWidths={'sort':2,'who':6,'name':15,'category':7, 'rate':9,'rank':9,'reco':9,'links':10,'notes':32};

var rateTable_colWidths={'sort':2,'who':6,'name':15,'category':6, 'rate':24, 'links':12,'notes':46};

var rankTable_colWidths={'sort':2,'name':15,'category':6,
                         'avgrate':8,'myrate':8,'doranks':15,'summary_rank':12,'allrankings':18,'recommend':5};

var recoTable_colWidths={'sort':2,'name':13,'category':8,
                          'avgrate':8,'imprate':8,'summary_rank':10,'allranks':50,'recos':7};

var choiceNameClass='sayChoiceNameBlue'  // select one of: sayChoiceName,sayChoiceNameNotBold,sayChoiceNameBlue -- class used to highlight suggestion name in view suggestions table


//  used to show ownRate (on several pages)
var rateIcons=['&#8709;','&#9312;','&#9313;','&#9314;','&#9315;']; // null, circled 1 2 3 4
var rateClass=['rateClass0','rateClass1','rateClass2','rateClass3','rateClass4']; // null, circled 1 2 3 4
var rateSays=['not yet rated','blah','okay','good','great'];

//  used to show ownRank (on several page)
var  rankIcons=['&empty','&#127299;','&#127293;','&#8861;'];
var  rankClass=['n.a.','ctop9_list','cnext9_list','rankClassNot'];
var  rankSays=['n.a.','top 9 ranking','next 9 ranking','not ranked'];

// Icons used in "Links"
// an object with icon names and urls to an image file
//  These are used when specifying Links -- the member is given a choice of which of these icons to use
//  when displaying a link (using an <img> with height=30 and width=20).
//  If you specify a relative url, it will be relative to the home page (where index.php is located).
//  Note that the case of the iconname does not matter (it will be converted to lower case)
// 'iconName':'url' (if relative, relative to home directory
//Note that a generic icon is used for downloads from this sites server:
//   a brown box with a down arrow (imgs/download.png)
//And two other icons are always available (they do not have to be specified in linkIcons
//     a green monitor (imgs/wwwLink.gif)
//      'download'  (imgs/download.gif)


var linkIcons={'tubi':'imgs/tubi.gif',
               'youtube':'imgs/youTube.gif',
               'ebay':'imgs/ebay.gif',
               'amazon':'imgs/amazon.gif'} ;


// =========================== End of admin settable global  parameters ===================

//  The following are set in  params/choicer_params.js. Thus, the values here are NOT used!
//  Hint: see  params/choicer_params_orig.js for a description of these parameters
var autoShowHelp= 0  ;
var autoStatusMessages= 0 ;
var autoShowIntro=0;
var compressHeaderRow=0 ;
var defaultRate=2;
var disableNewSuggestions=0 ;
var enableAlertRate=0  ;
var enableAlertRank=1  ;
var enableNewUserCheck=0 ;
var enterToDo='view' ;
var noSubmitterInNotes=0;
var passwordUse=0;
var rankingsLinearMenu='b' ;
var scheduleVarUse=''  ;
var siteAdminContact="admin";
var suppressLocalDownload=0;
var skipBlankCategories=0;

// these customize text displayed on various pages
var choiceNameSay='Choice';
var choiceNameSay2='Choices';
var scheduleHeaderName="The schedule"  ;
var scheduleStatusMessage='draft' ;
var welcomeGroupName="A group "  ;
var thisSiteHame="Our site" ;
var documentTitle="wsChoicer .... solicit suggestions ... rate ... rank ...  recommend  ... schedule! " ;

// Reminder: the above are overwritten when params/choicer_params.js is read by init()

// Note: params/choicer_params.php  has a few admin settable variables


// other globals


var isAdminUser=false ;           //if user is Admin, with correct pasword, this is set to true
var theAdminPassword='';           // sent to server when calling choicer_admin.php

var urlUserName=getQueryStringParams('user');


var noChangesAllowed=false ;     // set  if enableNewUserCheck=2

var lastToDo=enterToDo ;         // when reloading, show the most recently opened page (sugg,rank, etc)

var myLogonName='' ;             // retain case of logon name. This is rarely used.
var currentUserName='';    // will be a one-word, lowerCase, no odd characters version of logonName. Used extensively!!

var actualMemberName='';   // returned from server (could be '' if not in validNames, and checkValidNames=0
var checkValidNames=0 ;  // returned from server -- the $checkValidNames value (in choicer_params.php)
var validNamesList=[];  // returned from server -- built from $validNames (in choicer_params.php)
var validNamesLookup={};  // built from validNamesList

var nReloads=0;            // # of reloads this session. Not actively used  (3/2/2023)

var scheduleStuff={'list':[[],'']} ;  // used by schedule reorder

var statusMessageList=[];

// globals returned from server  -- so these values are overwritten (in choicer_1.js)
var  choiceArray=[] ;       // array of non-removed choices (in order of submission, oldest first). Values are ids (pointers into choiceList)
var  choiceArrayOrig=[] ;       // array of ALL hoices (in order of submission, oldest first). Values are ids (pointers into choiceList or removeChoices)
var  choiceList={} ;       // attributes, own rating/ranking/reco, and summary status for all suggestions.
var removeChoices={} ;    // list of choices that are removed (index by id)
var  choiceNames={}  ;    // indices are short versions of suggeestion names (commas after spaces remove, no multiple spaces) -- used to detect duplicates
var discardedChoices={};   // discasrded suggestions due to invalid submitter (i.e.; submitted by a non-member, but checkValidNames enabled

var customVarList={};     // list of custom variables (varnames as indices, with length as values)
var basicStats={} ;       // various summary statistics
var membernameList={};      // list of usernames. Id is username. Fields are 'nsuggest','nrate','nrank','nrecommend'
var allCategories={'all':{},'current':''} ;    // categories (For each choice) for all users
var allRates={};          // ratings (for each choice, if one was made) for all users
var nMissingRates=0;    // number of ratings for removed suggestions (could be more than # of removed suggestions)
var allRanks={}           // rankings (for each choice, if one was made) for all users
var allRecos={}           // recommendations, current and draft, for all users
var allScheds={} ;          // all the saved schedules
var repeats={};            // suggestions that are repeated (more than one entry with same "short" name)
var modified={}  ;         // suggestins that have been modified (by admin)
var schedulerType='time' ;    // the type of schedule to create (time,date,quantity,order)
var schedulerShow={} ;       // what variables to show in formatted schedule
var schedulerNoShow={};
var schedulerShowAddAll=0;

// these are set in choicer_params.php
var siteIntro="Welcome! ";      // a site introduction (can be several lines long)
var privateDownloadLink='' ;   // prepended to download links  in choicer_params.php
var  downloadUsers={'*':1};   // default is everyone can download. This is overwritten using info from server

// which project? Perhaps the default (as specified in choicer_init.php)
// or perhaps one specified in the query string?

$(document).data('showingMain','') ; // set by showxx functions  [eUse,todoName,mode (0..)]

// ========================== End of globals =====================

window.onload=init;  // intialize on load .. will read global paramers and the call init2


// Note: all openable "top level" (children of the <body>d) containers should have one of these attributes
// data-helpbox : a help box      -- unchanging  (or only set at logon) content
// data-infobox  : other information display -- updated in real time depending on choices and suggestions
// data-content : core (suggestions, etc) information display
// The string values of these should be a short description
// Exceptions: the header (top bar) and footer
//
// The data-content also have a name="mainContainer".
// They are (by id):
//  newSuggestionsDiv : new suggestions table
//                    table (a stub, with an add rows button) i written to newSuggestionsDivTableOuter
//  suggestionsDiv: the "view suggestions" (attributes, your choices, summary stats)
//                  full table   written to existingEntriesDivTableOuter
//                  includes help/suggHelp.html, which has a link to a "data-helpbox" (fixed)   help container
//  ratingsDiv   : ratings/category/notes table
//                 full table written to ratingsDivTableOuter
//                 includes  help/rateHelp.html ,  which has a link to a "data-helpbox" (fixed)   help container
//  rankingsDiv   : rankings table
//                full table written to rankingsDivTableOuter
//                includes help/rankHelp.html, which has a link to a longer "data-helpbox" (fixed)   help container
// recommendationsDiv : recommendations table, and details on ratings & rankings
//                data rows appended to a stub (<tr><th>... row), that is first written to theRecommendationsTableOuter
//                   Note that recoTableTop.html is used (on php side) to specify the stub
//                        This is beause the top row is  complicated (with several custom-sort buttons, that are modified after logon).
//               include help/recoHelp.html help, which has a link to a "data-helpbox" (fixed)   help container
//   scheduleDiv   :: schedule specifications
//
//   genericComments :  general comments (and ranking and recommendation comments)
//               content (as list) written to genericCommentsInner
//

//=============
// some setups
//
// step 1: read parameters file. If success,  initJsRead will call init2 (actually initialization)
// if fail, stop
// note that doLogon is invoked AFTER a user action (entering a user name)
// Until then, there is no server communication

function init(x,daproject,gotPubSchedule) {

// to be sure it happens, do this here
if (suppress_admin_edit!=0) {               //   suppress_admin_edit can be set above
   $('#admin_editParams_li').html('<tt>online parameter editing is disabled</tt>');
}
let aproject;
if (arguments.length<2) {
   aproject=useProject;
} else {
//  let ethis=wsurvey.argJquery(evt);
//  aproject=ethis.attr('data-pname');
  aproject=daproject ;
}

if (aproject=='*') {     // show menu of projects (for user to seledt from)
   $('#iLogonBox').hide();
   $('#siteHeaderTopRow').hide();
   let oy1='<div id="projectSelectDiv_errors" style="border:4px solid yellow;margin:3px 5em 3px 5em;display:none"></div>';
  $('#projectSelectDiv').html(oy1+choicerProjectsMenu).show();
  return 1;
}
useProject=aproject  ;                                          // useProjet is global

 // $('#projectSelectDiv').hide();
 $('#iLogonBox').show();
 $('#siteHeaderTopRow').show();

 if (gotPubSchedule==1) {
    $('#viewPublishedSchedule').show();
 } else {
   $('#viewPublishedSchedule').hide();
 }
 $('#projectSelectDiv').hide();
 let daJs='data/'+useProject+'/params/choicer_params.js';
$.getScript(daJs)
 .done(function(a,b,c) {
     initJsRead(a,b,c,useProject) ;
 }).
 fail(function(a,b,c) {
     initJsReadFail(a,b,c,daJs);
 });
}

//==========
// backup files to vxxx dir
function copyStuff(ii) {
  let ddata={};
  ddata['theProject']=useProject ;

    $.ajax({
        url: 'choicer_backup.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function (response) {
      wsurvey.dumpObj(response,1,'copy');

    });
}


// https://stackoverflow.com/questions/901115/how-can-i-get-query-string-values-in-javascript
function getQueryStringParams(sParam)  {
    var sPageURL = window.location.search.substring(1);
    var sURLVariables = sPageURL.split('&');

    for (var i = 0; i < sURLVariables.length; i++) {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam)        {
            return sParameterName[1];
        }
    }
    return false;
}

//===========
// project chosen, get some more info from server about it
function init_gotProject(athis) {
   ethis=wsurvey.argJquery(athis);
   let aproject=ethis.attr('data-pname');
   let ddata={};
   ddata['theProject']=aproject;

    $.ajax({
        url: 'choicer_getProjectInfo.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function (response) {

      let errs=[];
      if (response['gotJs']==0) errs.push('No choice_params.js file! ');
      if (response['gotPhp']==0) errs.push('No choice_params.php file! ');
      if (response['gotPasswords']==0) errs.push('No choice_passwords.php file! ');
      if (errs.length>0) {
          let oof='<div style="padding:5px">';
          oof+='Errors: unable to use project <tt>'+aproject+'</tt>';
          oof+='<ul><li>'+errs.join('<li>')+'</ul>';
          oof+='<input type="button" onClick="init_gotProject_admin(this)" value="Logon as admin" title="Enter the admin password, and then logon"><input type="text" size="15" title="enter admin password" name="admin_logon_1" > <em>and setup params files</em>...';
          oof+='</div>';
          $('#projectSelectDiv_errors').html(oof).show();
          $('#iLogonBox').hide();
          return 0;
      }

      let gotPubSchedule=0;
      let pubSchedules=response['viewPublish'];
      if (jQuery.trim(pubSchedules)!='') {        // display "view a published/public schedule" listf
         gotPubSchedule=1;
         $('#viewPublishedSchedule').html(pubSchedules).show();
      }

      init(1,aproject,gotPubSchedule);   // and show logon box

    });
}

//=========================
function init_gotProject_admin(athis) {
   let ethis=wsurvey.argJquery(athis);
   let eli=ethis.closest('div');
   let e1=eli.find('[name="admin_logon_1"]');
   let pval=jQuery.trim(e1.val()).toLowerCase();
   let md5aa=md5(pval);
   if (md5aa!=adminPwd) {
      alert('Incorrect');
      return 1;
   }
   theAdminPassword=pval;
   currentUserName='admin';
   isAdminUser=true;
   useProject=false;   // no project selected
   $.getScript( "choicer_admin.js" )
    .done(function(a,b,c) {
       showAdminMenu(2 ) ;
   }).
   fail(function(a,b,c) {
     initJsReadFail(a,b,c,daJs);
   });


   theAdminPassword=pval;
   showAdminMenu(1);

}

//=======================
// admin logon from top page (select project  page)
function adminLogon(i1) {

   let aa=prompt('Enter the admin password: ','password');
   aa=jQuery.trim(aa.toLowerCase());
   let md5aa=md5(aa);
   if (md5aa!=adminPwd) {
      alert('Incorrect');
      return 1;
   }
   theAdminPassword=aa;
   currentUserName='admin';
   isAdminUser=true;   // admin logon (global)
   useProject=false;   // no project selected  (global) 
   $.getScript( "choicer_admin.js" )
    .done(function(a,b,c) {
       showAdminMenu(2 ) ;

   }).
   fail(function(a,b,c) {
     initJsReadFail(a,b,c,daJs);
   });



}


</script>

<link rel="stylesheet" type="text/css" href="css/choicer_other.css" />
<link rel="stylesheet" type="text/css" href="css/choicer_several.css" />
<link rel="stylesheet" type="text/css" href="css/choicer_view.css" />
<link rel="stylesheet" type="text/css" href="css/choicer_rate.css" />
<link rel="stylesheet" type="text/css" href="css/choicer_rank.css" />
<link rel="stylesheet" type="text/css" href="css/choicer_reco.css" />
<link rel="stylesheet" type="text/css" href="css/choicer_sched.css" />

<style type="text/css">


</style>

<! ================================================================= -->

</head>

<!-- :::::::::::::::::::::  ::::::::::::   Body start        ::::::::::::::::::::::: :::::::::::::::::::-->

<body>

<div   id="siteHeader" class="csiteHeader">

<div style="width:99vw;padding:2px;min-height:1.9em" title="Header line"  id="siteHeaderTopRow" class="canCompressOuter">

<span style=" display:inline-block;float:left;margin-left:3px">
  <a name="topScreen">&nbsp;</a>
  <button class="pointerCursor" onClick="doLogon(2)" title="logoff, or logon under a different name">logoff</button> <!-- left corner of main page -->

   <button class="topRowButtonOther2" style="display:none" title="click to reload: use this to incorporate changes " onclick="doReload()">Reload </button>

  <button class="cSideButtons"  style="font-size:90%;padding:1px;margin:1px"   id="icompressHeaderButton"
      onClick="doCompressHeaderRow(this)" data-status="0" title="expand this row"  >&#11246;</button>
</span>
<span style=" display:inline-block;float:left;margin-left:4px">
    <span id="welcome_1">Welcome</span></a>
    <span class="sayLogonName"  name="logonNameSay" id="iLogonNameTop" ></span>
    <span class="canCompress" style="display:inline-block">
       to  <span style="white-space:nowrap" name="welcomeGroupName">your group name</span>
    </span>
</span>

   <button  id="topRowButton_view" class="cTopRowButton  "
           title="View the current suggestions"
            onclick="showCurrentSuggestions(1)"    >
          &#128083;  View <span class="canCompress">  suggestions</span>
   </button>
   <button  id="topRowButton_add" class="cTopRowButton  "
           title="Add one or several suggestions"
            onclick="showNewSuggestions(1)"    >
           &#9998;  Add <span class="canCompress"> suggestions</span>
   </button>
   <button  id="topRowButton_rate" class="cTopRowButton"
           title="Rate a suggestion, assign to categories, and add Links and descriptive notes "
            onclick="showRatings(1)"    >
           &#127898;&#65039; &Rscr;ate &hellip; <span class="canCompress"> + add notes &amp; categories</span>
   </button>

   <button  id="topRowButton_rank"  class="cTopRowButton"
           title="rank the suggestions (your personal top and next 9)   "
            onclick="showRankings(1)"     >
            &#8811; &real;ank  <span class="canCompress"> suggestions </span>
   </button>

   <button  id="topRowButton_recommendation"  class="cTopRowButton"
          title="make recommendations, and view details on rankings and ratings "
          onclick="showRecommendations(1)">
     &#127479;ecommend <span class="canCompress">  +  view rankings &amp; ratings </span>
    </button>

       <button  id="topRowButton_schedule"  class="cTopRowButton"
          title="create a schedule"
          onclick="showSchedule(1)">
     &#128197; schedule <span class="canCompress">  create  </span>
    </button>

    <button  id="topRowButton_comm"   class="cTopRowButton"     title="click to toggle view of the general comments & ranking comments"
           onclick="showComments(1)"  > &#128211;  comments
    </button>

  <span class="topRowButtonOther" style="float:right;margin-right:1.5em">     <!-- settings  -->
    <button type="button"    title="admin settings"   style="display:none"
           onclick="showAdminMenu(1)"   id="topRowButton_admin" >&#9784;</button>
  </span>

  <span class="topRowButtonOther" style="float:right;margin-right:0.2em">     <!-- help button -->
    <button type="button"  class="topRowButtonOtherHelp" title="hints on using this site"
           onclick="showMainHelp(1)"   id="topRowButton_help" > &#8505;&#65039; Help</button>
 </span>


  <span style="float:right;margin-right:0.5em"  class="topRowButtonOther">     <!-- statistics button -->
     <button  value="&#127274;tatistics" title="statistics on site usage: by user, and by choice"
           onclick="showMemberInfo(1)"   class="topRowButtonOtherHelp"  id="topRowButton_stats" >
           <img src="imgs/activityHistory.gif" height="15" width="20" /> &#127274;tatistics
     </button>
 </span>


  <span style="float:right;margin-right:0.5em"  class="topRowButtonOther  ">     <!-- intro  button -->

    <button  class="topRowButtonOtherHelp topRowButtonOtherPlus wsShowS"   data-wsshow="#showIntroduction"
           title="Read the introduction"  >&#128214;Intro</button>


  <span>


</div>     <!-- siteHeaderTopRow-->
</div>   <!-- site header -->


<!-- :::::::::::::::::::::  ::::::::::::       ::::::::::::::::::::::: :::::::::::::::::::-->
<!-- ::::::::: the new (add)  suggestions container :::::::::: -->

<div id="newSuggestionsDiv" class="cnewSuggestions" data-content="New suggestions"  name="mainContainer"   >
 <div id="newSuggestionsDivMainHeader" class="csuggestionsDivMainHeader">
    <button  class="cCloseButton wsShowH"   data-wsshow="-2"  title="click to close... ">&#128473;</button>

    <button id="addSuggestionsHelpButton"  class="cHelpButton " onClick="addSuggestionHelp(1)">&#10068;</button>

    <button  onClick="showCurrentSuggestions(4)" class="cshowCurrentSuggestions4" title="view the existing suggestions" >&#128374;</button>
    <span class="csugg_mainHeader1"  > &#9998; Add one or more suggestions</span>.
  </div>     <! -- newSuggestionsDivMainHeader -->

<div id="newSuggestionsDivTableOuter" >

</div>  <!-- newSuggestionsDivTableOuter -- -->

</div >   <!-- newSuggestionsDiv -->


<!-- :::::::::::::::::::::  ::::::::::::       ::::::::::::::::::::::: :::::::::::::::::::-->
<!-- ::::::::: the view suggestions container :::::::::: -->

<div id="suggestionsDiv"  class="cmainDivOuter"  data-content="View suggestions details,  and summaries of r
     ating/rankings/recommendations"  name="mainContainer"  >

<div id="suggestionsDivMain"  class="cDivMain" >

 <div id="suggestionsDivMainHeader" class="csuggestionsDivMainHeader">
  <input type="button" value="&neArr;" title="view existing suggestions in a new window" class="showInNewWindow"
       data-in_new_window_header="Current suggestions: attributes, and your own and summary values of rate/rank/reco"
       data-in_new_window_find="#existingEntriesDivTableOuter">

    <button id="viewSuggestionsHelpButton"  class="cHelpButton wsShowS"  name="helpButtonMain"
        data-wsshow="#viewSuggestionsHelp"   data-wsshow_alt="#iSuggestionsHelpMore"
        title="Using the view suggestions table&#010;Or double click to see the details!">&#10068;</button>

    <button onClick="showCommentsInView(1)" class="cshowComments4"  title="View the generic comments" >&#128210;</button>
    <button id="iscrollToComments" onClick="scrollToComments(1)" class="cshowComments4" style="display:none"
          title="Scroll down to the generic comments" >&#11015;&#65039;</button>

    <span class="csugg_mainHeader1"  >  &#128083; View suggestions: attributes &amp; notes, your rates &amp; ranks &amp; recommendations, and various summary statistics</span>.

    <button id="iShowHiddenCols" data-status="0" style="display:none;color:brown" onClick="showHiddenCols(this)"
         title="click to toggle view of hidden columns (less important attributes)">&#9199; vu</button>

    <span id="suggestionsBasicInfo" class="csuggestionsBasicInfo">user info here!</span>
 </div>

<div id="viewSuggestionsHelp" class="cviewHelp   " data-helpbox="Suggestions (add/rate/modify) help box">
<?php
   $curDir=getcwd();
   $helpfSugg=$curDir.'/includes/viewSuggHelp_header.html';
   require_once($helpfSugg);
?>

</div>

<div id="existingEntriesDivTableOuter" class="cexistingEntriesDivTableOuter"  name="tableOuter"  >
<!-- table of existing entries is .html() in here -->
</div>
<div title="bottom of suggestions table" style="height:0.75em;background-color:#dfdfaf">&nbsp;</div>

</div>

</div>



<!-- :::::::::::::::::::::  ::::::::::::            ::::::::::::::::::::::: :::::::::::::::::::-->
<!-- :::::::::::::::::::::   the ratings+ container :::::::::::::::::::-->

<div id="ratingsDiv"  class="cmainDivOuter"   data-content="View/add ratings, categories, and notes"   name="mainContainer"  >

<div id="ratingsDivMain" class="cDivMain   ">

<div id="ratingsDivMainHeader"  class="cratingsDivMainHeader" >
 <!-- filled by makeMyRatingsList()  -->
</div>


<div id="helpRatingDiv"  class="cratingHelp "  data-helpBox="Rating one-liner"  >
<?php
 $curDir=getcwd();
 $helpfRank=$curDir.'/includes/rateHelp_header.html';
 require_once($helpfRank);
?>
</div>


<div id="ratingsDivTableOuter"  class="cratingsDivTableOuter"   name="tableOuter"    >
    <!-- table of ratings+ input form is .html() in here -->
</div>
<div title="bottom of ratings+ specification table" style="height:0.75em;background-color:#dfdfaf">&nbsp;</div>

</div>

</div>


<!-- :::::::::::::::::::::  ::::::::::::            ::::::::::::::::::::::: :::::::::::::::::::-->
<!-- :::::::::::::::::::::   the rankings container :::::::::::::::::::-->

<div id="rankingsDiv"  class="cmainDivOuter" data-content="View and update rankings"   name="mainContainer"  >

<div id="rankingsDivMain" class="cDivMain   ">

<!-- :::: Header -->
<div id="rankingDivMainHeader"  class="crankingsDivMainHeader" >
header goes here
 <!-- filled by makeRankTable()  -->
</div>

<div id="helpRankingDiv"  class="crankingHelp "  data-helpBox="Ranking one-line"  >
<?php
//  hints for rankings included here (helpRankingDiv):::::::
 $curDir=getcwd();
 $helpfRank=$curDir.'/includes/rankHelp_header.html';
 require_once($helpfRank);
?>
</div>

<!-- ::::: list of your top and next rankings::::::: -->
 <div id="myRankingsListDiv"  data-recentclick="0"  class="cmyRankingsListDiv  "  name="listOfCurrentChoices" >
      box containing current rankings goes here
    <!-- filled by makeRankTable()  -->
 </div>    <!--  myRankingsListDiv -->

<!-- list of all suggestions, with input buttons to assign to do rankings -->

 <div id="rankingsDivTableOuter"  class="crankingsDivTableOuter"   name="tableOuter"  >
  table of suggestions goes here, with select a rank buttons
         <!-- filled by makeRankTable() :  table id=theRankingsTable  -->
 </div>             <!-- ::::  rankingsDivTableOuter -->
 <div title="below rankings table" style="height:0.75em;background-color:#dfdfaf">&nbsp;   </div>

</div>            <!-- ::::::::: rankingsDivMain  ::::::::::::::::::::::::::; -->

</div>         <!-- ::::::::: rankingsDiv  ::::::::::::::::::::::::::; -->


<!-- :::::::::::::::::::::  ::::::::::::            ::::::::::::::::::::::: :::::::::::::::::::-->
<!-- :::::::::::::::::::::   the view recommendations container :::::::::::::::::::-->

<div id="recommendationsDiv"  class="cmainDivOuter"    data-content="View and make recommendations" name="mainContainer"  >

<!-- navigation buttons included as fixed position (see choicer_navis.html for specification -->

<div id="recommendationsDivMain" class="cDivMain   ">

<div id="recommendationsDivMainHeader"  class="crankingsDivMainHeader" >

  <input type="button" value="&neArr;" title="view recommendations in a new window" class="showInNewWindow"
       data-in_new_window_header="Current selected recommendations, and rate/rank/reco details"
       data-in_new_window_find="#myRecommendationsListDiv_recommend,#theRecommendationsTable">

  <button class="cHelpButton wsShowS"    data-wsshow="#helpRecoDiv"  data-wsshow_alt="#helpRecoDiv2" name="helpButtonMain"
       title="Help for recommendations (view and make)&#010;Or double click to see the details!""  >&#10068;</button>

 <span style="font-weight:700;font-style:oblique;font-size:115%">&#127479;ecommendations (view and make) </span>

 <span style="background-color:yellow;margin:3px 5px 3px 5px;padding:3px 3px 3px 3px">
   <button id="iSelectRecommendations" class="cSelectRecommendations"
         title="Retrieve a set of recommendations to use.&#010;From you, or from others! Current or draft!"
            onClick="selectRecommendations(0)">Retrieve recommendations
   </button>
   <span title="Who provided the recently retrieved recommendations?"  >
       <span style="font-family:monospace" id="irecommendations_lastGetN"></span>
       <em> from:</em>
       <span id="irecommendations_lastGet"   class="crecommendations_lastGet" >&hellip;</span>
   </span>
   <span style="margin-left:1em">
      <button  title="save the `currently selected` recommendations, or view them in a new window (or tab)" id="iSaveRecommendationsButton"
             class="cSaveRecommendationsButton cSaveRecommendationsButton_on"
             onclick="showSaveRecommendationsMenu(1)">&#9997;Save recommendations
      </button>
   </span>
 </span>

 <span class="csuggestionsBasicInfo">
       <span id="iallRecommendations_nrankers"></span>     <!-- used for short summary of #suggestins, participants... -->
 </span>  <!-- this floats right -->

</div>     <!-- recommendationsDivMainHeader -->


<div id="helpRecoDiv"  class="crecoHelp "  data-helpBox="Recommendations one-line"  >
<?php
//  hints for rankings included here (recommendation):::::::
 $curDir=getcwd();
 $helpfReco=$curDir.'/includes/recoHelp_header.html';
 require_once($helpfReco);
?>
</div>    <!-- helpRecoDiv -->


<div id="myRecommendationsListDiv"   class="cmyRecommendationsListDiv  "   name="listOfCurrentChoices"   >
 The top container for recommendations
</div>         <!-- myRecommendationsListDiv -->

<div id="theRecommendationsTableOuter"  class="ctheRecommendationsTableOuter"  name="tableOuter" >
   recomendations table written here by makeRankTable

</div>         <!-- theRecommendationsTableOuter -->
 <div title="below recommendations table" style="height:0.75em;background-color:#dfdfaf">&nbsp;   </div>

</div>     <!-- recommendationsDivMain -->
</div>  <!-- recommendationsDiv -->

<!-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: -->
<!-- ::::::::: the   schedule container :::::::::: -->
<!-- :::::::::::::::::::::  ::::::::::::       ::::::::::::::::::::::: ::::::::::::::::::: -->

<div id="scheduleDiv"  class="cmainDivOuter"  data-content="View schedule"  name="mainContainer"  >

<div id="scheduleDivMain"  class="cDivMain" >

 <div id="scheduleDivMainHeader" class="cscheduleDivMainHeader">
  <input type="button" value="&neArr;" title="view schedule in a new window" class="showInNewWindow"
       data-in_new_window_header="Schedule"
       data-in_new_window_find="#scheduleDivTableOuter">

    <button id="scheduleHelpButton"  class="cHelpButton wsShowS "  name="helpButtonMain"
        data-wsshow="#scheduleHelp"   data-wsshow_alt="#scheduleHelpMore"
        title="Using the scheduler&#010;Or double click to see the details!">&#10068;</button>

    <span class="csched_mainHeader1"  >  &#128197; View or create a schedule</span>.


    <span id="scheduleBasicInfoReco" class="cscheduleBasicInfoReco">recor info here!</span>
    <span id="scheduleSaveButton"  >savebutton here!</span>

     <span id="scheduleBasicInfoSchedule" class="cscheduleBasicInfoSchedule">schedule info here!</span>

 </div>

<div id="scheduleHelp" class="cviewHelp   " data-helpbox="Schedule (view/create) help box">
<?php
   $curDir=getcwd();
   $helpfSche=$curDir.'/includes/scheduleHelp_header.html';
    require_once($helpfSche);
?>
</div>

<div id="scheduleListDiv"   class="cscheduleListDiv  "   name="listOfCurrentChoices"   >
 The top container for recommendations that can be scheduled
</div>         <!-- myRecommendationsListDiv -->


<div id="scheduleDivTableOuter" class="cscheduleDivTableOuter"  name="tableOuter"  >
<!-- table of existing entries is .html() in here -->

</div>

<div title="bottom of scheduler" style="height:0.75em;background-color:#dfdfaf">&nbsp;</div>

</div>

</div>


<!-- :::::::::::::::::::::  ::::::::::::       ::::::::::::::::::::::: :::::::::::::::::::-->
<!-- ::::::::::::::::::::   general comments :::::::::::: -->

<div id="genericComments" class="cGeneralComments"
     data-content="View and add general comments" name="mainContainer"  >

  <div id="genericComments_header">


 <input type="button" value="&neArr;" title="view current comments in a new window" class="showInNewWindow"
       data-in_new_window_header="General comments, and ranking and recommendations comments"
       data-in_new_window_find="#genericCommentsInner">

   <button class="cSideButtons" style="display:none" name="commentGoTopButton" name="commentGoTopButton" onClick="goTopScreen(1)" title="Scroll to top of the screen" >&#128285;</button>

   <span style="font-weight:800">General comments </span>
 </div>   <!-- genericComments_header -->

 <span class="genericComments_canhide">
  <a name="addGeneralComment"> You can </a><input id="iaddGeneralComments" type="button" value="add a general comment"
       onclick="showAddGeneralComment(1)">
 </span>

 <div class="genericComments_canhide">
 <table id="addGeneralComment" style="display:none;margin:16px" cellpadding="3" width="95%"   >
   <tr  ><td width="10%">
    Enter a comment  (not about a specific  <span name="choiceNameSay">choice</span>)?
   <br>
   And then
     <input class="bigButton" id="isaveCommentButton" type="button"
        value="Save it " title="Click here to save your new general comment "
        onclick="saveCommentsToServer(1)">
   </td>
  <td>
    <textarea id="generalComment" rows="3" cols="100" title="Comments or other suggestions"  >
    </textarea>
  </td></tr>
 </table>
 </div>

 <div id="genericCommentsInner"   style="border-top:1px dashed blue;margin:3px ">
    stored comments written here  (general, and comments on rankings)
 </div>

</div>      <!-- genericComments -->

<!-- :::::::::::::::::::::  ::::::::::::       ::::::::::::::::::::::: ::::::::::::::::::: -->


<!--  ::::::::::::::::::::::  Footer below the main container :::::::::::::::::::::  -->
<div class="cFooter">
  <hr>Questions:  <span name="siteAdminContact">...</span>
</div>

<!--  ::::::::::::::::::::::  :::::::::::::::::::::  :::::::::::::::::::::  -->
<!--  :::::::::::::::    fixed position   containers  ::::::::::  -->

<!--  Include fixed position navigation containers (and related help containers) -->
<?php
 $curDir=getcwd();
 $helpfNavi=$curDir.'/includes/choicer_navis.html';
 require_once($helpfNavi);
?>

<!-- ::::::::::::   logon box   -->

<div id="iLogonBox"    data-content="Logon"  class="cLogonBox">

<div  id="logonBox_otherLinks" style="padding:2px 1em 6px 1em;margin:4px;background-color:#96f4b2">
  <!-- other links here -->
</div>

<div style="margin:4px;border:3px ridge #c4b4fe">
 <span id="welcome_1"> Welcome</span></a> <span class="sayLogonName" id="iLogonName" name="logonNameSay"></span>
 to <span style="white-space:nowrap;" name="welcomeGroupName">your group name</span>
 </div>
  <div style="margin:5px 5em 1em 5em">
  <span style="display:inline-block;width:11em">Please enter your name: </span>
    <span class="myLogon" id="imyLogonNameOuter" class="crosshairCursor">
       <input type="text" value="" id="imyLogonName" size="15"  class="crosshairCursor" >    <!-- the welcome/logon screen -->
  </div>

  <!-- enable  passworduse global js variable (in choicer_params.js) for some security     -->
  <div style="display:none;margin:5px 5em 1em 5em" id="iPasswordUse">
         <span style="display:inline-block;width:11em">and the password:</span> <input type="text" value="" id="myLogonPassword">
  </div>

  <div style="margin:5px 5em 1em 5em">
   <span style="display:inline-block;width:11em">and then </span>
     <button id="doLogon1" type="button"  class="clogonWhat"  onClick="doLogon(1)"
          title="You can add  suggestions, revise current suggestions, rank & rate suggestions, or make a list of recommendations.." >
          &#9999;&#65039; View &amp; make suggestions, rankings, recommendations ... </button>

  </div>

  <div id="viewPublishedSchedule" class="cviewPublishedSchedule" style="display:none"> </div>

</div>           <!-- :::::::::::: logon box :::::::::::::: -->


<div id="projectSelectDiv" dog="fido" class="cprojectSelectDiv" style="display:none">


</div>
 <!-- :::::::::::: project select box :::::::::::::: -->

<!-- :::::::::::::::::::::::::::::::::::::::: end  ::::::::::::::::::: -->

<!-- include various fixed position files here  (main help, others), and the detailed help on view/rate/rank/reco -->
<!-- and fixed navigation bars -->
<?php
 $curDir=getcwd();
 $helpfHelp1=$curDir.'/includes/otherHelp.html';
 require_once($helpfHelp1)  ;

 $helpMainHelp=$curDir.'/includes/mainHelp.html';
 require_once($helpMainHelp);

 $helpNavi=$curDir.'/includes/choicer_navis.html';
 require_once($helpNavi) ;

 $helpInfos=$curDir.'/includes/infoBoxes.html';
 require_once($helpInfos) ;


?>

<!-- :::::::::::::::::::::::::::::::::::::::: footer page end ::::::::::::::::::: -->
<br clear="all" />
<div style="border-top:1px dotted gray;margin-top:6px">
</div>

</div>


<div style="background-color:cyan" id="dog1">
</div>
</html>

</body>

<?php

//==========
// :::::::::::::::::::::::::::::::::::::::::::::::::::::
// what project?
function checkProject($defaultProjectX) {
// if no project= in url
//    use defaultProject
//      If no defaultProject : show list of projects
//      If defaultProject does NOT point to valid directory: error message and exit
//      Else, useProject=defaultProject
//  if Project=x in url
//     if x=* or x='' : show list of project
//     If x does not point to a valid directory: error message and exit
//    ELse, useProject=x

// check for valid DefaultProject

   $curDir=getcwd();

   $arf=isset($defaultProjectX);

   if ($arf)  {        //  $defaultProject) is specified in choicer_init.php
     $defaultProjectX=trim($defaultProjectX);
     if ($defaultProjectX=='' || $defaultProjectX=='*') {    // show menu...
        $defaultProjectX='*';
     } else {                // a nonempty value for $defaultProjectx
       $defaultProjectDir=$curDir.'/data/'.$defaultProjectX;
       if (!is_dir($defaultProjectDir)) {       // fatal error
         print 'alert("Error: the default project directory does not exist! \n ('.$defaultProjectDir.')\n Please check  params/choicer_init.php  "); ' ;
         print "\n </script></head><body>Configuration error: bad default project specified  in params/choicer_init.php </body></html> \n";
         exit ;
       }
     }       // defaultproject ne ' '
   } else {     //  $defaultPRoject not specified in choicer_init.php
       $defaultProjectX='*';    // so show all projects
   }       // arf

// check for project=xx in  ?args
   $foo1=isset($_GET["project"]);
   if (!$foo1)  {    // a project= not specfied ... use defaultProject
     $useProject=$defaultProjectX ;  // might be '*'
   } else {
     $urlProject=$_GET["project"] ;
     $urlProject=trim($urlProject);
     if ($urlProject=='' || $urlProject=='*') {
          $useProject='*'   ;       // a ?project=xx overrides default. If x='' or x=* : show menu of projects
     } else {                       // desired project
       $urlProjectDir=$curDir.'/data/'.$urlProject;
       if (!is_dir($urlProjectDir)) {
         print 'alert("Warning: the  project directory  (specified in the url) does not exist! \n ('.$urlProjectDir.') "); '."\n";
         exit;
       }
       $useProject=$urlProject  ;   // a url specified projects exists! Use it
     }              // urlproject
   }             // ?project=x
 
   if ($useProject!='*')   {   // show menu of projects
      print 'var useProject=\''.$useProject.'\' ;  // if * will be changed by getProject() '."\n";
      return 1;
  }

// * -- show menu of projects
$directory_path=$curDir.'/data/*';

 $dirs= glob($directory_path , GLOB_ONLYDIR);
// if (count($dirs)==0) {
//     print "alert('There no project directories under  $directory_path) ;'\n" ;
//     return false;
//}
// $d2=array_map('basename',$dirs);

// check for init.txt file in each directory
 $daProjects=[];
 foreach ($dirs as $ii=>$dirnameFull) {
    $dirname=basename($dirnameFull);
    $ainitFile=$dirnameFull.'/init.txt';
    if (!file_exists($ainitFile) ) {            // missing init.txt file: fatal error
      print "// The $dirnameFull project directory does not have an init.txt file  ; \n" ;
      continue ;
    }

    $oof=file_get_contents($ainitFile);
    $dalines=explode("\n",$oof);
    $stuff=['created'=>'','comment'=>''];
    foreach ($dalines as $ij=>$daline) {
        $daline=trim($daline);
        if ($daline=='' ) continue;
        if ($daline.substr(0,1)==';') continue ;
        $dd=explode(':',$daline,2);
        if (count($dd)!=2) {
            print "// The $ainitFile project directory init.txt file is misspecified  ; \n" ;
            continue ;
         }
         $atag=trim(strtolower($dd[0]));
         $aval=trim(strtolower($dd[1]));
         $stuff[$atag]=$aval;
     }
     $daProjects[$dirname]=$stuff;
  }       // dirs

  $introFile=$curDir.'/data/projectIntro.html';
  $aintro='';
  if (file_exists($introFile)) {
     $aintro=file_get_contents($introFile);
  }

   print "var useProject='*' ;    // if * will be changed by getProject()     \n";
   print "var choicerProjects={} ;\n ";

   $amess ='<input type="button" value="&#9965;" class="clogonWhat" title="admin logon" onClick="adminLogon(1)"> ';
   $amess.= str_replace(array("\r\n", "\r", "\n"), "<br />", $aintro);

  $amess.=' <table rules="rows" width="96%" cellpadding="3">';
  $amess.='<tr><th width="15%">Project name</th><td width="50%"><em>description</em></td><td width="30%"><t>created</tt></td></tr>';

//  $gotDefault=0;
  $gotOther=0;
  foreach ($daProjects as $pname=>$pstuff) {
      print " choicerProjects['$pname']={} ;\n ";
      $gotOther++;

//       if ($pname=='_default') {
//        $gotDefault=1;
//       }   else {
//          $gotOther++;
//       }

      $acreate=$pstuff['created'];
      $acomment=$pstuff['comment'];
      $useMe='<button onclick="init_gotProject(this)"  data-pname="'.$pname.'"title="choose this project" class="cchoseThisProject">'.$pname.'</button>' ;
      $amess.="<tr><th>$useMe</th><td><em>$acomment</em></td><td><tt>$acreate</tt></td></tr>";

      print "   choicerProjects['$pname']['created']='".$acreate."' ;\n ";
      print "   choicerProjects['$pname']['comment']='".$acomment."' ;\n ";

  }
  $amess.='</table>';
  if ($gotOther==0)  {     // might be a fresh install
    $amess.='<div style="border:2px solid blue;margin: 5px">Admin note: to create a new project, logon with ';
    $amess.='<input type="button" value="&#9965;" class="clogonWhat" title="admin logon" onClick="adminLogon(1)"> ';
    $amess.=' </div>';
  }
  print "   choicerProjectsMenu='$amess' ;\n ";

  return 1;
}


?>
