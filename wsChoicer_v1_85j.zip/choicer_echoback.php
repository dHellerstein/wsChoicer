<?php

// echo back the contents -- typically help stuff to be shown in new window

session_start() ;
ob_start();

$curDir=getcwd();

$url = $_SERVER['REQUEST_URI']; //returns the current URL
$parts = explode('/',$url);
//$dir = $_SERVER['SERVER_NAME'];
$rootSel='';
for ($i = 0; $i < count($parts) - 1; $i++) {
 $rootSel .= $parts[$i] . "/";
}

// not currently used...
//$pwdfile=$curDir.'/params/choicer_init.php';      // get adminPwd
//require_once($pwdfile);
//// a bit of security   (redundant with js check, so not needed for most situations)
//$theAdminPassword=$_REQUEST['pwd'];
//$tMd5=md5($theAdminPassword) ;
//if ($tMd5!=$adminPwd) {
//     $amess="Incorrect admin password";
//     ob_end_clean();   // remove prints and other crap
//     $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
//     print $vsuggests;
//     exit;
//}

//    {'content':content,'username':currentUserName,'theProject':useProject};

$useProject= $_REQUEST['theProject']  ;
$dacontent=$_REQUEST['content'];
$username=$_REQUEST['username'];


$amess='';
$amess.="<!DOCTYPE HTML>\n";
$amess.='<html><head><title>wsChoicer help. Username '.$username.'</title>'."\n";
$amess.='<meta charset="utf-8">'."\n";
$amess.='<link rel="stylesheet" type="text/css" href="css/choicer_other.css" /> '."\n" ;
$amess.='<link rel="stylesheet" type="text/css" href="css/choicer_other.css" /> '."\n"  ;
$amess.='<link rel="stylesheet" type="text/css" href="css/choicer_several.css" />'."\n" ;
$amess.='<link rel="stylesheet" type="text/css" href="css/choicer_view.css" />'."\n"  ;
$amess.='<link rel="stylesheet" type="text/css" href="css/choicer_rate.css" />'."\n"  ;
$amess.='<link rel="stylesheet" type="text/css" href="css/choicer_rank.css" />'."\n"   ;
$amess.='<link rel="stylesheet" type="text/css" href="css/choicer_reco.css" />'."\n"   ;
$amess.='<link rel="stylesheet" type="text/css" href="css/choicer_sched.css" />'."\n" ;

$amess.='<style type="text/css">'."\n" ;
$amess.='.showAllHelp_topicBox {'."\n" ;
$amess.='  border:1px solid black; padding:1px 4px; margin:1px 4px; '."\n" ;
$amess.='  display:inline-block; '."\n" ;
$amess.='  width:15em; '."\n" ;
$amess.='  height:2.2em; '."\n" ;
$amess.='  background-color:#eaf4f1 ;'."\n" ;
$amess.='  overflow:auto ; '."\n" ;
$amess.="} \n";
$amess.="</style> \n ";

$amess.="\n";

$amess.='<script type="text/javascript" src="lib/jquery-3.6.0.min.js"></script>';
$amess.="\n";

$amess.='<script type="text/javascript"> ';

//$amess.="\n window.onload=init;  \n";

//$amess.="function init(i) { \n";
//$amess.=" $('.wsShowH').hide(); $('#topRowButton_help').hide();   $('.wsShowF').hide();  $('.wsShowS').hide(); $('.showInNewWindow').hide(); \n ";
//$amess.=" $('.cTopRowButton').prop('disabled',true) ; \n";
//$amess.=" $('.chelp_header_gobuttons').hide(); \n";
//
//$amess.="} \n";

$amess.="</script> \n";
$amess.="\n";
$amess.='</head>';
$amess.="\n";
$amess.='<body>';
$amess.="\n";
$amess.='<div style="border:1px solid blue;margin:3px 3em 5px 3em">Hello <u>'.$username. '</u></div>';
$amess.="\n " ;
$amess.=$dacontent;
$amess.="\n";
$amess.='</body>';
$amess.="\n";
$amess.='</html>';
$amess.="\n";

print $amess;
exit;
?>



?>


