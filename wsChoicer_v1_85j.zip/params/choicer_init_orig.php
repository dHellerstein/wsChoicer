<?php
//  This is a backup file for choicer_init.php
// It is NOT used -- its only use is if choicer_init.php is deleted, than this can be copied to choicer_init.php
// (and when index.php is next invoked, the wsChoicer initialization will occur)
// - ------------------------------------

// choicer_params : password (MD5) parameters.
// This is modified when wsChoicer is first opened (after its installation)
// Otherwise: choicer_params.php is NOT editable by wsChoicer's online tools. It can  be hand edited.
// Hint: to reset the admin password: set $adminPwd=false, and then load choicer (the "set admin parameters " screen will be shown)

//  md5 of the Admin user password
$adminPwd=false ;

// default project='' or '*' means "by default: show list of projects"
//  ?project=projectName in a url will override this
$defaultProject="*";
 
?>