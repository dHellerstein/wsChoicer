// js for choicer_htmlScehdule.php
// ==============

//  init stuff -- hide downloadlocal links?
function initHS(dakey) {

   if (dakey==0) return 1 ;  // downloadlocal are NOT private
   let arf=$('[name="downloadLocalLink"]');
 
   arf.hide() ;
}

//=========
// unlock (show links) on schedule page
function scheduleUnlockCode(athis,daKey) {
   ethis=wsurvey.argJquery(athis);
   let dakey=ethis.attr('data-keycode');
   if (daKey==1) return 1 ;   // download local is supprssed
   let ediv=ethis.closest('#scheduleDivMainHeader');
   let e1=$('#ischeduleUnlockCode');
   let aval=e1.val();
   let aval2=jQuery.trim(aval.toLowerCase());

   let aMd5=md5(aval2);

   if (aMd5!==dakey) {       // hash of codekey is stored in choicer_params.js
        alert('This does not seem to be correct. Try again');
        return false; // give up
   }
  let arf=$('[name="downloadLocalLink"]');
   arf.show();
   $('#askUnlockCode').hide();    // no need to display the keycode input stuff
}

