<?php

// first-open of wsChoicer -- do some initializations 

//ob_end_clean();   // remove prints and other crap
?>
function  saveThis(ifoo) {
   let e1=$('#daPwd')
   let apwd=jQuery.trim(e1.val()).toLowerCase();
   if (apwd=='') {
      alert(' You must enter a password ');
      return 0;
   }
   let bpwd=apwd.replace(/\s/g, '');
   if (apwd!=bpwd) {
      alert(' You must enter a single word password ');
      return 0;
   }
   amd5=md5(bpwd);

   let ddata={};
    ddata['md5']=amd5 ;

   let emessage=$('#topMessage');
   let amessage=jQuery.trim(emessage.val());
   let bmessage=wsurvey.makeHtmlSafe(amessage,1);
   ddata['topMessage']=bmessage[1];

  $.ajax({
        url: 'choicer_doInit2.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function (response) {

      alert(response.responseText) ;

    });

}
</script>
</head>

<body>

<?php
// else, first call
print '<b>wsChoicer: initialization</b> ';
print ' <a href="readMe.txt" target="viewer">Installation notes<a>';
print "<p> \n";

print '<table cellpadding="5">' ."\n";
print '<tr><td>Admin password</td><td>Enter an admin password (lowercase of it is used): ' ."\n";
print '<input type="text" size="15" id="daPwd"> </td></tr>' ."\n" ;

print '<tr><td>Header line for home page<br> <em>displayed above the list of projects</em></td> ';
print ' <td><textarea rows="4" cols="80" title="Enter a message. Simple html okay " id="topMessage"></textarea></td</tr> '."\n";

print '<tr><td>Default project</td><td>Edit params/choicer_init.php to change this. ' ."\n";
print '<input type="text" size="15" id="daProject" disabled value="'.$defaultProject.'"> </td></tr>' ."\n";
print '</table>' ."\n";
print '<input type="button" onClick="saveThis(1)" value="Save the admin pwd"> <em>as its MD5 hash</em>' ."\n" ;

?>
</body>
</html>
