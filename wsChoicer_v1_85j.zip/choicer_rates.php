<?php
// works with rates page. New rates, categories, links/infoBlurbs, and descriptive notes

session_start() ;
ob_start();

// add some php functions
$curDir=getcwd();
$libfile=$curDir.'/choicer_lib.php';
require_once($libfile);


 $username=$_REQUEST['username'];
 $useProject=$_REQUEST['theProject'];

 $todo=$_REQUEST['todo'];     //   updateRates is only one for now

// =-======================= save categories, rates, links/infoblurbs, notes ... to seperate files

$res=[];
$res[]='Saving rates, categories, links/infoBlurbs, and descriptive notes ';
// changes in categories?

$nnewCats=$_REQUEST ['nnewCats'];
if ($nnewCats>0) {
  $ares=saveCategories_1($username,$useProject);
  $res=array_merge($res,$ares);
}

// changes in rates?
$nnewRates=$_REQUEST ['nnewRates'];
if ($nnewRates>0)  {
  $ares=saveRates_1($username,$useProject);
  $res=array_merge($res,$ares);
}

// changes in links/infoBlurbs?
$nnewLinks=$_REQUEST ['nnewLinks'];
if ($nnewLinks>0) {
  $ares=saveLinks_1($username,$useProject);
  $res=array_merge($res,$ares);
}


// changes in  dewcriptive ntoes?
$nnewNotes=$_REQUEST ['nnewNotes'];
if ($nnewNotes>0) {
   $ares=saveNotes_1($username,$useProject);
   $res=array_merge($res,$ares);
}

  $rets=[];
  $rets['results']=$res ;

   ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($rets, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;

//================= save categories (all of them)
function saveCategories_1($cUser,$useProject) {
   $atime=time();

   $updateDate=date("Y-m-d H:i") ;
   $alines=$_REQUEST['newCats']  ;
   $nlines=count($alines);

   $amess='';
   $amess.="; categories for $cUser on $updateDate ";
   $amess.="\nusername: $cUser ";
   $amess.="\ndate: $updateDate ";
   $empty1=0;
   foreach ($alines as $mvid=>$acat) {
       $acategory=  strtolower(preg_replace('/[^a-zA-Z0-9_]/','', $acat));  // only characters, digits, _ (no embedded spaces)
       $mvid=trim($mvid);
       $amess.="\n$mvid: $acategory "  ;
   }
   $amess.="\n\n ";

    $curDir=getcwd();
   $doFile=$curDir.'/data/'.$useProject.'/submits/categories'.$atime.'.ctg';
   $fp=fopen($doFile,'w');

  fwrite($fp,$amess);  // categories
  fclose($fp);
 removeCacheFile($useProject);  // remove the .csh file
  

  return  ["Saved: $nlines categories for $cUser on $updateDate "];
}

//================= save rates (all of specifed)
function saveRates_1($cUser,$useProject) {
   $atime=time();

   $updateDate=date("Y-m-d H:i") ;
   $alines=$_REQUEST['newRates'] ;
   $nlines=count($alines);

   $amess='';
   $amess.="; rates for $cUser on $updateDate ";
   $amess.="\nusername: $cUser ";
   $amess.="\ndate: $updateDate ";
   $empty1=0;
   foreach ($alines as $mvid=>$acat) {
       $acategory=  strtolower(preg_replace('/[^a-zA-Z0-9_]/','', $acat));  // only characters, digits, _ (no embedded spaces)
       $mvid=trim($mvid);
       $amess.="\n$mvid: $acategory "  ;
   }
   $amess.="\n\n ";

    $curDir=getcwd();
   $doFile=$curDir.'/data/'.$useProject.'/submits/rates'.$atime.'.rte';
   $fp=fopen($doFile,'w');

  fwrite($fp,$amess); // rates
  fclose($fp);
  $zz=removeCacheFile($useProject);  // remove the .csh file

  return  ["Saved: $nlines rates for $cUser on $updateDate "];
}

//================= save rates (all of specifed)
function saveLinks_1($cUser,$useProject) {
   $atime=time();

   $updateDate=date("Y-m-d H:i") ;
   $alines=$_REQUEST['newLinks'] ;
   $nlines=count($alines);

   $retme=[];
   $nsaved=0;
   $errmess=[];

   $amess='';
   $amess.="; links and information blurbs for $cUser on $updateDate ";
   $amess.="\nusername: $cUser ";
   $amess.="\ndate: $updateDate ";
   $empty1=0;
   foreach ($alines as $mvid=>$anote) {
       $anote=  trim($anote);  // only characters, digits, _ (no embedded spaces)
       $qq=checkValidHtml($anote);
       if ($qq===true) {          // no bad html
          $mvid=trim($mvid);
          $str = preg_replace( "/\s+/", " ", $anote );
          $amess.="\n$mvid: $str "  ;
          $nsaved++ ;
       } else {                    // errors. Str
          $retme[]="HTML coding errors for entry id: $mvid ";
          foreach ($qq as $ii=>$aerr) $retme[]=$aerr  ;
       }
   }
   $amess.="\n\n ";

    $curDir=getcwd();
   $doFile=$curDir.'/data/'.$useProject.'/submits/links'.$atime.'.ava';
   $fp=fopen($doFile,'w');

  fwrite($fp,$amess);  // links
  fclose($fp);
 removeCacheFile($useProject);  // remove the .csh file

  $retme[]="Saved: $nsaved links and information blurbs for $cUser on $updateDate ";

  return $retme ;

}
//================= save rates (all of specifed)
function saveNotes_1($cUser,$useProject) {
   $atime=time();

   $updateDate=date("Y-m-d H:i") ;
   $alines=$_REQUEST['newNotes'] ;
   $nlines=count($alines);

    $retme=[];
   $nsaved=0;
   $errmess=[];

   $amess='';

   $amess.="; descriptive notes for $cUser on $updateDate ";
   $amess.="\nusername: $cUser ";
   $amess.="\ndate: $updateDate ";
   $empty1=0;
   foreach ($alines as $mvid=>$dnote) {
       $dnote=  trim($dnote);
       $qq=checkValidHtml($dnote);
       if ($qq===true) {          // no bad html
          $mvid=trim($mvid);
          $str = preg_replace( "/\s+/", " ", $dnote );
          $amess.="\n$mvid: $str "  ;
          $nsaved++ ;
       } else {                    // errors. Str
          $retme[]="HTML coding errors for entry id: $mvid ";
          foreach ($qq as $ii=>$aerr) $retme[]=$aerr  ;
       }
   }
   $amess.="\n\n ";

    $curDir=getcwd();
   $doFile=$curDir.'/data/'.$useProject.'/submits/notes'.$atime.'.nte';
   $fp=fopen($doFile,'w');

  fwrite($fp,$amess);  // notes
  fclose($fp);
 removeCacheFile($useProject);  // remove the .csh file

  $retme[]= "Saved: $nsaved descriptive notes for $cUser on $updateDate ";
  return $retme ;

}

