// logon, and show content,  functions



//=============
// this does some final iniaizliationl work (is called by initJsRead, assuming no errors on read  of params.js file
// After this function ends, the user (the site visitor) will see a logon screen.
//   He then enters a username, and selects an action (such as "view ... suggestions" or "view schedule".
//   Or he can use one of the 'other site links' on the logon page (and not bother entering a username)
//
//
// Note: retrieval of info from server starts when user successfully enters a username (which might require a 
// password, and a validUser check). The procedures
// After getting info from server, several pages are generated (and hidden) -- using functions in choicer_1.js
// The user than choose an action button, such as "view current/ suggestons"

function init2(x) {

  $('#welcome_1').attr('title','version '+ verNumber);
    let oof=$('[name="welcomeGroupName"]');        // a welcome phrase
   for (let ioof=0;ioof<oof.length;ioof++) {
       aoof=$(oof[ioof]);
       aoof.html(welcomeGroupName);
   }

// cleanup linkIcons (and add wwwLink and download)

  let tmpLink={};
   tmpLink['wwwlink']='imgs/wwwLink.gif';
   tmpLink['downloadlocal']='imgs/downloadLocal.png';       // add these always available
   tmpLink['downloadword']='imgs/downloadWord.gif';
   tmpLink['downloadother']='imgs/download_other.gif';


   if (typeof(linkIcons)!='object') inkIcons={};   // a problem  -- reset to empty
   for (let awhat in linkIcons) {                 // convert to lc
       let awhatc=jQuery.trim(fixString(awhat,1));
       awhatc=awhatc.toLowerCase();
       let wval=jQuery.trim(linkIcons[awhat]);
       delete linkIcons[awhat];   // just want the lc version
       if (wval=='') continue ;  // skip if empty
       tmpLink[awhatc]=wval;
   }
   linkIcons=tmpLink;

  let AReload='<input type="button" value="&#128260;" title="Reload (and select a project)" onClick="doLogon(3)"> ';
  $('#logonBox_otherLinks').html(AReload+' '+logonBox_otherLinks);  // global var: string of "other links" (customizable) -- for logon box

   if (compressHeaderRow==0) {
      $('#icompressHeaderButton').trigger('click');  // 1 means compress.. 0 means uncompress. Starts compressed!
   }

// assign click handlers (at a bubble up to level)
// Note these elements must be (and are) specified in index.php. They are not generated after getting info from the server

   let ess=$('#existingEntriesDivTableOuter');
   ess.on('click',clickOnViewSugg);             // could use delegated events, but let clickOnViewSugg check

   let ess2=$('#ratingsDivTableOuter');
   ess2.on('click',clickOnRatings);             // could use delegated events, but let clickOnRatings check
   ess2.on('change',clickOnRatings);             // could use delegated events, but let clickOnRatings check

   let ess3=$('#rankingsDivTableOuter');
   ess3.on('click',clickOnRankings);             // could use delegated events, but let clickOnRankings check

    let emy=$('#myRankingsListDiv');
    emy.on('click',clickOnRankings );

   let erecom0=$('#theRecommendationsTableOuter');
   erecom0.on('click',myRecomHandler);       // click on a choice name, or # recommendations,  in the recommendation  table

  let erecom1=$('#myRecommendationsListDiv');
    erecom1.on('click',recoClickHandler);   // click on a choice in the my recommendation list

  let ewsShow1=$('.wsShowS');
  ewsShow1.on('click',wsurvey.wsShow.show);
 
  let ewsShow2=$('.wsShowH');
  ewsShow2.on('click',wsurvey.wsShow.hide);
  let ewsShow3=$('.wsShowF');
  ewsShow3.on('click',wsurvey.wsShow.inFront);


    if (typeof(scheduleTableEventHandler)=='function')  {
       let esched1=$('#scheduleDivTableOuter');
       esched1.on('click',scheduleTableEventHandler);
       let esched2=$('#scheduleListDiv');
       esched2.on('click',scheduleListEventHandler);
    }

// don't distract the logon process with action buttons.

  $('.cTopRowButton').hide();
  $('.cTopRowButtonOther').hide();
  $('.cTopRowButtonOther2').hide();

  if (passwordUse==1) $('#iPasswordUse').show();

  let logonNameCookie=Cookies.get('choicerLogonName') // => 'value'

  if (urlUserName!==false) {                // urlUserName is a global
     $('#imyLogonName').val(urlUserName);    // prefill logon name -- if supplied in url
  } else {                                          // not in url .. perhaps from a cookie
    if (typeof(logonNameCookie)!=='undefined') {
       $('#imyLogonName').val(logonNameCookie);    // prefill logon name
     }
  }

  $(document).prop('title',documentTitle);       // use customized value for the browser title bar

// add escape handler   (for closing most recently shown (with wsShow.show) 
   shortcut.add("esc",wsurvey.wsShow.hideRecent,{
	'type':'keydown',
	'propagate':true,
	'disable_in_input':true,
	'target':document
   });

      shortcut.add("F1",showKeyHelp,{
	'type':'keydown',
	'propagate':true,
	'disable_in_input':true,
	'target':document
   });




// done --- now the user can enter his username (or click on a link to another site)

}

//==============
// response after getSript
// scrtip: text of what was read
// success message; "success" if sucessful
// object with ajax response fields. In particluar: responseText (same as script), readyState (such as 4), status (200), statusText ('OK')
function initJsRead(script,textStatus,jqxhr,useProject,justReturn) {
  if (arguments.length<5) justReturn=0;

  if (choicerParams_read!=1) {
    let amess='There was a problem reading parameters (file read but contains errors). Check '+useProject+'/params/choicer_params.js ' ;
    alert(amess);
    let arf='<div style="background-color:yellow;height:12em,width:50vw">'+amess+'</div>';
    $('body').append(arf) ;

    return 0;
  }

// do some cleanup
  if (!jQuery.isNumeric(autoShowHelp)) autoShowHelp=0;
  if (autoShowHelp<0) autoShowHelp=0;
  if (autoShowHelp==2) autoShowHelp=1 ;     //   2 is treated as 1.. fade requires > 2

  if (!jQuery.isNumeric(autoShowIntro)) autoShowIntro=0;

  if (!jQuery.isNumeric(autoStatusMessages)) autoStatusMessages=0;
  if (autoStatusMessages<0) autoStatusMessages=0;
  if (autoStatusMessages==2) autoStatusMessages=1.5 ;     //   special case of 2 (check if any messages) 
  if (autoStatusMessages==1) autoStatusMessages=2 ;     //   2 left as is .  > 2 also left as is

   rankingsLinearMenu=jQuery.trim(rankingsLinearMenu).toLowerCase();        // a if not a b or c
  if (!( rankingsLinearMenu=='a'  || rankingsLinearMenu=='b'   ||  rankingsLinearMenu=='c' )) rankingsLinearMenu='a'

  enterToDo=jQuery.trim(enterToDo).toLowerCase();
  lastToDo=enterToDo ;

  if (justReturn==0) init2(2)  // the rea1 initialzation

  return 1;

}

//==========
// show error message on error reading parameters file.
// jqxhr: as above
// settings: string. such as 'error'
// exceptions:  string. such as 'Not Found'
function initJsReadFail(jqxhr,settings,exception,awhich)   {
//  if (arguments.length<4) awhich='params/choicer_params.js';
  let amess='Error reading parameters file ('+exception+'). Please check for '+awhich ;

  let arf='<div style="background-color:yellow;height:12em,width:50vw;z-index:500">'+amess+'</div>';
  $('body').append(arf);
  $('#iLogonBox').hide();
  $('#siteHeaderTopRow').hide();
 
  return 0;

 }


//==========================================
// logon or logoff
// 1 : logon (from logon welcome screeen)
// 2 : logoff (logoff button in upper left of main page)
// 3 : logon, show schedule

function doLogon(ido) {

  if (ido==3)  {       //  browser reload
    Cookies.set('choicerLogonName',myLogonName,{'sameSite':'lax','expires':7}) // => expires in 7 days. Setting samesite to suppress browser nag
    let oof=window.location.protocol + "//" + window.location.host + window.location.pathname+'?project=*' ;  // get rid of any ?project=
    window.location.href = oof;
    return 0;
  }

  isAdminUser=false;
  let auser=currentUserName ;
  closeAllContent('dologon');

  disableChanges(1);
  resetAll(0);     // remove user entered information from various input fields
  clearAllGlobals(1);    // clear all server supplied info

  let elogn=$('[name="logonNameSay"]') ;
  elogn.html('');
  elogn.attr('title','');


  $('.cTopRowButton').fadeOut(50);
  $('.topRowButtonOther').fadeOut(50);
  $('.topRowButtonOther2').fadeOut(50);

   if (ido==2)  {       // logoff button on main page -- close everything and redisplay logon box
       writeStatusMessage(auser+': logoff ');
       $('#iLogonBox').hide();     // hide, and then fade in ..
       Cookies.remove('choicerLogonName');   // get rid of cookie
       $('.cTopRowButton').fadeOut(200);
       $('.topRowButtonOther').fadeOut(200);
       $('.topRowButtonOther2').fadeOut(200);
       $('#iLogonBox').fadeIn(500);                // display logon box
       $('#imyLogonName').val('');
       $('#myLogonPassword').val('');
       autoStatusMessages=0;           // do not auto show status messages
       return 0;
   }

// not a logout ...

// === logon

   let usernameLc='',username='';

   ethis=$('#imyLogonName');
   let aval=jQuery.trim(ethis.val());

   if (aval.toLowerCase()=='admin') {              // must match hashed password
     isAdminUser=false;
     let huh=prompt('Enter the admin password ... ','password');
     for (let m=0;m<10;m++) {
        huh=jQuery.trim(huh.toLowerCase());
        huhmd=md5(huh);
        if (huhmd !==adminPwd) {
           huh=prompt('Incorrect password. Please re-enter: ');
           if (!huh) return 0;
           continue;
        }
        isAdminUser=true;
        break;
     }
     if (isAdminUser===false) {
        $('#iLogonBox').hide();
        return 0;   // give up after 10 tries
     }
     username='admin';       // always lc
     theAdminPassword=huh   ; // global (sent to choicer_admin.php)
     usernameLc=username;

     writeStatusMessage('<b>You have logged on as an administrator.</b> ',1,0,1);

//     $('#basicHelp_adminOnly').show();  // 12 april: not currently used

     $('#topRowButton_admin').show();
     showAdminMenu(2);
   }

   if (isAdminUser===false)  {        // don't bother if admin
       username= fixString(aval,1);     // get rid of spaces etc
       usernameLc=jQuery.trim(username.toLowerCase());
       if (usernameLc.length>15 || usernameLc.length!=aval.length || username=='') {
          alert("Your name must be less than 15 characters, and can not include spaces or commas or quotes ");
          return 0;
       }
    }

    $('.cTopRowButton').show();

// set some globals
   myLogonName=username ;          // this is used for display purposes, so keep its case
   currentUserName=usernameLc ;    // a global  used everywhere!   This may be changed in  choicer_1.js -- to match a known validUserName

   Cookies.set('choickerLogonName',myLogonName,{'sameSite':'lax','expires':7}) // => expires in 7 days. Setting samesite to suppress browser nag

   if (passwordUse==1 && !isAdminUser )  {            // passwordUse is global. Skip if admin
     let p1=$('#myLogonPassword');
     let vpwd=jQuery.trim(p1.val()).toLowerCase();  // NOTE USE OF CASE INSENSTIVE! Make sure password obsfucated is md5 of lc password!
     avalo=md5(vpwd);

     if (avalo!==memberPassword) {  // memberPassword is global set in choicer_passwords.php for a project  (should be md5 of actual password)
        alert(' Incorrect password ');
        return 0;
     } else {
       Cookies.set('choicerLogonName',myLogonName,{'sameSite':'lax','expires':7}) // => expires in 7 days. Setting samesite to suppress browser nag
      }
  } else {   // no password required

  }


// if here logon worked
//  let elogn=$('#iLogonName') ;
  elogn.html(myLogonName);          // username --- membername
  elogn.attr('title','You logged on using: '+myLogonName );  // may not be the actual memberName

   if (currentUserName=='admin') {
     elogn.css({'background-color':'gold','font-size':'110%'});
   }

  $('.bigButton1').removeClass('bigButton1');
  $('#iLogonBox').hide();


  if  (isAdminUser ) {           // load admin stuff first (if admin)... then get info from server
$.getScript( "choicer_admin.js" )
 .done(function(a,b,c) {
    getInfoFromServerStart(ido);
 }).
 fail(function(a,b,c) {
     initJsReadFail(a,b,c,'choicer_admin.js');
 });
  return 1;
}

// not admin
   getInfoFromServerStart(ido);  // get a info from server (might take a while)


   return 0;                   //  getInfoFromServerStart will call functions that process  & display server info
}


//===================
// reload current page -- remove ALL stuff (rebuild using new info from server)
// but not a relogon. So save some userstuff (like name and admin privs)
// This is often done after a change, and the user wants the changes to be reflected in the content of the pages

function doReload(x) {

  let daUser=currentUserName ;
  let daLogonName=myLogonName;
  let qadmin=isAdminUser;
  let daReloads=nReloads ;
  let daLast=lastToDo;
  closeAllContent('doReload');
  showStatusMessage(0);   // often called from here

  resetAll(0);  // not really necessary (though removing entires from newSuggestions is useful)

// clear all server supplied info. Might clear some stuff that is user specific -- that's why some vars are saved locally (above)
  clearAllGlobals(1);

  currentUserName=daUser;   // since this is a reload, not a relogon
  isAdminUser=qadmin ;
  myLogonName=daLogonName ;
  lastToDo=daLast ;   // global
  nReloads=daReloads+1;

// get the info from server - typically after you made some changes and want them reflected in the content of the pages!
  getInfoFromServerStart(1,1);      // 2 means logoff, 3 means show schedule

}

//=======================
// reset content to "retrieved from server" status, and close all content
// this does not get anything from the server, and does not change info originally supplied by the server
// but it is called before retrieving info from server, just to be careful

function resetAll(ido) {

   if (arguments.length<1) ido=0;
   if (ido==2) {
      let q=confirm('Are you sure (all your changes, on all pages, will be removed');
      if (!q) return 0;
   }
   if (ido==1) closeAllContent('resetAll');  // if 0, assume was done before this call
   isAdminUser=false;

   $('#generalComment').val('');

  let enew=$('#newEntriesTable');    // remove new entry rows from new entry table
  let enewr=enew.find('.entryRow');
  enewr.remove();

 // note: there are no user changeable fields in viewSuggestions table (existingEntriesTable)

  ratingsReset(1);
  rankingsReset(1);    // in resetAll
  applySelectRecommendations(0)  ; // 0 means "apply" the saved currentUserName / current recommendations

  if (typeof(scheduleDo_clearAll)=='function') scheduleDo_clearAll(1);

  $('#admin_editSuggTableOuter').html('').show();     // admin stuff
  $('#mySchedule_alert').html('').hide();
  if (typeof(admin_editSugg)=='function') admin_editSugg(0);

  return 1;
}

//======================
// clear all server supplied information. These are variables declared (using  var xxx=nothing) in the index.php
// do before a logon/reload (a call to getInfoFromServerStart
function clearAllGlobals(ii) {
  isAdminUser=false ;           //if user is Admin, with correct pasword, this is set to true
  noChangesAllowed=false ;     // set if    enableNewUserCheck=2
  lastToDo=enterToDo ;         // when reloading, show the most recently opened page (sugg,rank, etc)
  myLogonName='' ;             // retain case of logon name. This is rarely used.
  currentUserName='';    // will be a one-word, lowerCase, no odd characters version of logonName. Used extensively!!
  nReloads=0;            // # of reloads this session. Not actively used  (3/2/2023)
  scheduleStuff={'list':[[],'']} ;  // used by schedule reorder

 // globals returned from server
  choiceArray=[] ;       // array of choices (in order of submission, oldest first). Values are ids (pointers into choiceList)
  choiceList={} ;       // attributes, own rating/ranking/reco, and summary status for all suggestions.
  choiceNames={}  ;    // indices are short versions of suggeestion names (commas after spaces remove, no multiple spaces) -- used to detect duplicates
  customVarList={};     // list of custom variables (varnames as indices, with length as values)
  basicStats={} ;       // various summary statistics
  membernameList={};      // list of usernames. Id is username. Fields are 'nsuggest','nrate','nrank','nrecommend'
  allCategories={'all':{},'current':''} ;    // categories (For each choice) for all users
  allRates={};          // ratings (for each choice, if one was made) for all users
  allRanks={}           // rankings (for each choice, if one was made) for all users
  allRecos={}           // recommendations, current and draft, for all users

  privateDownloadLink='' ; // prepended to download links  in choicer_params.php
  downloadUsers={'*':1};   // default is everyone can download. This is overwritten using info from server

   return 1;
}

//===================
// check if new user? Uses membeernameList that was supplied by server
// return 0 if not, 1 if new user will full rights, 2 if new user with viewing rights, 3 if new user not allowed entry

function doCheckNewUser(i1) {

   if (isAdminUser) return 0 ;
   if (enableNewUserCheck<1) return 0;

   if (membernameList.hasOwnProperty(currentUserName)) return 0 ;  // a member! good to go !!

// if here a "new" user:  someone who is not an identified "member"
// members are people (identified with the logon name) that have made any suggestions, ratings, rankings, or recommendations

  if (enableNewUserCheck==1  ) {   // just issue an alert
   let amess='';
   amess+='<div style="margin:5px 1.4em 10px 2em" > Hello <b>'+currentUserName+'</b>  ';
      amess+='This appears to be your first visit to this site?</div>';
      amess+='<ul class="cNewMemberQuery"><li>Perhaps you misspelled your name? If so -- <button onClick="doCheckNewUser2(1)">please try again</button>';
      amess+='<li>If you really are new to this site, we recommend reading the ';
      amess+=' <input type="button" value="Introductory Help"   onclick="doCheckNewUser2(2)"  > ';
//      amess+='<li>You can view a list of  <button onClick="doCheckNewUser2(4)">active members</button>';
      amess+='<li>You can <button onClick="doCheckNewUser2(3)">close this message</button> whenever you want. ';
      amess+='</ul>';

      let exx=$('#inewUserMessage');   // call of this will display it
      exx.html(amess);
     return 1 ;
   }

  if (enableNewUserCheck==2) {   // new users can view, but can't make changes.
   let amess='';
   amess+='<div style="margin:5px 1.4em 10px 2em" > Hello <b>'+currentUserName+'</b>.  ';
      amess+='This appears to be your first visit to this site?';
      amess+='<div style="font-size:120%;margin:0.5em 20%">You can view the contents, but you can <b>not</b> make changes</div>';
      amess+='<ul class="cNewMemberQuery"><li>Perhaps you misspelled your name? If so -- <button onClick="doCheckNewUser2(1)">please try again</button>';
      amess+='<li>If you really are new to this site, we recommend reading the ';
      amess+=' <input type="button" value="Introductory Help"   onclick="doCheckNewUser2(2)"  > ';
//      amess+='<li>You can view a list of  <button onClick="doCheckNewUser2(4)">active members</button>';
      amess+='<li>You can <button onClick="doCheckNewUser2(3)">close this message</button> whenever you want. ';
      amess+='</ul>';
      let exx=$('#inewUserMessage');
      exx.html(amess);

     return 2 ;
   }


  if (enableNewUserCheck==3) {   // do not allow access
   let amess='';

   amess+='<div style="margin:5px 1.4em 10px 2em" > Hello <b>'+currentUserName+'</b>  ';
      amess+='This site is currently not available to new members.</div>';
      amess+='<ul class="cNewMemberQuery"><li>Perhaps you misspelled your name? If so -- <button onClick="doCheckNewUser2(1)">please try again</button>';
      amess+='</ul>';
     let exx=$('#inewUserMessage');
     exx.html(amess) ;
     return 3
   }
}



//=--- helper function
function doCheckNewUser2(ith) {
   if (ith==1) {   // logon again
     doLogon(2) ;               // new user check... give 'em a chance to get their name right
     $('#inewUserMessage').hide();
     $('#imyLogonName').focus();   // make it easier to find the logon box
     return 1;
  }
  if (ith==2) {   // view help
      $('#inewUserMessage').hide();
      wsurvey.wsShow.show('#showIntroduction');
     return 1;
  }
  if (ith==3) {   // close
      $('#inewUserMessage').hide();
      return 0;
  }
  


}

// ====
// secondary help containers





//========================
// show alerts on logon (after all content retrieved from server and properly displayed
function doShowUserAlerts(i) {
   if (isAdminUser) return 0 ; // don't nag the admin!

//  var enableAlertRank=0  ;   0: do not enable noRanks alert, 1: enable. Message pops up if user had not ranked anything
//var enableAlertRate=0  ;  0 : do not enable rate alerts, >0 enable alerts if less than this number of ratings
var messages=[];
if (enableAlertRate>0) {
   if (typeof(basicStats['raterList'][currentUserName])=='undefined') {
     messages.push('You have not rated any choices.');
   } else {
      if (basicStats['raterList'][currentUserName]<enableAlertRate) {
          messages.push('You have only rated '+basicStats['raterList'][currentUserName]+' choices');
      }
   }
}
if (enableAlertRank>0) {
   if (typeof(basicStats['rankerList'][currentUserName])=='undefined') {
     messages.push('You have not ranked any choices.');
   } else {
      let sumM=basicStats['rankerList'][currentUserName]['next'];
      let sumT=basicStats['rankerList'][currentUserName]['top'];
      if (sumM<enableAlertRank || sumT<enableAlertRank) {
          let acomma=' '
          let ztop= (sumT<enableAlertRank) ? sumT+' <em>top 9</em> choices' : '';
          let znext= (sumM<enableAlertRank) ? sumM+' <em>next 9</em> choices ': '';
          if (sumT<enableAlertRank && sumM<enableAlertRank) acomma=', ';

          messages.push('You have only ranked: '+ztop+acomma+znext);
       }
   }
}

if (messages.length>0)  {     // some error messages .. display in status
  let amess='Hello <tt>'+currentUserName+'</tt>. We notice that: ';
  amess+='<ul><li>'+messages.join('<li>')+'</ul>';
  writeStatusMessage(amess,1);
  return true ;
}
return false ;



}



//====================
// compress selected elements under a descendant of athis.
//  Ancestor is identified by having a canCompressOuter class
// &#11246; right double head arrow (click to expand), &#11244; left double head arrow (click to compress

function doCompressHeaderRow(athis) {
   let ethis=wsurvey.argJquery(athis);
   let esite=ethis.closest('.canCompressOuter');
   if (esite.length!=1) return 0 ;
   let ecompress=esite.find('.canCompress');
   let istatus=ethis.attr('data-status');

   if (istatus==1)  {                    // uncompressed... so compress
      ecompress.hide();
   } else {
     ecompress.show();
   }
   istatus=1-istatus;

   ethis.attr('data-status',istatus);
   if (istatus==0) {
       ethis.html('&#11246;');
       ethis.attr('title','click to expand this row');
   } else {
       ethis.html('&#11244;');
       ethis.attr('title','click to compress this row');
   }
   return 1;
}


//===================
// save a general comment to the server
function saveCommentsToServer(ii) {
  let ecomment=$('#generalComment');
  let aval=jQuery.trim(ecomment.val());
  if (aval=='') {
     alert("You did not enter a general comment ");
     return 0;
  }
  let ddata={};
  ddata['todo']='saveComment';
  ddata['theProject']=useProject ;

  ddata['username']=currentUserName;  // global
  ddata['comment']=fixString(aval,2);    // all on one line
  $.ajax({
        url: 'choicer_comment.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function (response) {
       writeStatusMessage(response,2,1,5000);
    });

}

//===============
// show all help in a new window   -- with list of topic internal links at top

function showHelpInNewWindow(ido) {

    let dd1=wsurvey.get_currentTime(31,1);
    let topiclist=[];
    let ee=$('[data-helpbox]');
    let acontent='';
    for (let iee=0;iee<ee.length;iee++) {
        let ae=$(ee[iee]);
        let topic=ae.attr('data-helpbox');
        let goo= topic;
        topiclist.push(goo);
        let aid=ae.attr('id');
        let stuff=ae.html();
        let a1='<div style="font-size:120%;background-color:cyan;margin:2em">';
        a1+='<a href="#topicList">&uArr;</a> ';
        a1+='<a name="topic_'+iee+'">:'+topic+'</a></div>'+stuff  ;
        acontent+=a1 ;
    }

   let oof="&nbsp;&nbsp;<br><b>Help topics </b>";
     oof+='<div style="border:1px solid blue;margin:3px 3px 1em 3px"><a name="topicList">&nbsp;</a> ';
   let aspan='<span class="showAllHelp_topicBox">';
//   style="border:1px solid black;padding:1px 4px;margin:1px 4px;display:inline-block;width:15em;max-height:2em;overflow:auto"> ';
   for (let ij in topiclist) {
      let atopic=topiclist[ij];
      oof+=aspan+'<a href="#topic_'+ij+'">'+atopic+'</a></span> ';
   }
   oof+='</div>'
   acontent=oof+acontent;
   
   
   if (ido!=1) {       // quickly display in new window
      let opts={'header':'<tt>'+dd1+'</tt>.  Current user: <u>'+currentUserName+'</u>','title':'wsChoicer help screens'};
      opts['content']=acontent;
      opts['name']='viewHelp';
      wsurvey.displayInNewWindow(2,opts);
      return 1;
   }

   let da1='<div id="preEchoBack">';
   da1+=acontent;
   da1+='</div>';
 
   $('body').append(da1);
   let eda1=$('#preEchoBack');
    eda1.find('.wsShowH').remove();
    eda1.find('#topRowButton_help').remove();
    eda1.find('.wsShowF').remove();
    eda1.find('.wsShowS').remove();
    eda1.find('.showInNewWindow').remove();
    eda1.find('.cTopRowButton').prop('disabled',true).css({'opacity':0.5}); ;
    eda1.find('.chelp_header_gobuttons').remove();
    let bcontent=eda1.html();
    eda1.remove();



// input should be an object of 'varname':value elements
// If arrays are to used as values, they should first be 'varname':JSON.stringify(avar);
// and on the php end, use json_decode($_REQUEST['varname'],1);

   let ado={'content':bcontent,'username':currentUserName,'theProject':useProject};
   submitQuickForm('choicer_echoback.php', 'POST', ado,'helpview') ;
    return 1;

}

// ===============
// detect f1 key
function showKeyHelp(aevent) {

 let shm=$(document).data('showingMain') ; // set by showxx functions  [eUse,todoName,mode (0..)]
 if (typeof(shm)=='undefined')  return 1; // should never happen
 let amain=shm[1];
  if (amain=='view')  wsurvey.wsShow.show('#iSuggestionsHelpMore');
  if (amain=='rate')  wsurvey.wsShow.show('#helpRatingDiv2');
  if (amain=='rank')  wsurvey.wsShow.show('#helpRankingDiv2');
  if (amain=='reco')  wsurvey.wsShow.show('#helpRecoDiv2');
  if (amain=='new')  addSuggestionHelp(2);
  if (amain=='sched')  wsurvey.wsShow.show('#scheduleHelpMore') ;

}
 


//===========
// functions used by navigation buttons

//===========
// scroll table of table of suggestions (on the view,rate,rank, or recommend page)
// ii=0 top, ii=1 bottom
 
function doScrollInTable(ii) {
  
// admin page open?
   let eadmin=$('#myadminMenu');
   if (eadmin.length==1) {
      let eadmin2=$('#myScheduleAdmin_alert');
      if (eadmin2.is(':visible')) { 
        if (ii==0) {
           eadmin.animate({'scrollTop':'0px'},200);
        } else {
          let k1=eadmin[0].scrollHeight  ;
          eadmin.animate({'scrollTop':k1+'px'},300);
        }
        return 1;
     }
  }
  
// admin page not open

  let aa=$(document).data('showingMain') ; // set by showxx functions  [eUse,todoName]
  let euse=aa[0],apage=aa[1];
  let eouter;

  if (apage=='new') return 1 ; // disabled if add suggestion

  if (apage=='comm') {
    eouter=$('#genericComments');
  } else {
    eouter=euse.find('[name="tableOuter"]');
  }
  if (ii==0) {
    eouter.animate({'scrollTop':'0px'},200);
  } else {
      let k1=eouter[0].scrollHeight  ;
      eouter.animate({'scrollTop':k1+'px'},300);
  }
}

//===============
// scroll to top of screen
function goTopScreen(i) {
   $('html, body').animate({ scrollTop: '0px' }, 'slow');
}


// change size of div (the xxDivOuter) around a suggestions table
function changeTableSize(idire) {
  let aa=$(document).data('showingMain') ; // set by showxx functions  [eUse,todoName]
  let euse=aa[0],apage=aa[1];
  let eouter=euse.find('[name="tableOuter"]');
  let aheight=parseInt(eouter.height());
   let frac1=25 ;
//  let frac1=aheight/10 ;  // could use fraction of current height
  let newheight=aheight+(idire*frac1) ;
  newheight=parseInt(newheight);
  eouter.css({'height':newheight});

}


//=============
// change size of div   List of current choices (ranks or recos) container
function changeTableSizeChoiceList(idire ) {
  let aa=$(document).data('showingMain') ; // set by showxx functions  [eUse,todoName]
  let euse=aa[0],apage=aa[1];
  let eouter=euse.find('[name="listOfCurrentChoices"]');
  let aheight=parseInt(eouter.height());
  let frac1=25 ;            // could make this farction of current height
  let newheight=aheight+(idire*frac1) ;
  newheight=parseInt(newheight);
  eouter.css({'height':newheight});

}
//=============
// toggle between preset sizes. The set of presets depends on what page is being displayed
// For view: take up full screen, or 2/3 (leaving 1/3 for general comments
//    rate: full screen (basically, a reset after window resizing, help viewing, etc
//    rank : toggle size of "list of rankings" container (small, 100%, big), and adjust table to fit remainder
//    reco : toggle size of "list of recommendations" container (small, 100%, big), and adjust table to fit remainder

function doPresetHeights(ii) {
  let aa=$(document).data('showingMain') ; // set by showxx functions  [eUse,todoName]
  let euse=aa[0],apage=aa[1],viewmode=aa[2];
  let eouter=euse.find('[name="listOfCurrentChoices"]');

// simple case: fill screeen (replicate what happens on show page, without closing everything and opening the page
  if (apage=='view')  {                         // make table fill screen (similar to what is done on showing page)
    showCurrentSuggestions(0,viewmode)     ;     // only one viewing mode for rate (reset to fill)
  }
  if (apage=='rate')  {                         // make table fill screen (similar to what is done on showing page)
    showRatings(0,viewmode)     ;
   }
  if (apage=='sched')  {                         // make table fill screen (similar to what is done on showing page)
    showSchedule(0,viewmode)     ;
   }

  if (apage=='rank')  {                         // make table fill screen (similar to what is done on showing page)
    viewmode++;
    if (viewmode>2) viewmode=0;   // 3 modes, then cycle back
    showRankings(0,viewmode)     ;
    aa[2]=viewmode;
    $(document).data('showingMain',aa);
  }
  if (apage=='reco')  {                         // make table fill screen (similar to what is done on showing page)
    viewmode++;
    if (viewmode>2) viewmode=0;   // 3 modes, then cycle back
    showRecommendations(0,viewmode)     ;
    aa[2]=viewmode;
    $(document).data('showingMain',aa);
  }

  if (apage=='sched')  {                         // make table fill screen (similar to what is done on showing page)
    viewmode++;
    if (viewmode>2) viewmode=0;   // 1 modes, then cycle back
    showSchedule(0,viewmode)     ;
    aa[2]=viewmode;
    $(document).data('showingMain',aa);
  }

}

//=============
// close all help screens and info boxes
function closeAllHelp(ii) {
  let ehelp=$('[data-helpbox]');
  ehelp.hide();
  let einfo=$('[data-infobox]');
  einfo.hide();
  eother=$('[data-otherbox]');
  eother.hide();
}