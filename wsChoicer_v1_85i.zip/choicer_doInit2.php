<?php

// create a choicer_init.php file
if (!array_key_exists('md5',$_REQUEST)) {
  print "bad request ";
  exit;
}

 $curDir=getcwd();
 $getPwdsFile=$curDir.'/params/choicer_init.php';
 if (!file_exists($getPwdsFile)) {
   print "no choicer_init.php ";
   exit;
 }
 require_once($getPwdsFile);

 if (!isset($adminPwd) || $adminPwd!==false)  {
      print "problem with choicer_init.php "  ;  // could be a clever hacker? --
      exit;
 }


 $amd5=$_REQUEST['md5'];

 $amess="<?php \n\n ";
 $amess.=" //md5 of the Admin user password  \n";
 $amess.=" //  set =false to invoke `wsChoicer initialzation` as the home page -- where you can specify a new admin password \n";
 $amess.='$adminPwd="'.$amd5.'" ;'."\n" ;
 $amess.="\n" ;
 $amess.="// '*' means `by default: show list of projects` \n";
 $amess.="// ?project=projectName in a url will override this  \n";
 $amess.="\n";
 $amess.='$defaultProject="*" ; '."\n\n";
 $amess.="?> \n\n";

 $nbytes=file_put_contents($getPwdsFile,$amess);

 if ($nbytes===false) {
    print "Unable to save: $getPwdsFile ";
     exit;
 }

// now save message (displayed on home page abouve list of projects)
$tmessage=trim($_REQUEST['topMessage']);
$messFile=$curDir.'/data/projectIntro.html';
$nbytes2=file_put_contents($messFile,$tmessage);

 print "Saved $nbytes to $getPwdsFile, and $nbytes to $messFile.\n Using adminPwd=$amd5.\n Please reload wsChoicer (to go to the next initialization step)!";

?>


