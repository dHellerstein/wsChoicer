<?php
session_start() ;
ob_start();

// ============
// publish a schedule -- or save specs in a .js file

// add some php functions
$curDir=getcwd();
$libfile=$curDir.'/choicer_lib.php';
require_once($libfile);

$useProject=$_REQUEST['theProject'];
$paramsFile=$curDir.'/data/'.$useProject.'/params/choicer_params.php';   // customVars, etc ...
if (!file_exists($paramsFile)) {
    ob_end_clean();   // remove prints and other crap
    $amess="Error: missing parameters file: $paramsFile ";
    $stuff=['error'=>$amess];
   $vsuggests=json_encode($stuff, JSON_UNESCAPED_UNICODE);  // encode for web transmission
   print $vsuggests;
   exit;
}

//$paramsFile=$curDir.'/params/choicer_params.php';   // customVars, etc ...
require($paramsFile);

$todo=$_REQUEST['todo'];

$arr=$_REQUEST ;
unset($arr['todo']);   // don't need it anymore

if ($todo=='html') {
   $atitle= (array_key_exists('title',$_REQUEST)) ?  $_REQUEST['title'] : 'a schedule ';
   $s2=goMakeHtml($arr,$scheduleTopHeader,0,'',$atitle);      // scheduleTopHeader is in choicer_params.php, gomakehtml is in choicer_lib.php
   print $s2 ;  // will be printed to a new window
   exit;
}
if ($todo=='json') {
   goMakeJson($arr);
   exit;
}


 print "no such todo: $todo ";
 exit;



//================
// create a .json file with specs of this schedule
function goMakeJson($arr) {
  $stuff=[];

  $awho=$arr['who'];
  $atime=$arr['time'];
  $acomment= strtolower(trim(preg_replace("/\s+/", " ", $arr['comment'])));  // overkill but wth

  $afilename=trim($arr['filename']);

  $stuff['who']=$awho;
  $stuff['time']=$atime ;
  $stuff['acomment']=$acomment;


  $amess="// json save of schedule from $awho @ $atime \n";
  $amess.="// comment: $acomment \n";
  $amess.='if (typeof(choicerSaves)=="undefined") choicerSaves={} ; '. "\n";
  $amess.="choicerSaves['$afilename']={} \n";
  $amess.="choicerSaves['$afilename']['who']='".$arr['who']."' ;\n";
  $amess.="choicerSaves['$afilename']['acomment']='".$arr['comment']."' ;\n";
  $amess.="choicerSaves['$afilename']['header']='".$arr['header']."' ;\n";
  $amess.="choicerSaves['$afilename']['supressLocalDownload']='". $arr['supressLocalDownload']."' ; \n";
  $amess.="choicerSaves['$afilename']['keycode']='". $arr['keycode']."' ; \n";
  $amess.="choicerSaves['$afilename']['scheduleVar']='". $arr['scheduleVar']."' ; \n";
  $amess.="choicerSaves['$afilename']['schedulerType']='". $arr['schedulerType']."' ; \n";
  $amess.="choicerSaves['".$afilename."']['linkIcons']=JSON.parse('".$arr['linkIcons']."') ;\n";
  $amess.="choicerSaves['".$afilename."']['recosUsed']=JSON.parse('".$arr['recosUsed']."') ;\n";
  $amess.="choicerSaves['".$afilename."']['recosNotUsed']=JSON.parse('".$arr['recosNotUsed']."') ;\n";
  $amess.="choicerSaves['".$afilename."']['recoData']=JSON.parse('".$arr['recoData']."') ;\n";
  $amess.="choicerSaves['".$afilename."']['schedule']=JSON.parse('".$arr['schedule']."') ;\n";

  $usefile=pathinfo($afilename, PATHINFO_FILENAME).'.js' ;


 $slen=strlen($amess);
 ob_end_clean();
 header('Content-type: text/plain' );
 header("Content-Length: " . $slen);
 header('Expires: 0');
 header('Content-Disposition: attachment; filename='.$usefile);
 header('x-choicer: saved schedule from '.$awho.' using '.$afilename) ;
 print $amess;

 return 1;

}


