<?php

// ============
// backup choicer stuff
// creates vXXX directory
// copies all files in choicers, choicers/includes, choicers/params, choicers/css
// xxx is a VseqNumber -- adds 1 to current larget Vxxx directory on choicers


session_start() ;
ob_start();

// add some php functions
$curDir=getcwd();
$libfile=$curDir.'/choicer_lib.php';
require_once($libfile);

  $nowdate=date("Y-m-d h:i:sa");

$c1=$curDir.'/v*';
 $dirs = glob($c1, GLOB_ONLYDIR );
 $oink=[];
 foreach ($dirs as $i1=>$dname ) {
   $bb=basename($dname);
   $oink[]=substr($bb,1);
 }
 if (count($oink)==0) {
    $iuse=1;
 } else {
   sort($oink,SORT_NUMERIC);
   $ilast=count($oink)-1;
   $iuse=$oink[$ilast]+1;
 }
 $newDir=$curDir.'/v'.$iuse;
 mkdir($newDir)  ;

 print "\ @ $nowdate ";
 print "\nCreating $newDir ";

 $ncount=0; $nfail=0;
// copy all files in base (choicers

 $cmain=$curDir.'/*.*';
 $flist1= glob($cmain);
 foreach ($flist1 as $ii=>$afile) {
   if (is_dir($afile)) continue ;
   $bname=basename($afile)  ;
   $newname=$newDir.'/'.$bname ;
   $q1=copy($afile,$newname);
   if ($q1) {
      print "\n copy $afile as ::  $newname " ;
      $ncount++;
   } else {
      print "\n Can NOT copy $afile as ::  $newname " ;
      $nfail++;
   }
 }

// copy all files in includes (choicers

 $cincludes=$curDir.'/includes/*.*';
 $flist2= glob($cincludes);
 foreach ($flist2 as $ii=>$afile) {
   if (is_dir($afile)) continue ;
   $bname=basename($afile)  ;
   $newname=$newDir.'/'.$bname ;
   $q1=copy($afile,$newname);
   if ($q1) {
      print "\n copy $afile as ::  $newname " ;
      $ncount++;
   } else {
      print "\n Can NOT copy $afile as ::  $newname " ;
      $nfail++;
   }
 }

// copy all files in css (choicers

 $ccss=$curDir.'/css/*.*';
 $flist3= glob($ccss);
 foreach ($flist3 as $ii=>$afile) {
   if (is_dir($afile)) continue ;
   $bname=basename($afile)  ;
   $newname=$newDir.'/'.$bname ;
   $q1=copy($afile,$newname);
   if ($q1) {
      print "\n copy $afile as ::  $newname " ;
      $ncount++;
   } else {
      print "\n Can NOT copy $afile as ::  $newname " ;
      $nfail++;
   }
 }

// copy all files in params (choicers

 $cparams=$curDir.'/params/*.*';
 $flist4= glob($cparams);
 foreach ($flist4 as $ii=>$afile) {
   if (is_dir($afile)) continue ;
   $bname=basename($afile)  ;
   $newname=$newDir.'/'.$bname ;
   $q1=copy($afile,$newname);
   if ($q1) {
      print "\n copy $afile as ::  $newname " ;
      $ncount++;
   } else {
      print "\n Can NOT copy $afile as ::  $newname " ;
      $nfail++;
   }
 }

 $txtfile=$newDir.'/readme.txt';
 $txt="Backup created on $nowdate ";
 file_put_contents($txtfile,$txt);

 print "\n $ncount files copies, $nfail failures ";

 exit;

?>