<?php
// works with recommendations  page.

session_start() ;
ob_start();

// add some php functions
$curDir=getcwd();
$libfile=$curDir.'/choicer_lib.php';
require_once($libfile);


$username=$_REQUEST['username'];
$useProject=$_REQUEST['theProject'];
$todo=$_REQUEST['todo'];     //   updateRates is only one for now
 if ($todo=='saveRecos') {
      doSaveRecos($username,$useProject);
      exit;
  }
 exit;

 //=-=========================== _sortuse
// save recommendations for a user
// two versions: permanent (.rcm) and draft (.rcw)

function doSaveRecos($currentUser,$useProject) {
 $atime=time();
 $updateDate=date("Y-m-d H:i") ;

 $comment=$_REQUEST['comment'];
 $isDraft=$_REQUEST['draft'];
 $curList=$_REQUEST['list'];

 $amess='';
 if ($isDraft==1) {
    $amess="; recommendations (draft version) \n";
    $amess.="draft: 1 \n";
 } else {
    $amess="; recommendations (current version) \n";
    $amess.="draft: 0 \n";
 }
 $amess.="comment: $comment \n";
 $amess.="username: $currentUser \n";
 $amess.="date: $updateDate \n";

 $amess.="list:  $curList \n";

 $curDir=getcwd();
 
 if ($isDraft==1) {
   $doFile=$curDir.'/data/'.$useProject.'/submits/recoDraft'.$atime.'.rcw';
   $fp=fopen($doFile,'w');
//   $fp=fopen('submits/recoDraft'.$atime.'.rcw','a');
 } else {
   $doFile=$curDir.'/data/'.$useProject.'/submits/recoDraft'.$atime.'.rcm';
   $fp=fopen($doFile,'w');
//   $fp=fopen('submits/reco'.$atime.'.rcm','a');
 }

  fwrite($fp,$amess);
  fclose($fp);
 removeCacheFile($useProject);  // remove the .csh file

 $foo=explode(',',$curList);
 if ($isDraft==1) {
    print "Saved ".count($foo)." recommendations (draft version) @ $updateDate ";
 } else {
    print "Saved ".count($foo)." recommendations (current version) @ $updateDate ";
 }
  exit;
}
