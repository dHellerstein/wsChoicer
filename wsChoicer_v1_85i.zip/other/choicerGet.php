<?php
if (ob_get_level()) {
      ob_end_clean();
}
$a=$_REQUEST['todo'];
$adir1=getcwd();
$adir1 = dirname($adir1 );  // parent of /src 
$afile=$adir1.'/'.$a;
$q=file_exists($afile);
if (!$q) {
   print "No such file ($a): $afile ";
   exit;
}
$fsize=filesize($afile);
$mtype=mime_content_type($afile);
 header('Content-type: '.$mtype);
 header("Content-Length: " . $fsize);
 header('Expires: 0');
 header('Content-Disposition: attachment; filename='.$afile);
 header('x-sf23: hello');
readfile($afile);
exit;
