//===================
// make the recommendations page
function makeRecoTable(i1) {

// the big table to be written starts with the included toprow

 let allTable='';
 allTable+=' <table rules="rows" id="theRecommendationsTable" style="width:90vw" ';
 allTable+='       class="recommendationsTable" cellspacing="3"  rules="cols"  > '
 allTable+=allRecos['topRow'];

// some values to display in header
  let nRaters=basicStats['nRaters'];
  let nRankers=basicStats['nRankers'];
  let nPeople=basicStats['nMembers'];
  let showTranches=['','cTranche1','cTranche2','cTranche3','cTranche4','cTranche56','cTranche56','cTranche7'];

  let rankerList=basicStats['rankerList'];

   let amess='';

   amess+='<tt>'+basicStats['nSuggests']+'</tt> suggestions &amp; ';
    amess+='<tt>'+nPeople+'</tt> members <tt>: '+nRankers+'</tt> rankers, <tt>'+nRaters+'</tt> raters';

   $('#iallRecommendations_nrankers').html(amess); // write to title bar for this recommendations page

// &#11246; right double head arrow (click to expand), &#11244; left double head arrow (click to compress
   ctopmess='<div>';

   ctopmess+='<button class="cSideButtons" onclick="changeTableSizeChoiceList(-1)" title="Decrease the height of your current recommendations">&#10196;</button>';
   ctopmess+='<button class="cSideButtons" onclick="changeTableSizeChoiceList(1)" title="Increase the height  your current recommendations">&#10195;</button>';

   ctopmess+='<button title="Individual ranks on one line" id="iallRanksOnOneLine" onClick="allRanksOnOneLine(this)" data-oneline="0">&#10122;Line</button> ';

   ctopmess+=' Click a  '+choiceNameSay+' name to add (or remove) it from the <u>recommended</u> list! ';
   ctopmess+='  <span style="margin-left:2em">';
   ctopmess+='   When you are ready, you can ';
   ctopmess+='      <button  title="save recommendations, or view in a new window (or tab) ... " id="iSaveRecommendationsButton2"';
   ctopmess+='             class="cSaveRecommendationsButton cSaveRecommendationsButton_on"';
   ctopmess+='             data-dotrigger="#iSaveRecommendationsButton"  ';
   ctopmess+='             xonclick="doTrigger(this)">&#9997;Save recommendations</button>';
   ctopmess+='   </span> ';
   ctopmess+='</div>';

   ctopmess+='<div id="myRecommendationsListDiv_recommend"  class="cmyRecommendationsListDiv_recommend0" title="current recommendations">';
   ctopmess+=' <ol  id="myRecommendationsListDiv_recommend_ul" class="linearMenu_curRecommendations" start="0">   ';

   let rrct='<button title="remove all recommendations" onClick="removeAllRecommendations(this)">&#129533;</button>';
   rrct+='<span id="recommendationCount" class="crecommendationCount" title="Number of recommendations"></span>';
   let brecommend=' <button title="clear all markings (delete and move) " onClick="recoClickHandler(0,1)">Recommendations &hellip;</button>';
   ctopmess+='<li class="recommendationsListFirst">'+rrct+brecommend ;          // recommendations (that are removal) appended after here

// &#8667; right tripple bar arrow  , 8666 left
   let rrct2='';
    rrct2+='<button title="move recently select choice: to start of list " onClick="recommendationChangePos(-100)">&#8666;</button> ';
    rrct2+='<button title="move recently select choice: one to left " onClick="recommendationChangePos(-1)">&#8610;</button> ';
    rrct2+='<button title="move recently select choice: one to right " onClick="recommendationChangePos(1)">&#8611;</button> ';
    rrct2+='<button title="move recently select choice: to end of list " onClick="recommendationChangePos(100)">&#8667;</button> ';
   ctopmess+='<div class="creco_moveBoxes"  >'+rrct2+'</div>'
   ctopmess+=' </ol>';
    ctopmess+='<br clear="all" />';
   ctopmess+='</div>';

   ctopmess+='<div id="iviewNotes_recommendationsTableVer" class="cviewNotes_recommendationsTableVer" data-choiceid="0" title="notes"  >';
   ctopmess+='</div> ';

// this is inside of the myRecommendationsListDiv, but with fixed location. So can appear here in the code

   ctopmess+='<div id="myRecommendationsListDiv_saveBox" data-infobox_internal="save recommendations" class="cmyRecommendationsListDiv_saveBox" title="save current recommendations"> ';
   ctopmess+=' <button class="cCloseButton" onClick="wsurvey.wsShow.hide(this)" data-wsshow="#myRecommendationsListDiv_saveBox"  title="close this box">&#128473;</button>';
   ctopmess+='You can save the  <span name="nCurrentlySpecifiedRecos"></span> ';
   ctopmess+='    <em>currently specified recommendations</em> to the <u>'+ thisSiteName+'</u> server. ';
   ctopmess+=' The saved results are used permanently  -- but can be modified later. ';
   ctopmess+='<br>Or you can display the ';
   ctopmess+=' <span name="nCurrentlySpecifiedRecos"></span> <em>currently specified recommendations</em>  in a new window (as a table).';
   ctopmess+='<ul class="linearMenu_recoMenu" >';
   ctopmess+='<li style="width:2em" >';
   ctopmess+='   <button title="Clear the list of currently selected recommendations " ';
   ctopmess+='        onclick="removeAllRecommendations(this)">&#129533;  Clear</button> ';
   ctopmess+='<li>   <button title="Write the current  recommendations to a table in a new window" onClick="saveRecommendationList(1)">';
   ctopmess+='  Display as a table (in a new window)</button><br> ';
   ctopmess+='<label title="when writing tables... check to write notes in height limited container\nThis makes it easier to view on screen, but can limit what is printed">';
   ctopmess+='<input id="saveRecos_limitHeight" type="checkbox" value="1">Limit height of the boxes used for <em>descriptive notes</em>? </label>';
   ctopmess+='<li>   <button title="Save to server  -- the cuurently selected recommendations. These can be retrieved later" onClick="saveRecommendationList(4)">';
   ctopmess+='  Save to server </button> ';
   ctopmess+='<input type="button" value="?" title="What is a draft recommendation?"   onClick="wsurvey.wsShow.show(this)"  ';
   ctopmess+='       data-wsshow="#whatIsDraftReco"> ';
   ctopmess+='<br><label title="save as permanent, or a draft (in progress), version. One of each kind can be stored on the  server">';
   ctopmess+='<input id="saveRecos_draftVer" title="If unchecked, will be saved as the permanent version" type="checkbox" value="1">Save as a draft version?</label>';
   ctopmess+='</ul>';
   ctopmess+='<ul class="linearMenu_recoMenu" >';
   ctopmess+='<li   >';
   ctopmess+=' <em>Comment</em> ';
   ctopmess+='<li  class="recommendationsListFirst">';
   let dd1=wsurvey.get_currentTime(31,1);
   ctopmess+='  <textarea id="saveRecos_comment" title="optional comment" rows="1" cols="60">';
   ctopmess+='From '+currentUserName+' @ ' +dd1;
   ctopmess+='</textarea>';
//   ctopmess+='&#129533;  Clear</button>';
   ctopmess+='</ul>';
    ctopmess+='</div>';


   let eListDiv=$('#myRecommendationsListDiv') ; // save stuff to "header box", and set height
   eListDiv.html(ctopmess);

// .... create the  list of choices (one <tr> per choice)

  for (let ij1 in choiceArray) {

    let aid=choiceArray[ij1 ];
    let asugg=choiceList[aid] ;

    let arow='<tr class="recoRow" data-choiceid="'+aid+'">';

  // ::: name col

    let whoSubmit=asugg['submitBy'];
    let mvname2=asugg['shortName'].replace(/[\s\,]+/g, "").toLowerCase().substr(0,14) ;       // :::: choice name
    let mvname=asugg['Name'];

     arow+='<td >';
     arow+='<div class="crecName3" >';
     arow+='<button class="choiceReportButton" title="View details in a popup  " >&#129534;</button>';
     arow+='<button  title="view notes" class="creco_viewNoteButton" >&#128065;</button>';
     arow+='<label  data-mvid_addreco="'+aid+'">';
     arow+= '<button  class="caddRecommendationButton creco_addReco"  title="add/remove from recommendation list" >&#9673;</button>';
     let mvNameSpan=mvname;
     arow+='<span _sortUse="'+mvname2+'" title="'+aid+' : submitted by '+whoSubmit+'" class="cmvname_rec  creco_addReco2" name="recommendationsMvname">'+mvNameSpan+'</span>';
     arow+='</label>';
     arow+='</div>';
     arow+='</td>';


// :: category
    let catval= (asugg.hasOwnProperty('Category')) ? asugg['Category'] : ' ';     // :: Category
    let shtCat=catval.replace(/[\s]+/g, "").toLowerCase().substr(0,14);         // simplify for sorting purposes
    arow+='<td><span _sortUse="'+shtCat+'" class="categoryInViewTable"  >'+catval+'</span>';
    arow+='</td>';


// ::: avg rate
   let catvalRate= (asugg.hasOwnProperty('Rate')) ? asugg['Rate'] : '';      // :::::: own rate
   let catvalRate2=0;
   if (catvalRate!='') catvalRate2=parseInt(catvalRate);
   if (catvalRate2<0 || catvalRate2>4) catvalRate2=0;  // should never happen
   let avgRate=asugg['avgRate'];
   let navgRate=asugg['navgRate'] ;
   let avgRateUse= (navgRate==0) ? '&nbsp;' : avgRate.toFixed(1);
   let spanavg='<span  class="showTheseRates " title="the average rate (from '+navgRate+' raters)\nClick for details..." style="color:#6a6861;">'+avgRateUse+'</span>';
     let sayRate=rateSays[catvalRate2];
    let sayIcon=rateIcons[catvalRate2];
    let sayClass=rateClass[catvalRate2];
   arow+='<td>';
   arow+='<div style="border:1px dotted brown;padding:2px">';
   arow+='<span  _sortUse="'+catvalRate2+'">';
   arow+='<span  style="float:left;margin:2px 3px 2px 6px" class="'+sayClass+'" title="'+sayRate+'">'+sayIcon+ '</span>';
   arow+='<span style="float:right;margin:2px 7px 2px 3px">';
   arow+='<button title="View all ratings for this" class="showTheseRates showTheseRatesButton ">'+spanavg+'</button>';
   arow+='</span>';
   arow+='<br clear="all"></div></td>';


// ::: imprate

   let impRate=asugg['impRate'];
   let impRateUse= (navgRate==0) ? '&nbsp;' : impRate.toFixed(1);
   let spanavgImp='<span   title="the adjusted average rate (from '+navgRate+' raters)" style="padding-left:2em;color:#6a6861;">'+impRateUse+'</span>';
   arow+='<td><span  _sortUse="'+impRate+'"/>';
   arow+=spanavgImp;
   arow+='</span></td>';

// summary rank

   let noRank=asugg['noRankThis'];
   let summaryRank=parseInt(asugg['summary_rank']);
   let nboth,nnone,ntop;

   arow+='<td>';
   if (noRank==1)  {              // not subject to ranking (could be rankings exist for this, but ignore them
     arow+='<span _sortUse="0"></span>';
      arow+='<div class="cselectRank_noRank" title="This movie is not subject to ranking!">&#128721; No ranking for this movie!</div>';

  } else {       // subject to ranking
     arow+='<div style="border:2px dotted brown;padding:2px">';

     arow+='<span _sortUse="'+summaryRank+'"></span>';

     let rankSay=make_summary_rank_span(aid,0) ;
     arow+=rankSay;
     arow+='<span class="cAdjustedRank_recommendations" title="primary & secondary  score">';
     arow+=summaryRank.toFixed(0)+'</span> ';

     arow+='<span title="(#top9, #next9, # none)" style="float:right;margin-right:3px;font-family:monospace">';
     ntop=asugg['ntopRank'],nnext=asugg['nnextRank'];
     nboth=ntop+nnext;
     nnone=nRankers-(nboth);
     arow+='('+ntop+','+nnext+','+nnone+')';
     arow+='</span>';
     arow+='<br clear="all"></div> ';
  }    // rank details
  arow+='</td>';

// :: rank and rates details
  arow+='<td class="crecommendationsTable_colAll" name="recommendationsTable_colAll">' ;
  if (noRank==1)  {              // not subject to ranking (could be rankings exist for this, but ignore them
     let rwhy=asugg['noRankReason'];
     arow+='<span _sortUse="0"></span>';
     arow+='<div class="cCshowTrancheNoRank" title="not subject to ranking" >&#9940; '+rwhy+'</div> ' ;

  } else {

     arow+=' <span _sortUse="'+summaryRank+'" data-customCol="'+aid+'"  name="allRankings_byPerson" ';
     arow+='       data-origsortuse="'+summaryRank+'" data-totrankings="'+nboth+'"></span>';

     arow+='  <div title="Top 9 rankers " name="top9_list" class="ctop9_list" style="display: inline-block; min-width: 35%;"> ';
     arow+='   &#127299; &nbsp;';
     let top9s=asugg['topRank'];
     for (let itt=0;itt<top9s.length;itt++) arow+='<span class="ctop9_list_1">'+top9s[itt]+'</span>';
     arow+='</div>';

     arow+=' <div title="Next 9 rankers " name="next9_list" class="cnext9_list"  style="display: inline-block; border-left: 3px ridge blue; padding-left: 5px; margin-left: 2em;">';
     arow+=' &#127293; &nbsp;';
     let next9s=asugg['nextRank'];
     for (let itt=0;itt<next9s.length;itt++) arow+='<span class="cnext9_list_1">'+next9s[itt]+'</span>';
     arow+='</div>';
  }

 // toggleable row of rates
  arow+='<div class="crateListReco" title="Ratings for this '+choiceNameSay+'" >';
  arow+=' <ul class="linearMenuRateChoiceNew "><li><em>Ratings:</em>  </li> ';
  for (let rrname in asugg['allRates']) {
     let rrval=asugg['allRates'][rrname];
     arow+='<li>'+rrname+': '+rrval+'  </li> ' ;
  }

  arow+='</ul></div>';

  arow+='</td>';

//:::  recommendations

    arow+='<td class="crecommendationsTable_recoCol">';
    let useReco=parseInt(asugg['useReco']) ;
    let myReco=parseInt(asugg['useReco']) ;
    let myRecoSay= (myReco>0) ? myReco : '&empty;'  ;
    let nRecommenders=asugg['whoRecos'].length;

    let sortUseReco = (useReco>0 ) ? useReco : basicStats['nSuggests']+2  ; // more than # of suggestiosn (iow: can't have happened)

    arow+='<span _sortUse="'+sortUseReco+'"></span>';
    arow+='<span  class="creco_numRecos creco_whoReco"  name="ncreco_numRecos" ';
    arow+='    title="How many members recommended this?\nClick to view a list of who" >'+nRecommenders+'</span> ';

    if (useReco>0) {   // this is a recommended  choice (uising the currently retrieved recommendations
      arow+='  <span title="This is in the nth best (1=best) (in the  retrieved recommendations )" ';
      arow+='    class="creco_numRecos2">'+useReco+'</span>';
    }  else {
      arow+='  <span title="not in  retrieved recommendations" ';
      arow+='    class="creco_numRecos2"></span>';
    }

    if (myReco>0) {   // this is a recommended  choice (uising the currently retrieved recommendations
      arow+='  <span title="This is in the nth best (1=best) (in your current recommendations )" ';
      arow+='    class="creco_numRecos2a">'+myReco+'</span>';
    }  else {
      arow+='  <span title="not in your current recommendations" ';
      arow+='    class="creco_numRecos2a"></span>';
    }


    arow+='</td>';
    arow+='</tr>';

    allTable+=arow;
//    eTbody.append(arow);
  }
  allTable+='</table>';
  $('#theRecommendationsTableOuter').html(allTable)


 let eTableMain=$('#theRecommendationsTable');

// ... tweak the header
// populate the dropdown list (primary sort, aka who to sort by)
   let e1=$('#allSort_sortBy1');
   let a1='';
    a1+='<select onChange="recommendations_whoSort(this)" size="1" name="whoSort1" required id="iwhoSort1">';
   a1+='<option   value="None">none (just use secondary)</option>';
   a1+='<option selected value="Summary">summary_rank score</option>';
   a1+='<option  title="sum of top9 and next9 rankings"  value="mostRanks">most rankings</option>';
   a1+='<option  title="Currently retrieved recommendations (from first to last)"  value="currentRecos">retrieved recommend</option>';
   a1+='<option  title="Does this suggestion  in the recommendation list"  value="isRecommended">is recommended</option>';
   a1+='<option  title="Number of members who recommened a suggestion" value="nRecommenders"># recommending</option>';
   a1+='<option  title="One of your current recommendations (first to last)" value="ownRecommend">own recommend?</option>';

   for (let aname in basicStats['rankerList']) {
      let jranked=basicStats['rankerList'][aname];
      a1+='<option title="(number of '+choiceNameSay2+' ranked)" value="'+aname+'">'+aname+' ('+jranked+')</option>';
   }
   a1+='</select>';
   e1.html(a1);

// :: setup sort ...   (resize columns)

  let sopts={};                 // add table sort stuff
 //    sopts['skipCols']=[8,9]  ;
//   sopts['rowNumberClass']=1,
  sopts['rowNumberSortableClass']='rankRowNumber',
  sopts['rowNumberSortableIcon'  ]='&Oscr;';
  sopts['sortNumeric']=-1;
  wsurvey.sortTable.init('theRecommendationsTable',sopts)
  wsurvey.sortTable.rowColors('theRecommendationsTable',['tan','#dffef4','#f1f8fe' ]);

  let c1= (recoTable_colWidths.hasOwnProperty('sort')) ?  recoTable_colWidths['sort'] : 2 ;
   let c2= (recoTable_colWidths.hasOwnProperty('name')) ?  recoTable_colWidths['name'] : 15 ;
   let c3= (recoTable_colWidths.hasOwnProperty('category')) ?  recoTable_colWidths['category'] : 8 ;
   let c4= (recoTable_colWidths.hasOwnProperty('avgrate')) ?  recoTable_colWidths['avgrate'] : 8 ;
   let c5= (recoTable_colWidths.hasOwnProperty('imprate')) ?  recoTable_colWidths['imprate'] : 8 ;
   let c6= (recoTable_colWidths.hasOwnProperty('summary_rank')) ?   recoTable_colWidths['summary_rank'] : 12 ;
   let c7= (recoTable_colWidths.hasOwnProperty('allranks')) ?   recoTable_colWidths['allranks'] : 40 ;
   let c8= (recoTable_colWidths.hasOwnProperty('recos')) ?   recoTable_colWidths['recos'] : 8 ;

   if (!jQuery.isNumeric(c1) || !jQuery.isNumeric(c2) || !jQuery.isNumeric(c3) ||
          !jQuery.isNumeric(c4) ||   !jQuery.isNumeric(c5) || !jQuery.isNumeric(c6) ||
          !jQuery.isNumeric(c7) || !jQuery.isNumeric(c8)  ) {
          arf=[c1,c2,c3,c4,c5,c6,c7,c8];
       wsurvey.dumpObj(recoTable_colWidths,1,'Bad specification of  recoTable_colWidths: '+arf.join(', ')) ;
       return 0
    }

// note: no custom vars displayed in reco table!

    let colWidths=[c1,c2,c3,c4,c5,c6,c7,c8];       // sort button, who, name, category (in ems?)

   let totwidth=0;
   for (let itt=0;itt<colWidths.length;itt++) totwidth+=parseInt(colWidths[itt]);

   for (let itt=0;itt<colWidths.length;itt++)  {
      let apct=parseInt(100*colWidths[itt]/totwidth);
      colWidths[itt]=apct+'%';
   }
   let foo=wsurvey.sortTable.setTableColWidths('#theRecommendationsTable',colWidths,0);

   if (foo[0]===false) alert('Recommmendations table: '+foo[1]);

// hide sort button in the wide column (use the custom sort button instead
    let ecA=eTableMain.find('#irecoTable_rankCol');
    let ecB=ecA.find('[name="wsurvey_sortTable_button"]');
    ecB.hide();

// try to use 1 line mode?
  if (reco_ranksOn_1Line>0) $('#iallRanksOnOneLine').trigger('click') ;   // trigger button to use 1line mode (rank lists per row)
 
  let nmiss=applySelectRecommendations(0)  ;  // add users 'current' recomendatiosn to selected recommendations list -- are there anuy "mssing"

//  if (nmiss>0)  {          // probably a recommendation was removed
//    writeStatusMessage('Warning: '+nmiss+' recommendations are no longer available.<br> If these are your recommendations,  please examine and re-Save your &#127479;ecommendations! ',2,1,1);
//  }



// note who provided the retrieved recommendations
  let eWhoR=$('#irecommendations_lastGet');

  let theWho=allRecos['using'][0];
  let theWhoDraft=allRecos['using'][1];
  let nRR=allRecos['using'][2];
  if (theWhoDraft==1) theWho+=' (draft) ';
  eWhoR.html(theWho);

  let eWhoRN=$('#irecommendations_lastGetN');
   eWhoRN.html(nRR);

  return nmiss ;

}

//===================
// click handler for stuff in recommendations Table
// two types of elements are handled:
// view notes (class of creco_viewNoteButton
//  view who has recommended (creco_numRecos
// add/remove a choice to recommendation list (creco_addReco
// display list of raters (creco_raterList
function myRecomHandler(evt,aparam) {
 
   let atarget=evt.target;
   let etarget=$(atarget);
   let ecurrentReco=$('#myRecommendationsListDiv');
   let enotebox=$('#iviewNotes_recommendationsTableVer');

   if (etarget.hasClass('creco_viewNoteButton')) {         // view choice's notes in notes box in current-reco container
      let etr=etarget.closest('tr');
      let mvid=etr.attr('data-choiceid');
      let dnotes=getDescNotes(mvid,true,'<br/><em>n.a.</em>') ;    // (mvid,useDiv,noContent,noName)
      writeToNotesBox(mvid,dnotes,ecurrentReco,enotebox,'cviewNotes_recommendationsTableVer',false);

   } else if (etarget.hasClass('cviewAllRatesButton')) {   // 'view all rates': display  rates, for all choices (in the big column)
      let awhich=etarget.attr('data-which');
      let etable=$('#theRecommendationsTable');
      let etrs=etable.find('.recoRow');
      for (let irr=0;irr<etrs.length;irr++) {
         let aetr=$(etrs[irr]);
         let ee1=aetr.find('.crateListReco');
         if (awhich==1) {
             ee1.hide();
         } else {
             ee1.show();
         }
      }
      let newwhich= (awhich==1) ? 0  :  1;
      etarget.attr('data-which',newwhich);


   } else if (etarget.hasClass('creco_numRecos')) {    // for recommendations (who recommended)
      let etr=etarget.closest('tr');
      let mvid=etr.attr('data-choiceid')
      showWhoRecommended(mvid,ecurrentReco,enotebox,'cviewNotes_recommendationsTableVer')  ;

   } else if (etarget.hasClass('creco_addReco')) {          // green button -- add a recommeitdation
       let etr=etarget.closest('tr');
       let mvid=etr.attr('data-choiceid');
       noscroll= (arguments.length>1) ? aparam['noscroll'] : 0 ;
       addRecommendationButton(etarget,mvid,noscroll) ;

   } else if (etarget.hasClass('showTheseRates')) {   // avg rate button -- show list of all rates for one choice
        let etr=etarget.closest('tr');
        let ee1=etr.find('.crateListReco');
        ee1.toggle();
   }
   
  if (etarget.hasClass('choiceReportButton'))   {     // show report
     let etr=etarget.closest('tr');
     let mvid=etr.attr('data-choiceid');
     displayChoiceReport(mvid,'#theRecommendationsTable')    ;
     return 1 ;
  }        //  ============  choiceReportButton  =============



// else nto a click supported element
   return 1;

}

//============
//show list of who recomended this choice

function  showWhoRecommended(mvid,ecurrentReco,eNoteBox,aclass){

  if (!choiceList.hasOwnProperty(mvid)) {         // should never happen
     alert('no such index '+mvid+' in choiceList ');
     return 0;
  }

  let asugg=choiceList[mvid] ;

  mvname=asugg['Name'];
  let rlist=asugg['whoRecos'];

   let asay='';
   asay+='<ul id="whoRecos_mvid" class="linearMenu_recoMenu2" > ';
  asay+='<li style="background-color:#efefdf;width:15em;"><span ><b>'+mvname+'</b> had<br> <tt>'+rlist.length+'</tt> recommendations:</span> ';
  for (let ip=0;ip<rlist.length;ip++) {
      asay+='<li>'+rlist[ip];
  }
  asay+='</ul>';

// now display it

   writeToNotesBox(mvid,asay,ecurrentReco,eNoteBox,aclass,false);

}

//==============================
// add a recommendation (to top container in recomendations page  ) -- the buttons by the choicename in the recommendations table
//  noscroll is optional : if 1, do NOT scroll to top of myRecommendatiosn page

function addRecommendationButton(athis,amvid,noscroll) {
 
  if (arguments.length<3) noscroll=0;

  let ethis=wsurvey.argJquery(athis) ;

  let etd=ethis.closest("td");

// enlarge list of recommendations (on first recommendation)
   e0=$('#myRecommendationsListDiv_recommend');

   if (e0.hasClass('cmyRecommendationsListDiv_recommend0')) {
      e0.removeClass('cmyRecommendationsListDiv_recommend0');
      e0.addClass('cmyRecommendationsListDiv_recommend');
   }

   if (noscroll!=1) {
     let ep0=$('#myRecommendationsListDiv');
     ep0.animate({'scrollTop':'0px'},551);
   }

   if (etd.hasClass('cRecommendationAdded') )  { // already selected, so deselect
     let qq=doRecommendation_remove(amvid)
     if (qq==1) recommendationsCounter(-1);
     return 0
  }

// else, add to recommendations and mark name   as recommended

  etd.addClass('cRecommendationAdded');     // add to the button whose clickhandler called this

  let zchoice= (choiceList.hasOwnProperty(amvid)) ? choiceList[amvid] : false;     // should never happen
  if (zchoice===false) {        // should never happen
     alert('Unable to match '+amvid);
     return 0;
  }
  let mvname=zchoice['Name'];               // add this "recommendation <li><span> to list of recommendations
// 8610 lef arrow with < on non arrow end, 8611 right arrow , &#11012; white left right arrow
   let butts='<button class="crecommendationPosChangeButton" title="Mark this for position change" xonClick="recommendationChangePosMark(this)">&#11012</button>';

  let ali='<li>'+butts+' <span  class="crecommendationEntry" data-clicks="0" data-mvid="'+amvid+'">'+mvname+'</span>';
  $('#myRecommendationsListDiv_recommend_ul').append(ali);
  recommendationsCounter(1);

}


//====================
// remove recommendation: clear name col for choiceid  , remove recommendation li for eli
// if eli not specified or = false, find   recommenation li with this amvid
function   doRecommendation_remove(amvid,eli) {

   let ediv=$('#theRecommendationsTable');                 // look in recommendations table
   let etds=ediv.find('.cRecommendationAdded');     // just look at highlighted cells
   let edo=etds.find('[data-mvid_addreco="'+amvid+'"]');    // which one of these matches this amvid
    if (edo.length>0) {
     let edo1=edo.closest('.cRecommendationAdded');
     edo1.removeClass('cRecommendationAdded');   // unhighlight cel
   }

   if (arguments.length<2 || eli===false)  {   // find li (in list of recommendation) with this amvid
       let eli0=getCurrentlySelectedReco(amvid);  // find a particular choice in current recommendation list (it might not be there)
       if (eli0===false || eli0.length==0)   return false ;
       eli=eli0.closest('li');
   }
   eli.remove();
   return 1;
}

//========
// scroll in the recommendation's table to the row with choiceid=amvid -- and highlight its 'name' td

function  doRecommendationMoveTo(amvid) {
   let ediv=$('#theRecommendationsTable');
   let etrs=ediv.find('.recoRow');
   let edo=etrs.filter('[data-choiceid="'+amvid+'"]');
   
   let st1=wsurvey.centerInParent(edo,{'duration':200,'yOffset':30});   // center in rankings table
   if (st1['change']===false) {
        wsurvey.dumpObj(st1,1,'Problem with centerInParent ');  // should never happen
    }

//   let aoffset=edo.position().top ;
//   let use1=Math.max(0,aoffset-200);
//   ediv.animate({'scrollTop':use1+'px'},600);
   return 1;
}

//============
// remove all  currently selected recommendations
function removeAllRecommendations(ido) {

  showSaveRecommendationsMenu(0);

  eli=getCurrentlySelectedReco(0);     // clear currently selected  recommendations
  if (eli!==false) {
    for (let ii=0;ii<eli.length;ii++) {
        let ali=$(eli[ii]);
        let amvid=ali.attr('data-mvid');
        doRecommendation_remove(amvid);
     }
   }
   recommendationsCounter('',1);


   return eli.length;
}

//=============
// change counter    by iadd (1 or -1)
// if set =1 , set counter to iadd (tyhpically 0)
// also enable/disable save recommendations button
function recommendationsCounter(iadd,set) {
   if (arguments.length<2) set=0;
   let ecter=$('#recommendationCount');
   if (set==1) {
     ecter.html(iadd);
     if (iadd==0) {
     } else {
     }
     return 0;
   }
   let act=ecter.text();
   if (jQuery.trim(act)=='') act=0;
   act=parseInt(act);
   act=act+parseInt(iadd)  ;
   if (act==0) {
        act='';
   }  else {
   }
   ecter.html(act);
}

///===============
// retrieve list of <span> that display currently recommended choices
// each of these is in a seperate <li>
// the data-mvid attribute contains the choiceid (and its .html() is the choice name
//  Each of these <span>s has a class=crecommendationentry -- that is used by the recommendationsTable click hancler.
//  When a <span> is clicked once, it scrolls the table to its row. And turns the color blue
//  Clicking again (without clicking on another <span> will remove the choice from the list of currently selected
// choices. That means removing the <span> for the list, and unmarking its row in the table
//
// if ii==1: just return jQuery object of the <span> one whose data-mvid matches ii
//
// if ii=0, get all. 
//    ivals=0  : return jquery object containing the spans. Which can be .filter(), etc 
//           1 : return object with each recommenation as: [choiceid]=recPos (recpos=0 is best,...).
//           2 : return array, with [0] being best, and the values being the choiceid
//
// In both cases, if NO current recommendations, return false

function getCurrentlySelectedReco(ii,ivals) {
  if (arguments.length<2) ivals=0;
   if (arguments.length<1) ii=0;
   let eul=$('#myRecommendationsListDiv_recommend_ul');

   let spans=eul.find('.crecommendationEntry')

   if (spans.length==0)   return false ;

   if (ii==0) {
      if (ivals==0) return spans;
      if (ivals==1) {      // object (properties are choiceIds, value is position in lis
        let vlist={};
        for (let iss=0;iss<spans.length;iss++)  {
           let jval=$(spans[iss]).attr('data-mvid');
           vlist[jval]=iss;
        }
        return vlist;
    } else if (ivals==2) {   // return as array (first in list is 0 in array)
          let vlist=[];
          for (let iss=0;iss<spans.length;iss++)  {
             let jval=$(spans[iss]).attr('data-mvid');
             vlist[iss]=jval;
        }
        return vlist;
    }
    return fals;
 }   // ii eq 0

// return span of matching choiceid
   let aa=spans.filter('[data-mvid="'+ii+'"]');  // collection of the spans showing choice names (with ids)
   return aa;  // might be 0 length

}


//=============
// mark this recommendation <li><span> for position change
function recommendationChangePosMark(athis) {
   let ethis=wsurvey.argJquery(athis);

   let earf=$('#myRecommendationsListDiv_recommend_ul');
   let earf2=earf.find('.crecommendationChangePosMark');   // note order (remove from all, then add to current)
   earf2.removeClass('crecommendationChangePosMark');
   ethis.addClass('crecommendationChangePosMark');

   let ethis1=ethis.closest('li');
   let espan=ethis1.find('span');
   let eaa=getCurrentlySelectedReco(0);

   let qq=espan.hasClass('crecommendation_posChange');  // do this BEFORE removing this class from all recoList spans
   if (eaa!==false) eaa.removeClass('crecommendation_posChange');  // remove from all prior. sort of inefficient if same cell is being moved again
   if (!qq)  espan.addClass('crecommendation_posChange');  // don't add if this is a toggle off
}

//==================
// move a recommendation up or down (left or right) in the list of recommended choices
// https://stackoverflow.com/questions/31046590/move-items-in-ul-li-up-and-down
function recommendationChangePos(idire) {

   let eaa=getCurrentlySelectedReco(0);
   if (eaa===false) return 0;
   let ea1=eaa.filter('.crecommendation_posChange');
   if (ea1.length==0) return 0;           // nothing mark for change

   let eli=ea1.closest('li');         // should be just one
   let ndo=Math.abs(idire);
   let ndire=-1;
   if (idire>0) ndire=1;
   let doagain=0;
   if (Math.abs(idire)>1) doagain=1;

   for (j=1;j>0;j++)   {   // end via return -- either after just one, or when at ends of list
     if (ndire==-1) {
         before = eli.prev();
         if (before.hasClass('recommendationsListFirst'))  return 0;  // don't go before header cell
         eli.insertBefore(before);
     } else {
         after = eli.next();
         if (after.length==0) return 0 ;      // don't go past end of list
         eli.insertAfter(after);
     }
     if (doagain==0) return 0;
   }
   return 1;
}

/// =======================
// click handler for choice name <li><span> boxes in current recommendations list
// click 1: goto row i ntable
// click 2 (before any other clicks): remove from recommnedation list
// iclear=1 : ignore evt, just unset highlighting (by removing single click flag)
//
// OR ... for # recos boxes!

function recoClickHandler(evt,iclear)  {
    if (arguments.length<2) iclear=0;
    let edivUl=$('#myRecommendationsListDiv_recommend');

    if (iclear==1) {               // unclear (click on the recommendations... buttn
      let elis=edivUl.find('.recommendationsClick1');
      elis.removeClass('recommendationsClick1');

      let elis2=edivUl.find('.crecommendation_posChange');
      elis2.removeClass('crecommendation_posChange');

      let earf=$('#myRecommendationsListDiv_recommend_ul');
       let earf2=earf.find('.crecommendationChangePosMark');   // note order (remove from all, then add to current)
      earf2.removeClass('crecommendationChangePosMark');

      return 1;
    }

   let atarget=evt.target;
   let etarget=$(atarget);

   if (etarget.hasClass('crecommendationPosChangeButton')) {  // mark a choice for position change
     recommendationChangePosMark(etarget);
     return 1;
   }

// not reco box? m
   if (!etarget.hasClass('crecommendationEntry')) return 1 ; // not a click on a choice name box in recommendatin list

   let amvid=etarget.attr('data-mvid');

   let clickOn=etarget.hasClass('recommendationsClick1');
   if (!clickOn) {                            // this is NOT a second click
      let eothers=edivUl.find('.recommendationsClick1');          // this was clicked indicator
      if (eothers.length>0) eothers.removeClass('recommendationsClick1');   // un single click everything (should be at most 1)
      etarget.addClass('recommendationsClick1');  // mark as clcked
      doRecommendationMoveTo(amvid);              // srcoll to appropriate row in recommendations table
      return 1;
   }              // no need to change counter

// if here 2nd click -- so remove  <li><span> in list of recommednations, and unhighlight is recommendations table
   let qq=doRecommendation_remove(amvid) ;
   if (qq==1) recommendationsCounter(-1);

}


//===================
// save list of current recommendations
// DEPRECATED 0: open a container with some options
// 1: write currently selected recommendations   recommendations to html table in new window
// DEPRECATED 2: write all rcommendations (saved in this session) t
// DEPRECATED3 : save current recommendations locally. Can then be written (1 or 2), or saved to server (4)
// 4 : save to server (the currently selected recommendations )

function saveRecommendationList(i1) {
  
  let qb=true;
  let dd1=wsurvey.get_currentTime(31,1);

  if (i1==0) {        // open showRecommendationsList (rarely used)
    showSaveRecommendationsMenu(2) ;
    return 1;
  }
// get list of all current selected recommendations

  let curlist=getCurrentlySelectedReco(0,2);  // 2 means return array of choiceids; [0] is best (first inlist)
  if (curlist===false || curlist.length==0) {
     alert('There are no currently selected recommendations!');
     return 0;
  }

  if (i1==1  ) {                 // write table(s) to new window
     let ecomments=$('#saveRecos_comment');
     let comments=ecomments.val();
     let limitH=$('#saveRecos_limitHeight').prop('checked');
     let  fingus='';
     fingus+='<div style="background-color:#ebdeef;font-weight:700;margin-top:3em;border-top:2px solid brown;">'+comments+'</div>' ;
     fingus+='<table rules="rows" cellpadding="4">';
     fingus+='<tr><th>Name</th><td><em>Category</em></td>';

    for (let cvar in customVarList) {
       let vAtt=customVarList[cvar];
       let arequired=vAtt[1];
       if (arequired==1 || arequired==11) { // only show required
         fingus+='<td name="customVarCol" valign="top"><span class="customVarColVal">'+cvar+'</span></td>';
       }
     }

     fingus+='<th>AvgRate</th><th>ImpRate</th><th>summaryRank</th><th>Notes</th></tr> ';

// place each desc note inside of this div (</div> auto added at end
    let useDiv,astyle ;
    if (limitH) {  // use contents of class="cWriteNewWindowRecoNotes", since new window doesn't have css links
        astyle='max-height:2.5em;overflow:auto; padding:3px; margin:5px; border:1px solid gray ;';
    } else {                           // for printing
        astyle='max-height:52.5em;overflow:auto;padding:3px;margin:5px; border:1px dotted gray ;';
    }
    useDiv='<div style="'+astyle+'"  " >';

    for (let ido in curlist)  {            // for each currently selected recommendation
       let zid=curlist[ido];
       if (!choiceList.hasOwnProperty(zid)) continue ; // should never happen
       let asugg=choiceList[zid];
       r1='<tr class="recoRow_show">';
       r1+='<td>'+asugg['Name']+'</b> ';
       r1+='<td><em>'+asugg['Category']+' </em></td>';

      for (let cvar in customVarList) {
         let vAtt=customVarList[cvar];
         let arequired=vAtt[1];
         if (arequired==1 || arequired==11) { // only show required
           let cval=(asugg.hasOwnProperty(cvar)) ? asugg[cvar] : '' ;
           r1+='<td name="customVarCol" valign="top"><span class="customVarColVal">'+cval+'</span></td>';
       }
     }

       r1+='<td>'+asugg['avgRate'].toFixed(2)+'</td><td>'+asugg['impRate'].toFixed(2)+'</td>';
       r1+='<td>'+asugg['summary_rank'] +'</td>';

       let mynotes=getDescNotes(zid,useDiv,'<br/><em>n.a.</em>',true) ;    // // (mvid,useDiv,noContent,noName)

       r1+='<td>'+mynotes+'</td>';
       r1+='</tr>';

        fingus+=r1;

    }         // ido
    fingus+='</table> ';
    let opts={'header':'Currently selected '+choiceNameSay+' recommendations',
             'title':choiceNameSay+' recommendations ',
             'name':'recommends'};
    opts['content']=fingus;

    wsurvey.displayInNewWindow(1,opts);
    return 1;
 }


// save to server
  let ecomments=$('#saveRecos_comment');
   let comment=ecomments.val();
   let qDraft=$('#saveRecos_draftVer').prop('checked');
   isDraft = (qDraft) ? 1 : 0;

  let ddata={};
   ddata['username']=currentUserName;
   ddata['theProject']=useProject ;

   ddata['comment']=comment;
   ddata['draft']=isDraft;
   ddata['list']=curlist.join(',');
   ddata['todo']='saveRecos';

   $.ajax({
        url: 'choicer_recos.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function (response) {             // callback here (rather than seperate function)
       let datext=response['responseText'];
       datext+= '<br> :: :: ';
       datext+=' <button title="click to reload" onclick="doReload()">Reload </button> to view (on all pages) the revised recommendations ';
       writeStatusMessage(datext,2,0,1);
   });
}


// ====================
// see if both top9 and next9 lists can fit on one line
function showRecommendations_check1(c1) {
   if (c1!=2) return 0;
   let eb=$('#iallRanksOnOneLine');
   let is1=eb.attr('data-oneline');
   if (is1==0) return 0 ;           // not on one line

   let etable=$('#theRecommendationsTable');
   let etds=etable.find('[name="recommendationsTable_colAll"]');
   let nTest1=2,et9,em9 ;           // assume okay if no more than these spans (for either top9 or next9)

   for (ie1=0;ie1<etds.length;ie1++) {
       let aetd=$(etds[ie1]);
       et9=aetd.find('.ctop9_list');
       let et9spans=et9.find('span');
       em9=aetd.find('.cnext9_list');
       let em9spans=em9.find('span');
       let ok1=1 ;         // assume succes
       if (et9spans.length<=nTest1 && em9spans.length<=nTest1) continue ;  // if no list, or 2 or less... assume its okay
// too much .. so make this row two lines (at least one of these has non 0 length
       let etry1= (et9spans.length>0) ? et9spans[0] : em9spans[0] ;
       let etry2= (em9spans.length>0) ? em9spans[em9spans.length-1] : et9spans[et9spans.length-1];
       let qq=wsurvey.sameRowElements(etry1,etry2);

       if (et9spans.length>0 && em9spans.length>0) {                    //on same line
       }
       if (qq===true) continue ;

        et9.css({'display':'block'});
        em9.css({'display':'block','border-left':'','padding-left':'','margin-left':''});
   }  // for

}


//====
// open save reommendations menu
function showSaveRecommendationsMenu(i1) {
   let e1=$('#myRecommendationsListDiv_saveBox');
   if (arguments.length<2) i2=0;
  if (i1==0)   e1.hide();
  if (i1==1)   e1.toggle();
  if (i1==2)   e1.show();
  if (i1>2)   e1.show();         //fadeout not supported (for now)


    $('#myRecommendationsListDiv').animate({'scrollTop':'0px'},112);      // always scroll ?  !
//  }

  if (e1.is(':visible')) {           // update the # recommendations counters in the "save recommendations" box
    let ect=$('#recommendationCount');
    let act=ect.text();
    let eputs=$('[name="nCurrentlySpecifiedRecos"]');
    eputs.html(act);
  }

}

 //=================
 // write all  the ranks on one line (rather than seperate lines for top9 and next9
 // iforce: 0 : toggle, 1: force 1 line, 2: force 2 lints
function allRanksOnOneLine(athis,iforce) {
   if (arguments.length<2) iforce=0;
   let ethis=wsurvey.argJquery(athis);
    let astatus=0,newstatus=1;

   if (iforce==1)  newstatus=0  ; // force 1 line
   if (iforce==2)  newstatus=1   ; // force 2 line;
   if (iforce==0) {
      astatus=ethis.attr('data-oneline');     // 0 means currently 2 lines
      newstatus=1-astatus;                   // so toggle
   }
   let etable=$('#theRecommendationsTable');
   ecells=etable.find('[name="recommendationsTable_colAll"]')
   for (let ir=0;ir<ecells.length;ir++) {
     let acell=$(ecells[ir]);
     let ac1T=acell.find('.ctop9_list');
     let ac1M=acell.find('.cnext9_list');
     if (newstatus==1)  {                                    // not one line, so make it
        ac1T.css({'display':'inline-block','min-width':'35%'});
        ac1M.css({'display':'inline-block','border-left':'3px ridge blue','padding-left':'5px','margin-left':'2em'});
     } else {             // 2 lines
         ac1T.css({'display':'block'});
         ac1M.css({'display':'block','border-left':'','padding-left':'','margin-left':''});
     }
   }     // for each cell

   ethis.attr('data-oneline',newstatus);

}



//=====================
// display list of names -- to chose primary (who to sort by) by (for all column of recommendations table
// modify the _sortUse attribue  allRankings_byPerson of each row (to be the chosne persons rank: 1=top, 2=next, 3=none
// everyoneRanks.userTops_O[name][choiceid]=1 to indicate this person ranked this move top
// similar with everyoneRanks.userNexts
function recommendations_whoSort(athis) {

      let e1=$('#iwhoSort1');
     let e2=e1.find("option");
     let aa=e2.filter(":selected");
     if (aa.length==0) return 0 ;
     let aname=$(aa[0]).val();

     let egoo=$('#recommendations_currentSort') ;
     egoo.attr('data-sortwho',aname);
     changeRecommendationsSortButton(1);   // change text of custom sort button
     changeRecommendationsSortValues(1); // set the _sortUse values of the cells in this column (using attributes in custom sort button
}

//=================================
// secondary sort info -- how?

function recommendations_howSort(athis) {

  let e1=$('#iwhoSort2');
  let e2=e1.find("option");
  let aa=e2.filter(":selected");
  if (aa.length==0) return 0 ;

  let sortName=$(aa[0]).val();
  let egoo=$('#recommendations_currentSort') ;
  egoo.attr('data-sorthow',sortName);
  changeRecommendationsSortButton(2);     // change text of custom sort button
  changeRecommendationsSortValues(2);   // set the _sortUse values of the cells in this column (using attributes in custom sort button

}

//=================
// change the sort by button label (in everyone ranks column
function   changeRecommendationsSortButton(i1) {
  let egoo=$('#recommendations_currentSort') ;
  let sortWho=egoo.attr('data-sortwho');
 let sortHow=egoo.attr('data-sorthow');
  let sayit=sortWho ;
  if (sortHow!='none') sayit+=' / '+sortHow;

  egoo.html(sayit);
}


//==================
function changeRecommendationsSortValues(i) {
// 0   choice name, 1  avg rate, 2 flag for stream/download links, 3  ownrate , 4  year, 5 # raters, 6 submitter, 7 rankNotAllowed, 8 implicitAverageRate
// anyone with any rankings will have a row in veryoneRanks.userNexts and everyoneRanks.userTops
// note use min of 0.95 to ensure integer values do not change. Actually, 0.95 to allow for .fixed(2) to not
// round up to integer value

   let  arank;
   let pValues,sValues,highGood;
   let recoList={};

   let egoo=$('#recommendations_currentSort') ;
   let sortWho=egoo.attr('data-sortwho');
   let sortHow=egoo.attr('data-sorthow');  // none avgRate impRate mostTop mostRank
   let sortWhoLc=sortWho.toLowerCase();   // use Summary and mostRanks to ensure no conflict with a username


   let nRankers=basicStats['nRankers'];   // used to scale mostTop and mostRank

// get primary sort values

   if (sortWho!='Summary' && sortWho!='mostRanks' && sortWho!='currentRecos'   && sortWho!='ownRecommend'   &&
      sortWho!='None' && sortWho!='isRecommended' && sortWho!='nRecommenders') {        // if not one of these ...get the 9 top and next ranks for an individual

      let myTop9={},mynext9={}
      myTop9=(allRanks['userTops'].hasOwnProperty(sortWhoLc)) ? allRanks['userTops'][sortWhoLc] :  {} ;
      myNext9=(allRanks['userNexts'].hasOwnProperty(sortWhoLc)) ? allRanks['userNexts'][sortWhoLc] :  {} ;
      pValues=extractFromChoiceList('=',3);   // dfeault is no ranking
      for (let zid0 in myTop9) {
          let zid=myTop9[zid0];
          if (pValues.hasOwnProperty(zid)) pValues[zid]=1;
      }
      for (let zid0 in myNext9) {
          let zid=myNext9[zid0];
          if (pValues.hasOwnProperty(zid)) pValues[zid]=2;                // higher value are worse
      }
      highGood=0 ;                                // higher values are worse

   }  else if (sortWhoLc=='summary') {                    // use summary_rank. higher values are worse
        pValues=extractFromChoiceList('summary_rank',7);
        for (let ipp in pValues)   pValues[ipp]=parseInt(pValues[ipp]);
//        for (let ipp=0;ipp<pValues.length;ipp++) pValues[ipp]=parseInt(pValues[ipp]) ; // get rid of fractional part (we add our own below!)

        highGood=0 ;                                // higher values are worse

   }  else if (sortWhoLc=='mostranks') {                 // use mostRanks (top + next). lower values are worse
        pValues=extractFromChoiceList('nbothRank',0);
        highGood=1 ;                                // higher values are better

   }  else if (sortWhoLc=='currentrecos') {                 // the order in the retrieved recommendations. Higher is worse
        pValues=extractFromChoiceList('useReco',0);
        for (let pa in pValues) if (pValues[pa]==0) pValues[pa]=parseInt(basicStats['nSuggests'])+2;
        highGood=1 ;

   }  else if (sortWhoLc=='ownrecommend') {                 // the order in the your current recommendations. Higher is worse
        pValues=extractFromChoiceList('myReco',0);
        for (let pa in pValues) if (pValues[pa]==0) pValues[pa]=parseInt(basicStats['nSuggests'])+2;
        highGood=1 ;
                                   // higher values are better

                                   // higher values are better
   }  else if (sortWhoLc=='isrecommended') {                 // the order in the current recommendations. Higher is worse
        pValues=extractFromChoiceList('useReco',0);
        for (let pa in pValues) if (pValues[pa]>0) pValues[pa]=1 ;   // no or yes in recommendation list
        highGood=1 ;                                // higher values are better

   }  else if (sortWhoLc=='nrecommenders') {                 // the order in the current recommendations. Higher is worse
        pValues=extractFromChoiceList('whoRecos',0);
        for (let pa in pValues) pValues[pa]=pValues[pa].length ;   // # recommenders
        highGood=1 ;                                // higher values are better


   } else {                           // None
        pValues=extractFromChoiceList('=',0);
        highGood=1;
   }   // pvalue

// now get secondary values
   if (sortHow=='none')  {                       // no secondary sort
       // sValues=extractFromChoiceList('=',0); // leave pValues as is

    } else if (sortHow=='avgRate')       {   // avgRate. Lower is worse
        sValues=extractFromChoiceList('avgRate',0);
        for (let zid in sValues) {
           let zval=Math.min(0.95,sValues[zid]/4);    // 4 is best, so 1.0 (actually, 0.99) is best
           if (highGood==0) zval=1-zval  ;   // if lower is better, 0.99 becomes 0.01
           pValues[zid]+=zval;
        }
    } else if (sortHow=='impRate')       {   // avgRate. Lower is worse
        sValues=extractFromChoiceList('impRate',0);
        for (let zid in sValues) {
           let zval=Math.min(0.95,sValues[zid]/4);    // 4 is best
           if (highGood==0) zval=1-zval  ;   // if lower is better, 0.99 becomes 0.01
           pValues[zid]+=zval;
        }

    } else if (sortHow=='mostTop')       {   // avgRate. Lower is worse
        sValues=extractFromChoiceList('ntopRank',0);
        for (let zid in sValues) {
           let zval=Math.min(0.95,sValues[zid]/nRankers);     // cant be more than nRankers total rankings
           if (highGood==0) zval=1-zval  ;   // if lower is better, 0.99 becomes 0.01
           pValues[zid]+=zval;
        }

    } else if (sortHow=='mostRank')       {   // avgRate. Lower is worse
        sValues=extractFromChoiceList('nbothRank',0);
        for (let zid in sValues) {
          let wasp=pValues[zid];

           let zval=Math.min(0.95,sValues[zid]/nRankers);     // cant be more than nRankers total rankings
           let zvalA=zval;
           if (highGood==0) zval=1-zval  ;   // if lower is better, 0.99 becomes 0.01
           pValues[zid]+=zval;
        }

    } else {
       // sValues=extractFromChoiceList('=',0);  // use pValues as is
    }       // svalues

    let res1=wsurvey.sortTable.set_sortuse('#theRecommendationsTable',pValues,'[data-customcol]','data-choiceid');

// set the values of the .cAdjustedRank_recommendations box... kind of clumsy but don't know sort order
    let etable=$('#theRecommendationsTable');
    let etrs=etable.find('.recoRow');
    for (let iee=0;iee<etrs.length;iee++) {         // could use pValues and tr data-choiceid, but lets try this
       aetr=$(etrs[iee]);
       let ecol=aetr.find('[name="allRankings_byPerson"]');
       let ccval=parseFloat(ecol.attr('_sortUse')) ;
       ccval=ccval.toFixed(2);
       let eToFill=aetr.find('.cAdjustedRank_recommendations');
       eToFill.html(ccval);
    }

    if (res1===false || res1['nOk']==0) {
       wsurvey.dumpObj(res1,1,'problem setting up custom sort');
    }
    return 1 ;

 }


//=====================
// trigger click on the sort button in this the last col of reco table (after changing _sortUse attributes in all cells of the column
function doCustomSort_recos(athis) {
   let ethis=wsurvey.argJquery(athis) ;
   let eparent=ethis.closest('th,td');
   let esbutton=eparent.find('[name="wsurvey_sortTable_button"]');
   if (esbutton.length==0) {  // should never happen
      alert( 'doCustomSort_recos could not find sort button ');
      return 0;
   }
   esbutton.trigger('click');                      // the wsurvey.sortTable button 
}

//=======================
// insert some recomendation stats into basisStats. Uses allRecos
// only uses current recommendations (draft recommendations are works in progress)
function computeRecoStats(ii) {

   let nRecommenders=0,nTotalRecommendations=0,nChoicesRecommended=0;
   let zwhats=allRecos['nCurrent'];
    basicStats['recoList']={};
   for (auser in zwhats) {
      let idid=zwhats[auser];
// taken care of in getdata.php      membernameList[auser]['nrecommend']=idid;
      basicStats['recoList'][auser]=idid ;
      nRecommenders++;
      nTotalRecommendations+=parseInt(idid);
   }
   let zrecos=allRecos['whoRecos'];
   for (zid in zrecos) {
      nChoicesRecommended++;
   }
  basicStats['nChoicesRecommended']=nChoicesRecommended;
  basicStats['nTotalRecommendations']=nTotalRecommendations;
  basicStats['nRecommenders']=nRecommenders;


 return 1;

}
 
 
 //-----
// display a list of recommendations (from all mmebers, current and draft)
// current user then selects
// selectRecommendationsApply is then called (to apply the selected recommendations
// use the allRecos, and sets allRecos.who[name,isDraft
function selectRecommendations(ii) {
   let cuser=currentUserName ;
  let recos=allRecos['current'];   // [membername][zid][position]
  let recosDraft=allRecos['draft'];   // [membername][zid][position]

  let mine = (recos.hasOwnProperty(cuser)) ? recos[cuser] : {} ;
  
  let myR=0;
  for (let azid in  mine) myR++ ;

  let amess= 'Your have '+myR+' recommendations  in your <em>list of  saved  recommendations</em>  ';
  amess+='<br>Select a member: &nbsp;&nbsp;';

    let a1='' ;

    a1+='<select   size="1"   required id="iPeopleWithRecoList" title="Select a member (# of recommendations in parenthesis)">';
    a1+='<optgroup label="Your current recommendations" >';
    if (myR==0) {
       a1+='<option disabled selected value="'+cuser+'" title="You have not saved any recommendations!">'+currentUserName+' ('+myR+')</option>';
    } else {
       a1+='<option selected value="C.'+cuser+'">'+cuser+' ('+myR+')</option>';
    }
   a1+='<optgroup label="Other members: current recommendations" >';
   for (let aname in recos ) {
      if (aname==cuser) continue;
      let areco=recos[aname];
      let anR=0;
      for (let azid in  areco) anR++ ;
      a1+='<option value="C.'+aname+'">'+aname+' ('+anR+')</option>';
   }

// add draft recommendations here (in a new group)
   a1+='</optgroup>';
   a1+='<optgroup label="Draft recommendations" >';
   for (let aname in recosDraft ) {
      let areco=recosDraft[aname];
      let anR=0;
      for (let azid in  areco) anR++ ;
       a1+='<option value="D.'+aname+'">'+aname+' ('+anR+')</option>';
   }
   a1+='</optgroup >';


 a1+='</select>';

   a1+=' and then <button onClick="applySelectRecommendations(this)">retrieve their saved recommendations!</button>&nbsp;&hellip; ';
   a1+='<br><em>Currently selected recommendations will be removed</em></label>';

   amess+=a1;
   writeStatusMessage(amess,2,1,1);

 }


//===================
// apply someone's recommendations (uses allUserRecommendations)
// This changes a number of tables. And global variables (such as choiceList
// If called with athis=0, then use the currentUsername. But check for empty  allRecos (as occurs on first logon)

// Otherwise, this is the event handler for a selet list -- so pull out the value of the selected option
//

function applySelectRecommendations(athis,useName,useDraft ) {
  
  let clist, isQuick=false,aname,isDraft=0;
  if (athis==0) {
     if (!allRecos.hasOwnProperty('current')) {            // allREcos is empty?
        removeAllRecommendations(1) ;   // not really necessary
        return 1;
     }

     if (arguments.length<2) {     // use currentUserName, and ONLY update currently seleteced recommenations
          aname=currentUserName;   // this call  happens after succesful  logon, or on a resetAll
          atype0='c.';        // not needed
          isDraft=0;
          isQuick=true;
    } else {
         aname=jQuery.trim(useName);
         if (useDraft===true || useDraft==1)   isDraft=1;
    }
  } else  {                // pull from <select>
     let e1=$('#iPeopleWithRecoList');
     let e2=e1.find("option");
     let aa=e2.filter(":selected");
     if (aa.length==0) return 0 ;   // should not happen
     let aname0=$(aa[0]).val();
     let atype0=aname0.substr(0,2);   // C. or D.
     aname=aname0.substr(2);
     isDraft=(atype0.toLowerCase()=='d.') ? 1 : 0 ;
  }        // athis=0

   if (isDraft==1) {
      clist=(allRecos['draft'].hasOwnProperty(aname)) ? allRecos['draft'][aname] : {} ;
  } else {
      clist=(allRecos['current'].hasOwnProperty(aname)) ? allRecos['current'][aname] : {} ;
  }

  let nsugg2=parseInt(basicStats['nSuggests'])+2;

  removeAllRecommendations(1) ;   // always remove currently selected recommendations BEFORE applying retrieved recommendations

   showStatusMessage(0);

  let nRR=0;
  for (let oof in clist) nRR++ ;

// update global whoFrom box

  allRecos['using'][0]=aname;
  allRecos['using'][1]=isDraft ;
  allRecos['using'][2]=nRR ;

// change whoFrom box
  let eWhoR=$('#irecommendations_lastGet');
  let anameSay=(isDraft==1) ? aname+' (draft) ' : aname ;
  eWhoR.html(anameSay);
  let eWhoRN=$('#irecommendations_lastGetN');
  eWhoRN.html(nRR);


// update useReco in choiceList
 let clistOk={}
 for (let gooid in clist) clistOk[gooid]=0;      // 0 means "not found in choicelist

// always check -- look for missings (removeds)
  for (let zid in choiceList) {
       if (clist.hasOwnProperty(zid)) {   // this is one of the retrieved recommendeds
         let daval=  parseInt(clist[zid])+1 ;
         if (athis!=-0) choiceList[zid]['useReco']=daval;  // don;'t bother if logon call
         clistOk[zid]=1;                       // flag that this was found
       } else {
         if (athis!=-0) choiceList[zid]['useReco']=0;   // don;'t bother if logon c (0 means not recommened
      }
  }

// 4/8/2023: getData.php now removes mvids not in choiceslit
// let clistMiss=0;
// for (let gooid in clistOk) {        // are there ids in the recommended list that are removed?
//    if (clistOk[gooid]==0) clistMiss++;
// }
 clistMiss = (allRecos['userDiscards'].hasOwnProperty(currentUserName)) ?allRecos['userDiscards'][currentUserName] : 0 ;

 let eRecos=$('#theRecommendationsTable');   // change reco stuff on all row (using the retrieved recommendatins)

// update last col of recommendations table, and add to currently selected reocmmendations
  let etr1=eRecos.find('.recoRow');

  let dothese=[];
  for (let j1=0;j1<etr1.length;j1++) {
     let ae1=$(etr1[j1]);
     let mvid=ae1.attr('data-choiceid');
     let useReco=choiceList[mvid]['useReco'];
     if (!isQuick) {
       let sayV= (useReco>0) ? useReco : '' ;
       let sortV= (useReco>0) ? useReco : nsugg2;
       let etd=ae1.find('.crecommendationsTable_recoCol');
       let eRet1=etd.find('.creco_numRecos2');
       let esort=etd.find('[_sortuse]');
       eRet1.html(sayV);
       esort.attr('_sortuse',sortV);
     }

// "click" on these choices (to make them "currently selected" choices)
    if (useReco>0)  {          // this is all that really happens if isQuick=true (logon call)
     dothese[useReco]=ae1;     // sorted order save
    }
 }                   // reco table

// in order of recommendation, trigger the buttons (to highlight recommendeds)
  for (let ith in dothese) {  // avoid missing elements (shouldn't happen)
     let ae1=dothese[ith];
     let ebutton1=ae1.find('.caddRecommendationButton');
     ebutton1.trigger('click');                 // hack to add a "retrieved recommened choice" to the list of "seleted recommendations"
 }


 if (isQuick) {             // logon will handle clistMiss reporting
    return clistMiss;  // done if logon (since other page setup functions appropriately accont for choiceList['useReco'], etc
 }

// if here, user requsted retrieve recommendations

 if (clistMiss>0) {
   writeStatusMessage('Warning: '+clistMiss+' of <em>'+aname+'</em> recommendations are no longer available.');  // save a message, but don't force immediate display
 }

 let eRanks=$('#theRankingsTable');
 let eView=$('#existingEntriesTable');

// update last col of ranking table
  let etr2=eRanks.find('.rankRow');
  for (let j1=0;j1<etr2.length;j1++) {
     let ae1=$(etr2[j1]);
     let mvid=ae1.attr('data-choiceid');
     let useReco=parseInt(choiceList[mvid]['useReco']);

     let etd=ae1.find('.crankingTable_recoCol');

     let esort=etd.find('[_sortuse]');
     let sortV= (useReco>0) ? useReco : nsugg2;
     esort.attr('_sortuse',sortV);

     let eRet1=etd.find('.crankTable_inReco');
     if (useReco>0) {
       eRet1.attr('title','In most recently retrieved recommendations');
       eRet1.html('&#9745;&#65039; '+useReco);
   } else {
       eRet1.attr('title',"Not in most recently retrieved recommendations?");
       eRet1.html('');
   }
 }        // trs in ranking table

 // update reco  col of view table
  let etr3=eView.find('.suggRow');
  for (let j1=0;j1<etr3.length;j1++) {
     let ae1=$(etr3[j1]);
     let mvid=ae1.attr('data-choiceid');
     let useReco=parseInt(choiceList[mvid]['useReco']);

     let etd=ae1.find('.suggTable_recoCol');

     let esort=etd.find('[_sortuse]');
     let sortV= (useReco>0) ? useReco : nsugg2;
     esort.attr('_sortuse',sortV);

     let eRet1=etd.find('.csugg_useReco');
     if (useReco>0) {
       eRet1.attr('title','In most recently retrieved recommendations');
       eRet1.html('&#9745;&#65039;'+useReco);
   } else {
       eRet1.attr('title',"Not in most recently retrieved recommendations?");
       eRet1.html('');
   }
 }        // tr

 return clistMiss ;

}
