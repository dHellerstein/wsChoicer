// build   schedules  stuff
//
// 15 march todo :
//   implement different types of schedule ($schedulerType). 'time' is done!

//==========================
// make the view schedule  page (in   scheduleDiv)
// Makes stubs ons the "main page", and the "save" page

function makeSchedule(ifoo) {

    makeSchedule_table(ifoo) ;
    makeSchedule_formatMenu(ifoo);
    makeSchedule_saveToServerMenu(ifoo);
    return 1 ;
}

// ========================
// Create the main page -- with "list" and "table" containers.
//   list container: 'buttons' of each recommentation'. And several formatting options   (scheduleListDiv)
//   table container:  the scheduel table -- recommendations can be inserted, removed, and moved  (scheduleDivTableOuter)
//   basic info on schedule (scheduleBasicInfoSchedule)
//   basic info on recos (scheduleBasicInfoReco)
//   save/preview buttons (scheduleSaveButton)
// To start, the schedule table has #nrecos empty rows (#nrecs = # of current recommenations)
//
// 17 March : could initialize using user's own schedule (if it exists) -- for now, user mus click "My"


function makeSchedule_table(ii) {

   let qUseNumber ;
   let nRecosAvail=0;
   let scheduleVar='#';

   let gotRecos=get_currentRecos(1) ;

   useRecos=gotRecos['list'];
   recoUser=gotRecos['submitter'];

   $('#scheduleListDiv').data('useRecos',useRecos);
   $('#scheduleListDiv').data('recoUser',recoUser);

// === the "listDiv" for schedule

   //   the header bar  span for schedule    .............

   let sclist=allScheds['schedules'];
   let nSchedules=basicStats['nSchedules'];
   if (nSchedules==0) {
     $('#scheduleBasicInfoSchedule').html('<span class="scheduler_nAvail">There are no schedules available</span> ');
   } else {

      let gotSchButton='<span>';

      gotSchButton+='<button class="cSelectSchedules" name="selectScheduleButtonReco"  onClick="schedule_readCurrentRecos(this)" ';
      gotSchButton+='  title="Click to retrieve the currently recommendations "> ';
      gotSchButton+= '&#9935; &#127479;</button>';
  //    gotSchButton+='<em>Retrieve schedule &hellip; ';
      gotSchButton+='   ';
      gotSchButton+=' <button class="cSelectSchedules" name="selectScheduleButtonMy" title="Click to retrieve your current schedule  " ';
      gotSchButton+=' onClick="schedule_readExisting(this,1)">&#128197; My</button>';
      gotSchButton+=' <button class="cSelectSchedules" name="selectScheduleButtonAvail" title="Click to select a schedule to retrieve.  " ';
      gotSchButton+=' data-lastclick="0"  onClick="schedule_readExisting(this)">&#128197; Available ';
      gotSchButton+='<span  style="color:#8f8f9f;padding:1px 1px 1px 4px" title="# of schedules available"> ('+nSchedules+') </span>';
      gotSchButton+='</button> ';
       gotSchButton+='</span>';

      $('#scheduleBasicInfoSchedule').html(gotSchButton)
    }

// --- are there recommendations available (that can be used to create a schedule)

//   the header bar span for recommendations     ............
   if (recoUser=='' || useRecos.length==0) {
      let hdrMessageR='There are <b>no</b> recommendations available. ';
      $('#scheduleBasicInfoReco').html(hdrMessageR);
      let amess='There are <b>no</b> recommendations available. You can  use  &#127479;ecommend  to <em>retrieve</em> recommendations! ';
      $('#scheduleDivTableOuter').html(amess)  ;
 
   }      // no recommendations .. so nothing to do ... so return


// else, got some recommendations !
   let hdrMessage ;

   if (recoUser==currentUserName) {
     hdrMessage='<span id="scheduleBasicInfoReco_nsched">0</span> (of ';
     hdrMessage+='<span id="scheduleBasicInfoReco_submitter"  style="font-weight:700">your</span>  '+useRecos.length+') added ';
     hdrMessage+=' <span  id="scheduleBasicInfoReco_nbreak" class="cscheduleBasicInfoReco_nsched">0 abreaks</span> ';
   } else {
       hdrMessage='<span id="scheduleBasicInfoReco_nsched">0</span>  (of ';
       hdrMessage+=' <span id="scheduleBasicInfoReco_submitter" style="font-weight:700">'+recoUser+'</span> of '+useRecos.length+') added to schedule ';
       hdrMessage+=' <span id="scheduleBasicInfoReco_nbreak" class="cscheduleBasicInfoReco_nsched">0 bbreaks</span>';
   }

   $('#scheduleBasicInfoReco').html(hdrMessage);
   let saveButtonSay='';

   saveButtonSay+='<button class="cschedule_saveSchedule"  id="ischeduleFormat_button" onclick="schedule_showFormatMenu(2)" title="Specify new formatting options">Format...</button>';
   saveButtonSay+=' <button class="cschedule_saveSchedule" id="ischedulePreview_button"  title="Preview these entries (using formatting options)" onClick="schedule_preview(2)">Preview...</button>' ;
   saveButtonSay+=' <button class="cschedule_saveSchedule" id="ischeduleSave_button"  title=Save to server menu ..." onClick="schedule_showSaveToServerMenu(2)">Save...</button>' ;
   saveButtonSay+='  <button class="cschedule_saveSchedule" id="ischedulePublish_button" name="nschedulePublish_button"   title="Publish this schedule(using formatting options)" onClick="schedule_showPublishMenu(2)">Publish...</button>' ;

   $('#scheduleSaveButton').html(saveButtonSay);

// the "list" container  ................

   let tList='';

   let scheduleDefault=allScheds['scheduleDefault'];  // scheduleVarUse read in makeSchedule_recoButtons

// always have a "add break" option (multipe breaks can be added, of different lengths)
   let sayBreak='<li><span class="schedulerList_recommendation" data-nadds="0" data-mvid="0" >';
   sayBreak+=' <span class="cschedule_break" title="Add a break (in minutes/day/quantity). You can also specify a short description">';
   sayBreak+=' <span class="cschedule_sayBreak  ">Break</span> ';
   sayBreak+=' <span class="cschedule_sayBreak_icon">&#9202;</span> <input  type="text" size="2" value="10"  class="crosshairCursor"  name="schedule_breakLength">';
   sayBreak+=' </span>';
   sayBreak+=' <span class="cschedule_break" title="Short description of this break">&#9997;';
   sayBreak+='<input type="text" size="11" value=" " style="font-size:90%" name="schedule_breakDesc" class="crosshairCursor">';
   sayBreak+=' </span>';

   tList+=sayBreak  ;             // 'break' is  the first selection in the list !

   let listLis0=makeSchedule_recoButtons(useRecos) ;

   let listLis=listLis0[0] ;     // [1] is hash table of ids, pointing to row in listLis

   nRecosAvail=listLis.length;
   let aliUse='<li class="schedule_listOfReos">';

   let tlist1=aliUse+listLis.join(aliUse);

   tListSay='<ul name="nschedule_recoList" class="linearMenu22PctShort">'+sayBreak+tlist1+'</ul>';     // the list of <LI> buttons

   let  sayb='';                               // the row above the list of <li>

   sayb+='<div style="margin:1px 1em 1px 1em;">';
   sayb+='<span  class="cschedulerList_listResizer" >';

   sayb+='<button class="cHelpButton wsShowS" title="Hints on adding recommendations to the schedule" ';
   sayb+='      data-wsshow="#scheduleTableActionsHelpList">&#10068;</button>   ';

   sayb+='<button class="cSideButtons"  onClick="changeTableSizeChoiceList(-1)" title="Decrease the height of the list of current rankings"  >&#10196;</button>';
   sayb+='<button class="cSideButtons"  onClick="changeTableSizeChoiceList(1)" title="Increase the height of the list current rankings"  >&#10195;</button>';
   sayb+='</span>';

   sayb+='<span class="cschedulerList_fillAll cellCursor" >';
        sayb+='<button title="Add remamining recommendations to empty rows"  class="cschedule_addAll" >&#129751; Add all</button> ';
   sayb+='</span>';

    sayb+='<span class="cschedulerList_multiples pointerCursor" >';
      sayb+='<span title="Allow multiple entries for same recommendation"  >&#119055;Multiples ok?</span>';
      sayb+='<input type="checkbox" value="0" class="pointerCursor" name="schedule_allowMultiple"  >';
   sayb+='</span>';


// seperate "update formats" (for time,date,quantity,order scheduler modes)

// ::: time  (the default) :::::::
   sayb+='<span id="schedulerList_mode_time" class="schedule_updateFmt"  data-stype="time" style="display:inline-block">';

    sayb+='<span>';
      sayb+=' &#128347;';
      sayb+='<span class="cschedulerList_startTime" data-mvid="-1" >Start time (24hr)</span> ';
      sayb+='<span class="cschedule_break" title="What time to start. hr:min in 24hr time: from 0:0 to 23:59">';
        sayb+='<input type="text" size="2" value="13" name="schedule_startTimeHour" class="starTime_hour crosshairCursor " onChange="scheduleSetStartTime(this)"> : ';
        sayb+='<input type="text" size="2" value="00" name="schedule_startTimeMin" class="starTime_min crosshairCursor "  onChange="scheduleSetStartTime(this)">';
      sayb+='</span>';
    sayb+='</span>'

   sayb+='<span class="cschedulerList_gapBeforeOuter" >';
      sayb+='<span class="cschedulerList_gapBefore" data-mvid="-1" >&#128062;Pause <span style="font-size:80%">minutes</span></span> ';
      sayb+='<span class="cschedule_break" title="How long a pause before each  '+choiceNameSay+'  (in minutes)?">';
         sayb+='<input type="text" size="2" value="0" name="schedule_gapLength" class="crosshairCursor " >';
      sayb+='</span>';
   sayb+='</span>';

   sayb+='<span class="cschedulerList_default" >';
      sayb+='<span title="The default # minutes (if not specified)">&#19935;default</span> ';
      sayb+='<input type="text" value="'+scheduleDefault+'" size="3"  class="crosshairCursor" name="schedule_defaultDuration">';
   sayb+='</span>';

   sayb+='<span class="cschedulerList_bar"  title="Time formatting options ... used by `update &#128497;`"  >timeFmt ...</span>';

   sayb+='<span style="inline-block;border:3px dotted tan>';  // b1...
   sayb+='<span class="cschedulerList_ampm" > ';
      sayb+='<label title="Display schedule using 24 time " class="pointerCursor">24hr';
      sayb+='<input type="checkbox" value="1" checked name="schedule_timeType"  data-timetype="24hr" class="pointerCursor"  onClick="schedule_ampmCheck(this)">';
      sayb+='</label>';
   sayb+='</span>';

   sayb+='<span class="cschedulerList_ampm" > ';
      sayb+='<label title="Display schedule using AM and PM" class="pointerCursor">AM/PM ';
      sayb+='<input type="checkbox" value="2" name="schedule_timeType"   data-timetype="ampm" class="pointerCursor"  onClick="schedule_ampmCheck(this)">';
      sayb+='</label>';
   sayb+='</span>';

   sayb+='<span class="cschedulerList_minutes" >';
      sayb+=' <label title="Display schedule using elapaed minutes (from start) " class="pointerCursor">elapsed';
      sayb+='<input type="checkbox" value="3" name="schedule_timeType" data-timetype="elapsed" class="pointerCursor"  onClick="schedule_ampmCheck(this)">';
      sayb+='</label>';
   sayb+='</span>';

   sayb+='<span class="cschedulerList_daynumber" >';
      sayb+=' <label title="Display day # " class="pointerCursor" >nthDay ';
      sayb+='<input type="checkbox" value="1" class="pointerCursor"  name="schedule_dayNumber">';
      sayb+='</label>';
      sayb+='   ';
   sayb+='</span>';

   sayb+='</span>';         // .. b1

   sayb+='</span>';       // schedulerList_mode_time end

// ::: date    :::::::
   sayb+='<span id="schedulerList_mode_date" class="schedule_updateFmt" data-stype="date" style="display:none">';

    sayb+='<span>';
       sayb+='&#128197;';
       sayb+='<span class="cschedulerList_startDate" data-mvid="-1" title="enter year month day (month can be integer or 3 letters)">Start date </span> ';
       sayb+='<input type="text" size="4" value="2023" name="schedule_startYear" class="startTime_year crosshairCursor "  onChange="scheduleSetStartDate(this)">';
       sayb+='<input type="text" size="2" value="Jan" name="schedule_startMonth" class="startTime_month crosshairCursor " onChange="scheduleSetStartDate(this)"> /';
       sayb+='<input type="text" size="2" value="01" name="schedule_startDay" class="startTime_day crosshairCursor " onChange="scheduleSetStartDate(this)"> / ';
    sayb+='</span>'

   sayb+='<span class="cschedulerList_gapBeforeOuter" >';
      sayb+='<span class="cschedulerList_gapBefore" data-mvid="-1" >&#128062;Pause <span style="font-size:80%">days</span></span> ';
      sayb+='<span class="cschedule_break" title="How long a pause before each   '+choiceNameSay+' (in days) ?">';
         sayb+='<input type="text" size="2" value="0" name="schedule_gapLength" class="crosshairCursor " >';
      sayb+='</span>';
   sayb+='</span>';

   sayb+='<span class="cschedulerList_default" >';
      sayb+=' <span title="The default # days (if not specified)">&#19935;default</span> ';
      sayb+='<input type="text" value="'+scheduleDefault+'" size="3"  class="crosshairCursor" name="schedule_defaultDuration">';
   sayb+='</span>';

   sayb+='<span class="cschedulerList_bar"  title="Date formatting options ... used by `update &#128497;`"  >dateFmt ...</span>';
   
   sayb+='<span class="cschedulerList_calendar" >';
      sayb+=' <label title="Display schedule using year/month/day. Unchecked: display using elapsed days" class="pointerCursor">Calendar ';
      sayb+='<input type="checkbox" value="1" name="schedule_calendar" data-which="1" class="pointerCursor"  onClick="schedule_dateCheck(this)">';
      sayb+='</label>';
   sayb+='</span>';

   sayb+='<span class="cschedulerList_nthWeek" >';
      sayb+='<label title="Display week # if more than one week (ignored if `calendar` is checked " class="pointerCursor">nthWeek';
      sayb+='<input type="checkbox" value="1" name="schedule_nthWeek"  data-which="1"  class="pointerCursor"  onClick="schedule_dateCheck(this)">';
      sayb+='</label>';
   sayb+='</span>';

   sayb+='<span class="cschedulerList_showYear" >';
      sayb+='<label title="Display year  (only used if `calendar` is checked)" class="pointerCursor">showYear';
      sayb+='<input type="checkbox" value="1" name="schedule_showYear"  data-which="1"   class="pointerCursor"  onClick="schedule_dateCheck(this)">';
      sayb+='</label>';
   sayb+='</span>';

   sayb+='<span class="cschedulerList_showDayOfWeek" >';
      sayb+='<label title="Display day of week (3 characters) (only used if `calendar` is checked)" class="pointerCursor">dayOfWeek';
      sayb+='<input type="checkbox" value="1" name="schedule_dayOfWeek"  data-which="1"  class="pointerCursor"  onClick="schedule_dateCheck(this)">';
      sayb+='</label>';
   sayb+='</span>';

   sayb+='</span>';       // schedulerList_mode_date end

// ::: quantity    ::::::
   sayb+='<span id="schedulerList_mode_quantity" class="schedule_updateFmt"  data-stype="quantity" style="display:none">';

    sayb+='<span>';
       sayb+='&#129518;';
       sayb+='<span class="cschedulerList_startQuantity"  data-mvid="-1" title="enter starting value)">Start value </span> ';
       sayb+='<input type="text" size="6" value="0" name="schedule_startQuantity" class="crosshairCursor "onChange="scheduleSetStartQuantity(this)" >';
    sayb+='</span>'

   sayb+='<span class="cschedulerList_gapBeforeOuter" >';
    sayb+='&#129518; ';
    sayb+='<span class="cschedulerList_gapBefore" data-mvid="-1" >&#128062;Extra <span style="font-size:80%">value</span></span> ';
    sayb+='<input type="text" size="4" value="0" name="schedule_gapLength" class="crosshairCursor " >';
   sayb+='</span>';

   sayb+='<span class="cschedulerList_default" >';
      sayb+=' <span title="The default quantity (if not specified)">&#19935;default</span> ';
      sayb+='<input type="text" value="'+scheduleDefault+'" size="3"  class="crosshairCursor" name="schedule_defaultDuration">';
   sayb+='</span>';

   sayb+='<span class="cschedulerList_bar"  title="Quantity formatting options ... used by `update &#128497;`"  >quantityFmt ...</span>';

   sayb+='<span class="cschedulerList_addComma_useK">';
   sayb+='<span class="cschedulerList_addComma" >';
      sayb+=' <label title="Add commas to numbers" class="pointerCursor">addComma ';
      sayb+='<input type="checkbox" value="1" name="schedule_addComma" class="pointerCursor cschedule_addComma"  data-quantitytype="addComma"  onClick="schedule_quantityCheck(this)"  >';
      sayb+='</label>';
   sayb+='</span>';     //cschedulerList_addComma

   sayb+='<span class="cschedulerList_useK" >';
      sayb+='<label title="Use xxx.xK (or xxx.xM, G, etc) to display large numbers" class="pointerCursor">Use K';
      sayb+='<input type="checkbox" value="1" name="schedule_useK" class="pointerCursor cschedule_useK" data-quantitytype="useK"  onClick="schedule_quantityCheck(this)"  >';
      sayb+='</label>';
   sayb+='</span>';    //cschedulerList_useK
   sayb+='</span>';  // cschedulerList_addComma_useK

   sayb+='<span class="cschedulerList_prefix" >';
      sayb+='<label title="String to place before quantity (i.e.; `$`)" class="pointerCursor">Prefix ';
      sayb+='<input type="text" size="8" value="" name="schedule_prefix" class="crosshairCursor" >';
      sayb+='</label>';
   sayb+='</span>';

   sayb+='<span class="cschedulerList_postfix" >';
      sayb+='<label title="String to place after quantity (i.e.; `.00`)" class="pointerCursor">Postfix ';
      sayb+='<input type="text" size="8" value="" name="schedule_postfix" class="crosshairCursor"  >';
      sayb+='</label>';
   sayb+='</span>';

    sayb+='</span>';       // schedulerList_mode_quantity end

// ::: order      ::::::
   sayb+='<span id="schedulerList_mode_order" class="schedule_updateFmt"  data-stype="order" style="display:none">';

   sayb+='<span class="cschedulerList_default" >';
      sayb+=' <span title="The default quantity (if not specified)">&#19935;default</span> ';
      sayb+='<input type="text" value="'+scheduleDefault+'" size="3"  class="crosshairCursor" name="schedule_defaultDuration">';
   sayb+='</span>';

   sayb+='<span class="cschedulerList_bar"  title="Order format options used by `update &#128497;`"  >orderFmt ...</span>';

    sayb+='<span class="cschedulerList_orderSort">';
      sayb+=' <label title="Sort ascending" class="pointerCursor"> ';
      sayb+='sortAscending<input type="checkbox" value="1" name="schedule_sortAsc" class="pointerCursor cschedule_sortAsc"  data-sort="asc"  onClick="schedule_orderCheck(this)"  >';
      sayb+='</label>';
   sayb+='</span>';

    sayb+='<span class="cschedulerList_orderSort">';
      sayb+=' <label title="Sort descending" class="pointerCursor"> ';
      sayb+='<input type="checkbox" value="1" name="schedule_sortDsc" class="pointerCursor cschedule_sortDsc"  data-sort="dsc"  onClick="schedule_orderCheck(this)"  >';
      sayb+='sortDescending</label>';
   sayb+='</span>';

   sayb+='<span class="cschedulerList_sortNumeric" >';
      sayb+='<label title="Sort numerically (unchecked: sort using text values)" class="pointerCursor">';
      sayb+='<input type="checkbox" value="1" name="schedule_numericSort" class="pointerCursor cschedule_numericSort" data-sort="numeric"  onClick="schedule_orderCheck(this)"  >';
      sayb+='Numeric</label>';
   sayb+='</span>';

   sayb+='</span>';       // schedulerList_mode_order end


// end of   "update formats" (for time,date,quantity,order scheduler modes)

   sayb+=' </div> ';

   sayb+='<div id="schedule_alertBoxOuter" class="cschedule_alertBoxOuter " title="Schedule status ... ">';
    sayb+=' <button class="cCloseButton pointerCursor" dog="rover2a" onClick="wsurvey.wsShow.hide(this)"  data-wsshow="-1"  title="close this box">&#128473;</button>';
    sayb+='<div id="schedule_alertBox" class="cschedule_alertBox"> </div>';
   sayb+=' </div> ';

   let topMess=sayb+tListSay;       // the global options (top of the list container

// add a fixed container for save suggestions

 let esh=$('#scheduleListDiv');
 esh.html(topMess);

  let efoo=esh.find('.wsShowS');
  efoo.on('click',wsurvey.wsShow.show);

// === the table for schedule ..........

   let  amess='' ;

   if (nRecosAvail==0)  {  // no recommendations... need to Retrieve one
      amess='You can use <button onClick="showRecommendations(1)">&#127479;ecommend</button> to <em>retrieve</em> recommendations -- ';
      amess+=' either yours or someone elses. Then come back here and use them to build a &Sscr;chedule <hr />';
   }

   amess+='<table width="99%" cellpadding="5" border="1" id="scheduleDivTable" >';
   amess+='<tr class="scheduleTopRow" bgcolor="tan" >';
   amess+='<th width="20%">';

   amess+='<span style="float:left;margin-left:6px">';
   amess+=' <button title="clear this row" onClick="scheduleDo_clearAll(this)" data-lastclick="0" class="pointerCursor" fclass="cschedule_clearAllRows">&#129533;</button> ';
   amess+='</span>';

   amess+='<button    class="cHelpButton wsShowS" ';
   amess+='        data-wsshow="#scheduleTableActionsHelp" title="Working with the schedule table">&#10068;</button> ';

   amess+='<em>Actions..</em> ';
   amess+='</td>';
   amess+='<td width="11%"><button  id="ischedule_calcTime" class="cschedule_calcTime pointerCursor" onClick="scheduleDo_update(1)" title="Update time, date, or quantity">Update &#128497;</button></th>';

   let gapSay={'time':'minutes','date':'days','quantity':'amount'};
   amess+='<th width="25%">Name</th>';
   if (qUseNumber) {
      amess+='<th>#</th>';
   } else {
     if (schedulerType!='order') {
        amess+='<th width="10%"><span id="ischedule_durationTopCol" title="'+gapSay[scheduleVar]+' of the '+choiceNameSay+'  "> '+allScheds['scheduleVar']+'</span> (<span title="Extra '+allScheds['scheduleVar']+' added ">extra</span>)</th>';
     } else {
        amess+='<th width="10%"><span id="ischedule_durationTopCol" title="Order value of '+choiceNameSay+'  "> '+allScheds['scheduleVar']+'</span>  </th>';
     }
   }
   amess+='<th width="32%">Short description</th>';
   amess+='</tr>';

// top row is "start time" row -- shows start time, and allows adding a new first row (or moving something to top row)
   amess+='<tr class="scheduleTopRow " name="nscheduleTopRow" style="line-height:0.35em" data-choiceid="-2" bgcolor="#f4ddbe">';

   amess+='<td class="scheduleTopRowB">';
   amess+='<button title="add line below" class="schedule_addRow  plusCursor">&#10133;</button>  ';
   amess+=' <span class="schedule_targetLabelOuter"  >';

       amess+='<span class="schedule_moveMeHereTop handCursor" title="drop marked row  ... at top of table ">&nbsp;&#8984;&nbsp;&nbsp;</span>&nbsp;';
       amess+='<label class="schedule_targetLabel schedule_targetLabelTop" title="Click to move a row below this!">';
       amess+='<span  class="schedule_targetLabel2a moveCursor">&#128924;</span>'   ;
       amess+='<input type="checkbox"  class="schedule_targetLabel2  pointerCursor"   name="schedule_targetButton"> ';
       amess+='<span style="display:none">&#9989</span>';
       amess+='</label>';
       amess+='</span>';
   amess+='</td>';
// start time initioalized to 13:00 (1:00 Pm)
  if (schedulerType=='time') {
     let daStartValue='780';
      amess+='<td><span name="scheduleStartTime" data-startValue="'+daStartValue+'">13:00</span></th>'; // changed when start time text input is changed
  } else if (schedulerType=='date') {
     let daStartValue= 1672549200000;    // jan 1 2023 at 12:00:00 am
      amess+='<td><span name="scheduleStartTime" data-startValue="'+daStartValue+'">2023-Jan-01</span></th>'; // changed when start time text input is changed
  } else if (schedulerType=='order') {
      amess+='<td><span name="scheduleStartTime" data-startValue="0">&vellip;</span></th>'; // changed when start time text input is changed

  } else {
      let daStartValue='0';
      amess+='<td><span name="scheduleStartTime" data-startValue="'+daStartValue+'">0</span></th>'; // changed when start time text input is changed
  }
//   amess+='<td><span name="scheduleStartTime" data-startValue="'+daStartValue+'">13:00</span></th>'; // changed when start time text input is changed
   amess+='<th><em>Start <em></th>';
   amess+='<th><button title="update pauses/additions, and default values(using new defaults and user-specified values)" class="pointerCursor" onClick="scheduleDo_updateValues(1)">&#128498;Update</button></th>';
   amess+='<th></th>';
   amess+='</tr>';

   for (let ir1=0;ir1<useRecos.length;ir1++) {
      let aline=schedule_blankRow('&vellip;');
      amess+=aline;
   }

   amess+='<tr class="scheduleBottomRow" style="line-height:0.5em"  data-choiceid="-2"  bgcolor="#f4ddbe">';  // final row
   amess+='<td><span class="schedule_hour"  >&vellip;</span> </td>';
   amess+='<td><span name="updateCol" data-dog="arf!" data-scheduleval="0"></span></td>';
   amess+='<td><em>end</em></td>';
   amess+='<td> </td>';
   amess+='<td>&vellip;</td>';
   amess+='</tr>';

   amess+='</table>';

 let eouter=$('#scheduleDivTableOuter') ;
 eouter.html(amess)  ;

  let efoo2=eouter.find('.wsShowS');
  efoo2.on('click',wsurvey.wsShow.show);

// which "mode" to display
  let emodes=$('#scheduleListDiv').find('.schedule_updateFmt');
  emodes.hide();
  let emode1=emodes.filter('[data-stype="'+schedulerType+'"]');

  emode1.show();

  return gotRecos ;
}

//========================
// make the "select formatting" options.
// It will be modified when a schedule is retrieved from server
// dispaly menu of options used to format a schedule
// ido=1 : if exists, just make visible
//    2 : recreate

function makeSchedule_formatMenu(ido) {

  let amess='';

  let defColName={'Name':choiceNameSay,
   'rowNumber':'#',
   'rowNumberChoice':'#',
   'Start':'Start @ time (formatted) ',
   'totalDuration':'Minutes',
   'Links':'Links to information  ',
   'Desc':'Short Description  ',
   'Elapsed':'Elapsed minutes (of priors)',
    'Duration':choiceNameSay+' minutes',
    'Pause':'Pause before starting',
   'entryValueA':'#minutes : begin + prior durations ',
   'firstNote':'Short description  ',
   'descNotes':'Member notes',
   'infoBlurbs':'Information blurbs',
   'allLinks':'Links and blurbs'
 }
 if (schedulerType=='date') {
     defColName['Start']='Start @ date (formatted)';
     defColName['totalDuration']='days';
     defColName['Elapsed']='Elapsed days (of priors)';
     defColName['Duration']=choiceNameSay+' days' ;
     defColName['entryValueA']='#days: begin + prior durations  '  ;
 }
 if (schedulerType=='quantity') {
     defColName['Start']='Start @ quantity  (formatted)';
     defColName['totalDuration']='quantity';
     defColName['Elapsed']='Running sum (of priors)';
     defColName['Duration']=choiceNameSay+' value ' ;
     defColName['entryValueA']='Quantity: begin + sum of prior    '  ;
 }
  if (schedulerType=='order') {
     defColName['Start']='Order ';
     defColName['totalDuration']='totalDuration n.a.';
     defColName['Elapsed']='Elapsed n.a.';
      defColName['Duration']=choiceNameSay+' order var ' ;
     defColName['entryValueA']='entryValueA n.a.'  ;
 }

 let defColDesc={'Name':'Name of '+choiceNameSay,
   'rowNumber':'The row # (1 for first) -- can be highlighted',
   'rowNumberChoice':'The choice # (1 for first) -- can be highlighted',
   'Start':'Formatted starting time -- includes the sum of the durations of all prior entries and the begin time. ',
   'totalDuration':'Duration of '+choiceNameSay+'  + pause',
   'Links':'Links to information (on the WWW, or local server)',
   'Desc':'Short Description (specified in scheduler)',
   'Elapsed':'Time since start -- does NOT include the begin time.',
    'Duration':'Length of '+choiceNameSay,
    'Pause':'Pause before start of '+choiceNameSay,
   'entryValueA':'Time since start (includes begin time). Not formatted ',
   'firstNote':'A short description (specified  when '+choiceNameSay+' was suggested ',
   'descNotes':'Various descriptions (specified by various members)',
   'infoBlurbs':'Short information blurbs',
   'allLinks':'The Links and infoBlurbs'
 }
 if (schedulerType=='date') {
     defColDesc['Start']='Formatted starting date --  include the sum of the durations of all prior entries and the begin date.  ';
     defColDesc['Elapsed']='Elapsed days -- does not include the begin date';
     defColDesc['entryValueA']='Days since start -- (include begin date). Not formatted'  ;
 }
 if (schedulerType=='quantity') {
     defColDesc['Start']='Formatted starting quantity --  include the sum of the quantities of all prior entries and the begin value';
     defColDesc['Elapsed']='Running sum of quantities -- does not include the begin value  ';
     defColDesc['entryValueA']='Sum since start -- (include begin value). Not formatted'  ;
 }
 
  if (schedulerType=='order') {
     defColDesc['Start']='The orderBy value for this entry';
     defColDesc['Elapsed']='not used ...  ';
     defColDesc['entryValueA']='not used ...' ;
     defColDesc['totalDuration']='not used ...' ;
 }


// add length=0 vars in schedulerShow to schedulerNoShow  (28 march)
 let anull=false;
 if(schedulerNoShow == null  ) anull=true;
 if (anull===false) {

    for (let av1 in schedulerShow) {
       if (schedulerNoShow.hasOwnProperty(av1)) continue ;
       if (schedulerShow[av1]>0) continue ;
       schedulerNoShow[av1]=2;                // add to noShow because of length=0
    }
  }

  if (schedulerShowAddAll==1) {           //add non specified scheduleVar variables (as noShow with length=0)
    for (let sa in  defColName) {
       if (schedulerNoShow.hasOwnProperty(sa)) continue ; // already explicitly a nowSHow
       if (schedulerShow.hasOwnProperty(sa)) continue ;    // already a shown (could be a length 0)
       schedulerNoShow[sa]=3;         // add to noShow because of *All
       schedulerShow[sa]=0;       // and to schedulerShow (length=0) so that scheule maker can manually add
    }
    for (let sa2 in customVarList) {
       if (schedulerNoShow.hasOwnProperty(sa2)) continue ; // already explicitly a nowSHow
       if (schedulerShow.hasOwnProperty(sa2)) continue ;    // already a shown (could be a length 0)
       schedulerNoShow[sa2]=4;         // add to noShow because of *All
       schedulerShow[sa2]=0;       // andd to schedulerShow (length=0) so that scheule maker can manually add
       defColName[sa2]= sa2  ;
       defColDesc[sa2]=customVarList[sa2][2];
    }
  }                                          //schedulerShowAddAll =1

 for (let zvar in schedulerShow) {            //  fix names and desc for explititly included customVars
     if (!defColDesc.hasOwnProperty(zvar)) {
         defColDesc[zvar]=customVarList[zvar][2];
         defColName[zvar]= zvar  ;
     }
  }

  let dd1=wsurvey.get_currentTime(31,1);
  amess+='<div id="mySchedule_format_b" style="background-color:#f3fac9;padding:5px">';

  amess+='<button  class="cHelpButton wsShowS " ';
  amess+='    data-wsshow="#scheduleFormatOptionsHelp" title="Working with the formatted schedule options">?</button> ';

 amess+='<button title="reset formatting options to their defaults " onClick="schedule_format_reset(1)">&#128260;</button>  ';

  amess+='<b>Scheduler: choose formating options &amp; preview</b>. ';
  amess+='After setting the following options you can ';

  amess+='<button  style="font-size:100%"   class="cschedule_formatButton pointerCursor"   ';
  amess+='   title="create and display a formatted schedule " ';
  amess+='    onClick="schedule_preview(2)">';
  amess+='Preview the schedule';
  amess+='</button>'
  amess+=' <em>or</em> ';
  amess+='<button  style="font-size:100%"   class="cschedule_formatButton pointerCursor"   ';
  amess+='   title="Save the schedule, and these formatting options" ';
  amess+='    onClick="schedule_showSaveToServerMenu(1)">';
  amess+='Save the schedule';
  amess+='</button>'

  amess+='<form >';
  amess+='<ul class="linearMenu24Pct">';

// value display dependson schedulerType

  if (schedulerType=='time') {                         // :::::::: time   ::::::::
    amess+='<li><span title="For `Start` and `Elapsed` variables">Time formatting ';
    amess+=' <span style="font-size:80%"><tt>Start</tt> &amp; <tt>Elapsed</tt></span></span>';
    amess+='<li style="width:22%">';

    amess+='<span style="padding:1px 3px;background-color:#ceccad">';
    amess+=' <label class="cscheduler_format_timefmt">';
       amess+=' <input name="schedule_format_type" data-timetype="24hr" class="pointerCursor"  type="radio" checked value="1">24 hr</label>   ';
    amess+=' <label class="cscheduler_format_timefmt">';
       amess+=' <input name="schedule_format_type" data-timetype="ampm" class="pointerCursor"  type="radio" value="2"> AM/PM</label>   ';
    amess+=' <label class="cscheduler_format_timefmt">';
       amess+=' <input name="schedule_format_type" data-timetype="elapsed" type="radio" class="pointerCursor"  value="3">elapsed</label>  ';
    amess+='</span>';

    amess+='<li style="width:10%"> <label>';
       amess+='<input name="schedule_format_showDays" type="checkbox" class="pointerCursor"  value="1">showDays</label>  ';
  }
  if (schedulerType=='date') {                       // :::::::: date   ::::::::
    amess+='<li><span title="For `Start` and `Elapsed` variables">Date formatting ';
    amess+=' <span style="font-size:80%"><tt>Start</tt> &amp; <tt>Elapsed</tt></span></span>';

    amess+='<li style="width:35%">';

    amess+='<span style="padding:1px 3px;background-color:#ceccad">';
    amess+=' <label class="cscheduler_format_datefmt">';
      amess+=' <input name="schedule_format_calendar" data-datetype="calendar" class="pointerCursor" ';
      amess+='       type="checkbox" onClick="schedule_dateCheck(this)"  data-which="2"  value="1" checked>Calendar</label>   ';
    amess+=' <label class="cscheduler_format_datefmt">';
       amess+=' <input name="schedule_format_nthWeek" data-datetype="nthWeek" class="pointerCursor" ';
       amess+='       type="checkbox" onClick="schedule_dateCheck(this)" data-which="2"  value="1">nthWeek</label>   ';
    amess+=' <label class="cscheduler_format_datefmt">';
       amess+=' <input name="schedule_format_showYear" data-datetype="checkbox"  class="pointerCursor" ';
       amess+='      type="checkbox" onClick="schedule_dateCheck(this)"  data-which="2" value="1">show Year</label>  ';
    amess+=' <label class="cscheduler_format_datefmt">';
       amess+=' <input name="schedule_format_dayOfWeek" data-datetype="dayOfWeek" class="pointerCursor" ';
       amess+='       type="checkbox" onClick="schedule_dateCheck(this)"  data-which="2" value="1">dayOfWeek</label>   ';

    amess+='</span>';
  }

  if (schedulerType=='quantity') {           // :::::::: quantity    ::::::::
    amess+='<li style="width:14%"><span title="Running sum  ... ">Quantity formatting ';

   amess+='<li  style="width:20%" class="cschedulerList_addComma_useK">';
     amess+='<label class="cscheduler_format_quantityfmt ">';
       amess+=' <input name="schedule_format_addComma" data-quantitytype="addComma" class="pointerCursor cschedule_addComma " onClick="schedule_quantityCheck(this)" ';
       amess+='      type="checkbox" value="1">addComma</label>   ';

     amess+=' <label class="cscheduler_format_quantityfmt">';
       amess+=' <input name="schedule_format_useK" data-quantitytype="useK" class="pointerCursor  cschedule_useK" onClick="schedule_quantityCheck(this)" ';
       amess+='       type="checkbox" checked value="1">useK</label>   ';

    amess+=' <li  style="width:25%"><span class="cscheduler_format_quantityfmt">';
       amess+=' <input name="schedule_format_prefix" data-quantitytype="prefix" type="text" class="pointerCursor" size="5" type="text" value=" ">prefix</span> ';

    amess+=' <span class="cscheduler_format_quantityfmt">';
       amess+=' <input name="schedule_format_postfix" data-quantitytype="postfix" class="pointerCursor" size="5" type="text" value=" ">postfix </span>   ';

    amess+='</span>';

  }

  if (schedulerType=='order') {       // :::::::: order::::::::     schedule_sortAsc   schedule_sortDsc  schedule_numericSort
    amess+='<li style="width:14%"><span title="Sort stuff"><em>Order formatting</em> </span>';
    amess+='<li style="width:14%"> <span class="cschedulerList_orderSort">';
      amess+=' <span title="Sort ascending"  > ';
      amess+='sortAscending <input type="checkbox" disabled value="1" name="schedule_sortAsc"  data-sort="asc"  onClick="schedule_orderCheck(this)"  >';
      amess+='</span>';
   amess+='</span>';

    amess+='<li style="width:14%"><span class="cschedulerList_orderSort">';
      amess+=' <span title="Sort descending"  > ';
      amess+='<input type="checkbox" disabled value="1" name="schedule_sortDsc"   data-sort="dsc"  onClick="schedule_orderCheck(this)"  >';
      amess+='sortDescending</span>';
   amess+='</span>';

   amess+='<li style="width:14%"><span class="cschedulerList_sortNumeric" >';
      amess+='<span title="Sort numerically (unchecked: sort using text values)"  >';
      amess+='<input type="checkbox" disabled value="1" name="schedule_numericSort"   data-sort="numeric"  onClick="schedule_orderCheck(this)"  >';
      amess+='Numeric</span>';
   amess+='</span>';



  }

// all schedulertypes us maxheight
  amess+='<li style="width:30%">Max cellHeight <span onClick="schedule_format_clear(this)"   class="cschedule_headerName_useit">(empty for unlimited)</span>';

  amess+=' <input type="text" size="4" name="schedule_format_maxHeight" value="2.5"  class="crosshairCursor" title="Max height (in em). Leave blank for no limit"> ';
  amess+='</ul>';

  amess+='<ul class="linearMenu24Pct">';
  amess+='<li>Enter a  header (HTML allowed): ';
  amess+='<li style="width:74%">';
  amess+='<textarea name="schedule_format_Header" cols="70" row="3"> ';

  let mm1='Created by '+currentUserName ;  // this will be updated when showing "specify formatting options" menu
  amess+=mm1;
  amess+='</textarea>';
  amess+='</ul>';
  amess+='</form>';

  amess+='<div class="scheduler_format_headerSpecs">';
  amess+='<ul class="linearMenu30Pct">';
  amess+='<li>Specify column headers (column width in parenthesis)<br><span class="cschedule_headerName_useit">To use a column description, click it</span>' ;

  for (let avar in  schedulerShow) {
     amess+='<li>';
     let achecked= (schedulerNoShow.hasOwnProperty(avar)) ? ' ' : ' checked ';  // value of schedulerNowShow[avar] is ignored
     let bb='<input type="checkbox" class="pointerCursor" value="1" '+achecked +' title="Uncheck to NOT display ('+avar+')" name="schedule_headerKeep" >';
     amess+=bb;

//     amess+=avar+' <span title="column width" style="font-family:monospace">('+schedulerShow[avar]+')</span>' ;

     amess+='<input type="text" size="3" title="Width of the column header (as a percent)"  name="schedule_colWidth"  ';
     amess+='  style="font-family:monospace;color:blue"   data-defwidth="'+schedulerShow[avar]+'" class="crosshairCursor" ';
     amess+='   value="'+schedulerShow[avar]+'" data-varname="'+avar+'"> ';

     let avar2=defColName[avar];
     amess+='<input type="text" size="20" title="This is displayed as the column header"  name="schedule_headerName"  ';
     amess+='     data-varnameHdr="'+avar2+'" value="'+avar2+'" data-varname="'+avar+'"> ';

     let useIt= (defColDesc.hasOwnProperty(avar)) ?  defColDesc[avar] : ' ' ;

     amess+='<br><span title="Use column name "  data-which="2" onClick="schedule_format_asColName(this)">&#8634;</span> ';
     amess+='<span   data-which="1" title="Click to use this description as the column header" onClick="schedule_format_asColName(this)" class="cschedule_headerName_useit" >';
     amess+=useIt+'</span>';
     amess+='</li>';
  }
  amess+='</ul></div>';

  amess+='</div>';   // mySchedule_format_b

  $('#mySchedule_format').html(amess) ;  // copy to container on main schedules page

}

//==================================
// create the save to server box
function makeSchedule_saveToServerMenu(ido) {

  let amess='';
  amess+='<div name="schedule_saveToServerB">';
  amess='<b>Save this schedule (and its formatting options) to the server</b>. You can retrieve (and modify) it later.';
  amess+='<ul class="linearMenu30Pct">';
  amess+='  <li>Optional: enter a  <em>Comment</em> (no HTML) <br>';
  amess+='<em>This is for internal use.  The schedule header is specified with  <tt>Header</tt> (in <tt>Select formatting options</tt>) ';
  amess+=' </li>';
  amess+='  <li>';

// this is updated when save to server menu is show
  amess+='<textarea id="saveSchedule_comment"  title="optional comment" cols="70" row="1">Created by '+currentUserName +'</textarea>';
  amess+='</textarea></li>';
  amess+='</ul>';
  amess+='</div>';
  amess+='<div style="border:3px solid #f8ec54;padding:5px;margin:5px 20% 5px 20%">';
   amess+=' And then .. <input  class="cSaveItButton" type="button" value="Save the entries and formatting options!" class="cschedule_formatButton"  ';
  amess+=' title="save the schedule (and its formatting options) to the server" ';
  amess+=' onClick="schedule_saveToServerDo(1)"> <em>(and its formatting options)</em>  ';
  amess+='</div>'

  $('#mySchedule_saveToServerA').html(amess).show();

  return 1;
}


//=============================
// show main save page -- with select formatting options, preview, and save to server options
// but always check if times are up to date!

function schedule_showSave(ido ) {
  
   showStatusMessage(0);        // get rid of this distraction

  wsurvey.wsShow.show('#mySchedule_saveBox');

   $('#mySchedule_saveToServerA').hide();;  // hide the "save to server" box (that is inside of myscheule_savebox
   $('#mySchedule_format').hide();;  // hide the "specify formating options" box (that is inside of myscheule_savebox

   let eupdateb=$('#ischedule_calcTime');
   if (eupdateb.hasClass('cschedule_updateTimeHighlight')) {
      scheduleAlert('There are changes that are not accounted for. Please use <button>Update &#128497;</button>.',1);
      return false ;
   }
   oof=schedule_readTableRows(2) ;   // 2 signals "just return simple stuff ('message' is all that is used)

// show the schedule formatting options menu in a popup
   $('#mySchedule_saveBox_summary').html(oof['message']);

    scheduleAlert(oof['message']);   // basic info on current schedule --  useful if save to server is likely to be chosen
}


//==================
// show a menu of formatting options function - update a few fields
// ifoo not currently used

function schedule_showFormatMenu(ifoo) {
  let efmtb=$('#mySchedule_format_b');
  let q=schedule_showSave(1);      // make sure main "save" box is visible
  if (q===false)   { // a change was made, but times not recalculate
      wsurvey.wsShow.hide('#mySchedule_formatVersion');  // hide the preview schedule box (to reveal the error message, and allow user to update times)
      wsurvey.wsShow.hide('#mySchedule_saveBox');  // hide the save schedule box (to reveal the error message, and allow user to update times)
      return 1;
  }
  $('#mySchedule_saveToServerA').hide();;  // hide the "save to server" box (that is inside of myscheule_savebox

  let alist=schedule_readTableRows(1)  ;  // just need nbreaks and nchoices, but have to get evertying to figure that out

  let dd1=wsurvey.get_currentTime(31,1);

// default header ...
  let mm1=alist['nChoices']+' entries &amp; '+alist['nBreaks']+' breaks. Created by '+currentUserName+' @ ' +dd1 ;  // a default header for formated schedule
  let ee1=efmtb.find('[name="schedule_format_Header"]');
  ee1.html(mm1);

  if (schedulerType=='order')  {  // note status, but don't allow changes
    let elist=$('#scheduleListDiv');

    let esortA=elist.find('[name="schedule_sortAsc"]');
    let qsortA=(esortA.prop('checked')) ? true  : false  ;
    let esortA2=efmtb.find('[name="schedule_sortAsc"]');
    esortA2.prop('checked',qsortA);

    let esortD=elist.find('[name="schedule_sortDsc"]');
    let qsortD=(esortD.prop('checked')) ? true  : false  ;
    let esortD2=efmtb.find('[name="schedule_sortDsc"]');
    esortD2.prop('checked',qsortD);

    let esortN=elist.find('[name="schedule_numericSort"]');
    let qsortN=(esortN.prop('checked')) ? 1  : 0  ;
    let esortN2=efmtb.find('[name="schedule_numericSort"]');
    esortN2.prop('checked',qsortN);
  //  alert([isortA,isortD,isortN]);

  }

// :::::::: order::::::::   in mySchedule_format_b   schedule_sortAsc   schedule_sortDsc  schedule_numericSort
  $('#mySchedule_format').show();   //  show this container (that is inside of  mySchedule_saveBox

}

//==================
// show a menu of formatting options function - update a few fields
// ifoo not currently used

function schedule_showSaveToServerMenu(ifoo) {
   let q=schedule_showSave(1);      // make sure main "save" box is visible
    if (q===false)   { // a change was made, but update not yet done
      wsurvey.wsShow.hide('#mySchedule_formatVersion');  // hide the preview schedule box (to reveal the error message, and allow user to update times)
      wsurvey.wsShow.hide('#mySchedule_saveBox');  // hide the save schedule box (to reveal the error message, and allow user to update times)
   }

   let dd1=wsurvey.get_currentTime(31,1);

  $('#mySchedule_format').hide();;  // hide the "specify formating options" box (that is inside of myscheule_savebox

 // let alist=schedule_readTableRows(1)  ;  // just need nbreaks and nchoices, but have to get evertying to figure that out


  let mm1='Created by '+currentUserName+' @ ' +dd1 ;
  $('#saveSchedule_comment').html(mm1);

  $('#mySchedule_saveToServerA').show();   //  show this container (that is inside of  mySchedule_saveBox

}


//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// choose to create an html file from the formatted schedule, or xml or csv file  containing the specs
function schedule_showPublishMenu(ifoo) {
   showStatusMessage(0);        // get rid of this distraction

    wsurvey.wsShow.show('#mySchedule_publish') ;

   let epp=$('#mySchedule_publishInner');
   let epname=epp.find('[name="json_filename"]');
   let oof=new Date();
   let oof2=parseInt(oof.valueOf()/1000);
   let asay=currentUserName+'_'+oof2 ;

   epname.val(asay);

  if (isAdminUser)  {   // admin user
    epubA=epp.find('[name="publish_adminOptions"]');
    epubA.show();
    let emessA=epubA.find('[name="publish_admin_filename"]');
    emessA.val('pub_'+oof2)
  }

  return 1;
}



// ==============================
// useful functions for: mainPage



//=====================
// cleanup time checkboxes
function schedule_ampmCheck(athis) {

   let eList=$('#scheduleListDiv');
   let stypes=eList.find('[name="schedule_timeType"]');
   stypes.prop('checked',false);
   ethis=wsurvey.argJquery(athis);
   ethis.prop('checked',true)
   
   return 1;

}

//=====================
// cleanup order checkboxes
// name=schedule_format_addComma   schedule_format_useK
function schedule_orderCheck(athis) {
   let ethis=wsurvey.argJquery(athis) ;
   let eparent=ethis.closest('.schedule_updateFmt');

   let eAsc=eparent.find('[name="schedule_sortAsc"]');
   let eDsc=eparent.find('[name="schedule_sortDsc"]');

   let thisType=ethis.attr('data-sort');
   let qcheck=ethis.prop('checked');

   if (thisType=='asc') {       // simulate a radio button, but allow for neither to be checked
       if (qcheck) eDsc.prop('checked',false)
   }
   if (thisType=='dsc') {
       if (qcheck) eAsc.prop('checked',false)
   }

   let qAsc=eAsc.prop('checked');
   let qDsc=eDsc.prop('checked');
   if (qAsc===false && qDsc===false) {
      let eNum=eparent.find('[name="schedule_numericSort"]');
      eNum.prop('checked',false);
   }

  scheduleDo_updateButton(1) ;  //  hjighligint (in scheduleDo_updateValues)

   return 1;
}

//=====================
// cleanup quantity checkboxes
// name=schedule_format_addComma   schedule_format_useK
function schedule_quantityCheck(athis) {
   let ethis=wsurvey.argJquery(athis) ;

   let eli=ethis.closest('.cschedulerList_addComma_useK');

   let ebuttonC=eli.find('.cschedule_addComma');
   let ebuttonK=eli.find('.cschedule_useK');

   let iwhich=ethis.attr('data-quantitytype');
 
   if (iwhich=='addComma') {
      if (ethis.prop('checked')) ebuttonK.prop('checked',false);
   } else {
      if (ethis.prop('checked')) ebuttonC.prop('checked',false);
   }
   return 1;
}


//=====================
// cleanup date checkboxes
// name="schedule_calendar"  "schedule_nthWeek   schedule_showYear"
function schedule_dateCheck(athis) {
   let ethis=wsurvey.argJquery(athis);
   let iwhich=ethis.attr('data-which');
  let ecalendar,enthweek,eshowyear,edayOfWeek;

   if (iwhich==1)  {        // shceudle build page
      let eList=$('#scheduleListDiv');
      ecalendar=eList.find('[name="schedule_calendar"]');
      enthweek=eList.find('[name="schedule_nthWeek"]');
      eshowyear=eList.find('[name="schedule_showYear"]');
      edayOfWeek=eList.find('[name="schedule_dayOfWeek"]');
   } else {
      let eList=$('#mySchedule_format');
      ecalendar=eList.find('[name="schedule_format_calendar"]');
      enthweek=eList.find('[name="schedule_format_nthWeek"]');
      eshowyear=eList.find('[name="schedule_format_showYear"]');
      edayOfWeek=eList.find('[name="schedule_format_dayOfWeek"]');
   }

   let qcalendar=ecalendar.prop('checked');

    let enthweekLa=enthweek.closest('label');
    let eshowyearLa=eshowyear.closest('label');
    let edayOfWeekLa=edayOfWeek.closest('label');

   if (qcalendar) {           // calendar mode
        enthweek.prop('checked',false);
        enthweekLa.css({'opacity':0.5});
        eshowyearLa.css({'opacity':1.0});
        edayOfWeekLa.css({'opacity':1.0});

   } else {      // elapsed mode
        eshowyear.prop('checked',false);
        edayOfWeek.prop('checked',false);
        enthweekLa.css({'opacity':1.0});
        eshowyearLa.css({'opacity':0.5});
        edayOfWeekLa.css({'opacity':0.5});
   }

   return 1;
}

 //=============================
// list of recommendations (one per row of array)
// areturn [liArray,mvidArray] == [j] in both are the same (so basiclly a  [stuff[ij]=[liSay,mvid]

function makeSchedule_recoButtons(useRecos) {
   let tList=[],mvids={} ;
   let scheduleVarUse=allScheds['scheduleVar'];

   for (let im in useRecos) {                // create a <li> (with report, add, and #min)  for each recommendation .....
       let mvid=useRecos[im];
       if (!choiceList.hasOwnProperty(mvid)) continue ;  // should never happen
       let asugg=choiceList[mvid];
       let shtname=asugg['shortName'];
       let thisLi='';
       thisLi+='<button class="choiceReportButton2" title="View details in a popup ... ... " >&#129534;</button> ';
       let daVar='default',daVal='' ;

       if (scheduleVarUse!=='') {          // else, use '' and 'default'
          daVal= (asugg.hasOwnProperty(scheduleVarUse)) ? jQuery.trim(asugg[scheduleVarUse]) : '' ;  // should always exist
          daVar=scheduleVarUse+'= '+daVal;
          if (schedulerType=='order') {
             if (daVal===''   ) {
                 daVar='use the default';
             }
          } else {
             if (daVal==='' || !jQuery.isNumeric(daVal) || daVal<0 ) {
                daVal='';
                daVar='use the default';
             }
          }   // order
       }
       thisLi+='<input type="text" size="5" style="font-size:90%" title="Using ... '+daVar+'" style="font-size:2em" class="cschedule_varUse" value="'+daVal+'"> ';
       thisLi+='<span class="schedulerList_recommendation" data-nadds="0"  data-mvid="'+mvid+'" >'+shtname+'</span> ';

       let iat=tList.length;
       tList[iat]=thisLi ;
       mvids[mvid]=iat;

   }             // im in userecos ...

   return [tList,mvids] ;

}

//===
// create a string with a blank row for the schedule table
function schedule_blankRow(ir1) {
   let aline='';
   aline+='<tr class="scheRow" data-choiceid="-1" >';
       aline+='<td><div class="scheRow_1">';
       aline+='<span title="click to emphasize (click again to unemphasize)" data-emphasis="0" data-origRow="-1" class="cschedule_rowNumber">'+ir1+'</span> ';
       aline+='<button title="remove this row" class="schedule_removeRow pointerCursor">&#8998;</button> ';
       aline+=' <button title="clear this row" class="schedule_clearRow pointerCursor">&#129533;</button> ';
       aline+=' <button title="add line below" class="schedule_addRow plusCursor">&#10133;</button> ';
       aline+=' <button title="move this row up" class="schedule_moveUp moveCursor">&#9040;</button> ';
       aline+=' <button title="move this row down" class="schedule_moveDown  moveCursor">&#9047;</button> ';

// deprecated -- used the click on redPalm, and then click on desired row
//       aline+=' <button title="move after `current target row` up down row" class="schedule_moveBelowTarget">&#11119;</button> ';

       aline+=' <span class="schedule_targetLabelOuter"  >';

        aline+='<span class="flashMeMove" style="color:blue;font-size:120%;display:none">&#8962;</span> ';
       aline+='<span  class="schedule_moveMeHere handCursor" title="drop marked row ... below here ">&#8984;</span> ';
       aline+='<button class="schedule_moveMeButton grabbingCursor" title="Click to mark this for a move (click again on  &#8984;  to move beneath)">&#129780;&#127999;</button>';
       aline+='<label class="schedule_targetLabel  pointerCursor" title="Click to make this the `current target row`!">';
       aline+='<span  class="schedule_targetLabel2a moveCursor">&#8982;</span>';
       aline+='<input type="checkbox" class="schedule_targetLabel2 pointerCursor"   name="schedule_targetButton">  ';
       aline+='<span style="display:none">&#9989;</span>';
       aline+='</label>';
       aline+='</span>';
       aline+='</div>';
       aline+='</td>';
       aline+='<td><span class="schedule_hour" name="updateCol" data-dog="bowow!" data-scheduleval="0"> &vellip; </td>';

       aline+='<td><span class="schedule_stuffTd" name="mvName"></td>';

       aline+='<td><span class="schedule_stuffTd"  name="mvScheduleVarCol"   data-duration="0" data-pausebefore="0" data-isdefault="0">  ';
       aline+='<span  name="mvScheduleVarCol_1" title="Value used by  `Update`"></span> ';
       if (schedulerType=='time') {
          aline+='<span  name="mvScheduleVarCol_2" title="Extra value used by `Update` (a pause in minutes)" style="font-family:monospace;font-size:90%"></span>';
       } else  if (schedulerType=='date') {
          aline+='<span  name="mvScheduleVarCol_2" title="Extra value used by `Update` (a pause in days)" style="font-family:monospace;font-size:90%"></span>';
       } else  if (schedulerType=='quantity') {
          aline+='<span  name="mvScheduleVarCol_2" title="Extra value used by `Update` (an additional quantity)" style="font-family:monospace;font-size:90%"></span>';
       }     // not used by order
       aline+='</td>';

       aline+='<td><span  class="schedule_stuffTd"  title="Short description. You can modify it!"  name="mvShortDescOuter">';
       aline+='   <input  class="mvShortDesc  crosshairCursor cschedule_shortDescInput" type="text" size="55" value="" name="mvShortDesc"> </td>';

      aline+='</tr>';
   return aline;
}


// =================
// update the 2nd col : time, date, quantity, or non
function scheduleDo_update(i1) {
  if (schedulerType=='time') {
      scheduleDo_calcTimes(i1);
      return 1;
  }
  if (schedulerType=='date') {
      scheduleDo_calcDates(i1);
      return 1;
  }
  if (schedulerType=='quantity') {
      scheduleDo_calcQuantity(i1);
      return 1;
  }

  if (schedulerType=='order') {
      scheduleDo_calcOrder(i1);
      return 1;
  }
  
  alert('unable to update: '+schedulerType)  ;// should never get here
}



//==================
// calculate and display the "date" column (

function  scheduleDo_calcDates(i1)  {

   let msecInDay=(24*60*60*1000);

   let etable=$('#scheduleDivTable');
   let eList=$('#scheduleListDiv');

   let eCalendar=eList.find('[name="schedule_calendar"]');
   let iCalendar= (eCalendar.prop('checked')) ? 1  : 0 ;

   let enth=eList.find('[name="schedule_nthWeek"]');
   let iNthWeek= (enth.prop('checked')) ? 1  : 0 ;

   let eYear=eList.find('[name="schedule_showYear"]');
   let iShowYear= (eYear.prop('checked')) ? 1  : 0 ;


   let eDayOfWeek=eList.find('[name="schedule_dayOfWeek"]');
   let iDayOfWeek= (eDayOfWeek.prop('checked')) ? 1  : 0 ;

    let  estart=etable.find('[name="scheduleStartTime"]');
   let startDay_stamp=parseInt(estart.attr('data-startValue'));

   let totDay=0;

   let etrs=etable.find('.scheRow');

     let nthRow=0,nRecosAdded=0,nBreaksAdded=0;

     for (iet=0;iet<etrs.length;iet++) {
        aetr=$(etrs[iet]);
        let aid=aetr.attr('data-choiceid');

        let eday=aetr.find('[name="updateCol"]');
        let erownum=aetr.find('.cschedule_rowNumber');
        let ename=aetr.find('[name="mvName"]');
        let aname=jQuery.trim(ename.text());
        if (aname=='') {
           eday.html('');
           eday.attr('data-scheduleval',0);
           erownum.html('&vellip;');
           continue  ;   // empty row
        }

        nthRow++;
        erownum.html(nthRow);

        if (aid==0) {
           nBreaksAdded++;
        } else {
          nRecosAdded++;
        }

        let nowDay_stamp=startDay_stamp+(msecInDay*totDay);       // cumulative time to this row (in unix milliseconds) -- use it

        if (iCalendar==0) {          // total elapsed days?
            if (iNthWeek==0) {           // as is?
              eday.html('<tt>'+totDay+'</tt>');
           } else {                      // or as days (week #)
               let arf=scheduleDo_convertDayWeek(totDay); // elapsed days (#days (week #)
               eday.html('<tt>'+arf+'</tt>');
           }
        } else {
            let arf=scheduleDo_timeToCalendar(nowDay_stamp, iShowYear,iDayOfWeek );     // calendar day (given starting date). Perhaps including year
            eday.html(arf );
        }
        eday.attr('data-scheduleval',nowDay_stamp) ;



// augment totmin by the duration and beforePause of this row
        let edura=aetr.find('[name="mvScheduleVarCol"]');
        let aduration=parseInt(edura.attr('data-duration'));
        let apause=parseInt(edura.attr('data-pausebefore'));
        totDay+=(aduration+apause);   // days at end of this entry  -- used as start value in next row

     }           // etrs

// end time in scheduleBottomRow row
     let  eend=etable.find('.scheduleBottomRow');
     let eday2=eend.find('[name="updateCol"]');
     let endDayLast_stamp= startDay_stamp+(msecInDay*totDay);

        if (iCalendar==0) {          // total elapsed days?
            if (iNthWeek==0) {           // as is?
              eday2.html('<tt>'+totDay+'</tt>');
           } else {                      // or as hr:min (days)
               let arf=scheduleDo_convertDayWeek(totDay);    // elapsed days. and in what week(perhaps using #weeks #days format)
               eday2.html('<tt>'+arf[0]+'</tt>');
           }
        } else {
            let arf=scheduleDo_timeToCalendar(endDayLast_stamp, iShowYear,iDayOfWeek );     // calendar day (given starting date). Perhaps including year
            eday2.html(arf );
        }

     eday2.attr('data-scheduleval',endDayLast_stamp)

    $('#scheduleBasicInfoReco_nsched').html(nRecosAdded);  // udpate counter in schedule page top bar

    $('#scheduleBasicInfoReco_nbreak').html('['+nBreaksAdded+' breaks]');  // udpate counter in schedule page top bar

     if (nRecosAdded+nBreaksAdded>0)     {
         $('#ischeduleSave_button').addClass('cscheduleSaveButton_on');
         $('#ischeduleFormat_button').addClass('cscheduleSaveButton_on');
         $('#ischedulePreview_button').addClass('cscheduleSaveButton_on');

      } else {
         $('#ischeduleSave_button').removeClass('cscheduleSaveButton_on');
         $('#ischeduleFormat_button').removeClass('cscheduleSaveButton_on');
         $('#ischedulePreview_button').removeClass('cscheduleSaveButton_on');
     }

     scheduleDo_updateButton(0) ;  // remove hjighligint (in calcTimes)


    return 1;

}

//==========
// convert elapsed days into a  week . dayOfWeek
// totDay=0 means "0 days elsaped: start of first day of first week) -- yields '1 .  1'
//      7 means  "7 days elapsed: start of first day of 2nd week)  --  '2 . 1'
function scheduleDo_convertDayWeek(totDay) {
   let fweeks=totDay/7 ;
   let dayLeft=totDay-(parseInt(fweeks)*7);
   dayLeft++   ;  // 0 means first day
   let nweeks=parseInt(fweeks)+1;
   if (totDay<10) totDay='<span style="float:left;margin-left:6px">&nbsp;'+jQuery.trim(totDay)+'</span>' ;
   let asay=totDay+' <span  style="float:right;margin-right:5px" title="Start in week # " class="cschedule_weekNum">'+nweeks ;
    asay+=' <span  title=" ...  day in week" class="cschedule_weekNumDay">'+dayLeft+'</span>';
    asay+='</span>';
   return asay;
}


//=========
// convert millisecond unix time to calendar date. Return  DDD year-month-day  : DDD and year might be suppressed (iyear and iDayOf Week)
function scheduleDo_timeToCalendar(dayStamp,iyear,iDayOfWeek) {
   let dd=new Date(dayStamp);
   let adate=dd.getDate();
   let amonth=dd.getMonth();
   let ayear=dd.getFullYear();
   let amonth3=dd.toLocaleString([], { month: 'short'});

   let asay='';
   if (iyear==1)   asay+=jQuery.trim(ayear)+'-' ;
   asay+=jQuery.trim(amonth3);
   asay+='-'+jQuery.trim(adate);

   if (iDayOfWeek==1) {
     const options = { weekday: "short" };
//     let arf=new Intl.DateTimeFormat("en-US", options).format(dd) ;
     let arf=new Intl.DateTimeFormat([], options).format(dd) ;

     asay=arf+' '+asay;
   }

   return asay;
}



//==================
// calculate and display the "quantity"
// also update "active row counter"

function  scheduleDo_calcQuantity(i1)  {

   let etable=$('#scheduleDivTable');
   let eList=$('#scheduleListDiv');

   let eComma=eList.find('[name="schedule_addComma"]');
   let iComma= (eComma.prop('checked')) ? 1  : 0 ;

   let euseK=eList.find('[name="schedule_useK"]');
   let iuseK= (euseK.prop('checked')) ? 1  : 0 ;

   let eprefix=eList.find('[name="schedule_prefix"]');
   let daPrefix=  eprefix.val() ;
   daPrefix=wsurvey.removeAllTags(daPrefix);

   let epostfix=eList.find('[name="schedule_postfix"]');
   let daPostfix=  epostfix.val() ;
   daPostfix=wsurvey.removeAllTags(daPostfix);

   let estart=etable.find('[name="scheduleStartTime"]');
   let startValueAll=parseInt(estart.attr('data-startValue'));

   let etrs=etable.find('.scheRow');
   let totValue=0;
   let nthRow=0,nRecosAdded=0,nBreaksAdded=0;

   for (iet=0;iet<etrs.length;iet++) {
      aetr=$(etrs[iet]);
      let aid=aetr.attr('data-choiceid');

      let eday=aetr.find('[name="updateCol"]');
      let erownum=aetr.find('.cschedule_rowNumber');
      let ename=aetr.find('[name="mvName"]');
      let aname=jQuery.trim(ename.text());
      if (aname=='') {
           eday.html('');
           eday.attr('data-scheduleval',0);
           erownum.html('&vellip;');
           continue  ;   // empty row
      }

      nthRow++;
      erownum.html(nthRow);

      if (aid==0) {
           nBreaksAdded++;
      } else {
        nRecosAdded++;
      }

      let nowVal=startValueAll+totValue;       // cumulative time to this row (in unix milliseconds) -- use it
      let sayval=nowVal ;
      if (iuseK==1) {
        sayval=wsurvey.makeNumberK(nowVal,10000,-1);
      } else if (iComma==1) {
        sayval=wsurvey.addComma(nowVal);
      }
       sayval=daPrefix+sayval   ;
       sayval+=daPostfix ;
       eday.html(sayval);
       eday.attr('data-scheduleval',nowVal) ;



// augment totmin by the duration and beforePause of this row
        let edura=aetr.find('[name="mvScheduleVarCol"]');
        let aduration=parseInt(edura.attr('data-duration'));
        let apause=parseInt(edura.attr('data-pausebefore'));
        totValue+=(aduration+apause);   // days at end of this entry  -- used as start value in next row


     }           // etrs

// end time in scheduleBottomRow row
     let  eend=etable.find('.scheduleBottomRow');
     let eday2=eend.find('[name="updateCol"]');
     let nowEndVal=startValueAll+totValue;       // cumulative time to this row (in unix milliseconds) -- use it
     let sayval=nowEndVal
      if (iuseK==1) {
        sayval=wsurvey.makeNumberK(nowEndVal,10000,-1);
      } else if (iComma==1) {
        sayval=wsurvey.addComma(nowEndVal);
      }
       sayval=daPrefix+sayval ;
       sayval+=daPostfix ;

       eday2.html(sayval);
       eday2.attr('data-scheduleval',nowEndVal) ;


    $('#scheduleBasicInfoReco_nsched').html(nRecosAdded);  // udpate counter in schedule page top bar

    $('#scheduleBasicInfoReco_nbreak').html('['+nBreaksAdded+' breaks]');  // udpate counter in schedule page top bar

     if (nRecosAdded+nBreaksAdded>0)     {
         $('#ischeduleSave_button').addClass('cscheduleSaveButton_on');
         $('#ischeduleFormat_button').addClass('cscheduleSaveButton_on');
         $('#ischedulePreview_button').addClass('cscheduleSaveButton_on');

      } else {
         $('#ischeduleSave_button').removeClass('cscheduleSaveButton_on');
         $('#ischeduleFormat_button').removeClass('cscheduleSaveButton_on');
         $('#ischedulePreview_button').removeClass('cscheduleSaveButton_on');
     }

     scheduleDo_updateButton(0) ;  // remove hjighligint (in calcTimes)

    return 1;





}

//==================
// calculate and display the "order" column

function  scheduleDo_calcOrder(i1)  {
   let etable=$('#scheduleDivTable');
   let eList=$('#scheduleListDiv');
//       alert('oof ');
//       return 1;
   let esA=eList.find('[name="schedule_sortAsc"]');
   let isAsc= (esA.prop('checked')) ? 1  : 0 ;

   let esD=eList.find('[name="schedule_sortDsc"]');
   let isDsc= (esD.prop('checked')) ? 1  : 0 ;

   if (isAsc==1) isDsc=0;   // should never happen

   let esN=eList.find('[name="schedule_numericSort"]');
   let isNumeric= (esN.prop('checked')) ? 1  : 0 ;

   let etrs=etable.find('.scheRow');

   let nthRow=0,nRecosAdded=0,nBreaksAdded=0;

   let daOrders=[];
   let doRenumber=0;
   for (iet=0;iet<etrs.length;iet++) {
      aetr=$(etrs[iet]);
      let aid=aetr.attr('data-choiceid');

      let eupdateCol=aetr.find('[name="updateCol"]');
      let erownum=aetr.find('.cschedule_rowNumber');
      let ename=aetr.find('[name="mvName"]');
      let aname=jQuery.trim(ename.text());
      if (aid<0 ||  aname=='') {    // aid<0 should be sufficient (31 march)... maybe should get rid of aname test
           eupdateCol.html('');
           eupdateCol.attr('data-scheduleval','');
           erownum.html('&vellip;');
           continue  ;   // empty row   -- do NOT add to daOrders
      }

      nthRow++;
      erownum.html(nthRow);
      let iwas= erownum.attr('data-origrow')    ;  // if -1, first call to calcORder
      if (iwas<0) doRenumber=1;

      if (aid==0) {
           nBreaksAdded++;
      } else {
          nRecosAdded++;
      }

      let eOrder=aetr.find('[name="mvScheduleVarCol"]');
      let aOrder= eOrder.attr('data-duration') ;   // use asis (no  validity check -- it should be one word no tags
      eupdateCol.html(aOrder);
      eupdateCol.attr('data-scheduleval',aOrder);

      let afoo=[aetr,aOrder,iwas]; // iwas might be rewritten
      daOrders.push(afoo);
  }           // etrs

  if (doRenumber==1)   {        // at least one newly added row (that does NOT have an origrow). Renumber the rows!
     for (let idd=0;idd<daOrders.length;idd++) {
         let cetr=daOrders[idd][0];
         let idd1=idd+1;
         let ec1=cetr.find('.cschedule_rowNumber');
         ec1.attr('data-origrow',idd1);
         daOrders[idd][2]=idd1;
     }
  }

  $('#scheduleBasicInfoReco_nsched').html(nRecosAdded);  // udpate counter in schedule page top bar

  $('#scheduleBasicInfoReco_nbreak').html('['+nBreaksAdded+' breaks]');  // udpate counter in schedule page top bar

   if (nRecosAdded+nBreaksAdded>0)     {
         $('#ischeduleSave_button').addClass('cscheduleSaveButton_on');
         $('#ischeduleFormat_button').addClass('cscheduleSaveButton_on');
         $('#ischedulePreview_button').addClass('cscheduleSaveButton_on');
   } else {
         $('#ischeduleSave_button').removeClass('cscheduleSaveButton_on');
         $('#ischeduleFormat_button').removeClass('cscheduleSaveButton_on');
        $('#ischedulePreview_button').removeClass('cscheduleSaveButton_on');
   }

   scheduleDo_updateButton(0) ;  // remove hjighligint (in calcTimes)

// now sort!
   let isTextSort=0;
   if (isAsc==0 && isDsc==0 ){
     daOrders.sort(scheduleDo_calcOrderSortOrig);
     daOrders.reverse();
   }   else {
     if (isNumeric) {            // isNumeric=1 only if asc or dsc selected
       daOrders.sort(scheduleDo_calcOrderSortNumeric);
       if (isAsc==1)  daOrders.reverse();  // reverse order due to how tr moves are done ...
    } else if (isAsc==1 || isDsc==1) {
       isTextSort=1;
       daOrders.sort(scheduleDo_calcOrderSortText);
       if (isAsc==1)  daOrders.reverse();  // reverse order due to how tr moves are done ...
     }
   }


// use daOrders[0] to rearrange
   let etopRow=etable.find('[name="nscheduleTopRow"');

   for (let im=0;im<daOrders.length;im++){
      let betr=daOrders[im][0];
      etopRow.after(betr)  ;
   }

// renumber and maybe format the uupdate col
   let etrsB=etable.find('.scheRow') ;   // the sorted order

   for (let ij=0;ij<etrsB.length;ij++) {
      let betr=$(etrsB[ij]);

      let ern=betr.find('.cschedule_rowNumber');
      let ij1=ij +1;
      ern.html(ij1);    // renumber

      if (isTextSort==1)   {           // non-numeric sort used lc, no spaces
         let emv=betr.find('[name="updateCol"]');
         let bval=emv.attr('data-scheduleval');
          if (!jQuery.isNumeric(bval)) {
              bval=fixString(bval,1).toLowerCase();
              emv.attr('data-scheduleval',bval);
              emv.html(bval);
         }
      }     // isnumeric
   }       // etrsb


   return 1;

}

function scheduleDo_calcOrderSortOrig(a,b) {    // sort to original (order entried added).
  let a1=a[2];
  let b1=b[2];
  return a1-b1 ;                                 // larger values after smaller
}

function scheduleDo_calcOrderSortNumeric(a,b) {    // numbers first, followed by asis value (cases retained, internal spaces retained)
  let a1=a[1];
  let b1=b[1];
  if (!jQuery.isNumeric(a1) && !jQuery.isNumeric(b1))  {  // both not numbers, do a text on actual value (not trimmed lc)
     if (a1==b1) return 0;
     if (a1>b1) return 1 ;
     return -1 ;
  }
  if  (!jQuery.isNumeric(a1)) return 1 ;                     // non-numerics sort after numerics
  if  (!jQuery.isNumeric(b1)) return -1 ;
  return a1-b1 ;                                 // larger values after smaller
}

function scheduleDo_calcOrderSortText(a,b) {     // spaces removed lower case sort
  let a1=jQuery.trim(a[1]).toLowerCase();
  a1=fixString(a1,1);
  let b1=jQuery.trim(b[1]).toLowerCase();
  b1=fixString(b1,1)
  if (a1==b1) return 0;
  if (a1>b1) return 1 ;
  return -1;
}

//==================
// calculate and display the "time" column (using durations and gaps of each row
// also update "active row counter"

function  scheduleDo_calcTimes(i1)  {

     let etable=$('#scheduleDivTable');
     let eList=$('#scheduleListDiv');
     let iElapsed=0,doAmPm=0;

     let stypes=eList.find('[name="schedule_timeType"]');
     let stype1=stypes.filter(':checked');
     let itype=stype1.val();
     if (itype==2) {                // am/pm itype=1 is the default 24hr)
        doAmPm=1;
        iElapsed=0;
     }
     if (itype==3) {   // elapsed
         doAmPm=0;
         iElapsed=1;
     }

     let eday1=eList.find('[name="schedule_dayNumber"]');
     let iShowDay= (eday1.prop('checked')) ? 1  : 0 ;

     let  estart=etable.find('[name="scheduleStartTime"]');
     let startMin=parseInt(estart.attr('data-startValue'));
     let totMin=0;
     let etrs=etable.find('.scheRow');

     let nthRow=0,nRecosAdded=0,nBreaksAdded=0;

     for (iet=0;iet<etrs.length;iet++) {
        aetr=$(etrs[iet]);
        let aid=aetr.attr('data-choiceid');

        let ehour=aetr.find('[name="updateCol"]');
        let erownum=aetr.find('.cschedule_rowNumber');
        let ename=aetr.find('[name="mvName"]');
        let aname=jQuery.trim(ename.text());
        if (aname=='') {
           ehour.html('');
           ehour.attr('data-scheduleval',0);
           erownum.html('&vellip;');
           continue  ;   // empty row
        }

        nthRow++;
        erownum.html(nthRow);

        if (aid==0) {
           nBreaksAdded++;
        } else {
          nRecosAdded++;
        }

        let nowTime=startMin+totMin;       // cumulative time to this row -- use it

        let arf;
        if (iElapsed==1) {          // total elapsed minutes?
            arf=scheduleDo_convertMinutes(totMin,{'elapsed':1,'showdays':iShowDay,'doampm':0});  //doampm not used, but wth
        } else {
            arf=scheduleDo_convertMinutes(nowTime,{'elapsed':0,'showdays':iShowDay,'doampm':doAmPm});     // clock time (given starting time)
        }
        ehour.html(arf[0]);
        ehour.attr('data-scheduleval',nowTime) ;



// augment totmin by the duration and beforePause of this row
        let edura=aetr.find('[name="mvScheduleVarCol"]');
        let aduration=parseInt(edura.attr('data-duration'));
        let apause=parseInt(edura.attr('data-pausebefore'));
        totMin+=(aduration+apause);   // time at end  -- used as start in next row

     }           // etrs

// end time in scheduleBottomRow row
     let  eend=etable.find('.scheduleBottomRow');
     let ehour2=eend.find('[name="updateCol"]');
     let endTimeLast= startMin+totMin;

    let arf2;
    if (iElapsed==1) {          // total elapsed minutes?
        arf2=scheduleDo_convertMinutes(totMin,{'elapsed':1,'showdays':iShowDay,'doampm':0});  //doampm not used, but wth
    } else {
        arf2=scheduleDo_convertMinutes(endTimeLast,{'elapsed':0,'showdays':iShowDay,'doampm':doAmPm});     // clock time (given starting time)
   }
   ehour2.html(arf2[0]);
   ehour2.attr('data-scheduleval',endTimeLast) ;

    $('#scheduleBasicInfoReco_nsched').html(nRecosAdded);  // udpate counter in schedule page top bar

    $('#scheduleBasicInfoReco_nbreak').html('['+nBreaksAdded+' breaks]');  // udpate counter in schedule page top bar

     if (nRecosAdded+nBreaksAdded>0)     {
         $('#ischeduleSave_button').addClass('cscheduleSaveButton_on');
         $('#ischedulePreview_button').addClass('cscheduleSaveButton_on');
         $('#ischeduleFormat_button').addClass('cscheduleSaveButton_on');

      } else {
         $('#ischeduleSave_button').removeClass('cscheduleSaveButton_on');
         $('#ischedulePreview_button').removeClass('cscheduleSaveButton_on');
        $('#ischeduleFormat_button').removeClass('cscheduleSaveButton_on');
     }

     scheduleDo_updateButton(0) ;  // remove hjighligint (in calcTimes)


    return 1;
}

//========================
// update all non-zero pauses -- using current value of the pause
// IOW: skip breaks
function scheduleDo_updateValues(ii) {
   let eList=$('#scheduleListDiv');

  let  agap=(schedulerType=='order') ? ' ' : scheduleDo_readGap(0,0);
  let defValueUse=scheduleDo_defUseValue(0,0);

  let eTable=$('#scheduleDivTableOuter');
  let etrs=eTable.find('.scheRow');
  for (iet=0;iet<etrs.length;iet++) {
     aetr=$(etrs[iet]);
     let mvid=aetr.attr('data-choiceid');
     if (mvid==0 || mvid<0) continue   ; // empty row, or a break

     let edura=aetr.find('[name="mvScheduleVarCol"]');
     edura.attr('data-pausebefore',agap);
     let edura2=aetr.find('[name="mvScheduleVarCol_2"]');
     edura2.html(agap);

     let adura=scheduleDo_readOwnDuration(mvid,false,0)    ;
     let isDefault=0;

     if (adura===false) {
        isDefault=1;
        adura=defValueUse;
     }
     edura.attr('data-duration',adura);
     let edura1a=aetr.find('[name="mvScheduleVarCol_1"]');
     if (isDefault==1) {             // if the default duration was used, update using (perhaps) new default duration
          edura1a.html('<em>'+adura+'</em>');  // em to signal using default duration
      } else {
           edura1a.html(adura);  // em to signal using default duration
      }
  }   // etrs

    scheduleDo_updateButton(1) ;  //  hjighligint (in scheduleDo_updateValues)

  return 1;

}


//==================
// add  recommendation to table .. in targted row, or first empty
// check for multiples and updates
// returns false if error. jQUery object of added to row if okay
// forceadd=1 : add always (ignore multiple cosntraints)

function scheduleDo_addReco(etarget,mvid,forceadd) {

  if (arguments.length<3) forceadd=0;

 // 15 March: could  make addRowIfNeeded a choice_parms.js var?
  let addRowIfNeeded=1;            //  set to 0 to issue alert if no space. 1 to add row to bottom

  let eList=etarget.closest('#scheduleListDiv');

  let defValueUse=scheduleDo_defUseValue(0,0);
  
  if (schedulerType!='order') agap=scheduleDo_readGap(0,0);   // gaps not used in order mode

  let aduration,isDefault;
  let rowId ;

  let eTable=$('#scheduleDivTableOuter');

  let eRowTarget=scheduleDo_targetRow(1) ;  // false if no targeted row,  [erow,mvid] if one exists
  if (eRowTarget===false)  eRowTarget=scheduleDo_firstEmpty(1) ;  // false if no targeted row,  [erow,0] if one exists

  if (eRowTarget===false) {
     if (addRowIfNeeded==1) {
         let aline=schedule_blankRow('?+');
         let eRowTarget0= $(aline);
         let eTableBottom=eTable.find('.scheduleBottomRow');
         eTableBottom.before(eRowTarget0);
         eRowTarget=[eRowTarget0,-1];
         writeStatusMessage('Adding row to bottom of table ...');

     } else {        // if addRowIfNeeded not enabled. Otherwise never occurs!
       let mvname=etarget.text();
       scheduleAlert('No place to  <tt>'+mvname +'</tt>. You must add a row, or clear an existing row!');
       return false;
     }
  }

  let eUse=eRowTarget[0];
  let wasId=eRowTarget[1];       // could be -1 or 0, or a choiceid

  if (wasId<-1) {
     if (eUse.hasClass('scheduleTopRow')) { // a peramenet row (the first one)? Can't overwrite
         scheduleAlert('Can not overwrite top row! Please select another target row. ') ;
         return false;
      }        // else something else (not supposed to happen)
      scheduleAlert('You can not overwrite this row. Choose a different <em>target row</em>' );
      return false;
  }


// check if already added, and if multiple copies allowed
  let nadd=etarget.attr('data-nadds');

  if (forceadd==0)  {          // forceadd not enabled
  if (nadd>0 && mvid!=0) {            // multiple breaks are always allowed
      if (wasId!=mvid) {          // somethin here, and not update... is multiple permitted ?
         let emultiple=eList.find('[name="schedule_allowMultiple"]');
         let qcheck=emultiple.prop('checked');
         if (!qcheck) {
           scheduleAlert('You already added this recommendation. To add multiple copies, uncheck <tt>Multiples ok?</tt>');
           return false;
         }
      }                  // not update (rowid!=mvid)
  }         // nadd
  }   // forceadd

// if here ... add recommendation to  targeted (or first empty) row  in schedule table

// determine what the values are (to update content of this row)
   let eli=etarget.closest('li');

   if (mvid==0)  {                    // special case (a break)
       let edura=eli.find('[name="schedule_breakLength"]');     // entered by user
       mvname='<span class="cschedule_breakName">Break</span>';
       aduration=jQuery.trim(edura.val());
       if (schedulerType=='order')  {    // breaks can be any value
          isDefault=0;
       } else {                     // check for numric
          aduration=jQuery.trim(edura.val());
          if (aduration=='') aduration=0;

          if (!jQuery.isNumeric(aduration) )   {
             scheduleAlert('Break duration should be a number (for <tt>'+schedulerType+'</tt> mode): <tt>'+aduration+'</tt>' );
            return false;
          }
          aduration=Math.max(0,parseInt(aduration));
          isDefault=0;
      }
      let ebdesc=eli.find('[name="schedule_breakDesc"]');
      descNote=ebdesc.val();
      descNote=wsurvey.removeAllTags(descNote);     // no html
      descNote=fixString(descNote,2); // extra spaces

      agap= (schedulerType=='order')  ? ' ' : 0;        // break duration should include any "before" pause -- pause not used in order mode

  } else {

      asugg=choiceList[mvid];
      mvname=asugg['Name'];

      aduration=scheduleDo_readOwnDuration(mvid,false,0);   // use false as default, and catch '' below
 
      if (aduration===false) {
         aduration=defValueUse;
         isDefault=1;
      }

      descNote=false  ;          // false means "read from choiceList using mvid"

  }

// find targeted row in table

// row ready to have content updated

   let q1=scheduleDo_addContent(eUse,mvid,aduration,descNote,isDefault)  ; // update content in a row (using clicked on reco)

   return [eUse,wasId] ;   // caller can uncheck target-this-row button
}


//===================
// find the "checked" row. Return [etr,mvid] if found. False if none
function scheduleDo_targetRow(ii) {
  let etable=$('#scheduleDivTable');
  let einputs=etable.find('.schedule_targetLabel2');  // class of the <Input checkbox>s for flagging the "target row"
  let arf=einputs.filter(':checked');
  if (arf.length==0) return false;
  let etr=arf.closest('tr');
  let mvid=etr.attr('data-choiceid');
  return [etr,mvid];
}

//==================
// find first empty row
// '' in name column signals empty row
function scheduleDo_firstEmpty(ii) {
  let eTable=$('#scheduleDivTableOuter');
  let enames=eTable.find('[name="mvName"]');
  for (let ien=0;ien<enames.length;ien++) {
    let enA=$(enames[ien]);
    let zname=jQuery.trim(enA.text());
    if (zname==='') {  // first empty row
       eUse=enA.closest('tr');;
       return [eUse,0];   // empty row always have data-movieid=0
    }
  }
  return false;
}

//================
// add content to a row in table
// etruse -- the row to add content to
// mvid: choiceid
// aduration (typically varies by recommendation -- either as a customVar , or a default value, or dynamically chosen
// descnote from choiceList
// gap is read from <input> field (so read each time this is called -- hence is dynamic

function scheduleDo_addContent(etruse,mvid,aduration,descNote,isDefault) {

  let asugg ;
  mvid=parseInt(mvid);
  let mvname='<span class="cschedule_breakName">Break</span>';  // default is "break"
  let agap= (schedulerType=='order') ? ' ' : 0;        // gap not used in order mode

  let eList=$('#scheduleListDiv');
  etruse.attr('data-choiceid',mvid);          // save the recommendations choice id (in this row)
  if (mvid!==0  ) {
      asugg=choiceList[mvid];
      mvname=asugg['Name'];
      if (schedulerType!='order') agap=scheduleDo_readGap(0,0) ;    // order mode doesn't use gap
  }

  if (descNote===false  && asugg.hasOwnProperty('Notes')){
     descNote=asugg['Notes']
  } else {
     if (mvid==0) descNote='<span class="cschedule_breakDesc">'+descNote+'</span>';
  }

  if (schedulerType!='order') aduration=parseInt(aduration);  // should not be necessary

  let ename1=etruse.find('[name="mvName"]');
  ename1.html(mvname);

  let eduration=etruse.find('[name="mvScheduleVarCol"]');  // replace contents

  eduration.attr("data-duration",aduration);
  eduration.attr('data-pausebefore',agap);
  eduration.attr('data-isdefault',isDefault);

  let dd1=eduration.find('[name="mvScheduleVarCol_1"]') ;
  if (isDefault==1) aduration='<em>'+aduration+'</em>';  // signal that default is being used
    dd1.html(aduration);
  let dd2=eduration.find('[name="mvScheduleVarCol_2"]') ;
    dd2.html(agap);

  let enote1=etruse.find('[name="mvShortDesc"]');
   descNote=wsurvey.removeAllTags(descNote);
   descNote=fixString(descNote,2);
//  enote1.html(descNote);
  enote1.val(descNote);

  let ehour=etruse.find('[name="updateCol"]');
  ehour.html('<tt>&#8263;</tt>');

  return etruse ;          // 13 march ... sort of useless (its the first argument)...
}

//=====================         gap
// remove content from a row
function   scheduleDo_removeContent(etruse)  {
  etruse.attr('data-choiceid',0);
  let ename1=etruse.find('[name="mvName"]');
  ename1.html('');
  let enote1=etruse.find('[name="mvShortDesc"]');
//  enote1.html('');
  enote1.val('');

  let ehour1=etruse.find('[name="updateCol"]');
  ehour1.html('&vellip;');
  ehour1.attr('data-scheduleval',0);

  let eduration=etruse.find('[name="mvScheduleVarCol"]');  // replace contents
  eduration.attr("data-duration",0);
  eduration.attr('data-pausebefore',0);
  eduration.attr('data-isdefault',0);
  let dd1=eduration.find('[name="mvScheduleVarCol_1"]') ;
    dd1.html('');
  let dd2=eduration.find('[name="mvScheduleVarCol_2"]') ;
    dd2.html('');

  return 1;
}

//================
// clear contents in all rows
// ido=1 : clear the schedule table (retains rows, clear their contents).
// ido=2 : and close a save a schedule box
function scheduleDo_clearAll(athis,double) {

  if (arguments.length<2) double=0;

  if (athis===1) {

  } else { // event call
     ethis=wsurvey.argJquery(athis);
     let lastClick=ethis.attr('data-lastclick');
 
     let tt= Date.now();
     ethis.attr('data-lastclick',tt);

     let eps=tt-lastClick ;
     epsSec=(eps/1000) ;
     if (epsSec<0.5) double=1;

  }

  let eTable=$('#scheduleDivTable');
  let eList=$('#scheduleListDiv');

  let etrs=eTable.find('.scheRow');
  for (let ie=0;ie<etrs.length;ie++) {
     let aetr=$(etrs[ie]);
     aetr.attr('data-choiceid',0);
     scheduleDo_removeContent(aetr);
  }

  scheduleDo_uncheckTargets();

 if (double==1 ) etrs.remove();  // and remove the row

  let elis=eList.find('.schedulerList_recommendation');

  for (let i2=0;i2<elis.length;i2++) {
     aeli=$(elis[i2]);
     let nadds=aeli.attr('data-nadds');
     aeli.attr('data-nadds',0);
     aeli.removeClass('schedulerList_recommendation_selected');
   }

   scheduleDo_updateButton(1) ;  // update, or click, Update times button (in clearall


   let etargB=eTable.find('.schedule_targetLabel2');
   etargB.prop('checked',false);

   return etrs.length;
}

// ---------------------
// add all unadded recommetnations to table
function scheduleDo_addAll(ii) {

  let eList=$('#scheduleListDiv');
  let eTable=$('#scheduleDivTable');
   let eTableBottom=eTable.find('.scheduleBottomRow');

  let defValueUse=scheduleDo_defUseValue(0,0);

  let toadds=[];

  let eall=eList.find('.schedulerList_recommendation'); // all the avaialble recommendations

  for (let ia=0;ia<eall.length;ia++) {  // make list of all unadded recommendations [id,duration]
       let ae1=$(eall[ia]);
       let mvid=ae1.attr('data-mvid');
       if (mvid==0) continue  ;        // don't add a break
       let nadds=ae1.attr('data-nadds');
       if (nadds>0) continue ;    // don't add if already selected
       let isDefault=0;
       let aduration=scheduleDo_readOwnDuration(ae1,false,0);   // use false as default, and catch '' below
       if (aduration===false) {
           aduration=defValueUse;
           isDefault=1;
       }
       let mvname=choiceList[mvid]['Name'];
       let adesc=choiceList[mvid]['Notes'];
       let add1=[mvid,aduration,mvname,adesc,isDefault];
       toadds.push(add1);
   }
   if (toadds.length==0) {
      scheduleAlert('There are no unadded recommendations!');
      return 1;
   }

  let enames=eTable.find('[name="mvName"]');
  let emptyRows=[];
  for (let ien=0;ien<enames.length;ien++) {
     let enA=$(enames[ien]);
     let zname=jQuery.trim(enA.text());
     if (zname==='') {  // first empty row
        let entr=enA.closest('tr');
        emptyRows.push(entr);
     }
  }

  if (emptyRows.length<toadds.length)   {  // not enough empty rows ... so add a few
     let nadd=toadds.length-emptyRows.length;
     for (let ia=0;ia<nadd;ia++) {
         let aline=schedule_blankRow('&forall;');
         let erowN=$(aline);
         eTableBottom.before(erowN);
         emptyRows.push(erowN);
     }
   }   // should be enough rows


   for (let ib=0;ib<toadds.length;ib++) {
       let to1=toadds[ib];            // mvid,adura,mvname,adesc
       let erow=emptyRows[ib];
       scheduleDo_addContent(erow,to1[0],to1[1],to1[3],to1[4])  ;  // adding all unaddde (etruse,mvid,aduration,descNote,isdefulat)
       scheduleDo_markReco(to1[0],1);   // adding all
   }


   return 1;
}      // schedule_addAll

//==================
// event handler for click in list div

function scheduleListEventHandler(evt) {

   let etarget=wsurvey.argJquery(evt);

   if (etarget.hasClass('choiceReportButton2')) {      // Show a report on this recommendation
      let eli=etarget.closest('li');
      let espan=eli.find('.schedulerList_recommendation');
      let mvid=espan.attr('data-mvid');
      displayChoiceReport(mvid,'#scheduleDivTable')    ;
      return 1;
   }


// add all unadded recommendations to empty rows in table.
// if not enough empty rows, add a few!
   if (etarget.hasClass('cschedule_addAll')) {      // add all recommendtions  (but not breaks) -- will also deal with 'buttons' in the list
     scheduleDo_addAll(1);
     scheduleDo_uncheckTargets();       // clear the "targe this row" buttons
     scheduleDo_highlightRow(false);         // highlight row just acced o
     scheduleDo_updateButton(1) ;  //  highlight the Update times button  (scheduleListEventHandler -- cschedule_addAll

     etarget.prop('checked',false);  //
     return 1;
   }


   if (etarget.hasClass('schedulerList_recommendation') || etarget.hasClass('cschedule_sayBreak')) {
       let mvid;
       if (etarget.hasClass('cschedule_sayBreak')) etarget=etarget.closest('.schedulerList_recommendation');
       mvid=etarget.attr('data-mvid');
       let edid=scheduleDo_addReco(etarget,mvid);        // event handler ...
       if (edid!==false) {
          scheduleDo_uncheckTargets();       // clear the "targe this row" buttons
          scheduleDo_highlightRow(edid[0]);         // highlight row just acced o
          scheduleDo_updateButton(1) ;  //  highlight the Update times button  -- schedulerList_recommendation
          if (edid[1]>0) scheduleDo_markReco(edid[1],0)  ; // the id of what was here -- >0 means a recommendation. Unmark it!
          if (mvid!=0)  window.setTimeout(function(){        // (use slight delay to avoid  hover text showing up
              scheduleDo_markReco(mvid,1) ;                    // mark in list of recos
          },150);
    }
  }

  return 0;
}

//============
// event handler for clicks on the table
function scheduleTableEventHandler(evt) {
   let etarget=wsurvey.argJquery(evt);
   let esched=$('#scheduleDivTableOuter');
   let eList=$('#scheduleListDiv');
 

   if (etarget.hasClass('schedule_targetLabel2') || etarget.hasClass('schedule_targetLabel') ) {     // set this as target for next add-recommendation
       if (etarget.hasClass('schedule_targetLabel')) {  // should not happen, but might (if brower sees  click on label and ignores checkbox)
         let e1=etarget.find('.schedule_targetLabel2');
         etarget=e1;
       }
       let echecks=esched.find('.schedule_targetLabel2');
       let qchecked=etarget.prop('checked');     // retain current state of the clicked on ...
       echecks.prop('checked',false);
       if (qchecked) etarget.prop("checked",true);
       return 1;
   }

   if (etarget.hasClass('schedule_removeRow')) {     // remove this row
     let etr=etarget.closest('tr');
     let mvid=etr.attr('data-choiceid');  // make this recommendation  "available" in the list
     etr.remove() ;   // remove this row
     scheduleDo_markReco(mvid,0) ;         // remove
     scheduleDo_updateButton(1) ;  // update, or click, Update times button  -- schedule_removeRow

   }

   if (etarget.hasClass('schedule_addRow')) {     // add row below this row
     let etr=etarget.closest('tr');
     let aline=schedule_blankRow('+');
     etr.after(aline);
     return 1;             // no need to change save or update buttons (added row is empty
  }

   if (etarget.hasClass('schedule_moveMeButton')) {     // mark row for move
      let etd1=etarget.closest('.scheRow_1');
      if (etd1.hasClass('cschedule_markForMove')) {    // could use toggleClass... but might want to do more
          etd1.removeClass('cschedule_markForMove');        // only one can be marked at a time (no need to check others)
      } else {
         let etds=esched.find('.cschedule_markForMove');  // remove any existing marks
         etds.removeClass('cschedule_markForMove');
         etd1.addClass('cschedule_markForMove');           // and add to this
      }
       return 1;
   }

   if (etarget.hasClass('cschedule_rowNumber')) {     // toggle empahsis of this row number
     let etr=etarget.closest('tr');
     let aid=etr.attr('data-choiceid');

     if (aid==-1) return 1;            // can't emphasize empty rows
     let etd1=etr.find('.scheRow_1');
     let isemp=etarget.attr('data-emphasis');

     if (isemp==0) {
         etarget.attr('data-emphasis',1);
         etarget.addClass('schedule_buttonEmphasis');
     } else {
         etarget.attr('data-emphasis',0);
         etarget.removeClass('schedule_buttonEmphasis');     }
     return 1;             // no need to change save or update buttons (added row is empty
  }

   if (etarget.hasClass('schedule_moveUp')) {     // move row up one
     let etr=etarget.closest('tr');
     let before=etr.prev();
     if (before.hasClass('scheduleTopRow'))  return 0;  // don't go before header row
     etr.insertBefore(before);
     scheduleDo_highlightRow(etr);
     scheduleDo_updateButton(1) ;  // update, or click, Update times button   -- schedule_moveUp
     return 1;
  }
   if (etarget.hasClass('schedule_moveDown')) {     // move  row down one
     let etr=etarget.closest('tr');
     let after=etr.next();
     if (after.length==0) return 0 ;      // don't go past end of table
     etr.insertAfter(after);
     scheduleDo_highlightRow(etr);
    scheduleDo_updateButton(1) ;  // update, or click, Update times button  -schedule_moveDown
     return 1;
  }

  if (etarget.hasClass('schedule_clearRow')) {     // clear content  in this row
    var etr=etarget.closest('tr');
    let mvid=etr.attr('data-choiceid');  // make this recommendation  "available" in the list
    scheduleDo_removeContent(etr)  ; // remoev content in this row
    scheduleDo_markReco(mvid,0) ;           // clear
    scheduleDo_updateButton(1) ;  // update, or click, Update times button  --schedule_clearRow
    scheduleDo_highlightRow(false);

  }
  
  if (etarget.hasClass('scheRow_1') || etarget.hasClass('scheduleTopRowB') || etarget.hasClass('schedule_moveMeHere')
        || etarget.hasClass('schedule_moveMeHereTop') ) {
      let  qtop=false;
      if ( etarget.hasClass('schedule_moveMeHereTop')) {
         qtop=true;
      }
      var etr=etarget.closest('tr');        // the target row -- moved row is placed underneath this
      if (qtop===false) {
        var etd1=etarget.closest('.scheRow_1');
        if (etd1.length>0 && etd1.hasClass('cschedule_markForMove')) {    // could use toggleClass... but might want to do more
            etd1.removeClass('cschedule_markForMove');        // only one can be marked at a time (no need to check others)
            return 1;
        }
      }

      let etds=esched.find('.cschedule_markForMove');
      if (etds.length==0) return 1 ;                   // nothing marked for move


// move to below here
// animate it for fun

     let eToMove=$(etds[0]);               // the marker (the downward facing hand icon)
     var eToMoveTr=eToMove.closest('tr');     // the row the marker is in

     if (qtop)  {          // make this top row .. no animation
        etr.after(eToMoveTr);
        scheduleDo_highlightRow(eToMoveTr);
        return 1;
     }

     var eflash=etr.find('.flashMeMove');
     eflash.fadeIn(300,scheduleTableEventHandler_s1);  // a sequence of fadeins/outs and highlighting at end

     scheduleDo_updateButton(1) ;
     return 1;
  }

// internal functions to animate the move of a row
function scheduleTableEventHandler_s1() {       // after fade in target row indicator
   etd1.addClass('schedule_moveToHere');
   eToMoveTr.fadeOut(300,scheduleTableEventHandler_s2);     // fade out of toBeMoved row

}
function scheduleTableEventHandler_s2() {       // after fade out the toBeMoved rpw
// eThis=$(this);
 etr.after(eToMoveTr);                         // move it
 eToMoveTr.fadeIn(300,scheduleTableEventHandler_s3);   // fade in of toBeMovedRow
}
function scheduleTableEventHandler_s3() {       // after fade in the toBeMoved rpw
  etd1.removeClass('schedule_moveToHere');
   eflash.fadeOut(700);                  //   fadeout target row indicator
   scheduleDo_highlightRow(eToMoveTr);
}

}    // scheduleTableHandler

//======================
// set the start time (hr or min)
function scheduleSetStartTime(athis) {

   let etarget=wsurvey.argJquery(athis);
   let dohour=0,domin=0;
   if (etarget.hasClass('starTime_hour'))   dohour=1 ;
   if (etarget.hasClass('starTime_min'))   domin=1 ;
   let asum=dohour+domin;
   if (asum!=1) return 1;  // should never happen

   let aval=jQuery.trim(etarget.val());
   if (aval=='') aval=0;             // be nice and treat blank as 0
   if (!jQuery.isNumeric(aval)) {
      if (dohour==1) {
         scheduleAlert('You must enter an hour value between 0 and 23 (inclusive): '+aval );
     } else {
         scheduleAlert('You must enter a minute value between 0 and 59 (inclusive): '+aval  );
     }
     etarget.val(0);
     return 1;
   }
   if (dohour==1) {         // check hour value
    let ahr=parseInt(aval);
     if (ahr<0 || ahr>23)  {
         scheduleAlert('Please enter an hour value between 0 and 23 (inclusive): '+aval );
         etarget.val(0);
         return 1;
     }
     let sayHour= (ahr<10)? '0'+ahr : ahr ;
     etarget.val(sayHour);     // clean up input

   }
   if (domin==1) {
     let amin=parseInt(aval);
     if (amin<0 || amin>59) {
         scheduleAlert('Please enter a minute value between 0 and 59 (inclusive): '+aval );
         etarget.val(0);
         return 1;
     }
     let sayMin= (amin<10) ? '0'+amin : amin ;
     etarget.val(sayMin);
   }

// could use above, but instead reread both and set hr:min on top row of table
  let eList=etarget.closest('#scheduleListDiv');

  let ehr=eList.find('[name="schedule_startTimeHour"]');
  let ahr=ehr.val();
  if (!jQuery.isNumeric(ahr)) ahr=0;
  ahr=parseInt(ahr);

  let emin=eList.find('[name="schedule_startTimeMin"]');
  let amin=emin.val();
  if (!jQuery.isNumeric(amin)) amin=0;
  amin=parseInt(amin);

  let nowMinute=(60*ahr)+amin;

  let eTable=$('#scheduleDivTableOuter');
  let eName=eTable.find('[name="scheduleStartTime"]');
  eName.attr('data-startValue',nowMinute);

  let sayMin= (amin<10) ? '0'+amin : amin ;
  let sayHour= (ahr<10) ? '0'+ahr : ahr ;
  eName.html(sayHour+':'+sayMin);

   scheduleDo_updateButton(1)  ; // new start time -- scheduleSetStartTime
  return 1;
}

//===========
// start quantityt

function scheduleSetStartQuantity(athis) {
   let ethis=wsurvey.argJquery(athis);
   let aval=ethis.val();
   if (!jQuery.isNumeric(aval)) {
      alert('Starting values must be a number ');
      ethis.val(0);
      return 1;
   }
   let etable=$('#scheduleDivTable');

   let estart=etable.find('[name="scheduleStartTime"]');
   estart.attr('data-startValue',parseFloat(aval));
   estart.html(aval);

   scheduleDo_updateButton(1)  ; // new start q -- so highlight the update buttom

   return 1;
}


//==============
// set start date   -- read all of them, regardless of which one changed
// default 2023Jan01 = 1672549200000

function scheduleSetStartDate(athis) {

  let etarget=wsurvey.argJquery(athis);

  let eTable=$('#scheduleDivTableOuter');
  let eDateVal=eTable.find('[name="scheduleStartTime"]');

   let doday=0,domonth=0,doyear=0,doval=0;

// use all date fields... get their values
   let eday=$('[name="schedule_startDay"]');
     doday=jQuery.trim(eday.val());
     if (doday==='') doday=1;
     if (!jQuery.isNumeric(doday) || doday<1) {
         alert('Invalid day: '+doday)  ;
         doday=1 ;   // set to deavult
     }
     doday=parseInt(doday);

   let emonth=$('[name="schedule_startMonth"]');
     domonth=jQuery.trim(emonth.val());
     if (domonth==='') domonth=1;
     if (!jQuery.isNumeric(domonth)) {   // check for month name
        let xdate=new Date('1 '+domonth+' 1999');
        let newmonth=xdate.getMonth();
        if (!jQuery.isNumeric(newmonth)) {
           alert('Invalid month: '+domonth)  ;
           etarget.val(1);        // set to deafulat
        }
        domonth=newmonth+1;       // convert jan=0 to jan=1
     }
     domonth=parseInt(domonth);

// https://stackoverflow.com/questions/13178069/getting-the-month-number-from-a-given-month-name
   let eyear=$('[name="schedule_startYear"]');
     doyear=jQuery.trim(eyear.val());
     if (doyear==='') doyear=2023;
     if (!jQuery.isNumeric(doyear) ) {
         alert('Invalid  year: '+doyear)
         etarget.val(2023);     // set to default
     }
     doyear=parseInt(doyear);

   let d1=wsurvey.validateDate(doyear,domonth,doday); // month from 1 to 12

   if (d1===false)  {
      if (etarget.hasClass('startTime_day')) {
         alert('Bad day value: '+doday );
         doday=1 ;
         etarget.val(doday);
      } else if (etarget.hasClass('startTime_month')) {
         alert('Bad month value: '+domonth );
         domonth=1  ; // /default
         etarget.val('Jan');
      } else if (etarget.hasClass('startTime_year')) {
         alert('Bad year value: '+doyear);
         doyear=2023 ;     // default
         etarget.val(2023);
      } else {        // should never happen
        alert('Bad date entered '+etarget.prop('outerHTML'));
        return 0 ;
      }

      d1=wsurvey.validateDate(doyear,domonth,doday);
  }

  if (d1===false) {     // should never hppan
     alert('problem with date: '+etarget.prop('outerHTML') );
     return 0;
  }

  let aDateStamp=d1['value'];
  let sayMonth=d1['month3'];
  let sayDay=d1['day'];
  let sayYear=d1['year'];

  eDateVal.attr('data-startValue',aDateStamp);
  eDateVal.html(sayYear+'/'+sayMonth+'/'+sayDay);

  eyear.val(sayYear);
  emonth.val(sayMonth);   // to be clean, rewrite as javascript otuput
  eday.val(sayDay);

   scheduleDo_updateButton(1)  ; // new start date -- so highlight the update buttom
  return 1;
}


//=================
// read the current "gap" value   -- duration in time or days, or extra values

function scheduleDo_readGap(idef,amin) {
  if (arguments.length<2) amin=0;
  let eList=$('#scheduleListDiv');
  let goids={'time':'#schedulerList_mode_time','date':'#schedulerList_mode_date','quantity':'#schedulerList_mode_quantity','order':'#schedulerList_mode_order'};
   let saydef={'time':'minutes','date':'days','quantity':'quantity','order':'order'};

  if (!goids.hasOwnProperty(schedulerType)) {      // should nevaer happen
    alert('unknown schedulerType: '+schedulerType);
    return 0;
  }

  let eSpan=eList.find(goids[schedulerType]);
  let egap=eSpan.find('[name="schedule_gapLength"]');
  if (egap.length==0) return 0;   // order mode?

   agap=jQuery.trim(egap.val());
   if (agap=='') agap=idef;                // assume '' means 0
   if (!jQuery.isNumeric(agap)  ) {
      scheduleAlert(' The gap ('+saydef[schedulerType]+' before each '+choiceNameSay+') should be a number: <tt>'+agap+'</tt>')
      return idef; ;
   }
  agap=parseInt(agap);
  return agap;
}

//=================
// read the current "default duration" value
function scheduleDo_defUseValue(idef,amin) {

   if (arguments.length<2) amin=0;
   let eList=$('#scheduleListDiv');

   let goids={'time':'#schedulerList_mode_time','date':'#schedulerList_mode_date','quantity':'#schedulerList_mode_quantity','order':'#schedulerList_mode_order'};
   let saydef={'time':'minutes','date':'days','quantity':'quantity','order':'order'};

   if (!goids.hasOwnProperty(schedulerType)) {      // should nevaer happen
     alert('unknown schedulerType: '+schedulerType);
     return 0;
   }

  let eSpan=eList.find(goids[schedulerType]);
  let edef=eSpan.find('[name="schedule_defaultDuration"]');
  if (edef.length==0) return 0;   // order mode?

  let defValueUse=jQuery.trim(edef.val());
  if (schedulerType=='order') {               // order -- don't check for valid number
     let afoo1=fixString(wsurvey.removeAllTags(defValueUse),2);  // can be more than word
     return afoo1 ;
  }
  if (defValueUse==='') defValueUse=idef;
  if (!jQuery.isNumeric(defValueUse)) {
      scheduleAlert(' The default <tt>'+saydef[schedulerType]+'</tt> must be a number: <tt>'+defValueUse+'</tt>' );
     return idef;
  }
  defValueUse=parseInt(defValueUse);
  return Math.max(amin,defValueUse) ;
}


//====================
// read own duration (of a suggestionName button in the list of recommendations
// hint: adef=false, then if return false manually assign defValueUse (and other stuff, such as isDefault)

function scheduleDo_readOwnDuration(tolook,adef,amin) {
    let aduration ;
 
    let atype=typeof(tolook) ;
     atype=atype.toLowerCase();
    if (atype=='object' ) {            // not an id -- so look "locally"
      let eli=$(tolook).closest('li')   ;  // might find itself


      if (eli.length==0) return adef ;     // no match, return default
      let edura=eli.find('.cschedule_varUse');

      if (edura.length==0) return adef ;
      aduration=jQuery.trim(edura.val());

      if (aduration==='') return adef ;    // don't check for validity (assume programmer called this corretly)
      if (schedulerType=='order') {
         let afoo1=fixString(wsurvey.removeAllTags(aduration),2);  // can be multiple words
         return afoo1 ;   // no need to check for valid number
      }

      if (!jQuery.isNumeric(aduration)) {
        scheduleAlert('Duration should be a number (<tt>'+schedulerType+'</tt> mode): <tt>'+aduration+'</tt>' );
        return adef;
      }

      aduration=parseInt(aduration);
      aduration=Math.max(amin,aduration);

      return aduration;
   }

// else, tolook is a choiceid
    let eList=$('#scheduleListDiv');
    let einputs=eList.find('.schedulerList_recommendation');
    let e1=einputs.filter('[data-mvid="'+tolook+'"]');
    if (e1.length==0) return adef ;                  // nomatch  -- don't bother checking for validity of adef (might be ===false)
    aduration=scheduleDo_readOwnDuration(e1,adef,amin)   ;  // might as well use this
    return aduration ;
}

//===============
// uncheck any "target this row" boxes
function scheduleDo_uncheckTargets(eTable) {
    if (arguments.length<1 || typeof(eTable)!=='object') eTable=$('#scheduleDivTable');
    let etargB=eTable.find('.schedule_targetLabel2');   // uncheck "target"
    etargB.prop('checked',false);
    return 1;
}

//=================
// highlight a row (unhighlight all others
function scheduleDo_highlightRow(erow) {
   eTable=$('#scheduleDivTable');
   let etrs=eTable.find('.scheRow');
   etrs.removeClass('cschedule_rowHighlight');
   if (erow===false) return 0 ;      // just unhighlight

   erow.addClass('cschedule_rowHighlight');

   return 1;
}
//===============
// update,   "update times" button-- 13 March -- could auto click it
// 1 april : each mode does the same thing.. but keep seperate for future flexiblity
// this handles time, date, quantity, orader modes!
function scheduleDo_updateButton(i1) {

  if (schedulerType=='time') {
    let ebc=$('#ischedule_calcTime');
    let eoof=$('#scheduleBasicInfoReco');
    let ebutSave=$('#ischeduleSave_button');
    if (i1==1) {               // up date occurred
       ebc.addClass('cschedule_updateTimeHighlight');
       eoof.addClass('cScheduleBasicInfoReco_dim');
       ebutSave.removeClass('cscheduleSaveButton_on');

    } else {
        ebc.removeClass('cschedule_updateTimeHighlight');
       eoof.removeClass('cScheduleBasicInfoReco_dim');
       ebutSave.addClass('cscheduleSaveButton_on');
     }
    return 1;
  }

  if (schedulerType=='date') {
    let ebc=$('#ischedule_calcTime');
    let eoof=$('#scheduleBasicInfoReco');
    let ebutSave=$('#ischeduleSave_button');
    if (i1==1) {               // up date occurred
       ebc.addClass('cschedule_updateTimeHighlight');
       eoof.addClass('cScheduleBasicInfoReco_dim');
       ebutSave.removeClass('cscheduleSaveButton_on');

    } else {
        ebc.removeClass('cschedule_updateTimeHighlight');
       eoof.removeClass('cScheduleBasicInfoReco_dim');
       ebutSave.addClass('cscheduleSaveButton_on');
     }
    return 1;
  }

  if (schedulerType=='quantity') {
    let ebc=$('#ischedule_calcTime');
    let eoof=$('#scheduleBasicInfoReco');
    let ebutSave=$('#ischeduleSave_button');
    if (i1==1) {               // up date occurred
       ebc.addClass('cschedule_updateTimeHighlight');
       eoof.addClass('cScheduleBasicInfoReco_dim');
       ebutSave.removeClass('cscheduleSaveButton_on');

    } else {
        ebc.removeClass('cschedule_updateTimeHighlight');
       eoof.removeClass('cScheduleBasicInfoReco_dim');
       ebutSave.addClass('cscheduleSaveButton_on');
     }
    return 1;
  }

  if (schedulerType=='order') {
    let ebc=$('#ischedule_calcTime');
    let eoof=$('#scheduleBasicInfoReco');
    let ebutSave=$('#ischeduleSave_button');
    if (i1==1) {               // up date occurred
       ebc.addClass('cschedule_updateTimeHighlight');
       eoof.addClass('cScheduleBasicInfoReco_dim');
       ebutSave.removeClass('cscheduleSaveButton_on');

    } else {
        ebc.removeClass('cschedule_updateTimeHighlight');
       eoof.removeClass('cScheduleBasicInfoReco_dim');
       ebutSave.addClass('cscheduleSaveButton_on');
     }
    return 1;
  }


}


//==============
// mark a reco 'button', in the list of recommendations container, as added or not added
function  scheduleDo_markReco(mvid,doAdd) {
   let eList=$('#scheduleListDiv');

   if (doAdd==0)   {  // remove
     let elis=eList.find('.schedulerList_recommendation');
     let eli1=elis.filter('[data-mvid="'+mvid+'"]');
     if (eli1.length==0) return 1 ;  // should never happen
     let nadds=eli1.attr('data-nadds');
     if (nadds>0) nadds-- ;          // should never be a problem
     if (nadds==0) eli1.removeClass('schedulerList_recommendation_selected');   // if multiple copies, don't uncheck until all are removed
     eli1.attr('data-nadds',nadds);
     return 1;
   }

// else, mark this
   let elis=eList.find('.schedulerList_recommendation');
   let eli1=elis.filter('[data-mvid="'+mvid+'"]');
   if (eli1.length==0) return 1 ; // should never happen
   let nadds=eli1.attr('data-nadds');
   nadds++ ;
   if (nadds==1) eli1.addClass('schedulerList_recommendation_selected');  // no need to add again if multiple entries of this
   eli1.attr('data-nadds',nadds);
   return 1 ;

}

//==============
// convert days to calendare or elapsed
// opts0 {'docalendar':doCalendar,'doshowweek':doShowWeek,'doshowyear':doShowYear,'doshowweekday':doShowWeekDay };

function scheduleDo_convertDays(daTime,opts0,startValue ) {

  let icalendar=opts0['docalendar'];
  if (icalendar==1) {
      let showYear=opts0['doshowyear'];
      let showWeekDay=opts0['doshowweekday'];

      let adate=scheduleDo_timeToCalendar(daTime,showYear,showWeekDay) ;
      return adate;
  }

// elapsed days. Perhaps add week counter?
  let iShowWeeks=opts0['doshowweek'];
  let eps1=daTime-startValue ;
  let msecInDay=(24*60*60*1000);
  let jdays=parseInt(eps1/msecInDay);

  if (iShowWeeks==0) {
      let afoo='<tt>'+jdays+'</tt>';
      return afoo;
  }
  
  let daw=scheduleDo_convertDayWeek(jdays);
  return '<em>'+daw+'</em>';
}



//=======================
// convert minutes to time, using various formatting options
// Given a time, calculate the hour and minutes, and (optionally) days.
// Thus, values of daTime greater than 1440(or multiples there of) cycle back 12:00am, with "days" incremented
//
// daTime: the time (in minutes) to convert.
// options: a object with properties
//      elapsed: default=0 . If 1, compute elapsed time - ignroe doAmPM, days preceding
//      doAmPm : (default=0) if 1, convert to AM / PM. Otherwise, 24 hour time
//               If doAmPM=0, then 24 hour time is used.
//      showDays : (default =1) show the number of days IF daTime+baseTime is greater than 1440.
//              Note that #days starts at "2" (the first day is suppressed)
//
//  returns [sayTime,days,hours,minutes]
//  sayTime format is  hr:min (days) --  inclusion  of '(days)' depends on the value of
//

function scheduleDo_convertMinutes(daTime,opts0) {

   if (arguments.length<2) opts0={};

   let opts={};
   let eTable=$('#scheduleDivTable');
   let eList=$('#scheduleListDiv');

   if (typeof(opts0)!='object') opts0={};

   let defOpts={'doampm':0,'showdays':0,'elapsed':0 };        // 23 march: alwaysdays always 1

   for (let aopt in opts0) {         // convert to lowercase , and trim values
      let aopt2=jQuery.trim(aopt).toLowerCase();
      opts[aopt2]=jQuery.trim(opts0[aopt]);
   }

   for (let aopt in defOpts) {           // for each of the required options  -- set if not specified
    if (!opts.hasOwnProperty(aopt)) {     // not specified in opts?
          opts[aopt]=defOpts[aopt] ;
     }      // hasownproper
    }        // in defopts


   let checkTime=parseInt(daTime) ;
   let showday=parseInt(opts['showDays']);

   let rets=scheduleDo_convertMinutes1(checkTime,opts['elapsed'],opts['doampm'],opts['showdays'] ) ;     // alwaysdays=1


   return rets;
}

// basetime
// Returns [timeSay,days,hours,minutes]; where timeSay uses doAmPm, showDays,   and  elapsedTime
//=======================
// convert minutes to 24 time
// returns [' hr:mm (nthDay)',days,hr,minutes].  if days<1, the (days) is dropped
// if useAm== hr:mm AM/PM. If 0, hr is 24 hr time (0 to 23)
// if showDay =0, do NOT display # of days. 1: display.

function scheduleDo_convertMinutes1(daTime,elapsed,useAm,showDay) {

   let minuntesInDay=24*60;
   let ndays=parseInt(daTime/minuntesInDay) ;
   let remTime=daTime-(ndays*minuntesInDay) ;
   let nhours=parseInt(remTime/60);
   let nmin=remTime-(nhours*60);

   if (elapsed==0)  {   // clock time

     let sayPm='';
     if (useAm==1) {
         sayPm='am';
         if (nhours>=12)    {  // use pm
           sayPm='pm';
           nhours=nhours-12 ;
           if (nhours==0) nhours=12 ;   // gosh, why is 12 actually 0?
        }
     }

     let ahours=(nhours<10) ? '0'+jQuery.trim(nhours) : nhours ;
     let amins= (nmin<10) ? '0'+jQuery.trim(nmin) :  nmin ;
     let atime=ahours+':'+amins+' '+sayPm;
     if (showDay==1) {
          atime=atime +' <span class="csayDaysInTime" title="nth day">'+(1+ndays)+'</span>';   // day 0 displayed as 1, 1 as 2...
     }
     return [atime,ndays,ahours,amins]
  }

// elapsed time!

  let atime= '<tt>'+daTime+'</tt>' ;
  if (showDay!=0) {
    atime=atime +' <span class="csayDaysInElapsedTime" title="nth day">'+(1+ndays)+'</span>  ';
   }

  let ahours=(nhours<10) ? '0'+jQuery.trim(nhours) : nhours ;
  let amins= (nmin<10) ? '0'+jQuery.trim(nmin) :  nmin ;

   return [atime,ndays,ahours,amins]
}

// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// read/retreive an existing schedule, and use it to populate forms and preview

//============
// read existing schedule  (called by the Read a schedule button)
// if single click: show <select> with all current schedules
// if double click OR idouble=1: auto load current (the currentUserName's current)
function schedule_readExisting(athis,idouble) {
   if (arguments.length<2) idouble=0;

   let ethis=wsurvey.argJquery(athis);
   let lastClick=ethis.attr('data-lastclick');
   let tt= Date.now();
   let eps=tt-lastClick ;
   epsSec=(eps/1000) ;
   ethis.attr('data-lastclick',tt);

   let didDouble=0;
   if (idouble==1 || epsSec<0.5) {  // double click (real or simulatd)!  -- retrieve your own
       didDouble=1;
       writeStatusMessage('Retrieving your saved schedule ...',2,1,1);

       let amess=applySelectSchedule(athis,currentUserName);  // amess might be error message. Usually short status message
       if (amess===false) return 0 ;     //some kind of error, don't preview
//        alert(' in readexisint abotu to call preview ');
//        return 1;
       schedule_preview(1);                     // preview if read on logon
       scheduleAlert('Reading from your saved schedule: '+amess);
       window.setTimeout(function(){
          schedule_preview(2)
          showStatusMessage(0);    },

       400);  // wait out first and secind click
  }      // epssec

   let daScheds=allScheds['schedules']
   let nSchedules=daScheds.length;

   let cuser=currentUserName ;

   let nBreaks=0,nChoices=0,nEntries=0;
   if (daScheds.hasOwnProperty(cuser)) {
        nBreaks=parseInt(daScheds[cuser]['nBreaks']);
        nChoices=parseInt(daScheds[cuser]['nChoices']);
        nEntries= nBreaks+nChoices ;
   }

   let amess= 'Your have '+nChoices+' recommendations (and '+nBreaks+' breaks) in your <em>saved schedule</em>  ';
   amess+='<br>Select a member: &nbsp;&nbsp;';
   let a1='';

   let gotOwn=0;
   a1+='<select   size="1"   required id="iPeopleWithSchedList" title="Select a member (# of` entries in schedule` in parenthesis)">';
   a1+='<optgroup label="Your schedule" >';
   if (nEntries==0) {
       a1+='<option disabled selected value="'+cuser+'" title="You have not saved a schedule !">'+currentUserName+'  </option>';
   } else {
        gotOwn=1;
       a1+='<option selected value="'+cuser+'">'+cuser+' ('+nEntries+')</option>';
   }
   a1+='<optgroup label="Other members " >';
   for (let aname in daScheds ) {
       if (aname==cuser) continue;
       let  nBreaks1=parseInt(daScheds[aname]['nBreaks']);
       let  nChoices1=parseInt(daScheds[aname]['nChoices']);
       let nEntries1=nBreaks1+nChoices1;
       a1+='<option value="'+aname+'">'+aname+' ('+nEntries1+')</option>';
   }
   a1+='</optgroup>';

   a1+='</select>';

   a1+=' and then <button  class="cSelectSchedules" onClick="applySelectSchedule(this)">retrieve the schedule!</button>&nbsp;&hellip; ';
   a1+='<br><em>Currently selected schedule will be cleared</em></label>';

// not needed
//   if (gotOwn==1)  a1+='<p><u>Hint</u>: to auto-retrieve your own saved schedule -- double click <button>Read a schedule</button>';

   amess+=a1;
   writeStatusMessage(amess,2,1,1);

   if (didDouble==0)  { // hide stuff to ensure visilbity of select-schedule box
      wsurvey.wsShow.hide('#mySchedule_formatVersion');  // hide the preview schedule box (to reveal the error message, and allow user to update times)
      wsurvey.wsShow.hide('#mySchedule_saveBox');  // hide the save schedule box (to reveal the error message, and allow user to update times)
   }

}

//================
// called by the Retrive the schedule button ... or indireclty via double click on Read a Schedule

// given a schedule, write its info to the "list or recommendations " and "table of schedule entries "
// a schedule is chosen  (a saved scheduled produced by aname or anameuse)
// typically from seleciton list
// but could be an explicit name (anameUse)

function applySelectSchedule(athis,anameUse) {
  if (arguments.length<2) anameUse=false;

  if (typeof(applySelectScheduleUse)!='function') {
     let daJs='choicer_sched2.js';
      $.getScript(daJs)
       .done(function(a,b,c) {
         applySelectSchedule(athis,anameUse) ;
         return 0;
     })
     .fail(function(a,b,c) {
       alert("problem!" );
        initJsReadFail(a,b,c,daJs);
        return 1;
     });
     return 0;
  }

  let  xx=applySelectScheduleUse(athis,anameUse);
 
  return xx;
}

// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//  save to server functions ...

//=------------------------
// save the schedule entires,comment, and formatting options  ...
// disable publish button

function schedule_saveToServerDo(ifoo) {
  let rets={};
  rets['list']=schedule_readTableRows(1)  ; // return info fron schedule table)
  let afmt=schedule_formatReadOptions(1);

  if (afmt===false) return 1 ;           // always double check for "bad html, user wants to fix"
  rets['formats']=afmt

  let ecomment=$('#saveSchedule_comment');
  let acomment=ecomment.val();
  acomment=wsurvey.removeAllTags(acomment);
  acomment=fixString(acomment,2);

  let useRecos=$('#scheduleListDiv').data('useRecos');
  let recoUser=$('#scheduleListDiv').data('recoUser');

  rets['schedulerType']=schedulerType ;
  rets['theProject']=useProject ;
  rets['username']=currentUserName;
  rets['comment']=acomment;
  rets['todo']='save';
  rets['recoList']=useRecos.join(',');
  rets['recoFrom']=recoUser ;
 
  $.ajax({
        url: 'choicer_schedule.php',
        type: 'POST',
        dataType: 'json',
        data: rets
    }).always(function (response) {
       if (typeof(response)!='string') {
          wsurvey.dumpObj(response,1,'Problem saving schedule  ');
       } else {
          schedule_saveToServer2b(response) ;
       }
    });

}

function  schedule_saveToServer2b(response) {
  let amess=response+'<br> Please <button class="topRowButtonOther2" onclick="doReload()">Reload </button> to Publish these changes ';

  let epubs=$('[name="nschedulePublish_button"]');
  epubs.removeClass('cscheduleSaveButton_on');

   scheduleAlert(amess);
   $('#schedule_alertBoxOuter').html(amess);
   wsurvey.wsShow.show('#schedule_alertBoxOuter',2);
   
   wsurvey.wsShow.hide('#mySchedule_saveBox',500);
   wsurvey.wsShow.hide('#mySchedule_formatVersion');  // hide the preview schedule box (to reveal the error message, and allow user to update times)
   return 1 ;
}


//=======================
// copy the descirption to the "specify column" header input box
// iwhich=1 : use .text(), 2: use defaultValue
function schedule_format_asColName(athis ) {

   let ethis=wsurvey.argJquery(athis);
   let iwhich=ethis.attr('data-which');
   let eli=ethis.closest('li');
   let einput=eli.find('[name="schedule_headerName"]');
   let daDesc ;
   if (iwhich==1) {
      daDesc=ethis.html();   // the descsription span was clicked
   } else {
      daDesc=einput.attr("data-varnameHdr");
   }

   einput.val(daDesc);
   return false;
}

function schedule_format_clear(athis) {
   let ethis=wsurvey.argJquery(athis);
   let eli=ethis.closest('li');
   let einput=eli.find('input');
   einput.val('');
}

// ========================
// reset formatting options to original values
function schedule_format_reset(ifoo) {
    makeSchedule_formatMenu(1)  ; // kind of overkill, but wth
}


//::::::::::::::::::::::::::;
// pubish functions

//  --------
// publish as html file (with appropriate css and js files
function schedule_publish_makeHtml(ifoo) {

  if (!allScheds.hasOwnProperty('using')) {
     alert('You must first retrieve a schedule. To use a schedule you just created -- save it, reload, and then retrieve it!');
     return 0;
  }
  let aname=allScheds['using'];
  let ddata=schedule_makeHtmlStuff(aname);
  ddata['theProject']=useProject;
  ddata['title']=documentTitle ;

 let stmess='The Schedule (as a standalone HTML page) should now be visible in a new window (or tab)';
 stmess+='<br>Note: the top row header\'s text is from the  <tt> $scheduleTopHeader</tt> variable (admin settable using <button>Set parameters</button>)';
 writeStatusMessage(stmess,2,1,1);

 $('#publishHtml_message').html(stmess);
  submitQuickForm('choicer_htmlSchedule.php','POST', ddata,'viewer')

}


//=========
// make html content to upload to server
function schedule_makeHtmlStuff(aname,nostringify) {
 if (arguments.length<2) nostringify=0;

 let schList=allScheds['schedules'][aname];

 let amess=''
 let aHeader=schList['Header'];
 amess+='<div class="cschedule_formatHeader"> ';
 amess+=aHeader ;
 amess+='</div>';

 let daHtmlSchedule=schedule_toHtml(schList,schList,schedulerShow);
 ddata={};
 ddata['todo']='html';
 ddata['theProject']=useProject ;
 ddata['who']=aname;
 ddata['time']= Date.now();
 ddata['keycode']=localDownloadKeycode;         // march 2023 not very secure (no salt used)
 ddata['suppressLocalDownload']=suppressLocalDownload;         // march 2023 not very secure (no salt used)
 ddata['htmlSchedule']= amess+' '+daHtmlSchedule ;
 if (nostringify==0) {
   ddata['fmtvars']=JSON.stringify(schList['fmtVars']);
   ddata['linkIcons']=JSON.stringify(linkIcons);       // linkIcons is a globa
 } else {
   ddata['fmtvars']= schList['fmtVars'] ;
   ddata['linkIcons']=linkIcons;       // linkIcons is a globa
 }
 return ddata ;
}

//==========
// save schedlue specs, and send back as a .js file
function schedule_publish_makeJSON(ifoo) {

 if (!allScheds.hasOwnProperty('using')) {
     alert('You must first retrieve a schedule. To use a schedule you just created -- save it, reload, and then retrieve it!');
     return 0;
  }

 let epp=$('#mySchedule_publishInner');
 let epname=epp.find('[name="json_filename"]');
 let fname=epname.val();
 fname=jQuery.trim(fixString(fname,1));
 if (fname=='') fname='save1';  // should never happen

  epcmt=epp.find('[name="json_comment"]');
 let acomment=jQuery.trim(epcmt.val());
 acomment=wsurvey.removeAllTags(acomment);

 let aname=allScheds['using'];

 ddata=schedule_makeJsonStuff(aname,acomment,fname)   ;
  ddata['theProject']=useProject;
  ddata['title']=documentTitle ;

 let stmess='Schedule (JSON specifications) will be downloaded in a <tt>.js</tt> file.<br> Look for  <tt>'+fname+'</tt> in your browser Downloads &#9047; ';
 writeStatusMessage(stmess,2,1,1);
 $('#publishJson_message').html(stmess);

 submitQuickForm('choicer_htmlSchedule.php','POST', ddata,'viewer')

}

//=======
// create stringified data for upload to sever (of the current schedule entries, formats, etc

function schedule_makeJsonStuff(aname,acomment,fname,nostringify) {
  if (arguments.length<4) nostringify=0;
 let schList=allScheds['schedules'][aname];

 let scheduleVar=allScheds['scheduleVar'];

// get minimal info on non-chosen recommendations
 let entries1=schList['entries'];
 let recos1=schList['recoList'];
 let reco1sGot={} ;  // list of recos in shceudle
 for (let iss=0;iss<entries1.length;iss++) {
    let ae1=entries1[iss];
    let aid=ae1['Id'];
    if (aid==0) continue;
    reco1sGot[aid]=1;
 }
 let recosNotUsed={};
 let recosUsed={};
 let lrecos=recos1.split(',');   // all recommendations available for this schedule
 let recoData={};
 for (let iss2=0;iss2<lrecos.length;iss2++) {
     let zid=lrecos[iss2];
     let ause=schedule_makeJsonStuff_owndata(zid,schList) ;  // and uses choiceList global -- returns false if break or removed
     if (ause!==false) {
        recoData[zid]=ause     ;  // not removed or break
        if (!reco1sGot.hasOwnProperty(zid)) {
           recosNotUsed[zid]=1;
        } else {
           recosUsed[zid]=1;
        }
     }
 }

 ddata={};
 ddata['filename']=fname;
 ddata['theProject']=useProject ;

 ddata['comment']=acomment ;
 ddata['scheduleVar']=scheduleVar;
 ddata['schedulerType']=schedulerType ;
 ddata['todo']='json';
 ddata['who']=aname;
 ddata['header']=schList['Header'];
 ddata['time']= Date.now();
 ddata['keycode']=localDownloadKeycode;         // march 2023 not very secure (no salt used)
 ddata['suppressLocalDownload']=suppressLocalDownload;         // march 2023 not very secure (no salt used)

 let afle=schList['file'];    // march 2023: wierd js bug that doesn't like x:\\dir\\filename
 schList['file']=afle.replace(/\\/g,'/');

 if (nostringify==0) {
   ddata['linkIcons']=JSON.stringify(linkIcons);       // linkIcons is a globa
   ddata['recosNotUsed']=JSON.stringify(recosNotUsed);
   ddata['recosUsed']=JSON.stringify(recosUsed);
   ddata['recoData']= JSON.stringify(recoData);
   ddata['schedule']=JSON.stringify(schList);
 } else {
   ddata['linkIcons']=linkIcons;       // linkIcons is a globa
   ddata['recosNotUsed']=recosNotUsed;
   ddata['recosUsed']=recosUsed;
   ddata['recoData']= recoData;
   ddata['schedule']=schList;
 }

 return ddata ;
}

//==========
// extracte recommendation speicifc variables (from choiceList, and customVarlist
// for each recoomendations, save custom variables and rate/etc info
//  'Name'       : (15) the name of the suggestions. If not specified, it will be added!
//  'Links'      : (20) the links (specified on the Rate page)   -- as <a ..><img></a> (no text)
//  'Desc'       : (20) the description (as specified when the entry was added to the schedule-- or updated)
//   'firstNote'  : (30) the short note (no html). Specified on the Add  suggestions page
//   'descNotes'  : (40) the descriptive notes (specified on the Rate page). Also includes the firstNote
//   'infoBlurbs' : (20) the "information blurbs" (specified on the Rate page)
//   'allLinks'   : (20) the Links and the infoBlurbs
// the customVars variables. The default lengths are those specified in customVarsLength

function schedule_makeJsonStuff_owndata(zid,schList) {
  let stuff={};

  if (zid<=0) return false ;          // break?
  if (!choiceList.hasOwnProperty(zid)) return false ; // removed?

  let  varList=schList['fmtVars'];

  let dynVars={'rowNumberChoice':1,'totalDuration':1,'Start':1,'rowNumber':1,'Duration':1,
               'Pause':1,'Elapsed':1,'entryValueA':1};            // dynamic variables, so do NOT include

  let thisdata={};
  for (let i1 in schList['entries'])  {    // find entry for zid
     aentry=schList['entries'][i1];
     let aid=aentry['Id'];
     if (aid!=zid) continue;
     thisdata=aentry;                      // schList vars
  }

  let daChoice=choiceList[zid];       // choiceList   vars

  for (let cc in varList) {
     if (dynVars.hasOwnProperty(cc)) continue  ; // this is created by scheduler dynamicaly
     if (customVarList.hasOwnProperty(cc)) {
        stuff[cc]=daChoice[cc];
     } else if (cc=='Name')  {
        stuff[cc]=daChoice[cc];
     } else if (cc=='firstNote') {
         stuff[cc]=daChoice['Notes'] ;
     } else if (cc=='Desc') {
         stuff[cc]=thisdata['desc'] ;

     } else if (cc=='allLinks') {
         stuff[cc]=daChoice['linkNotes'] ;

     } else if (cc=='Links' || cc=='infoBlurbs') {
         let arf1=daChoice['linkNotes'];
         let arf2=[];
         for (let iarf=0;iarf<arf1.length;iarf++) {
             arfB=arf1[iarf];
             let arfB0=arfB[0];
             if (arfB0.substr(0,1)=='@' && cc=='Links')  {     // a link
                arf2.push(arfB);
            }
             if (arfB0.substr(0,1)!=='@' && cc=='infoBlurbs')  {     // a infoblurb
                arf2.push(arfB);
            }
        }
        stuff[cc]=arf2 ;
     }        // else, ignore
  }
  return stuff;
}




// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// preview a schedule

//==============
// create formated  schedule using scheduleShowVar (and currently specified scheule table)
// ido no currently used (check visiblity of mySchedule_format_b  instead)
function schedule_preview(ido) {

// alwasy open the basic save menu
  let q=schedule_showSave(1);                  // opens the basic "save" menu box  -- and check for significant changes

  if (q===false) {             // an error -- changes in schedule table but no update of times
     wsurvey.wsShow.hide('#mySchedule_formatVersion');  // hide the preview schedule box (to reveal the error message, and allow user to update times)
     wsurvey.wsShow.hide('#mySchedule_saveBox');  // hide the save schedule box (to reveal the error message, and allow user to update times)
     return 1;
  }
  wsurvey.wsShow.hide('#mySchedule_saveBox');  //  don't need it open

  let daOptions=schedule_formatReadOptions(1);  // info from formatting menu  (the defaults if just opened)

  if (daOptions===false) return 1;       // problem with header, let user reenter

   let astuff=schedule_readTableRows(1)  ; // return info from the current schedule table
 
  let amess='';
  amess+='<div class="cschedule_formatHeader"> ';
  amess+=daOptions['Header'];
  amess+='</div>';

  let atable=schedule_toHtml(astuff,daOptions,schedulerShow) ;

   amess+=atable;

  let pwindow=$('#mySchedule_formatVersion');         // write the formmated schedule to this fixed div (
  let pwindow2=$('#mySchedule_formatVersionInner');
  pwindow2.html(amess);

  wsurvey.wsShow.show('#mySchedule_formatVersion'); 

  return 1;

}

//=================
// background the preview box, open the saveToServer of formatMenu box
// this is used by buttons in the "preview schedule" popup
function schedule_previewGoBack(evt,iWhich) {

 wsurvey.wsShow.inFront(evt,1)    ; // send schdedule preview back
  if   (iWhich==1)  {   // save to server box
     schedule_showSaveToServerMenu(1)
  } else {
     schedule_showFormatMenu(1) ;       // the formatting options menu
  }
}
// ============================================
// functions used in several places
//=======================
// create html of a schedule, with formatting
// daStuff and daOptions are same (if using retrieved from server info
// dastuff:   entries and some vars (endValueAll)
// daOptions: formatting optoins. Note that if using saved schcedule, dastuff and daoptions are exactly the same.
// schedulerShow : for now, always call with global schedulerShow (18 march 2023)

function schedule_toHtml(daStuff,daOptions,schedulerShow1) {

  let maxHeight=daOptions['maxHeight'];

  let doAmPm,showDays,doElapsed;
  let doCalendar,doShowWeek,doShowYear,doShowWeekDay;

  if (schedulerType=='time') {
     doAmPm=daOptions['doAmPm'];
     showDays=daOptions['doShowDays'];
     doElapsed=daOptions['doElapsed'];
  }

  if (schedulerType=='date') {
     doCalendar=daOptions['doCalendar'];
     doShowWeek=daOptions['doShowWeek'];
     doShowYear=daOptions['doShowYear'];
     doShowWeekDay=daOptions['doShowWeekDay'];
  }

    if (schedulerType=='quantity') {
     doAddComma=daOptions['doAddComma'];
     doUseK=daOptions['doUseK'];
     doPrefix=daOptions['doPrefix'];
     doPostfix=daOptions['doPostFix'];
  }

  if (schedulerType=='order') {
      // no options for order
  }

  let startValueAll=daStuff['startValueAll'];

  let keepers=(daStuff.hasOwnProperty('fmtVarsKeep'))  ? daStuff['fmtVarsKeep'] : daOptions['varsKeep'];  // latter if using current schedule
  let colNamesSay=(daStuff.hasOwnProperty('fmtVars')) ? daStuff['fmtVars'] : daOptions['vars'];  // latter if using current schedule

  let colWidths=(daOptions.hasOwnProperty('colWidths')) ?  daOptions['colWidths'] :  daStuff['colWidths'] ;
  if (typeof(colWidths)=='undefined' ) colWidths={};
  for (let avar in schedulerShow) {
      if (!colWidths.hasOwnProperty(avar)) colWidths[avar]=schedulerShow[avar];
      colWidths[avar]=parseInt(colWidths[avar]);
  }
  let alist=daStuff['entries'];

  let atable='';
  let totwide=0;
  for (let avar in schedulerShow) {        // note that schedulerShow has the "customVars" added (with their widths)
    if (keepers[avar]==0) continue ;      // drop this coluumn
    let awide= colWidths[avar] ;
    totwide+=awide;
  }

  atable='<table border="1"  style="width:99%" id="schedule_formatSchedule">'+'\n' ;
  atable+='<tr class="formatHeaderTr">';
  for (let avar in schedulerShow) {
      if (keepers[avar]==0) continue ;    // drop this coluumn
     let awide0=colWidths[avar]  ;
     let awide=parseInt(99* (awide0/totwide));
     let cvar=jQuery.trim(colNamesSay[avar]);
     atable+='<th style="width:'+awide+'%">'+cvar+'</th>';
  }
  atable+='</tr>';

// these are pulled directly  from the current schedule table
 let fromSchedVars={'Name':1,'entryValueA':1,'Duration':1,'Pause':1,'Desc':1} ;

  let da1='',da2='';
  if (maxHeight!=='') {    // limit height of cells?
       da1='<div style="overflow:auto;max-height:'+maxHeight+'em">'+'\n' ;
       da2='</div> \n'  ;
  }
  let irow=0,irowChoice=0;

  nScheErr=0;
  for  (let ii in alist) {
     let alist0=alist[ii];

     let mvid= (alist0.hasOwnProperty('Id')) ? alist0['Id'] : alist0['id'];  // check 2 variants (since diferent soruces use slightly differnt property names

     if (mvid!=0 && !choiceList.hasOwnProperty(mvid)) {  // a removed suggestion
        nScheErr++;
        continue ;
     }

     irow++ ;

     if (mvid>0) irowChoice++;

     let mvname;
     if (mvid==0) {
        mvname='<em>Break</em>';
     } else {
       mvname= (alist0.hasOwnProperty('Name')) ? alist0['Name'] : alist0['name'];
     }
     let orderVal,orderValOrig,entryValueA ;
     entryValueA=  (alist0.hasOwnProperty('entryValueA')) ? alist0['entryValueA'] : alist0['entryvaluea'];
     if (schedulerType!='order')  {
        entryValueA=parseFloat(entryValueA);
     } else {
        orderVal=entryValueA ;
//       alert(' orerVal =' +orderVal);

     }
     let aDuration=  (alist0.hasOwnProperty('Duration')) ? alist0['Duration'] : alist0['duration'];
        if (schedulerType!='order'){
          aDuration=parseFloat(aDuration);      // if order, might be text
        } else {
          orderValOrig=aDuration ;
        }

     let aPause=  (alist0.hasOwnProperty('Pause')) ? alist0['Pause'] : alist0['pause'];
        if (schedulerType=='order') {
          aPause='';
        } else {
            aPause=parseFloat(aPause);
        }

     let aDesc=  (alist0.hasOwnProperty('Desc')) ? alist0['Desc'] : alist0['desc'];
     let gotEmphasis=  (alist0.hasOwnProperty('gotEmphasis')) ? alist0['gotEmphasis'] : alist0['gotemphasis'];

     let fromSchedVars={'Name':1,'entryValueA':1,'Duration':1,'Pause':1,'Desc':1} ;
     let arow='<tr class="formatRow">';

     for (let dovar in schedulerShow) {
         if (keepers[dovar]==0) continue ;      // drop this coluumn

         let atd='';

         if (dovar=='Name') atd='<td>'+da1+mvname+da2+'</td>'+'\n' ;

         if (dovar=='entryValueA'   ) {
           if (schedulerType!='order') {
              atd='<td>'+entryValueA+'</td>'+'\n' ;
           } else {
              atd='<td>&vellip;</td>'+'\n' ;
           }
         }

         if (dovar=='Duration') {
            if (schedulerType!='order') {
              atd='<td>'+aDuration+'</td>'+'\n' ;
            } else {                                    // show the order vaalue
               atd='<td>'+orderValOrig+'</td>'+'\n' ;
            }
         }
         if (dovar=='Pause') atd='<td>'+aPause+'</td>'+'\n' ;
         if (dovar=='Desc') atd='<td>'+da1+aDesc+da2+'</td>'+'\n' ;

        if (dovar=='rowNumber') {
           if (gotEmphasis==1) {
             atd='<td><span style="background-color:cyan;font-weight:600">'+irow+'</span></td> \n'  ;
           } else {
             atd='<td><tt>'+irow+'</tt></td> \n'  ;
           }
        }
        if (dovar=='rowNumberChoice') {
          if (mvid==0) {
             atd='<td>&vellip;</td> \n'  ;
          } else {
             if (gotEmphasis==1) {
               atd='<td><span style="background-color:cyan;font-weight:600">'+irowChoice+'</span></td> \n'  ;
             } else {
               atd='<td><tt>'+irowChoice+'</tt></td> \n' ;
             }
          }
        }

        if (dovar=='Start') {
            let t1;
            if (schedulerType=='time') {
               let tfmts={'doampm':doAmPm,'showdays':showDays,'elapsed':doElapsed };
               let t0=scheduleDo_convertMinutes(entryValueA,tfmts,0);   // timeSay,ndays,ahours,amins -- not using timeSay
               t1=t0[0];

            }
            if (schedulerType=='date') {
                let tfmts={'docalendar':doCalendar,'doshowweek':doShowWeek,'doshowyear':doShowYear,'doshowweekday':doShowWeekDay };
                 t1=scheduleDo_convertDays(entryValueA,tfmts,startValueAll);
            }
            if (schedulerType=='quantity') {
              t1=entryValueA ;
              if (doUseK==1) {
                  t1=wsurvey.makeNumberK(entryValueA,10000,-1);
              } else if (doAddComma==1) {
                 t1=wsurvey.addComma(entryValueA);
              }
              t1=doPrefix+t1+doPostfix
//              t1+=doPrefix   ;
//              t1+=doPostfix ;
           }
           if (schedulerType=='order') {
              t1=orderVal;
           }

           atd='<td>'+t1+'</td>'+'\n' ;
        }

        if (dovar=='Elapsed') {
            let t1,tuse;
            if (schedulerType!='order')   tuse=entryValueA -startValueAll ;

            if (schedulerType=='time') {
                let tfmts={'doampm':0,'showdays':showDays,'elapsed':1};   // elapsed is always show as elapsed time (not clock time) .. so doampm is ignroed
                let t0=scheduleDo_convertMinutes(tuse,tfmts);   // timeSay,ndays,ahours,amins -- not using timeSay
                t1=t0[0];
            }
            if (schedulerType=='date') {
                  let tfmts={'docalendar':0,'doshowweek':0,'doshowyear':0,'doshowweekday':0 };   // elapsed, so never calendar
                  t1=scheduleDo_convertDays(entryValueA,tfmts,startValueAll);
            }
            if (schedulerType=='quantity') {
                t1=tuse ;
                if (doUseK==1) {
                    t1=wsurvey.makeNumberK(tuse,10000,-1);
                } else if (doAddComma==1) {
                   t1=wsurvey.addComma(tuse);
                }
              t1=doPrefix+t1+doPostfix
//                t1+=doPrefix   ;
//                t1+=doPostfix ;
           }
           if (schedulerType=='order') {
                t1='&vellip;';
           }
           atd='<td> '+t1+' </td> \n'  ;

        }     // elpased

        if (dovar=='totalDuration') {
            isum= (schedulerType=='order')  ? '&vellip; ' :   aDuration +aPause ;
             atd='<td>'+isum+'</td> \n';
        }
        if (dovar=='allLinks'  ) {
            if (mvid==0) {
               atd='<td>&vellip;</td>'+'\n' ;
            } else {
              let t1=getlinkNotes(mvid,0,'&empty;') ;
              atd='<td>'+da1+t1+da2+'</td> \n' ;
            }
        }
        if (  dovar=='infoBlurbs'   ) {
            if (mvid==0) {
               atd='<td>&vellip;</td>'+'\n' ;
            } else {
              let t1=getlinkNotes(mvid,3,'&empty;') ;
              atd='<td>'+da1+t1+da2+'</td> \n' ;
            }
        }
        if (dovar=='Links'  ) {
            if (mvid==0) {
               atd='<td>&vellip;</td>';
            } else {
              let t1=getlinkNotes(mvid,2,'&empty;') ;
              atd='<td>'+da1+t1+da2+'</td> \n';
            }
        }
        if (dovar=='descNotes') {
            if (mvid==0) {
               atd='<td>&vellip;</td>'+'\n' ;
            } else {
               let t1=getDescNotes(mvid,true,'&empty; ',true)  ;
               atd='<td>'+da1+t1+da2+'</td> \n' ;
            }
        }
        if (dovar=='firstNote') {
            if (mvid==0) {
               atd='<td>&vellip;</td> \n' ;
            } else {
               let t1=choiceList[mvid]['Notes'];
               atd='<td>'+da1+t1+da2+'</td> \n' ;
            }
        }
        if (atd=='')    {        // not dealt with above: must be a customvar
           if (mvid==0) {            // a break
             atd='<td>&vellip;</td> \n' ;
           } else {
             let t1=(choiceList[mvid].hasOwnProperty(dovar)) ? choiceList[mvid][dovar] : '...';
             atd='<td>'+da1+t1+da2+ '</td> \n' ;
           }
        }

        arow+=atd;   // add this cell

     }          // vars in scheduleShow
     arow+='</tr> \n' ;
     atable+=arow;
  }         // entries
  atable+='</table> \n' ;

  if (nScheErr>0) {
     writeStatusMessage('Warning: '+nScheErr+' '+choiceNameSay2 + ' have been dropped (they were removed).<br>You should rebuild the schedule');
  }
  return atable ;
//  amess+=atable;
//  return amess;


}
 
// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// retrieve current specifications of  schedlue and formatting options

//=======================
// read information from the current schedule table
// return object with   with several single value properties (nBreaks,nChocies) and
// and entries: an array with each row object with the attributes (id, name, etc) of the entry in this row
// and message: a status message.
// ido=2 : just return some status info (do not read entries)

function schedule_readTableRows(ido) {

   let etable=$('#scheduleDivTable');   // read from specification of schedule table (Not formmating of schedule page!)

   let daStuff={'message':'','entries':[],'nBreaks':0,'nChoices':0,'nEmpty':0,
         'startValueAll':0,'endValueAll':0,'defValueUse':0,'defAddBefore':0,'nRows':0} ;

   let aetrTop=etable.find('[name="nscheduleTopRow"]');
   let e0=aetrTop.find('[name="scheduleStartTime"]');
   let startValueAll=e0.attr('data-startValue');

   let aetr=etable.find('.scheduleBottomRow');
   let e1=aetr.find('[name="updateCol"]');
   let endValueAll=e1.attr('data-scheduleval');

   daStuff['startValueAll']=startValueAll ;
   daStuff['endValueAll']=endValueAll;
   daStuff['defValueUse']=scheduleDo_defUseValue(0,0);
   daStuff['defAddBefore']=scheduleDo_readGap(0,0);

   let etrs=etable.find('.scheRow');
   daStuff['nRows']=etrs.length;

   if (ido==2) {              // just get basic stuff
       daStuff['message']=daStuff['nRows']+' rows: start at '+startValueAll+', end at '+daStuff['endValueAll']  ;
       return daStuff;   // just get basic stuff (NOT entries)
   }

   let daEntries=[];
   let nBreaks=0,nChoices=0,nEmpty=0;

   for (i1=0;i1<etrs.length;i1++) {   // read entry data from each row (or skip if empty
       let aetr=$(etrs[i1]);
       let arow=schedule_readTableRow_data(aetr);
       if (arow===false) {
          nEmpty++;
          continue;
       }
       if (arow['isBreak']==1)  {
          nBreaks++;
       } else {
         nChoices++;
       }
       daEntries.push(arow);
   }

   daStuff['entries']=daEntries;
   daStuff['nChoices']=nChoices ;
   daStuff['nBreaks']=nBreaks ;
   daStuff['nEmpty']=nEmpty ;

   if (nBreaks+nChoices==0)  {
      daStuff['message']='There are no entries in the schedule table ' ;
   } else {
      daStuff['message']==nChoices+' recommendations &amp; '+nBreaks+' breaks ';
   }

   return daStuff ;
}
// ===========
// read info from a row
function schedule_readTableRow_data(aetr) {
   let aid=aetr.attr('data-choiceid');
   if (typeof(aid)=='undefined' || parseInt(aid)<0)  return false ;        // empty row

   let isBreak=(aid==0) ? 1 : 0 ;
   let e1=aetr.find('[name="updateCol"]');
   let daMinutes=e1.attr('data-scheduleval');
   let e2=aetr.find('[name="mvName"]');
   let daName=jQuery.trim(e2.text()) ;

   if (daName==='') return false ;        // should never happen.. but if it does its an empty row

   let e3=aetr.find('[name="mvScheduleVarCol"]');
   let daDuration=e3.attr('data-duration');
   let daPause=e3.attr('data-pausebefore');
   let isDefault=e3.attr('data-isdefault');
   let e4=aetr.find('[name="mvShortDesc"]');
   let daDesc=e4.val();
   daDesc=wsurvey.removeAllTags(daDesc);
   daDesc=fixString(daDesc,2);

   let eemph=aetr.find('.schedule_buttonEmphasis');
   let iemph=(eemph.length==0) ?  0 :  1  ;

//   let daDesc=e4.text();
   let rr={'Id':aid,'Name':daName,'isBreak':isBreak,
           'entryValueA':daMinutes,'Duration':daDuration,'Pause':daPause,'useDefaultDuration':isDefault,  // for this entry!
           'Desc':daDesc,'gotEmphasis':iemph};
   return rr;
}

//=======================
// read the current options in the menu of scheduling options
// if not existant, use defaults  (this should never happen)
// returns false if improper html and user did not accept it (did not choose to use plainttext)
// ido is not used

function schedule_formatReadOptions(ifoo) {
  let useOpts;
   if (schedulerType=='time') {
    useOpts={'doAmPm':0,'doShowDays':0,'doElapsed':0,'Header':'','maxHeight':2.5 };   //'alwaysDays':1,
   } else if (schedulerType=='date') {
     useOpts={'doCalendar':1,'doShowWeek':0,'doShowYear':0,'doShowWeekDay':0,'Header':'','maxHeight':2.5 };   //'alwaysDays':1,

   } else if (schedulerType=='quantity') {
     useOpts={'doAddComma':1,'doUseK':0,'doPrefix':'','doPostFix':'','Header':'','maxHeight':2.5 };   //'alwaysDays':1,
   } else if (schedulerType=='order') {
       useOpts={'maxHeight':2.5,'sortAsc':0,'sortDsc':0,'sortNumeric':0,'Header':'' };
   }

   useOpts['vars']={};
   useOpts['varsKeep']={};
   useOpts['colWidths']={};

   for (let zvar in schedulerShow) {            // what  varibles to show in formatted schedule
     useOpts['vars'][zvar]=zvar;
     useOpts['varsKeep'][zvar]=1 ;
   }
// defaults created...
// is the menu available?
  let ebox=$('#mySchedule_format_b');
  if (ebox.length==0) return useOpts ;        // menu not created, so can't read <input> values from it . Use defaults

// menu exists, so read values from input boxes. ... they might be the defaults

  if (schedulerType=='time') {
    let ets=ebox.find('[name="schedule_format_type"]');
    let et1=ets.filter(':checked');
    let tval=et1.val();
    if (tval==2)  useOpts['doAmPm']=1;
    if (tval==3)  useOpts['doElapsed']=1;

    e1= ebox.find('[name="schedule_format_showDays"]');
    useOpts['doShowDays']=(e1.prop('checked')) ? 1  : 0 ;
  }
  if (schedulerType=='date') {
     let e1=ebox.find('[name="schedule_format_calendar"]');
     useOpts['doCalendar']= (e1.prop('checked')) ? 1  :  0 ;
     e1=ebox.find('[name="schedule_format_nthWeek"]');
     useOpts['doShowWeek']= (e1.prop('checked')) ? 1  :  0 ;
     e1=ebox.find('[name="schedule_format_showYear"]');
     useOpts['doShowYear']= (e1.prop('checked')) ? 1  :  0 ;
     e1=ebox.find('[name="schedule_format_dayOfWeek"]');
     useOpts['doShowWeekDay']= (e1.prop('checked')) ? 1  :  0 ;
  }
  
//      useOpts={'doAddComma':1,'doUseK':0,'doPrefix':'','doPostFix':'','Header':'','maxHeight':2.5,};   //'alwaysDays':1,
    if (schedulerType=='quantity') {
     let e1=ebox.find('[name="schedule_format_addComma"]');
       useOpts['doAddComma']= (e1.prop('checked')) ? 1  :  0 ;
     e1=ebox.find('[name="schedule_format_useK"]');
       useOpts['doUseK']= (e1.prop('checked')) ? 1  :  0 ;
     e1=ebox.find('[name="schedule_format_prefix"]');
        useOpts['doPrefix']=wsurvey.removeAllTags(e1.val());
     e1=ebox.find('[name="schedule_format_postfix"]')
        useOpts['doPostFix']=wsurvey.removeAllTags(e1.val());
  }

 if (schedulerType=='order') {   
     let e1=ebox.find('[name="schedule_sortAsc"]');
       useOpts['sortAsc']= (e1.prop('checked')) ? 1  :  0 ;
       e1=ebox.find('[name="schedule_sortDsc"]');
       useOpts['sortDsc']= (e1.prop('checked')) ? 1  :  0 ;
       e1=ebox.find('[name="schedule_numericSort"]');
       useOpts['sortNumeric']= (e1.prop('checked')) ? 1  :  0 ;
  }



  e1=ebox.find('[name="schedule_format_maxHeight"]');
  let maxHeight=e1.val();
  maxHeight=jQuery.trim(maxHeight);
  if (!jQuery.isNumeric(maxHeight) || maxHeight=='' ) maxHeight=2.5;
  maxHeight=parseFloat(maxHeight);
  maxHeight=Math.max(maxHeight,0.10);
  useOpts['maxHeight']=maxHeight;

  e1=ebox.find('[name="schedule_format_Header"]');
  let cmt=jQuery.trim(e1.val());
  let cmt2=wsurvey.makeHtmlSafe(cmt,1);
  if (cmt2[0]==0){
     let q=confirm('Your header contains some improper HTML. Confirm (or Yes) to use a text version; Cancel to reenter');
     if (q==false) return false;
  }
  useOpts['Header']=jQuery.trim(cmt2[1]);

  let ehhs=ebox.find('[name="schedule_headerName"]');
  for (let imm=0;imm<ehhs.length;imm++) {
      let aeh=$(ehhs[imm]);                       // customized column header hame?
      let avar=aeh.attr('data-varname');
      let tval=jQuery.trim(wsurvey.removeAllTags(aeh.val()));
      useOpts['vars'][avar]=tval;

      let eli1=aeh.closest('li');             // keep or drop this column?
      let egoo=eli1.find('[name="schedule_headerKeep"]');
      let iKeep= (egoo.prop('checked')) ? 1 :  0 ;
      useOpts['varsKeep'][avar]=iKeep;
  }

  let ewws=ebox.find('[name="schedule_colWidth"]');
  for (let imm=0;imm<ewws.length;imm++) {
      let aew=$(ewws[imm]);                       // customized column header hame?
      let avar=aew.attr('data-varname');
      let tval=jQuery.trim(aew.val());
      if (!jQuery.isNumeric(tval) || tval<1) tval=aew.attr('data-defwidth');
      useOpts['colWidths'][avar]=tval;
  }

  return useOpts;
}
//===========



//========================
// read the current recommenations (as set using Retrieve Recommdatiosn on the Recommend page,
//  and rebuild list and schedule pages using them
function schedule_readCurrentRecos(ifoo) {
 let alist=makeSchedule_table(1);       // this does it all
 if (alist['list'].length==0)  {  // no current recos
   alert('There are no current recommendations! You can use  \uD83C\uDDF7ecommend to create a set of current recommendations.' );
 }
}

// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//=====================
// misc functions
//==========
// remove all rows in table , and "buttons" in the list
function schedule_removeAll(ii) {
  let etable=$('#scheduleDivTable');
  let eList=$('#scheduleListDiv');
  let etrs=etable.find('.scheRow');
  etrs.remove();

  espans=eList.find('.schedule_listOfReos');
  espans.remove();
  return 1;
}

//==========
// write a message to the "schedule page" alert box
function scheduleAlert(amess) {
    let ealert=$('#schedule_alertBox');
    ealert.html(amess);
    wsurvey.wsShow.show('#schedule_alertBoxOuter' );
    return 1;
}

