9 April 2023

Description of data files used by wsChoicer

wsChoicer uses small data files to store information.
mySql (or some other database) engine might be more efficient, but as of now --   for reasons of portablity 
and ease of setup -- a file based system is used.

  For each project, a seperate set of files is used; and are stored in a submits/ subdirectory under
  data/projecthame.

The files are typically small. There can be hundreds of them, depending on how many suggestions are entered.
And how many ratings, rankings, recommendations, and schedules are entered by the members.

Several file extensions are used, that identify the type of information saved.
These file names have a structure of  fnameTTTT.xxx
   fname : short description of the information. For example: 'rates'.
   TTTT  : a time stamp (to the second)
   .ext  : an extension that identifies the type of informaton saved
   
 The fname is not important -- it can be modified to anything BUT MUST NOT CONTAIN ANY NUMBERS

 The TTTT is important -- is the datestamp of the file creation.  It should NOT be changed.
   For some types of data, Choicer will ONLY use the most recent file (for each member)
   TTTT is used to choose which file to use!
   And NOT the file system time stamp.

 The .ext is important -- it identifies what type of data is in the file. It should NOT be changed.

Some "types" of data are cumulative. That means the information in several files may be combined.
   Thus: older files are combined with newer files.
   In one case, information in newer files can overwrite information in older files (.rte files)
Some types of data are "overwrite". That means only the information in the most recent file is used.
   Thus: older files are ignored.

For all but one type of file: files are specified for a particular username in a particular project. 
The one exception is .cmt (comment) files.


The following extensions are used

.ava  :  Links and info blurbs (cumulative)
         Each file can contain "links and infoBlurbs" for one or several suggestions.
         There can be several .ava files from the same username (in a project). 

.cmt   : General comments (cumulative).
         By project. 
    	 One comment per file
   	 Comment files contain a "username" identifier, which is only used for display purposes.

.ctg   :  Categories  each suggestion is assigned to (overwrite).  
	Each file contains category assignments for one or more suggestions (by suggestion id).
	There may be rows that contain no category.
	And, if new suggestions were added after categories were saved, obviously their ids will  not appear 
        in a .ctg file.

.nte   : Descriptive notes (cumulative)
         Each file can contain notes for one or several suggestions.
         There can be several note files from the same username (in a project). 
 
.rcm   : Recommendations -- current (overwrite). 
         Each file contains a list of the   `current` recommended suggestions.

.rcw   : Recommendations -- draft (overwrite).
         Each file contains a list of the   `draft` recommended suggestions.

.rnk  :  Ranks (overwrite). 
          Each file contains a list of the Top9 and Next9 suggestions.

.rte  :  Rates (cumulative)
          Each file contains ratings for one or more suggestions.
          If a suggestion is rated in more than one file: the rating in the newer file is used (the older one is discarded).
 
.sch   : Schedules (overwrite). 
         Each file contains specifications for a proposed schedule --   the suggestions, their position in the schedule and other 
         timing information, and formatting options.

.sug  :  Add, or modified, suggestions (overwrite)
         Contains information on one or more suggestions.
	 Information includes: suggestion id, name and note fields.   And, other fields for the admin specified customVar variables.
         Each suggestion  has a unique id, but might have the same name!
 	 There are two variants of .sug files
   	    Original entry
	    Modifications of an existing entry (that overwrite information older .sug files). Modifications can only be done by the admin!

The number of "overwrite" files can get long.
   For example, if members frequently modify and tweak recommendations  and schedules.
The admin can use the "cleanup" option (on the admin menu) to get rid of old (hence no longer used) versions of these
files.


