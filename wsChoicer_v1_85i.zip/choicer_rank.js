// make ranking table
// ido=1 -- write entire page
// ido=2 -- reset list of current rankings
function makeRankTable(ido) {

  if (arguments.length<1) ido=1 ;

  if (!allRanks.hasOwnProperty('userTops')) {
     return 1 ;  // this is a call from reset on startup, before info loaded. Ignore (don't ignore if user caused reset (after logon))
  }

// allRanks: ['choiceRanks'=>{},'userTops'=>{},'userNexts'=>{},'trancheList'=>{}];
//     choiceRanks[choiceId][top9 and next9][array of usernames]
//     userTops[username][choiceId]  (value is meaningless -- order of entry
//     userNexts[username][choiceId] (value is meaningless -- order of entry
//     trancheList[choiceId]   values are the summary_rank score (fractional adjustments depend on adjustSummaryRank variable)

  let userTops=allRanks['userTops'];

  let userNexts=allRanks['userNexts'];
  let userDiscards=allRanks['userDiscards'];

  let nRankers=basicStats['nRankers'];
  let nTotalRankings=basicStats['nTotalRankings'];
  let nChoicesRanked=basicStats['nChoicesRanked'];


// ::::     container with clickable  lists of top9 and next9 rankings :::::::::::::::: -->

  let emy=$('#myRankingsListDiv');

// list of id that are noRank;

  let noRankers={},nNoRankers=0;
  for (let ij1 in choiceArray) {   // choiceArray is order of first appearance of NON-removed suggestions
     let aid=choiceArray[ij1 ];
     let asugg=choiceList[aid] ;
     if (asugg['noRankThis']==1) {
        noRankers[aid]=asugg['noRankReason'];
        nNoRankers++;
     }
  }


//  .... make the lists
  let myTop9= (userTops.hasOwnProperty(currentUserName)) ? userTops[currentUserName] : {} ;
  let myTop9A=[],myTop9Hash={};


  nNoRanksFound= (userDiscards.hasOwnProperty(currentUserName)) ? userDiscards[currentUserName] : 0 ;
//  wsurvey.dumpObj(userDiscards,1,currentUserName+' has ' +nNoRanksFound);

  let nMissT=0,nMissN=0;

  for (let acid0 in myTop9) {
      let acid=myTop9[acid0] ;
      if (!choiceList.hasOwnProperty(acid)) {             //    can happen if a removed suggestions
         nMissT++ ;
         continue ;
      }
      if (noRankers.hasOwnProperty(acid)) {          // got classified as noRank sometime after entry
//        nNoRanksFound++;                             //   deprecarted, but keep for now :
        continue ;                        // dont include in top9  or next9
      }

      let cname=choiceList[acid]['Name'];
      let  shortName=jQuery.trim(choiceList[acid]['shortName']);
      let myRanking=1 ;
       sfoo= '<li><span class="cSaveMyRankingsLi"   data-rtype="'+myRanking+'" data-mvid="'+acid+'">'+shortName+'</span></li>';
       myTop9A.push(sfoo);
       myTop9Hash[acid]=acid0;
   }
   let nmyTop9=myTop9A.length;

   let myNext9= (userNexts.hasOwnProperty(currentUserName)) ? userNexts[currentUserName] : {} ;
   let myNext9A=[], myNext9Hash={};
   for (let acid0 in myNext9) {
       acid=myNext9[acid0] ;
       if (!choiceList.hasOwnProperty(acid)) {
          nMissN++ ;
          continue ;
       }
       if (noRankers.hasOwnProperty(acid)) {          // got classified as noRank sometime after entry
//        nNoRanksFound++;                            //   deprecarted, but keep for now :
        continue ;                        // dont include in top9  or next9
      }

       let cname=choiceList[acid]['Name'];
       let  shortName=jQuery.trim(choiceList[acid]['shortName']);
       let myRanking=2 ;
       sfoo= '<li><span class="cSaveMyRankingsLi"  data-rtype="'+myRanking+'" data-mvid="'+acid+'">'+shortName+'</span></li>';
       myNext9A.push(sfoo);
       myNext9Hash[acid]=acid0;
   }
   let nmyNext9=myNext9A.length;

   let sayTop9=myTop9A.join(' ' );       // the full list of choiceids in top9 (useable in a <ul>
   let sayNext9=myNext9A.join(' ' );   // and next 9


//  .... write lists

   let dct=1;      // how to format each choiceName clickable box (height, overflow, etc of the text display)
   if (rankingsLinearMenu=='b') dct=2;
   if (rankingsLinearMenu=='c') dct=3;

   amess='';

   let useLiClass='linearMenu_curRankings'+rankingsLinearMenu ;  // rankingsLinearMenu is global: either  'a' 'b' or 'c'

   amess+='<table rules="rows" cellpadding="2" id="iMyCurrentRankings">  ';

   amess+='<tr><td valign="top" rowspan="3" style="background-color:#f8e393;padding:2px 4px 2px 2px">';
   amess+='<div style="margin:0px 20% 1px 20%;padding:2px">';
   amess+='<button class="cSideButtons"  onClick="changeTableSizeChoiceList(-1)" title="Decrease the height of the list of current rankings"  >&#10196;</button>';
   amess+='<button class="cSideButtons"  onClick="changeTableSizeChoiceList(1)" title="Increase the height of the list current rankings"  >&#10195;</button>';
   amess+='</div>';

   amess+='<div style="margin:3px 3px 2px 4px;padding:2px">';
   amess+='<button  id="isaveMyRankings" class="csaveMyRankings"  class="csaveMyRankings" title="click to save your modified current top and next 9 rankings">';
   amess+='Update!<br> my current<br> rankings </button>';
   amess+='<span style="display:none" id="isaveMyRankingsNope" class="csaveMyRankingsNope">New users can not save changes</span>';
   amess+='</div>';
   amess+='</td>'   ;

   amess+='<td><span style="background-color:white ">Top 9</span>'
   let nfooT9=nmyTop9 ;
   if (nfooT9>=9) nfooT9='all 9';
   let ttA0='Number of suggestions you ranked in your top 9\nClick to compress display of  names \n(click again to cycle through)';

   amess+='<button id="saveMyRankings_top9_button" class="setOlClassButton" data-which="1" data-count="'+dct+'"  title="'+ttA0+'" >';
   amess+=' <span id="saveMyRankings_top9" class="csaveMyRankings_top9"  >'+nfooT9+'</span>';
   amess+='</button>';
   amess+=' </td>';

   amess+='<td><div style="width:70vw">';
   amess+=' <ol name="ishowTop9"  class="'+useLiClass+'" ';
   amess+='  title="Your top9 rankings. Click on a suggestion to highlight, double click to remove " > '+sayTop9+' &nbsp; </ol>';
   amess+='</div></td>';
   amess+='<tr>';
   amess+='<td><span style="background-color:white ">Next 9</span>';
   let nfooN9=nmyNext9 ;
   if (nfooN9>=9) nfooN9='all 9';

   let ttA='Number of suggestions you ranked in your next 9\nClick to compress display of names \n(click again to cycle through)';

   amess+='<button  id="saveMyRankings_next9_button" class="setOlClassButton" data-which="2"  data-count="'+dct+'" title="'+ttA+'" >';
   amess+=' <span id="saveMyRankings_next9" class="csaveMyRankings_next9"  >'+nfooN9+'</span>';
   amess+='</button>';
   amess+='</td>';
   amess+='<td><div style="width:70vw ">';
   amess+='<ol  name="ishowNext9" class="'+useLiClass+'" ';
   amess+='  title="Your next9 rankings.  Click on selection to highlight, double click to remove" >'+sayNext9+' &nbsp; </ol>';

   amess+='</div></td>';
   amess+='</tr><td colspan="2">';
   amess+='  Comment <input type="text" size="80" id="rankingComment" title="optional comment about these rankings">     ';
   amess+='</td></tr></table>';

<!-- misc notes, etc written here -->
   amess+='<div id="viewNotes_rankList" title="notes"   data-usingid="0" xdata-choiceid="0" class="cviewNotes_rankList0"></div>';

   emy.html(amess);  // write to "list of current rankings container"

   if (ido==2)  {  //  reset checkboxes (and name highlging) in table rows  (user requested reset)
      let etrs=$('#theRankingsTable').find('.rankRow');
      for (let im=0;im<etrs.length;im++) {
         let aetr=$(etrs[im]);
         let mvid=aetr.attr('data-choiceid');
         let tdname=aetr.find('.rankTableNameCol');
         tdname.removeClass('crankTableNameColTop9 crankTableNameColNext9 ');
         let myrank=3;
         if (myTop9Hash.hasOwnProperty(mvid)) {
             myrank=1;
             tdname.addClass('crankTableNameColTop9');
         } else if (myNext9Hash.hasOwnProperty(mvid)) {
             myrank=2;
             tdname.addClass('crankTableNameColNext9');
         }
         let tdinputs=aetr.find('.rankTableSelectCol');
         let tdbuttons=tdinputs.find('input');
         tdbuttons.prop('checked',false);
         if (myrank!==3) {
             let tdbA=tdbuttons.filter('[value="'+myrank+'"]');
             tdbA.prop('checked',true);
         }
      }      // for im
      return 1;
   }         // if not 2, write "permanent" header and list of suggestions


// ::::   header stuff  ::::::::::::::::::::::::::

  let amessH='<div >';

  amessH+=' <input type="button" value="&neArr;" title="view ranks in a new window" class="showInNewWindow"  ';
  amessH+='       data-in_new_window_header="Ranking information"  ';
  amessH+='       data-in_new_window_find="#myRankingsListDiv,#rankingsDivTableOuter"> ';

  amessH+='<button class="cHelpButton "  name="helpButtonMain" onclick="wsurvey.wsShow.show(this)"  ';
  amessH+='   title="Help for ranking&#010;Or double click to see the details!"   ';
  amessH+='   data-wsshow="#helpRankingDiv"  data-wsshow_alt="#helpRankingDiv2" >  ';
  amessH+='&#10068;</button> ';

  amessH+='<span class="crankTable_header_1"  >&#8811; Rank suggestions &hellip;</span>  ';
  amessH+=' view &amp; modify ranks, view <tt>summary_ranks</tt>.';

  let dbutton='<button style="margin-left:2em">'+nChoicesRanked+' '+choiceNameSay2+' ranked by  '+nRankers+' people</button>';

  amessH+='<span style="margin:3em 8px 4px 4em"> ';
  amessH+='<button id="isaveMyRankings2" class="csaveMyRankings"   data-dotrigger="#isaveMyRankings"  title="click to save your modified current top and next 9 rankings ...">Update rankings </button> ';
  amessH+='&nbsp;&nbsp;&nbsp;';
  amessH+='<span style="float:right;margin-right:2em">'+dbutton+'</span>';
  amessH+='</span> ';
  amessH+='</div>'
  $('#rankingDivMainHeader').html(amessH);


// ::::     table listing all suggestions, with a column where you can select a ranking    ::: -->

  let amessT='<table  id="theRankingsTable" style="width:90vw"  class="rankingsTable" cellspacing="3" border="1">';

// The table header row ...
  amessT+='<tr class="permRow" > '


// ::: name
  amessT+='<th name="c1"  valign="top" ><span style="font-style:oblique">   ';
  amessT+='<button class="toggleNotesHeaderButton"  >&#9432;</button>';    // :hover used to display title specified in itoggleNotesHeaderButton2 -->
  amessT+='<span id="itoggleNotesHeaderButton2" class="toggleNotesHeaderButton2">Click  &#9432; to display  notes  </span>';
  amessT+=' <span name="choiceNameSay">choice</span> name</span> ';
  amessT+='</th> ';

// :: category
  amessT+='<td name="c1b"  valign="top" >Category</td>  ';

// the zero or more customVar cols
  let gotHiddens=0;
  for (let cvar in customVarList) {
    let vAtt=customVarList[cvar];
    let arequired=vAtt[1];
    if (arequired!=1 && arequired!=11)  {   // only display required columns
       gotHiddens++;                     // might use this later
       continue ;
    }
    amessT+='<td name="customVarCol" valign="top"><span class="customVarColVal">'+cvar+'</span></td>';
  }

// ::: rate" avg and own

  amessT+='<th name="c3c" valign="top" ><em>Avg &Rscr;ate</em> </th>';

  amessT+='<th name="c3b" valign="top" ><em>Your &Rscr;ate</em> </th>';

// ::: chose a rank
  amessT+=' <th  >  ';
  amessT+=' <span  style="border-bottom:1px dotted blue"  ';
  amessT+='        title="Sorting will be by your rankings &#010; ... NOT including changes you may have just made!">Your &real;anks?</span>';
  amessT+=' </th>      ';

  amessT+=' <th  >summary_ rank</th>  ';

// ::: top and next rankings counter
  amessT+='    <th name="rankTableNoteCol" > ';
  amessT+='    <span   title="How many top9, and next9, rankings did this recieve ">Sum of rankings</span> ';
  amessT+=' ';
  amessT+='    </td> ';

// recommendations
  amessT+='<td><span style="border-bottom:1px dashed blue" title="In the retrieved recommendations?">&#127479;eco mend</span></td>';

  amessT+='</tr> ';

  let olUseTop9=emy.find('[name="ishowTop9"]');
  let olUseNext9=emy.find('[name="ishowNext9"]');
  let next9ct=0,top9ct=0;

//  :::::  a tr (row) for each suggestion     :::::::::::::::::::::::::

  for (let ij1 in choiceArray) {   // choiceArray is order of first appearance of NON-removed suggestions

     let aid=choiceArray[ij1 ];
     let asugg=choiceList[aid] ;

     let asubmit=asugg['submitBy'];

     let arow='<tr class="rankRow" data-choiceid="'+asugg['ID']+'">';


// ::::: name
     let  myRanking1=asugg['myRank'];
     let hiClass='';
     if (myRanking1==1) {
         hiClass='crankTableNameColTop9';      // highlight this td to indicate its top9
     } else if (myRanking1==2) {
          hiClass='crankTableNameColNext9';      // highlight this td to indicate its next9
     }

     let shtname=asugg['shortName'].replace(/[\s\,]+/g, "").toLowerCase().substr(0,14) ;

     let shwButton='<button class="choiceReportButton" title="View details ('+shtname+') in a popup  " >&#129534;</button>';
     shwButton+='<button class="rankShowMessage" title="View notes in the `my current rankings` box">&#9432;</button>';

     arow+='<td class="rankTableNameCol '+hiClass+'"><span _sortUse="'+shtname+'" title="Submitted by:'+asubmit+'"> '
     arow+=shwButton ;
     arow+='<span  title="Submitted by:'+asubmit+'\nId='+aid+'">'+asugg['Name']+'</span>';
     arow+='</span>';
     arow+='</td>';

     let catval= (asugg.hasOwnProperty('Category')) ? asugg['Category'] : ' ';     // :: Category
     let shtCat=catval.replace(/[\s]+/g, "").toLowerCase().substr(0,14);         // simplify for sorting purposes
     arow+='<td><span _sortUse="'+shtCat+'" class="categoryInRankTable" >'+catval+'</span></td>';


// ::  zero or more custom vars

     for (let cvar in customVarList) {                                         // ::: zero or more custom cols
       let vAtt=customVarList[cvar];
       let arequired=vAtt[1];
       let ccval= (asugg.hasOwnProperty(cvar)) ? asugg[cvar] : 'n.a.';
       let vsht=fixString(ccval.toLowerCase(),1).substr(0,14);               // simplify for sorting purposes
       if (arequired!=1 && arequired!=11) continue ;                         // don't bother with non-required
       arow+='<td name="customVarCol" ><span _sortUse="'+vsht+'"/>'+ccval+'</td>';
     }

// :::: rate selection, average and own

     let catvalRate= (asugg.hasOwnProperty('Rate')) ? asugg['Rate'] : '';      // :::::: own rate
     let catvalRate2=0;
     if (catvalRate!='') catvalRate2=parseInt(catvalRate);
     if (catvalRate2<0 || catvalRate2>4) catvalRate2=0;  // should never happen

     let avgRate=asugg['avgRate'];
     let navgRate=asugg['navgRate'] ;
     let avgRateUse= (navgRate==0) ? '&nbsp;' : avgRate.toFixed(1);
     let spanavg='<span  class="showTheseRates_inrank" title="average rate (from '+navgRate+' raters) " style="color:#6a6861;">'+avgRateUse+'</span>';
     arow+='<td><span _sortUse="'+avgRate+'">'+spanavg+'</td>';

// :: own
     let sayRate=rateSays[catvalRate2];
     let sayIcon=rateIcons[catvalRate2];
     let sayClass=rateClass[catvalRate2];
     arow+='<td><span  _sortUse="'+catvalRate2+'"  class="'+sayClass+'" title="'+sayRate+'">';
     arow+=sayIcon+ '</span>';
     arow+='</td>';

// :: rank

     noRank=asugg['noRankThis'];
     arow+='<td><div class="rankTableSelectCol">';    // check boxes for top9 or next 9   ------------

     let isTop='',isNext='',myRanking=3,olUse ;
     let  shortName=jQuery.trim(asugg['shortName']);
     if (noRank==1) {                  // no ranking can be imposed AFTER some users have ranked it.
         arow+='<div class="cselectRank_noRank" title="This choice is not subject to ranking!">&#128721; No ranking for this ';
         arow+='  <span name="choiceNameSay">choice</span></em> ';
         arow+='</div>';
         myRanking=0;
     } else {   // ranking allowed -- check if it was rankd (
         myRanking=asugg['myRank'];
         if (myRanking==1) {
             isTop=' checked ';
             olUse=olUseTop9
             top9ct++ ;
          } else if (myRanking==2) {
             isNext=' checked ';
             olUse=olUseNext9 ;
             next9ct++ ;
          }
          arow+=' <label> <input '+isTop+' class="rankCheckbox" type="checkbox" value="1" name="top9">Top 9? </label>';
          arow+=' <label> <input '+isNext+' class="rankCheckbox" type="checkbox" value="2" name="next9">Next 9? </label>';
     }          // norank

     arow+=' <span _sortUse="'+myRanking+'" /> ' ;
     arow+='</div></td>';

// :: summary_rank
    if (noRank==1) {
       arow+='<td><span _sortUse="'+0+'"/> &vellip;</td>';
    } else {
      let smrank=asugg['summary_rank'];
      let rankSay=make_summary_rank_span(aid) ;
      arow+='<td><span _sortUse="'+smrank+'"/>'+rankSay+'</td>';
    }


// :: how  many rankings
    if (noRank==1) {
       let dareason= asugg['noRankReason']  ;
       arow+='<td><span _sortUse="'+0+'"/><em>'+dareason+'</em></td>';
    } else {
      let nTopRank=parseInt(asugg['ntopRank']);
      let nNextRank=parseInt(asugg['nnextRank']);
      nRankBoth= nTopRank + nNextRank ;
      let vfrac= (nRankBoth>0) ?  Math.min(0.99,nTopRank/nRankBoth) : 0 ;
      let vboth=nRankBoth+ vfrac ;

      let rnkgoo='<span name="everyoneRank1" class="ceveryoneRank1"  title="'+nRankBoth+' rankings">';
      rnkgoo+=' Top:  '+nTopRank+' &vellip;  Next: '+nNextRank+'</span>';
      rnkgoo+='<span _sortUse="'+vboth+'" />';
      arow+='<td>'+rnkgoo+'</td>';
    }

// in currently retrieved list of recommendatons?

   let isReco= (asugg.hasOwnProperty('useReco')) ? asugg['useReco'] :  -1 ;
   let recogoo='';
   if (isReco>0) {
     recogoo='<span class="crankTable_inReco" title="In most recently retrieved recommendations">';
     recogoo+='&#9745;&#65039;'+isReco+'</span>';
     recogoo+='<span _sortUse="'+isReco+'" />  ';
   } else {
     recogoo='<span class="crankTable_inReco" title="Not in most recently retrieved recommendations"> </span>';
     recogoo+='<span _sortUse="11111111" />';   // a large number
   }
   arow+='<td class="crankingTable_recoCol"><span class="crankingTable_recoVal">'+recogoo+'</span></td>';


    arow+='</tr>';

     amessT+=arow ;

  }           // this suggestion

  $('#saveMyRankings_top9').html(top9ct);
  $('#saveMyRankings_next9').html(next9ct);

  amessT+='</table>';

  $('#rankingsDivTableOuter').html(amessT);

   let sopts={};                 // add table sort stuff
 //    sopts['skipCols']=[8,9]  ;
//   sopts['rowNumberClass']=1,
   sopts['rowNumberSortableClass']='rankRowNumber',
   sopts['rowNumberSortableIcon'  ]='&Oscr;';
   sopts['sortNumeric']=-1;


   wsurvey.sortTable.init('theRankingsTable',sopts)
   wsurvey.sortTable.rowColors('theRankingsTable',['tan','#dffef4','#f1f8fe' ]);

   let c1= (rankTable_colWidths.hasOwnProperty('sort')) ?  rankTable_colWidths['sort'] : 2 ;
   let c2= (rankTable_colWidths.hasOwnProperty('name')) ?  rankTable_colWidths['name'] : 15 ;
   let c3= (rankTable_colWidths.hasOwnProperty('category')) ?  rankTable_colWidths['category'] : 8 ;
   let c4= (rankTable_colWidths.hasOwnProperty('avgrate')) ?  rankTable_colWidths['avgrate'] : 8 ;
   let c5= (rankTable_colWidths.hasOwnProperty('myrate')) ?  rankTable_colWidths['myrate'] : 15 ;
   let c6= (rankTable_colWidths.hasOwnProperty('doranks')) ?   rankTable_colWidths['doranks'] : 40 ;
   let c7= (rankTable_colWidths.hasOwnProperty('summary_rank')) ?   rankTable_colWidths['summary_rank'] : 40 ;
   let c8= (rankTable_colWidths.hasOwnProperty('allrankings')) ?   rankTable_colWidths['allrankings'] : 40 ;
   let c9= (rankTable_colWidths.hasOwnProperty('recommend')) ?   rankTable_colWidths['recommend'] : 40 ;

   if (!jQuery.isNumeric(c1) || !jQuery.isNumeric(c2) || !jQuery.isNumeric(c3) ||
          !jQuery.isNumeric(c4) ||   !jQuery.isNumeric(c5) || !jQuery.isNumeric(c6) ||
          !jQuery.isNumeric(c7) ||   !jQuery.isNumeric(c8) || !jQuery.isNumeric(c9)
          ) {
       wsurvey.dumpObj(rankTable_colWidths,1,'Bad specification of  rankTable_colWidths') ;
       return 0
    }
    let colWidths=[c1,c2,c3];       // sort button, who, name, category (in ems?)
    for (let avar in  customVarList) {
         let areq=customVarList[avar][1];
          if (areq!=1 && areq!=11) continue  ;        // only show required
         colWidths.push(parseInt(customVarList[avar][0])) ;    // [width,required ]
   }
   colWidths.push(c4);
   colWidths.push(c5) ;
   colWidths.push(c6) ;
   colWidths.push(c7) ;
   colWidths.push(c8) ;
   colWidths.push(c9) ;

   let totwidth=0;
   for (let itt=0;itt<colWidths.length;itt++) totwidth+=parseInt(colWidths[itt]);

   for (let itt=0;itt<colWidths.length;itt++)  {
      let apct=parseInt(100*colWidths[itt]/totwidth);
      colWidths[itt]=apct+'%';
   }
   let foo=wsurvey.sortTable.setTableColWidths('#theRankingsTable',colWidths,0);
   if (foo[0]===false) alert('Rankings table: '+foo[1]);

 let nn=nMissT+nMissN;

 return [nn,nNoRanksFound];

}


///================
// click handler for ratings + page
function clickOnRankings(evt) {
  let atarget=evt.target ;
  let etarget=wsurvey.argJquery(atarget);
  let etag=etarget.prop('tagName').toLowerCase() ;

  let etr=etarget.closest('tr');
  let mvid=etr.attr('data-choiceid');

  if (etarget.hasClass('rankShowMessage')) {   // note use of default <div> around notes
     let q2=writeToNotesBox(mvid,false);
     let mynotes;
     if (q2)    {  // mvid is already being displayed (this is a second click). So don't bother getting notes content
         mynotes='';
     } else {
       mynotes=getDescNotes(mvid,true,'<br/><em>n.a.</em>');     // might be better  to check for "double click" before bothring to get this.
     }
     writeToNotesBox(mvid,mynotes,true,true,true,false)  ;    // write to, or clear, the "notes" box in the currentRankings box
  }

  if (etarget.hasClass('choiceReportButton'))   {     // show report
     let etr=etarget.closest('tr');
     let mvid=etr.attr('data-choiceid');
     displayChoiceReport(mvid,'#theRankingsTable')    ;
     return 1 ;
     

  }        //  ============  choiceReportButton  =============



  if (etarget.hasClass('rankCheckbox')) {   // click on a rank seleciton checkbox
     if (etag=='label') return 1 ;      // the inner input should deal with this
     let rtype=etarget.val();
     doRankSelect(etarget);
     return 1;
  }

// click on a format list (top9 or next9) in myrankings conainter
  if (etarget.hasClass('csaveMyRankings_top9') || etarget.hasClass('csaveMyRankings_next9')
     || etarget.hasClass('setOlClassButton') ) {
     let etarget2=  (etarget.hasClass('setOlClassButton')) ? etarget : etarget.closest('button');
     setOlClass(etarget2);   // could combine these tow
     return 1;
  }

  if (etarget.hasClass('cSaveMyRankingsLi')) {   // click on a choiceName box in my-rankings container
     clickMyRanked(etarget);
     return 1;
  }

  if (etarget.hasClass('csaveMyRankings')) {
      saveRankingsToServer(1);

  }
// ignore


}



// ==================      emt
// a ranking box checked. foo2 is jquery object of button that was clicke
function doRankSelect(foo2) {
   let emyList=$('#myRankingsListDiv');  // where the list of ranked choices (for current user ) is dsipalyed
   let eTable=$('#theRankingsTable');   // where all choices are displayed (and where the checkboxes are)

   let submitButton= $('#isaveMyRankings') ;   // do NOT use isaveMyRankings2 (the 'doTrigger' extra button in the ranking page header
   let ischecked=foo2.prop('checked');
   let whichRank=foo2.val();

   let etr=foo2.closest('tr');
   let mvid=etr.attr('data-choiceid') ;           // id of this choice

   let etdSelectCol=etr.find('.rankTableSelectCol');  // the div with this row's checkboxes (including the one chedked)
   let etdNameCol=etr.find('.rankTableNameCol');   // column (td) of ranking table with choice names

   let gline=choiceList[mvid];                   // choice info
   let choiceName=gline['Name'];
   let whichRankSay,olUse,olCounter,olCounterSpan,hiClass;
   if  (whichRank==1) {           // a top9 checkbox
      whichRankSay='top9'
      olCounter=emyList.find('#saveMyRankings_top9_button');  // button to switch li formats (parent of the span with the current count)
      olCounterSpan=emyList.find('#saveMyRankings_top9');  //  where to write current ocunt
      olUse=emyList.find('[name="ishowTop9"]');      // ol with list of current top9
      hiClass='crankTableNameColTop9';      // highlight this rows name td
   } else  if  (whichRank==2) {         // else  a next 9 checkbox
      whichRankSay='next9'
      olCounter=emyList.find('#saveMyRankings_next9_button');  // button to switch li formats
      olCounterSpan=emyList.find('#saveMyRankings_next9');  //  where to write current ocunt
      olUse=emyList.find('[name="ishowNext9"]');      // ol with list of current top9
      hiClass='crankTableNameColNext9';      // highlight this rows name td
   }              //  other values of whichRank  should never happen

// remove a  selection
   if (!ischecked)  {              // not now checked, but most of been previously checked .. -- remove from list of ranked choices
     let enow=emyList.find('[data-mvid="'+mvid+'"]');   // since can only be in one of top and next, don't need to look seperately
     if (enow.length==0)   {       // SHOULD NOT HAPPEN
       alert('error: could not find '+choiceName+' for removal (list) ');
       return 0;
     }
     let eli=enow.closest('li');  // remove from list
     eli.remove();

     let nowlis=olUse.find('li');   // how many recommendations )(each in own li)
     let lict=nowlis.length;
     olCounterSpan.html(lict) ; // update counter
     olCounter.attr('data-count',lict);

     etdNameCol.removeClass(hiClass);     // unhighlight this row's name column (highlight depends on if next9 or top9
     submitButton.addClass('csaveMyRankingsGo');  // highlight submit button
     $('#isaveMyRankings').addClass('csaveMyRankingsGo');  // signal (in the update button) that rankings have changed

     return 1;
   }        // !ischecked   -- remove from list

// a new selection ... is it allowed?
  if (ischecked) {        // a new selection -- make sure other one is not selected
        let other1=2,str1='next',str2='top';   // assume top9 box was clicked, so next nine ?
        if (whichRank==2) {                     // the next9 box was clicked
          other1=1,str1='top',str2='next';      // so check  the top9 box.
        }
        let ecc=etdSelectCol.find('.rankCheckbox').filter('[value="'+other1+'"]');
        if (ecc.prop('checked')) {
         alert('This choice ('+choiceName+') is in the '+str1+' list. Remove from '+str1+' before ranking in '+str2+' !');
         foo2.prop('checked',false);    // uncheck the checkbox (return to original state)
         return 0;                       // and give up
       }
  }

//   checked, and passed the above  -- so this is an addition
   let mgot=olUse.find('li').length;   // how many recommendations )(each in own li)
   if (mgot >=9) {
      alert('There are '+mgot+' '+choiceNameSay2+' choices ranked in the '+whichRankSay+'\n You can not add this choice\n Unselect a '+whichRankSay+' ranked '+choiceNameSay+' and try again!');
      foo2.prop('checked',false);          // uncheck it
      return 0 ;
   }
   let sadd= '<li><span class="cSaveMyRankingsLi"  data-rtype="'+whichRank+'" data-mvid="'+mvid+'">'+choiceName+'</span></li>';
   olUse.append(sadd);        // add this choice to the displayed list

   let nowlis=olUse.find('li');   // how many recommendations )(each in own li)
   let lict=nowlis.length;
   olCounterSpan.html(lict) ; // update counter
   olCounter.attr('data-count',lict);
   etdNameCol.addClass(hiClass);     // highlight this row's name column (highlight depends on if next9 or top9

   submitButton.addClass('csaveMyRankingsGo');  // highlight submit button

   return 1;

}

//===============
// click on a choice name in the list of currently ranked choices( #myRankingsListDiv')

function clickMyRanked(etarget) {

   let emyList=$('#myRankingsListDiv');  // where the list of ranked choices (for current user ) is dsipalyed
   let clickId=emyList.attr('data-recentclick') ;

   let eTable=$('#theRankingsTable');   // where all choices are displayed (and where the checkboxes are)

   let atype=etarget.wsurvey_attrCi('data-rtype',0);     // top9 or next9? row of table that generated this choice
   let mvid=etarget.attr('data-mvid');
   let achoice=choiceList[mvid];

   let etable1=eTable.find('.rankRow');
   let ex1=etable1.filter('[data-choiceid="'+mvid+'"]');  // the tr with the data-choiceid= mvid
   let etr=ex1.closest('tr');

   if (mvid==clickId) {  // second ...  remove
     etr.removeClass('highlightThis');
     if (atype==1) {                              // uncheck top9 checkbox (on this row)
       let ebox=etr.find('[name="top9"]');
       ebox.trigger('click');                // click the top9 checkbox
     } else {                             // next 9
       let ebox=etr.find('[name="next9"]');
       ebox.trigger('click');               // click the next9 checkbox (on this row)
    }

      etarget.remove();
      let eol=etarget.closest('ol');
      let eolA=eol.find('.cSaveMyRankingsLi')
      let nGots=eolA.length;
      if (atype==1) {
         $('#saveMyRankings_top9').val(nGots);
         $('#saveMyRankings_top9_button').attr('data-count',nGots);
      } else if (atype==2) {
         $('#saveMyRankings_next9').val(nGots);
         $('#saveMyRankings_next9_button').attr('data-count',nGots);
      }

      emyList.attr('data-recentclick',0)  ;
      return 1;
   }

// else first click
   let st1=wsurvey.centerInParent(etr,{'duration':200,'yOffset':30});   // center in rankings table
   if (st1['change']===false) {
        wsurvey.dumpObj(st1,1,'Problem with centerInParent ');  // should never happen
     }

   emyList.attr('data-recentclick',mvid)  ;
   let eolA=etarget.closest('#iMyCurrentRankings');
   let eolAu=eolA.find('.rankingsClick1');
   eolAu.removeClass('rankingsClick1');
   etarget.addClass('rankingsClick1');

   let  egoo=eTable.find('.highlightThis');      // green background on entire row
   egoo.removeClass('highlightThis');            // just this one!
   etr.addClass('highlightThis');

   return 1;


}


// ====================  end of rank click handlers   =================

//=================
// reset ratings inputs
function rankingsReset(athis) {
        makeRankTable(2) ;    // in rankingsReset
}


//===================
// compute rank stuff,
// modifes global basicStats
// uses global  allRanks
//
// relevant fields on basicStats to change
//   nRankers:  number: 0
//   nTotalRankings:  number: 0
//   nChoicesRanked:  number: 0
//   rankerList:  array(0): {

function computeRankStats(ii) {

 let ntotal=0,nRankers=0;
 let rankerList={};
 for (let au in allRanks['userTops']) {
   ntotal+=allRanks['userTops'][au].length;
   if (!rankerList.hasOwnProperty(au)) {
      rankerList[au]=0;
      nRankers++;
   }
   let intop=allRanks['userTops'][au].length;
   rankerList[au]+=intop;

// Now taken care of in getStats.php   if (!membernameList.hasOwnProperty(au))  membernameList[au]={'nsuggest':0,'nrate':0,'nrank':0,'nrecommend':0,'nRankTop':0,'nRankNext':0};
//   membernameList[au]['nrank']+=intop ;
//   membernameList[au]['nRankTop']=intop ;
 }

 for (let au in allRanks['userNexts']) {
   ntotal+=allRanks['userNexts'][au].length;
   if (!rankerList.hasOwnProperty(au)) {
      rankerList[au]=0;
      nRankers++;
   }
   let innext=allRanks['userNexts'][au].length;
   rankerList[au]+=innext ;
 
 }

 basicStats['rankerList']=rankerList;
 basicStats['nRankers']=nRankers ;
 basicStats['nTotalRankings']=ntotal ;

 let nChoicesRanked=0;
 for (let acid in allRanks['choiceRanks'])  {
     let ac1=allRanks['choiceRanks'][acid];
      if  (ac1['top9'].length >0  || ac1['next9'].length >0) nChoicesRanked++;
 }

 basicStats['nChoicesRanked']=nChoicesRanked ;

  return  0 ;
}





//======================
// cycle through how list of top9 and next9 are displayed (Change ol class, which effects formatting of its <li>)
// iwhich : 1=top , 2 = next
// saveMyRankings_top9_button (iwhich=1),     saveMyRankings_next9_button (iwhich=2)
function setOlClass(athis,setTo) {
  if (arguments.length<2) setTo=-1;
  let clist=['','linearMenu_curRankingsa','linearMenu_curRankingsb','linearMenu_curRankingsc'];
  let ethis=wsurvey.argJquery(athis);
  let iwhich=ethis.attr('data-which');
  let ict= (arguments.length<2) ? ethis.attr('data-count') : setTo ;  // mode to set to (setTo: 0 to 2, attr: 1 to 3)
  let doUl;
  if (iwhich==1)  {
      doUl=$('[name="ishowTop9"]');
  } else {
      doUl=$('[name="ishowNext9"]');
  }
  doUl.removeClass('linearMenu_curRankingsa linearMenu_curRankingsb linearMenu_curRankingsc');
  ict++ ;
  if (ict>3) ict=1;
  ethis.attr('data-count',ict);

  let daclass=clist[ict];
  doUl.addClass(daclass);
}


//=====================
// save top and next 9 rankings to the server
function saveRankingsToServer(i) {

 let ddata={};
  let eub=$('#isaveMyRankings') ;

  let emyList=$('#myRankingsListDiv');  // where the list of ranked choices (for current user ) is dsipalyed

  let oof=jQuery.trim($('#rankingComment').val());
  oof= jQuery.trim(fixString(oof,2));  // collapse space to 1 space

  if (!eub.hasClass('csaveMyRankingsGo') && oof==='') {
    writeStatusMessage('You did not change your rankings. ',2,1,1);
    return 0 ;  // no changes
  }


  ddata['theProject']=useProject ;
  ddata['comment']=oof;
  ddata['todo']='saveRanks';
  ddata['username']=currentUserName;  // global

  let ooft=[],oofm=[];
  olUse=emyList.find('[name="ishowTop9"]');      // ol with list of current top9
  let lis=olUse.find('.cSaveMyRankingsLi');
  let top9=[]
  for (let ili=0;ili<lis.length;ili++) {
     let eli1=$(lis[ili]);
     let aaid=eli1.attr('data-mvid') ;
     top9.push(aaid);
  }
  let olUse2=emyList.find('[name="ishowNext9"]');      // ol with list of current top9
  let lis2=olUse2.find('.cSaveMyRankingsLi');
  let next9=[]
  for (let ili=0;ili<lis2.length;ili++) {
     let eli1=$(lis2[ili]);
     let aaid=eli1.attr('data-mvid') ;
     next9.push(aaid);
  }
  ddata['top9']=top9;
  ddata['next9']=next9;


  $.ajax({
        url: 'choicer_ranks.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function (response) {

       if (typeof(response)!='string') {
          wsurvey.dumpObj(response,1,'Problem submitting ranks ');
       } else {
          saveRankingsToServer2(response) ;
       }
    });

}

function saveRankingsToServer2(response) {    // note that reload will clear rankings
  let rrs=$('.csaveMyRankings');
  rrs.prop('checked',false);     // saved, so un
  
  let eub=$('#isaveMyRankings') ;
  eub.removeClass('csaveMyRankingsGo') ;  // to discourage resubmitting unncessarily

  amess=response;
  amess+='<br><button title="click to reload" onclick="doReload()">Reload </button> to see the revised rankings';
   window.scrollTo(0, 0);   // top of screen..

  writeStatusMessage(amess,2,0,1);   // auto show this
}

