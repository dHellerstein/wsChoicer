<?php
// admin: edit  with schedule  page.

session_start() ;
ob_start();

$curDir=getcwd();

$url = $_SERVER['REQUEST_URI']; //returns the current URL
$parts = explode('/',$url);
//$dir = $_SERVER['SERVER_NAME'];
$rootSel='';
for ($i = 0; $i < count($parts) - 1; $i++) {
 $rootSel .= $parts[$i] . "/";
}

$pwdfile=$curDir.'/params/choicer_init.php';      // get adminPwd
require_once($pwdfile);

// a bit of security   (redundant with js check, so not needed for most situations)
$theAdminPassword=$_REQUEST['pwd'];
$tMd5=md5($theAdminPassword) ;
if ($tMd5!=$adminPwd) {
     $amess="Incorrect admin password";
     ob_end_clean();   // remove prints and other crap
     $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
     print $vsuggests;
     exit;
}

// add some php functions

$libfile=$curDir.'/choicer_lib.php';
require_once($libfile);


$useProject= (isset($_REQUEST['theProject'])) ? $_REQUEST['theProject'] : false;


$todo=$_REQUEST['todo'];

if ($todo!='createProject' && $todo!='copyParameters'  && $todo!='projectList'  )  {
  $paramsFile=$curDir.'/data/'.$useProject.'/params/choicer_params.php';   // customVars, etc ...
  if (!file_exists($paramsFile)) {
    ob_end_clean();   // remove prints and other crap
    $amess="Error createProject: missing parameters file: $paramsFile ";
    $stuff=['error'=>$amess];
   $vsuggests=json_encode($stuff, JSON_UNESCAPED_UNICODE);  // encode for web transmission
   print $vsuggests;
   exit;
  }

  require($paramsFile);
}


 if ($todo=='modify') {
     doModifySuggestions($useProject);
     exit;
  }
  if ($todo=='adminSave') {
     saveJsHtml($useProject);
     exit;
  }

  if ($todo=='getPubs') {
    goGetPubs($useProject);
  }

  if ($todo=='saveParams') {
    saveParams($useProject);
  }

  if ($todo=='displayPubs') {
    goDisplayPubs($useProject);
  }

  if ($todo=='createProject') {
    goCreateProject(1);
  }

  if ($todo=='copyParameters') {
    goCopyParameters(1);
  }

  if ($todo=='delPubs') {
    delPublish($useProject);
  }

  if ($todo=='cleanup') {
    doCleanup($useProject);
  }

  if ($todo=='cleanupDel') {
    doCleanupDel($useProject);
  }

 if ($todo=='zipSubmits') {
    doZipSubmits($useProject);
  }

 if ($todo=='zipSubmitsGo') {
    doZipSubmitsGo($useProject);
 }

 if ($todo=='projectList') {
    doProjectList($useProject);
  }


// do this here (since it uses the stuff in the included choicer_params.php
  if ($todo=='getVars') {
    $varlist=['checkValidNames','validNames','downloadUsers','privateDownloadLink',
      'customVars','customVarsLength','customVarsRequired','customSchedulerVar','customSchedulerDefault',
      'schedulerType','schedulerShow','schedulerNoShow','scheduleTopHeader',
      'siteIntro'
     ];

     $davars=[];
     foreach ($varlist as $ii=>$vname) {
        $davars[$vname]=$$vname;
     }
     ob_end_clean();   // remove prints and other crap
     $vsuggests=json_encode($davars, JSON_UNESCAPED_UNICODE);  // encode for web transmission
     print $vsuggests;
     exit;
  }


  exit;

//=============
// modify suggestions
function doModifySuggestions($useProject) {

  $changes=$_REQUEST['changes'];
  $atime=time();
  $theDate=date("Y-m-d H:i") ;
   $curDir=getcwd();

   $fp=fopen($curDir.'/data/'.$useProject.'/submits/sug'.$atime.'.sug','a');

  $amess=';suggestion file (revision) @ '.$theDate."\n";
  $amess.="username: admin \n";
  $amess.="date: $atime \n";
  $nchanged=0;
  foreach ($changes as $mvid=>$vlist) {
     $amess.="\n";
     $amess.="id: $mvid \n";
     $awho=$vlist['Who'] ;
     $amess.="submitBy: $awho \n";
     $amess.="modifiedBy: admin \n";
     $nchanged++;
     foreach ($vlist as $avar=>$aval) {
         $avar2=trim($avar);
         if ($avar2=='Who') continue ;    // dealt with above
         $qq=checkValidHtml($aval);                // this is done on the js side, but wth
         if ($qq!==true) $aval=strip_tags($aval,'<br><p>');       // no error message, just strip tags
         $str = preg_replace( "/\s+/", " ", $aval ) ;
         $amess.="$avar2:  $str \n";
     }
  }

  fwrite($fp,$amess."\n\n");    // modified .sug file
  fclose($fp);
  removeCacheFile($useProject);  // remove the .csh file


  $bmess="Modifications to suggestions: ". $nchanged ."   saved (@ $atime).  ";

   ob_end_clean();   // remove prints and other crap
   $tt=[];
   $tt['message']=$bmess;
   $tt['okay']=1;
  $vsuggests=json_encode($tt, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;

}

//================
// save .js and .hmtl file to publish/  -- as submitted by admin
//   let ddata={'mname':aname,'comment':acmt,'fname':fname,'htmlStuff':ddataHtml,'jsonStuff':ddataJson,'todo':'adminSave'}  ;
function saveJsHtml($useProject) {

 global $scheduleTopHeader,$rootSel;

  $atitle=$_REQUEST['title'];

  $atime=time();
  $theDate=date("Y-m-d H:i") ;
   $curDir=getcwd();

  $awho=$_REQUEST['mname'];
  $acomment= strtolower(trim(preg_replace("/\s+/", " ", $_REQUEST['comment'])));  // overkill but wth
  $afilename=trim($_REQUEST['fname']);
  $jsData=$_REQUEST['jsonStuff']  ;

// the .js
  $jsStuff=saveJsHtml_js($jsData,$awho,$theDate,$afilename,$acomment,$atitle) ;
  $curDir=getcwd();

  $useFileJsBase=pathinfo($afilename, PATHINFO_FILENAME).'.js' ;
  $useFileJs=$curDir.'/data/'.$useProject.'/publish/'.$useFileJsBase ;
  $useSelJs= 'data/'.$useProject.'/publish/'.$useFileJsBase ;

  $fp=fopen($useFileJs,'w');
  $njs=fwrite($fp,$jsStuff."\n\n");     // .js file in publish
  fclose($fp);
 removeCacheFile($useProject);  // remove the .csh file

// now the html
  $htmlData=$_REQUEST['htmlStuff']  ;

  $htmlStuff=goMakeHtml($htmlData,$scheduleTopHeader,1,$rootSel,$atitle)  ;

  $useFileHtmlBase=pathinfo($afilename, PATHINFO_FILENAME).'.html' ;
  $useFileHtml=$curDir.'/data/'.$useProject.'/publish/'.$useFileHtmlBase ;

  $useSelHtml= 'data/'.$useProject.'/publish/'.$useFileHtmlBase ;


  $fp2=fopen($useFileHtml,'w');
  $nhtml=fwrite($fp2,$htmlStuff."\n\n");  // .html file in publish
  fclose($fp2);
 removeCacheFile($useProject);  // remove the .csh file

  $bmess=" $useFileJs saved ($njs bytes) | $useFileHtml saved ($nhtml bytes)  ";

// a .pub file
  $amess=";html and js publish \n";
  $amess.="; $atime \n";
  $amess.="Date: $theDate \n" ;
  $amess.="Comment: $acomment \n";
  $amess.="Type: ".$jsData['schedulerType']."\n";
  $amess.='Html: '.$useSelHtml."\n";
  $amess.='Js: '.$useSelJs."\n";

  $useFilePub=pathinfo($afilename, PATHINFO_FILENAME) ;
  $useFilePub=$curDir.'/data/'.$useProject.'/publish/publish_'.$atime.'.pub';

  $fp=fopen($useFilePub,'w');
  fwrite($fp,$amess);                   // .pub file in publish
  fclose($fp);
 removeCacheFile($useProject);  // remove the .csh file


  ob_end_clean();   // remove prints and other crap
  $tt=[];
  $tt['message']=$bmess;
  $tt['okay']=1;
  $vsuggests=json_encode($tt, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;

}

function saveJsHtml_js($arr,$awho,$atime,$afilename,$acomment) {

  $amess="// json save of schedule from $awho @ $atime \n";
  $amess.="// comment: $acomment \n";
  $amess.='if (typeof(choicerSaves)=="undefined") choicerSaves={} ; '. "\n";
  $amess.="choicerSaves['$afilename']={} \n";
  $amess.="choicerSaves['$afilename']['who']='".$arr['who']."' ;\n";
  $amess.="choicerSaves['$afilename']['acomment']='".$arr['comment']."' ;\n";
  $amess.="choicerSaves['$afilename']['header']='".$arr['header']."' ;\n";
  $amess.="choicerSaves['$afilename']['keycode']='". $arr['keycode']."' ; \n";
  $amess.="choicerSaves['$afilename']['scheduleVar']='". $arr['scheduleVar']."' ; \n";
  $amess.="choicerSaves['$afilename']['schedulerType']='". $arr['schedulerType']."' ; \n";

  $dalinks=json_encode($arr['linkIcons'], JSON_UNESCAPED_UNICODE);
  if (!array_key_exists('recosUsed',$arr)) {
      $darecosUsed=='{}';
  } else {
     $darecosUsed=json_encode($arr['recosUsed'], JSON_UNESCAPED_UNICODE);
     $darecosUsed="JSON.parse('".$darecosUsed."')  ";
  }
  if (!array_key_exists('recosNotUsed',$arr)) {
      $darecosNotUsed='{}';
  } else {
     $darecosNotUsed=json_encode($arr['recosNotUsed'], JSON_UNESCAPED_UNICODE);
     $darecosNotUsed="JSON.parse('".$darecosNotUsed."')  ";
  }

  $darecoData=json_encode($arr['recoData'], JSON_UNESCAPED_UNICODE);
  $daschedule=json_encode($arr['schedule'], JSON_UNESCAPED_UNICODE);

  $amess.="choicerSaves['".$afilename."']['linkIcons']=JSON.parse('".$dalinks."') ;\n";
  $amess.="choicerSaves['".$afilename."']['recosUsed']=".$darecosUsed." ;\n";
  $amess.="choicerSaves['".$afilename."']['recosNotUsed']=".$darecosNotUsed." ;\n";

  $amess.="choicerSaves['".$afilename."']['recoData']=JSON.parse('".$darecoData."') ;\n";
  $amess.="choicerSaves['".$afilename."']['schedule']=JSON.parse('".$daschedule."') ;\n";

  return $amess;
}


//============================
// return selectable list of publications (to be displayed on home page
function goGetPubs($useProject) {

  $aext='pub';
  $curDir=getcwd();
  $basedir=$curDir.'/data/'.$useProject.'/publish';
  $flist=getFileByType_all($aext,"",$basedir) ;
 // $basesel='data/'.$useProject.'/publish';
  $amess='';
  $pubGot=[];

  foreach ($flist as $ii=>$afile2) {

     $afile=$afile2[0];
     $fnameBase=pathinfo($afile, PATHINFO_FILENAME);
     $fnameTime=$afile2[1];

    $oof=file_get_contents($afile);
    $fnameDate=date('Y-M-d:H:i',$fnameTime);

    $alines =explode("\n",$oof);

    $ado='';$saveDate='';$aComment='';$aHtml='';$aJs='';
    for ($iline=0;$iline<count($alines);$iline++) {     // look for username before first empty line . might be 'admin' (if this is a modification file)
      $astuff=$alines[$iline];
      $jline=$iline;

      $bline=trim($astuff);
      if (substr($bline,0,1)==';') continue ;
      if ($bline=='') break ;       // end of section
      $vv2=explode(':',$bline,2);
      $ado=trim($vv2[0]);

      if ($ado=='Date') {
         $saveDate=trim($vv2[1]);
         continue;
      }
      if ($ado=='Comment') {
         $aComment=trim($vv2[1]);
         continue;
      }
      if ($ado=='Type') {
         $aType=trim($vv2[1]);
         continue;
      }
      if ($ado=='Html') {
         $aHtml=trim($vv2[1]);
         continue;
      }
      if ($ado=='Js') {
         $aJs=trim($vv2[1]);
         continue;
      }


    }    // lines
    $t1=['Filename'=>$fnameBase,'Date'=>$saveDate,'Comment'=>$aComment,'Type'=>$aType,'Html'=>$aHtml,'Js'=>$aJs];
    $pubGot[]=$t1;
  }     // file

  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($pubGot, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;


  exit;

}

///===========
// update List of publish schedules to display ...
function goDisplayPubs($useProject) {
   $atime=time();
  $theDate=date("Y-m-d H:i") ;

  $hdrMessage=trim($_REQUEST['message']);
  $daList=$_REQUEST['list'];
  if ($daList==='')  { // message only
    if (trim($hdrMessage)!='') {
      $amess="<!-- what to display on the main page (the  view published stuff ). Updated  $theDate --> \n ";
      $amess.='<span class="cmainPage_listOfSchedules_or"> ... </span> '."\n";
      $amess.=' <div class="cmainPage_listOfSchedules"  >'."\n";
      $amess.=$hdrMessage."\n".$daList;
      $amess.="\n</div>\n";
      $amess.='<br clear="all" />'."\n";
    }   else {     // no message -- than nothing to show
        $amess="<!-- what to display on the main page (the  view published stuff ). Suppressed  $theDate --> \n ";
    }

 } else {
   $amess.='<span class="cmainPage_listOfSchedules_or">or ... </span> '."\n";
   $amess.=' <div class="cmainPage_listOfSchedules"  >'."\n";
   $amess.=$hdrMessage."\n".$daList;
   $amess.="\n</div>\n";
   $amess.='<br clear="all" />'."\n";
 }
$curDir=getcwd();

 $fp=fopen($curDir.'/data/'.$useProject.'/params/choicer_viewPublish.html','w');  // overwrite
 $nb=fwrite($fp,$amess."\n\n");               //    choicer_viewPublish.html in params
 fclose($fp);
 removeCacheFile($useProject);  // remove the .csh file

  $say1="List of displayed <u>published</u> schedules ...  has been updated ($nb bytes) ";
  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($say1, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;

  exit;

}

//=============
// return array of the variables in choicer_params.php
function saveParams($useProject) {

  $phpVars=$_REQUEST['phpVars'];
  $jsVars=$_REQUEST['jsVars'];
  $customSchedulerVar=$_REQUEST['customSchedulerVar'];
  $customVars=$_REQUEST['customVars'];
  $schedulerVars=$_REQUEST['schedulerVars'];
  $validNames=$_REQUEST['validNames'];
  $downloadUsers=$_REQUEST['downloadUsers'];
  $siteIntro=$_REQUEST['siteIntro'];

// write the choicer_params.js file
// first rename old one to choicer_params_prior.js
  $curDir=getcwd();

  $jsfile=$curDir.'/data/'.$useProject.'/params/choicer_params.js';   // customVars, etc ...

//  $jsfile=$curDir.'/params/choicer_params.js';
  if (file_exists($jsfile)) {
  $jsFileBack=$curDir.'/data/'.$useProject.'/params/choicer_params_prior.js';   // customVars, etc ...
//     $jsFileBack=$curDir.'/params/choicer_params_prior.js';
     if (file_exists($jsFileBack)) unlink($jsFileBack);
     $q1=rename($jsfile,$jsFileBack);
  }

// and the choicer_params.php file
// first rename old one to choicer_params_prior.js


  $phpfile=$curDir.'/data/'.$useProject.'/params/choicer_params.php';   // customVars, etc ...
//  $phpfile=$curDir.'/params/choicer_params.php';
  if (file_exists($phpfile)) {
    $phpfileBack=$curDir.'/data/'.$useProject.'/params/choicer_params_prior.php';   // customVars, etc ...
//     $phpfileBack=$curDir.'/params/choicer_params_prior.php';
      if (file_exists($phpfileBack)) unlink($phpfileBack);
     $q1=rename($phpfile,$phpfileBack);
  }

  $atime=time();
  $theDate=date("Y-m-d H:i") ;

  $quote="'";  // use in string replaces
  $arf='\\'.$quote ;

  $amess="// choicer_params : javascript parameters. Created $theDate  \n ";
  foreach ($jsVars as $avar=>$aval ) {
    $quote="'";
    $arf='\\'.$quote ;
    $aval2=str_replace("'",$arf,$aval);
    $a1=$avar."='".$aval2."' ; \n ";
    $amess.=$a1;
  }
  $amess.="\n";
  $amess.="// DO NOT CHANGE BELOW HERE \n ";
  $amess.="var choicerParams_read=1  \n \n ";

  $fp=fopen($jsfile,'w');
  $nbytes=fwrite($fp,$amess."\n\n");        // jsfile in params
  fclose($fp);
 removeCacheFile($useProject);  // remove the .csh file


// now the php
   $pmess="<?php \n";
   $pmess.="// choicer_params : php parameters. Created $theDate  \n ";

// general
   foreach ($phpVars as $avar=>$aval ) {
      $aval2=str_replace("'",$arf,$aval);
      $a1='$'.$avar."='".$aval2."' ; \n ";
      $pmess.=$a1;
    }
    $pmess.='$customSchedulerVar=\''.$customSchedulerVar.'\' ; '."\n ";

// validnames
   $pmess.="\n";
   $pmess.='$validNames=[] ; '."\n";
   foreach ($validNames as $anick=>$amember) {
        $zz1='$validNames[\''.$anick.'\']=\''.$amember.'\' ; '."\n";
        $pmess.=$zz1;
   }

// downloadUsers
   $pmess.="\n";
   $pmess.='$downloadUsers=[] ; '."\n";
   foreach ($downloadUsers as $amember=>$doallow) {
        $zz1='$downloadUsers[\''.$amember.'\']=\''.$doallow.'\' ; '."\n";
        $pmess.=$zz1;
   }

// scheduleVars
   $pmess.="\n";
   $pmess.='$schedulerShow=[] ; '."\n";
   $daNoShows=[];
   foreach ($schedulerVars as $avar=>$a1) {
       $alength=$a1['length'];
       if ($a1['noShow']==1) $daNoShows[]=$avar;
        $zz1='$schedulerShow[\''.$avar.'\']=\''.$alength.'\' ; '."\n";
        $pmess.=$zz1;
   }
   $pmess.="\n";
   $pmess.='$schedulerNoShow=\''.implode(',',$daNoShows).'\' ; '."\n";

// customVarsRequired   customVarsLength   customVars

   $pmess.="\n";
   $pmess.='$customVars=[] ; '."\n";
   $pmess.='$customVarsLength=[] ; '."\n";
   $pmess.='$customVarsRequired=[] ; '."\n";

   foreach ($customVars as $avar=>$a1) {
       $adesc=$a1['desc'];
       $adesc=str_replace($quote,$arf,$adesc);
       $alength=$a1['length'];
       $arequired=$a1['required'];
       $zz1='$customVars[\''.$avar.'\']=\''.$adesc.'\' ; '."\n";
       $zz1.='   $customVarsRequired[\''.$avar.'\']=\''.$arequired.'\' ; '."\n";
       $zz1.='   $customVarsLength[\''.$avar.'\']=\''.$alength.'\' ; '."\n";
       $pmess.=$zz1;
   }

// Intro
   $pmess.="\n";
   $siteIntro=str_replace($quote,$arf,$siteIntro);


   $pmess.='$siteIntro= \'';
   $pmess.=$siteIntro;
   $pmess.="\n";
   $pmess.='\' ; '."\n";

   $pmess.="?> \n ";

  $fp=fopen($phpfile,'w');
  $nbytes2=fwrite($fp,$pmess."\n\n");   // php file in params
  fclose($fp);
 removeCacheFile($useProject);  // remove the .csh file

  $smess="$jsfile updated ($nbytes bytes)    ";
  $smess.="<br>$phpfile updated ($nbytes2 bytes) ";
  $smess.="<br>(@ $theDate)";

   ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($smess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;

}



//====================
// create a project

function goCreateProject($a1) {
  $aname=$_REQUEST['name'];

  $iwords=str_word_count($aname,1,'0..9_-');

  if (count($iwords)!=1) {
     $amess="Sorry: the project name must be a single word (<tt>$aname</tt> ... ".count($iwords);
      $amess.='<br><tt>'.implode(' | ',$iwords)  ;
     ob_end_clean();   // remove prints and other crap
     $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
     print $vsuggests;
     exit;
  }

  $adesc=strip_tags($_REQUEST['desc']);
  $created=strip_tags($_REQUEST['created']);

  $curDir=getcwd();
  $d1=$curDir.'/data/'.$aname;

  if (is_dir($d1)) {
     $amess="Sorry: this project already exists (<tt>$d1</tt>)";
     ob_end_clean();   // remove prints and other crap
     $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
     print $vsuggests;
     exit;
  }
   $q1=mkdir($d1);
   if (!$q1) {
     $amess="Error: unable to create directory:(<tt>$d1</tt>)";
     ob_end_clean();   // remove prints and other crap
     $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
     print $vsuggests;
     exit;
   }

  $d2=$curDir.'/data/'.$aname.'/params';
   $q2=mkdir($d2);
  $d3=$curDir.'/data/'.$aname.'/publish';
   $q3=mkdir($d3);

  $d4=$curDir.'/data/'.$aname.'/submits';
   $q4=mkdir($d4);
  $d4a=$curDir.'/data/'.$aname.'/submits/backup';
   $q4a=mkdir($d4a);

  $d5=$curDir.'/data/'.$aname.'/cache';
   $q5=mkdir($d5);

  if (!$q2 || !$q3 || !$q4 || !$q5) {
     $amess="Error: unable to create a sub directory: params=$q2, publish=$q3, submits=$q4, submits/backup=$q4a, cache=$q5 (in <tt>$d1</tt>)";
     ob_end_clean();   // remove prints and other crap
     $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
     print $vsuggests;
     exit;
   }

   $ainit="created: $created \n";
   $ainit.="comment: $adesc \n ";

   $dinit=$curDir.'/data/'.$aname.'/init.txt';

   $fp=fopen($dinit,'w');
   $nbytes=fwrite($fp,$ainit );     // init.txt file in project root
   fclose($fp);
// removeCacheFile($useProject);  // project just crated -- no need to remove .csh file!


  $amess="Project created: <tt>$aname</tt> <em>$adesc</em> @ $created ";
  $amess.='<br><button data-pname="'.$aname.'" onClick="admin_project_3(this)" title="Create default parameter files">Create <tt>default</tt> parameter files</button>';
  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;
}

//==============================
function goCopyParameters($a1) {
  $aname=$_REQUEST['name'];
  $iwords=str_word_count($aname,1,'0..9_-');

  if (count($iwords)!=1) {
     $amess="Sorry: project name must be a single word (<tt>$aname</tt>)";
     ob_end_clean();   // remove prints and other crap
     $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
     print $vsuggests;
     exit;
  }

  $curDir=getcwd();

  $d1=$curDir.'/data/'.$aname.'/params';
  if (!is_dir($d1)) {
     $amess="Sorry: this project does not exist (<tt>$d1</tt>)";
     ob_end_clean();   // remove prints and other crap
     $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
     print $vsuggests;
     exit;
  }

  $paramsDir=$curDir.'/params';

  $errs=[];
  $jsFile =$paramsDir.'/choicer_params_orig.js';
  $origJs=file_get_contents($jsFile);
    if ($origJs===false) $errs[]=":: No original (js) parameters file: $jsFile";

  $phpFile =$paramsDir.'/choicer_params_orig.php';
  $origPhp=file_get_contents($phpFile);
     if ($origPhp===false) $errs[]="No original (php) parameters file: $phpFile";

  $pwdFile=$paramsDir.'/choicer_passwords_orig.php';
  $origPwd=file_get_contents($pwdFile);
     if ($origPwd===false) $errs[]="No original (password) parameters file: $pwdFile";

  if (count($errs)>0) {
     $amess=implode('<br>',$errs);
     ob_end_clean();   // remove prints and other crap
     $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
     print $vsuggests;
     exit;
  }

  $newJsFile=$d1.'/choicer_params.js';
  $qnJs= file_put_contents($newJsFile,$origJs);
  if ($qnJs===false) $errs[]="Unable to save (js) parameters file: $newJsFile";

  $newPhpFile=$d1.'/choicer_params.php';
  $qnPhp= file_put_contents($newPhpFile,$origPhp);
  if ($qnPhp===false) $errs[]="Unable to save (php) parameters file: $newPhpFile";

  $newPwdFile=$d1.'/choicer_passwords.php';
  $qnPwd= file_put_contents($newPwdFile,$origPwd);
  if ($qnPwd===false) $errs[]="Unable to save (passwords) parameters file: $newPwdFile";

 removeCacheFile($aname);  // remove the .csh file

  if (!$qnJs || !$qnPhp || !$qnPwd) {
     $amess=implode('<br>',$errs);
     ob_end_clean();   // remove prints and other crap
     $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
     print $vsuggests;
     exit;
  }

  $amess='Default versions of parameter files created for project <tt>'.$aname.'</tt> in <tt>'.$d1.'</tt>  ';
  $amess.="<br>";
  $amess.='<button onclick="admin_project_4(this)" data-pname="'.$aname.'" class="pointerCursor">Specify the parameters</button> ';
     ob_end_clean();   // remove prints and other crap
     $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
     print $vsuggests;
     exit;

}

//================
// delete published scheduels.
function delPublish($useProject) {

  $curDir=getcwd();
  $d1=$curDir.'/data/'.$useProject.'/publish';
  if (!is_dir($d1)) {          // shoule never happen
     $dd=['error'=>'No such `publish` directory: '.$d1];
     ob_end_clean();   // remove prints and other crap
     $vsuggests=json_encode($dd, JSON_UNESCAPED_UNICODE);  // encode for web transmission
     print $vsuggests;
     exit;
  }
  $dels=$_REQUEST['list'];
  $errs=[];
  $dones=[];
  foreach ($dels as $ii=>$afile) {
      $d2=$d1.'/'.$afile.'.pub';
      if (!file_exists($d2)) {
         $errs[]='No such .pub file: '.$afile;
         continue;
      }
      $arf=file_get_contents($d2);
      $alines=explode("\n",$arf);
      $htmlFile=false;
      $jsFile=false;
      foreach ($alines as $i2=>$bline) {
         $bline=trim($bline);
         if ($bline=='') continue;
         if ($bline.substr(0,1)==';') continue;
         $vv2=explode(':',$bline,2);
         $ado=trim($vv2[0]);
         if ($ado=='Html') $htmlFile=trim($vv2[1]);
         if ($ado=='Js') $jsFile=trim($vv2[1]);
      }

      $qdel=unlink($d2);
      if ($qdel) {                 // the .pub file
          $dones[]='Deleted: '.$d2;
      } else {
          $errs[]='Unable to delete : '.$d2;
      }

      if ($htmlFile!==false) {      // the .html file associated with this .pub file
          $dHtml=$curDir.'/'.$htmlFile;
          if (file_exists($dHtml)) {
            $qdel=unlink($dHtml);
            if ($qdel) {
               $dones[]='Deleted: '.$htmlFile;
            } else {
               $errs[]='Unable to delete : '.$htmlFile;
            }
          }           // don't bother if no such file
      }
      if ($jsFile!==false) {          // the .js file associated with this .pub file
          $dJs=$curDir.'/'.$jsFile;
          if (file_exists($dJs)) {
            $qdel=unlink($dJs);
            if ($qdel) {
               $dones[]='Deleted: '.$jsFile;
            } else {
               $errs[]='Unable to delete : '.$jsFile;
            }
          }           // don't bother if no such file
      }
   }   // next one

   $dd=[];
   $dd['fails']=$errs;
   $dd['okays']=$dones;
   ob_end_clean();   // remove prints and other crap
   $vsuggests=json_encode($dd, JSON_UNESCAPED_UNICODE);  // encode for web transmission
   print $vsuggests;
   exit;
}

//==================================
// cleanup files in submits/
// remove old verions (by user/project) of  .ctg,   rnk  rcm   rcw   sch
// step 1: report what would be removed  and retained (and errors)

function doCleanup($useProject) {

   $doDels=[];
   $doErrs=[];
   $doRetains=[];

//   $useFilesCtg=getFileByType('ctg','*',$useProject );    // get most recent .ctg file for all users
   doCleanup_get('ctg',$useProject,$doDels,$doErrs,$doRetains) ;
   doCleanup_get('rnk',$useProject,$doDels,$doErrs,$doRetains) ;
   doCleanup_get('rcm',$useProject,$doDels,$doErrs,$doRetains) ;
   doCleanup_get('rcw',$useProject,$doDels,$doErrs,$doRetains) ;
   doCleanup_get('sch',$useProject,$doDels,$doErrs,$doRetains) ;

// csh files
   $curDir=getcwd();
   $cshDir=$curDir.'/data/'.$useProject.'/cache';
   $dafiles=$cshDir.'/*.csh';
   $goo=glob($dafiles);
   foreach ($goo as $i1=>$afile) {
     $doDels[]=$afile;
   }

   $dd=[];
   $dd['Retains']=$doRetains;
   $dd['Dels']=$doDels;
   $dd['Errs']=$doErrs;

   ob_end_clean();   // remove prints and other crap
   $vsuggests=json_encode($dd, JSON_UNESCAPED_UNICODE);  // encode for web transmission
   print $vsuggests;

   exit;
}

//=======
// do a cleanup
function doCleanupDel($useProject) {

   $doDels=[];
   $doErrs=[];
   $doRetains=[];

//   $useFilesCtg=getFileByType('ctg','*',$useProject );    // get most recent .ctg file for all users
   doCleanup_get('ctg',$useProject,$doDels,$doErrs,$doRetains) ;
   doCleanup_get('rnk',$useProject,$doDels,$doErrs,$doRetains) ;
   doCleanup_get('rcm',$useProject,$doDels,$doErrs,$doRetains) ;
   doCleanup_get('rcw',$useProject,$doDels,$doErrs,$doRetains) ;
   doCleanup_get('sch',$useProject,$doDels,$doErrs,$doRetains) ;

   $ndel=0;$nfail=0;

   foreach ($doDels as $ii=>$afile) {
     $qq=unlink($afile);
     if ($qq) {
         $ndel++;
     } else {
        $nfail++;
     }
   }

// csh files
   $curDir=getcwd();
   $cshDir=$curDir.'/data/'.$useProject.'/cache';
   $dafiles=$cshDir.'/*.csh';
   $goo=glob($dafiles);
   foreach ($goo as $i1=>$afile) {
      $qq=unlink($afile);
      if ($qq) {
        print " deleted ";
         $ndel++;
      } else {
         $nfail++;
      }
   }
   $amess="Cleanup of $useProject. # files deleted:<tt>$ndel</tt>.<br> # of files unable to delete: <tt>$nfail</tt>";

   ob_end_clean();   // remove prints and other crap
   $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
   print $vsuggests;

   exit;
}


//==========
// add to lists of files to delete, files to retain, and missing files
function doCleanup_get($aext,$useProject,&$doDels,&$doErrs,&$doRetains) {

   $useFilesCtg=getFileByType($aext,'*',$useProject );    // get most recent .ctg file for all users
   foreach ($useFilesCtg as $auser=>$stuff) {
      $useFile=$stuff[0];
      $doRetains[]="$auser: $useFile ";
      $usePath=dirname($useFile);  // could build from curDir, but might as well use this
      $flist=$stuff[2];
      for ($ifile=0;$ifile<count($flist)-1;$ifile++) {
         $goo=$flist[$ifile];
         $dafile=$goo[1].'.'.$aext;
         $fname=$usePath.'/'. $dafile  ;
         $qgot=file_exists($fname);
         if ($qgot) {
            $doDels[]=$fname;
         } else {
           $doErrs[]=$fname;
         }
      }
   }

   return 1;
}


//===========
// zip submits and copy to backup/
// step 1: check
function doZipSubmits($useProject) {
 $oof=method_exists('ZipArchive','addFromString');
 if (!$oof) {
    $amess="Sorry: ZipArchive is not available";
    ob_end_clean();   // remove prints and other crap
    $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
    print $vsuggests;
    exit;
 }
 $curDir=getcwd();
 $daDirArchive=$curDir.'/data/'.$useProject.'/submits/backups';
   $daDirArchive=str_replace('\\','/',$daDirArchive);
  $daDirArchive=str_replace('//','/',$daDirArchive);

 if (!is_dir($daDirArchive)) {
    $amess="Sorry: backups directory (<tt>$daDirArchive</tt>) does not exist.";
    ob_end_clean();   // remove prints and other crap
    $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
    print $vsuggests;
    exit;
 }
 $zipGots=glob($daDirArchive.'/*.zip');

 $daDir=$curDir.'/data/'.$useProject.'/submits';
  $basedir=str_replace('\\','/',$daDir);
  $basedir=str_replace('//','/',$basedir);

 $daFiles=glob($daDir.'/*.*');
 $amess="There are ".count($daFiles)." files in <tt>$useProject/submits</tt>. ";
 $amess.='<br> Do you want to <button data-project="'.$useProject.'" onClick="adminProjects_submitZipGo(this)">Zip them all? </button>';
$amess.='<p>Note: there are currently <tt>'.count($zipGots)."</tt> .zip files in $daDirArchive";
  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit ;

}


//===========
// zip submits and copy to backup/
// step 2: do it
function doZipSubmitsGo($useProject) {
 $oof=method_exists('ZipArchive','addFromString');
 if (!$oof) {
    $amess="Sorry: ZipArchive is not available";
    ob_end_clean();   // remove prints and other crap
    $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
    print $vsuggests;
    exit;
 }
 $curDir=getcwd();
 $daDirArchive=$curDir.'/data/'.$useProject.'/submits/backups';
   $daDirArchive=str_replace('\\','/',$daDirArchive);
  $daDirArchive=str_replace('//','/',$daDirArchive);

 if (!is_dir($daDirArchive)) {
    $amess="Sorry: backups directory (<tt>$daDirArchive</tt>) does not exist.";
    ob_end_clean();   // remove prints and other crap
    $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
    print $vsuggests;
    exit;
 }
  $daDir=$curDir.'/data/'.$useProject.'/submits';
  $basedir=str_replace('\\','/',$daDir);
  $basedir=str_replace('//','/',$basedir);

 $daFiles=glob($daDir.'/*.*');

 $newName='submits_'.time().'.zip';
 $zipFile=$daDirArchive.'/'.$newName;

 $zip = new ZipArchive();


if ($zip->open($zipFile, ZipArchive::CREATE)!==TRUE) {
    $amess="Sorry: can not open $zipFile ";
    ob_end_clean();   // remove prints and other crap
    $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
    print $vsuggests;
    exit;
}

//$zip->addFromString("testfilephp.txt" . time(), "#1 This is a test string added as testfilephp.txt.\n");
//$zip->addFromString("testfilephp2.txt" . time(), "#2 This is a test string added as testfilephp2.txt.\n");
   foreach ($daFiles as $ii=>$doFile) {
      $useName=basename($doFile);
       $zip->addFile($doFile,$useName);
   }
   $nFiles=$zip->numFiles ;
   $aStatus=$zip->status ;
   
   $adate=date('Y-m-d H:i');
   $acomment="Archive of $useProject on $adate ";
   $zip->setArchiveComment($acomment);

   $zip->close();

    $amess="Created: <u>$zipFile</u> with <tt>$nFiles</tt> files.<br>";
    $amess.="Status: $aStatus ";

    ob_end_clean();   // remove prints and other crap
    $vsuggests=json_encode($amess, JSON_UNESCAPED_UNICODE);  // encode for web transmission
    print $vsuggests;
    exit;
}


//=======================
// list of projects
function doProjectList($aproject) {  // aproject might be false (if generic admin logon)
 $stuff=[];
 $curDir=getcwd();
 $adir=$curDir.'/data';

 $phtml=$adir.

 $daintroFile=$adir.'/projectIntro.html';
 $stuff['introFile']=(file_exists($daintroFile)) ? htmlspecialchars(file_get_contents($daintroFile)) : '' ;

 $dirs = glob($adir.'/*', GLOB_ONLYDIR );
 $alist=[];
 foreach ($dirs as $ith=>$adir) {
    $foo=['gotInit'=>0,'got_cache'=>0,'got_params'=>0,'got_publish'=>0,'got_submits'=>0,'got_backup'=>0,'got_backup'=>0,'init_text'=>''];
    $daname=basename($adir);
    $foo['name']=$daname;
    $dirs2 = glob($adir.'/*', GLOB_ONLYDIR );
    foreach ($dirs2 as $ith2=>$adir2) {
       $basename2=basename($adir2);
       $got1='got_'.$basename2;
       if (array_key_exists($got1,$foo)) $foo[$got1]=1;
    }
    if ($foo['got_submits']==1)  {  // backup
      $dirs3 = $adir.'/submits/backup';
      $foo['got_backup']= (is_dir($dirs3)) ? 1  : 0;
    }

    $dainit=$adir.'/init.txt';
    if (file_exists($dainit))  {
      $foo['gotInit']=1 ;
      $foo['init_text']=htmlspecialchars(file_get_contents($dainit));
    }
    $alist[]=$foo;
 }
 $stuff['projects']=$alist;


  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($stuff, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;

}
