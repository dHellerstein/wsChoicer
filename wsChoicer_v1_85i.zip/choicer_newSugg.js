// functions for adding suggestions

//============
// retrieve the stub of the add new suggestions table
function makeNewSuggestions(ii) {

// and build the table(php does it because it has the variable names
   let ddata={};
   ddata['username']=currentUserName;
   ddata['theProject']=useProject ;

   ddata['todo']='newSuggestionsTable';    // $suggTableVars and

   $.ajax({
        url: 'choicer_newSugg.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function(response) {             // callback
        makeNewSuggestions2(response);
    });

    return 1;
}

// html table built (with one empty new suggestions row). Display it.
function makeNewSuggestions2(aresponse) {
 
// 'table' = table with one new row
//  varlist = list  varname:[width,required], as appearing in table.
// entryrow = blank entry row, suitable for appending to table
 
  let ed1=$('#newSuggestionsDiv');

  let etableOuter=$('#newSuggestionsDivTableOuter');
  etableOuter.html(aresponse['table']);

  let ed2=$('#newEntriesTable') ; // just added table .. save specs needed elsewhere

  ed2.data('entryrow',aresponse['entryrow']);  // used by addARow
  return 1;
}


// ========= add a blank row to new entries table
function addARow(i1) {
  let  eNews=$('#newEntriesTable');
  let entryrow=eNews.data('entryrow');
  $('#newEntriesTable tbody').append(entryrow);
}

//==========
// remove a new suggestion entry
function removeEntry(athis) {
  let ethis=$(athis);
  let erow=ethis.closest('tr');
  erow.remove();
}



// ======= save 'em


function saveNewSuggestionsToServer(ii) {

  let  eNews=$('#newEntriesTable');
  let erows=eNews.find('.entryRow');
  if (erows.length==0) {
     alert('No new suggestion. ');
     return 0;
  }
  let dsuggests=[];
  let issues=[];
  for (let ier=0;ier<erows.length;ier++) {
     let dd={};
     let arow=$(erows[ier]);

     let ename=arow.find('[name="aName"]');
     let zname=ename.val();
     zname=wsurvey.removeAllTags(zname);  //  no html in name
     let zname2 = jQuery.trim(zname.replace(/[\s]+/g, " ")); // no spaces, tabs, crlfs

     let qq =saveNewSuggestionsToServer_checkRequired(ier,'name',ename,zname2) ;
     if (qq===false) return 0 ;  // fatal error (required not filled in)
     if (qq!==true)  issues.push(qq);  // possible issue

     let qmatch=saveNewSuggestionsToServer_check(zname);   // compares shortname version against global choiceNames
      if (qmatch) {
          let qok=confirm('There is a close match for `'+zname+'`. Click OK to save it, cancel to skip it ');
          if (!qok) continue ;  // get next row of table, without saving this one
      }
     dd['aName']=jQuery.trim(zname2);

     let enote=arow.find('[name="aNote"]');
     let anote=jQuery.trim(enote.val());
     anote=wsurvey.removeAllTags(anote);  //  no html in this short description (okay in descriptive notes)

     let qq2 =saveNewSuggestionsToServer_checkRequired(ier,'note',enote,anote) ;
       if (qq2===false) return 0 ;  // fatal error (required not filled in)
       if (qq2!==true)  issues.push(qq2);  // possible issue
//        bnote=wsurvey.removeAllTags(bnote);
     let bnote = anote.replace(/[\s]+/g, " ");
     dd['aNote']=jQuery.trim(bnote);

     let cee=arow.find('[name="avar"]');          // no need to check against customVarList, since table build did that
     for (let icee=0;icee<cee.length;icee++) {
         let vv1=$(cee[icee]);
         let usevar=vv1.attr('data-varname');
         let vval0=vv1.val();
         let  vval=wsurvey.removeAllTags(vval0);
          vval=fixString(vval,2);
         let qq3 =saveNewSuggestionsToServer_checkRequired(ier,usevar,vv1,vval) ;
         if (qq3===false) return 0 ;  // fatal error (required not filled in)
         if (qq3!==true)  issues.push(qq3);  // possible issue
         dd[usevar]=vval;
     }   // icee

     dsuggests.push(dd);       // add thiese suggestions
  }        // ier

  if (issues.length>0) {
      let asay=issues.join('\n *  ');
      let qq=confirm('You had '+issues.length+' missing fields. Are you sure you want to add these suggestions?\n * '+asay);
      if (!qq) return 0;
  }
   let ddata={};
   ddata['username']=currentUserName;
   ddata['theProject']=useProject ;
   ddata['todo']='newSuggestionsAdd';    // $suggTableVars and
   ddata['list']=dsuggests;

   $.ajax({
        url: 'choicer_newSugg.php',
        type: 'POST',
        dataType: 'json',
        data: ddata
    }).always(function(response) {             // callback
       let astatus=response['okay'];
       if (astatus!='1') {
          alert(astatus);
       } else {
          let amess=response['message'];
            amess+='<br>Please <button class="topRowButtonOther2" onclick="doReload()">Reload </button> to see changes ';
          writeStatusMessage(amess,1,1,1);
       }
    });

    return 1;

}

// ==========
// compares shortname version against global choiceNames (avoid reentering same sugggestion
function saveNewSuggestionsToServer_check(testname) {
  let t1=testname.replace(/[\s]+/g, " ")  ;
  let t2=t1.replace(/\s*,\s*/,',') ;
  t2=jQuery.trim(t2.toLowerCase());
  if (choiceNames.hasOwnProperty(t2)) return true;  // checking for existence is good enough
  return false ;  // no match
}

// =====
// is this a required (or dsired) field, with no content
// return true if okay, false if required but nothing, string if desired but nothhing
function saveNewSuggestionsToServer_checkRequired(ier,avar,aelem,aval) {

   let isReq=aelem.attr('data-required');
   let zval=jQuery.trim(aval);
   if ( (isReq==1 || isReq==11) && zval=='') {   // error: name must be entered
        alert('You did not specify a '+avar+' (in row '+(1+ier)+'). Please correct and try again ');
        return false ;
   }
   if ( isReq==11 && !jQuery.isNumeric(zval)) {   // error: number  must be entered
        alert('You did not specify a numeric value for '+avar+' (in row '+(1+ier)+'). Please correct and try again ');
        return false;
     }
   if (isReq==2 && zval=='') {   // suggestion to fill in this field
        return  'No value for '+avar+' in row '+ier;
   }

   return true;
}


//====================
// display help for adding suggestions (add list of custom variables
function addSuggestionHelp(ii) {
  let edo= $('#addSuggestionsHelpMore');
  if (ii==0) {
     edo.hide();
     return 1;
  }
  if (ii==2) {
     if (edo.is(':visible')) {
        edo.hide();
        return 1;
     }
  }

// show the help
  wsurvey.wsShow.show('#addSuggestionsHelpMore');


// add the custom vars // [varname][len,type,label]
 let evlist=$('#addSuggestions_customVars');
 let dfill=evlist.attr('data-filled');
 if (dfill==1) return 1  ;            // already filled !
 for (let cvar in customVarList) {
    let alabel=customVarList[cvar][2];
    let isRequired0=customVarList[cvar][1];
    let aRequired='';
    if (isRequired0==1 || isRequired0==11) aRequired='<em>(required)</em> ' ;
    if (isRequired0==2) aRequired='<em>(recommended, but not required)</em> ' ;

    let ali='<li><b>'+cvar+'</b>  '+aRequired;
    ali+=': <tt>'+alabel+'</tt>';
    evlist.append(ali);
 }
  evlist.attr('data-filled',1);


 return 1;
}
