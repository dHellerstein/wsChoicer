<?php

// ============
// build info about suggestions. This is called right after logon, and returns a number of different
// arrays. That are used on the .js side to build tables of suggestions, etc


session_start() ;
ob_start();

// :::   admin changeable parameters      :::::::::::::::::::::

$noCacheFile=0 ;        // if 1, do NOT try reading from cache file

// ::: END of admin changeable parameters :::::::::::::::::::::

// add some php functions
$curDir=getcwd();
$libfile=$curDir.'/choicer_lib.php';
require_once($libfile);

$useProject=$_REQUEST['theProject'];


// check for passwords file (even if they aren't used something must be specified
$passwordsFile=$curDir.'/data/'.$useProject.'/params/choicer_passwords.php';   // customVars, etc ...
if (!file_exists($passwordsFile)) {
    ob_end_clean();   // remove prints and other crap
    $amess="Error: missing passwords file: $passwordsFile ";
    $stuff=['error'=>$amess];
   $vsuggests=json_encode($stuff, JSON_UNESCAPED_UNICODE);  // encode for web transmission
   print $vsuggests;
   exit;
}

require($passwordsFile);

if (!isset($localDownloadKeycode) || !isset($memberPassword)) {
    ob_end_clean();   // remove prints and other crap
    $amess="Error: no value for localDownloadKeycode or memberPassword in  passwords file: $passwordsFile ";
    $stuff=['error'=>$amess];
   $vsuggests=json_encode($stuff, JSON_UNESCAPED_UNICODE);  // encode for web transmission
   print $vsuggests;
   exit;
}

// read parameters file

$paramsFile=$curDir.'/data/'.$useProject.'/params/choicer_params.php';   // customVars, etc ...
if (!file_exists($paramsFile)) {
    ob_end_clean();   // remove prints and other crap
    $amess="Error: missing parameters file: $paramsFile ";
    $stuff=['error'=>$amess];
   $vsuggests=json_encode($stuff, JSON_UNESCAPED_UNICODE);  // encode for web transmission
   print $vsuggests;
   exit;
}
require($paramsFile);

// can a cache file be used?
 $cacheDir=$curDir.'/data/'.$useProject.'/cache';   // customVars, etc ...
 $cacheFiles=getFileByType_all('csh','',$cacheDir) ;

 $cacheMessage='Not using cache file' ;

 if ($noCacheFile!=1) {
   if (count($cacheFiles)>0)  {
    $oof=$cacheFiles[count($cacheFiles)-1];
    $oofFile=$oof[0];
    $aa=file_get_contents($oofFile);
    if ($aa===false) {
        $cacheMessage= "Unable to retrieve .csh file: $oofFile ";
    } else {
      $rets=unserialize($aa);
      if ($rets===false) {
          $cacheMessage="Problem with .csh file: $oofFile ";
      } else {
         $dd=date('Y-m-d H:i',$oof[1]);
         $cacheMessage='Using cache file created on '.$dd ;
         $rets['cacheMessage']=$cacheMessage;
         $rets['toCache']=false;
         ob_end_clean();   // remove prints and other crap
         $vsuggests=json_encode($rets, JSON_UNESCAPED_UNICODE);  // encode for web transmission
          print $vsuggests;
          exit;
      }  // serialize okay
    }    // cache file retreived
   }           // count >0
  }  // noCacheFile
  

// if here, no (or bad) cache file... or noCacheFile=1 .... so read all the data (and build a cache file)

 $filesInOrder= getFileByType_all('.sug',$useProject);

$validNamesList=[]; // array of valid member names (not nicknames)
$validNamesLookup=[];
foreach ($validNames as $anick=>$amember) {
   if (!array_key_exists($amember,$validNamesLookup)) {
     $validNamesLookup[$amember]=1;    // used internally
     $validNamesList[]=$amember;
   }
}

$username=$_REQUEST['username'];
$checkName=trim(strtolower($username)) ; // should already be trimmed and lc, but wth
$actualMemberName= (array_key_exists($checkName,$validNames)) ?  $validNames[$checkName] : '' ;

// valid name check enabled?
if ($checkValidNames==1) {
  if (!array_key_exists($checkName,$validNames) && $checkName!='admin')  {     // failure
    $rets=[ 'goterr'=>1,'statusMessage'=>'Only members are allowed ('.$checkName.' is not a member)','actualMemberName'=>$actualMemberName];
    ob_end_clean();   // remove prints and other crap
    $vsuggests=json_encode($rets, JSON_UNESCAPED_UNICODE);  // encode for web transmission
    print $vsuggests;
    exit;
  }
}       // checkValidNames


$todo=$_REQUEST['todo'];  // not currently used (9 april 2023)

  $filesInOrder= getFileByType_all('.sug',$useProject);
//  print_r($filesInOrder);
  $discardedSugg=[];

  foreach ($filesInOrder as $ii=>$afile2) {            // read all .sug files (basic  info on a suggestion).
                                                       // Each file was submitted by a unique user, but information is not assigned to a user
     $afile=$afile2[0];
     $fnameTime=$afile2[1];

     $oof=file_get_contents($afile);
    $fnameDate=date('Y-M-d:H:i',$fnameTime);

    $alines =explode("\n",$oof);
    $submitBy='';

    $username=false ;$jline=0;
    for ($iline=0;$iline<count($alines);$iline++) {     // look for username before first empty line . might be 'admin' (if this is a modification file)
      $astuff=$alines[$iline];
      $jline=$iline;

      $bline=trim($astuff);
      if (substr($bline,0,1)==';') continue ;
      if ($bline=='') break ;       // end of section
      $vv2=explode(':',$bline,2);
      $ado=trim($vv2[0]);

      if ($ado=='username') {
         $username=trim($vv2[1]);
         $isDiscarded=false;
         if ($checkValidNames==1 && $username!='admin') {
            if (!array_key_exists($username,$validNamesLookup)) {   // not a validNames
              if (!array_key_exists($username,$discardedSugg)) $discardedSugg[$username]=[];
              $discardedSugg[$username][]=$afile2[0];
              $isDiscarded=true;
            }
         }
         continue;
      }                  // get username
      if ($ado=='date') continue ;          // not used
   }

   if ($username==false || $isDiscarded==true) continue  ;  // no username in file (or somehow an invalid one), so ignore

   $aid='';$vlist=[];

// reparse the file, each suggestion is in a crlf delmited block of lines

   for ($iline=$jline+1;$iline<count($alines);$iline++)  {
      $astuff=$alines[$iline];
      $jline=$iline;
      $bline=trim($astuff);
      if (substr($bline,0,1)==';') continue ;

      if ($bline=='') {            // done with block? record it?
         if ($aid=='' || $gotName=='') {           // no id, or no name: clear vlist and keep going
            $aid='';$gotName='';
            $vlist=[];
            continue;
         }
         if (!array_key_exists('submitBy',$vlist)) $vlist['submitBy']=$username;  // if no explicit submitBy, its from the username
         $vlist['ID']=$aid;
         $vlist['fromFile']=$fnameTime;

         $pattern = '/\s*,\s*/';
         $replace = ',';
         $str = trim(preg_replace($pattern, $replace, $gotName));   // deal with spaces around commas
         $strlc=strtolower($str);
         if (substr($strlc,0,4)=='the ')  {
           $str=substr($str,4) ;  // get rid of a leading 'the '
         } else if (substr($strlc,0,2)=='a ')  {
           $str=substr($str,2) ;  // get rid of a leading 'a '
         }

         $vlist['shortName']= strtolower(trim(preg_replace("/\s+/", " ", $str)));  // overkill but wth

         $suggests[]=$vlist;
         $vlist=[];
         $aid='';
         $gotName='';
         continue ;
     }                      // record entry (an emptySeperator line was found

      $vv2=explode(':',$bline,2);     // still in block of data... save the var: value
      $ado= trim($vv2[0]);
      $vval=trim($vv2[1]);
      if (strtolower($ado)=='id') {         // id is special !
          $aid=$vval;
          continue;
      }

      if ($ado=='aNote') $ado='Notes';        // hacky fixes
      if ($ado=='aName') $ado='Name';
      $vlist[$ado]=$vval;
      if ($ado=='Name')   $gotName=$vval;  // used to make a short name  (above-- after blank row signal end of this suggestion)
   }    // lines in file
  }    // .sug files

  $choiceList=[];       // info on choices (indexed by id)
  $nameList=[];         // names of choices
  $choiceArray=[];      // array of non-removed choices, with values of id (each id is a property of  choiceList)
  $choiceOrderOrig=[] ;  // array of all choices, with values of id (each id is a property of choiceList or removes)
  $membernameList=[];      // usernames, with stats on #suggests, etc
  $submitterList=[];
  $repeats=[];
  $modified=[];
  $removes=[];

// write  info from suggestions to various places
// create choiceList

  $choiceOrderOrig0=[];      // used to build choiceOrderOrig (below)
  $ncc=0;

  foreach ($suggests as $ith=>$infos) {

      $aid=$infos['ID'];
      if (!array_key_exists($aid,$choiceOrderOrig0)) {
         $ncc++;
         $choiceOrderOrig0[$aid]=$ncc;
      }
      $doRemove= (array_key_exists('removeThis',$infos)) ? $infos['removeThis'] : 0 ;
      if ($doRemove==1) {        // remove from list -- retain in removes
         $wasIth=$ith;
         if (array_key_exists($aid,$choiceList)) unset($choiceList[$aid]) ;
         if (array_key_exists($aid,$modified)) unset($modified[$aid]) ;
         $removes[$aid]=$infos;
         $removes[$aid]['removeThis']=1  ;
         $removes[$aid]['removeReason']=$infos['removeReason'] ;
         continue;
      } else {
         if (array_key_exists($aid,$removes)) unset($removes[$aid]) ;  // no longer on the remove list
         $infos[$aid]['removeThis']=0  ;
         $infos[$aid]['removeReason']='' ;
      }

      $doNoRank= (array_key_exists('noRankThis',$infos)) ? $infos['noRankThis'] : 0 ;
      $infos['noRankThis']=$doNoRank ;  // take care of entries that don't have this field

      if (array_key_exists($aid,$choiceList)) {     // a modification (from a more recent  file) --
         if (!array_key_exists($aid,$modified)) $modified[$aid]=0;
         $modified[$aid]++;
      }
      $infos['ithDone']=$ith ;   // the most recent specs for this id
      $choiceList[$aid]=$infos;    // don't change any  of the "informational" arrays  (choiceArray, nameList, repeats,membernameList
  }

  foreach ($choiceList as $aid=>$infos) {
      $ith=$infos['ithDone'];
      $awho=$infos['submitBy'];
      $choiceList[$aid]['nModified']= (array_key_exists($aid,$modified)) ? $modified[$aid] : 0 ;
      if (!array_key_exists($awho,$membernameList)) {
        $submitterList[]=$awho;
        $membernameList[$awho]=['nsuggest'=>0,'nrate'=>0,'nrank'=>0,'nrecommend'=>0,'nRankTop'=>0,'nRankNext'=>0];
      }
      $membernameList[$awho]['nsuggest']++ ;
      $choiceArray[$ith]=$aid ;            // choices in order entered (with removes skipped)
      $asht=$infos['shortName'];
      if (array_key_exists($asht,$nameList)) {  // repeat of name?
        $wasid=$nameList[$asht][0];
        if (!array_key_exists($wasid,$repeats))$repeats[$wasid]=$asht;  // first repeat of this name
        $repeats[$aid]=$asht;    // 2nd or later appearance
        $nameList[$asht][]=$aid;
      } else {
        $nameList[$asht]=[$aid];          // array of ids that have this name (if no repeats length will be 1)
      }
  }


  foreach ($choiceOrderOrig0 as $aaid=>$ith) { // used by admin edit-suggestions
         $choiceOrderOrig[$ith]=$aaid;          // includes references to "removed" suggestions (aaid NOT in choiceList, but in removes list!
  }

// the variable list
  $varList_custom=[];

  foreach ($customVars as $avar=>$adesc) {
   $adesc2=strip_tags($adesc);
   $avar2=strip_tags($avar);
   $avar2 = preg_replace("/(\W)+/", "", $avar2);    // alphanumerics only
   $avar2=strToLower($avar2);
   $awidth= (array_key_exists($avar,$customVarsLength)) ? $customVarsLength[$avar] : 6 ;
   if (!is_numeric($awidth)) $awidth=6;

   $arequired= (array_key_exists($avar,$customVarsRequired)) ? trim($customVarsRequired[$avar]) : '3' ;   // default is not required
   if ($arequired!='1' && $arequired!='2' && $arequired!='11' && $arequired!='3' && $arequired!='4') $arequired=3;
   $arequired=intval($arequired);
   $varList_custom[$avar2]=[$awidth,$arequired,$adesc2];  // used below, and on js side
  }

// get categories (most recently saved submission,  per user)
  $categories=doReadCategories($useProject);

// get rates (most recent saved, per user and choice  (newer overwrite older)
  $rateList0=doGetRates($useProject,$choiceList);
  $rateList= $rateList0[0];
  $nMissingRates=$rateList0[1];

  foreach ($rateList as $awho=>$stuff) {
     if (!array_key_exists($awho,$membernameList))  $membernameList[$awho]=['nsuggest'=>0,'nrate'=>0,'nrank'=>0,'nrecommend'=>0,'nRankTop'=>0,'nRankNext'=>0];
     $membernameList[$awho]['nrate']=count($stuff);
  }

// get rates (most recent saved, per user   (newer overwrite older)
  $rankList=doGetRanks($useProject,$choiceList,$checkValidNames,$discardedSugg);
  foreach ($rankList['userTops'] as $awho=>$stuff) {
     if (!array_key_exists($awho,$membernameList))  $membernameList[$awho]=['nsuggest'=>0,'nrate'=>0,'nrank'=>0,'nrecommend'=>0,'nRankTop'=>0,'nRankNext'=>0];
     $membernameList[$awho]['nRankTop']=count($stuff);
     $membernameList[$awho]['nrank']+=count($stuff);
  }
  foreach ($rankList['userNexts'] as $awho=>$stuff) {
     if (!array_key_exists($awho,$membernameList))  $membernameList[$awho]=['nsuggest'=>0,'nrate'=>0,'nrank'=>0,'nrecommend'=>0,'nRankTop'=>0,'nRankNext'=>0];
     $membernameList[$awho]['nRankNext']=count($stuff);
     $membernameList[$awho]['nrank']+=count($stuff);
  }

// get links/infoBlurbs (cumulative over multipe submissions rom multiple users -- accumulates (no overwrite), shared across all users
  $linksList=doGetLinks($useProject);

// get descriptive notes (cumulative over multipe submissions from multiple users-- accumulates (no overwrite), shared across all users
  $notesList=doGetNotes($useProject);

// get recommendations (most recent saved, per user. Two versions: draft and current
  $recoList=doReadRecommendations($username,$useProject,$choiceList,$checkValidNames,$discardedSugg);

  foreach ($recoList['recList'] as $awho=>$stuff) {
     if (!array_key_exists($awho,$membernameList))  $membernameList[$awho]=['nsuggest'=>0,'nrate'=>0,'nrank'=>0,'nrecommend'=>0,'nRankTop'=>0,'nRankNext'=>0];
     if (trim($stuff)!='') {   // shouldnt ever be empty. but if it is keep it at 0
       $arf=explode(',',$stuff);
       $membernameList[$awho]['nrecommend']=count($arf);
     }
  }
        
  $schedulerVar_use=[];
  $schedList=doReadSchedules($username,$useProject);   // $schedList['schedules'][$username]='id1,id2,... ';


  $schedulers=[];
  foreach ($schedList['schedules'] as $aname=>$alist) {
     $schedulers[]=$aname;
  }

 $commentList=doReadComments($useProject);   // get all comments from all users


// get some passwords

// some overall stats

 $basicStats=[];

 $basicStats['nMembers']=count($membernameList);   // this will change as rating/rankging/recommenders are found

 $basicStats['nSubmitters']=count($submitterList);
 $basicStats['nSuggests']=count($suggests);
 $basicStats['submitterList']=$submitterList ;     // array, each index points to more info in membernameList

 $basicStats['nRaters']=0;                    // filled in on js site
 $basicStats['nTotalRatings']=0;
 $basicStats['nChoicesRated']=0;
 $basicStats['raterList']=[];

 $basicStats['nRankers']=0;                // filled in on js site
 $basicStats['nTotalRankings']=0;
 $basicStats['nChoicesRanked']=0;
 $basicStats['rankerList']=[];

 $basicStats['nChoicesRecommended']=0;
 $basicStats['nTotalRecommendations']=0;
 $basicStats['nRecommenders']=0;
 $basicStats['recoList']=[];

 $basicStats['nSchedules']=count($schedulers);
 $basicStats['schedulers']=$schedulers ;      // array, each index points to a username (who created a schedule)


// 'suggestions' used to build choiceList and choiceArray (no need to send it also)
  $rets=[ 'goterr'=>0,'statusMessage'=>'Data read','actualMemberName'=>$actualMemberName,
   'checkValidNames'=>$checkValidNames,'validNamesList'=>$validNamesList,
  'memberPassword'=>$memberPassword,'localDownloadKeycode'=>$localDownloadKeycode,
  'choiceList'=>$choiceList,'choiceNames'=>$nameList,
  'choiceArray'=>$choiceArray,'repeats'=>$repeats,'modified'=>$modified,'choiceOrderOrig'=>$choiceOrderOrig,
  'discardedSugg'=>$discardedSugg,
     'categories'=>$categories,'rates'=>$rateList,'nMissingRates'=>$nMissingRates,
     'ranks'=>$rankList,'recos'=>$recoList,
     'links'=>$linksList,'notes'=>$notesList,'comments'=>$commentList,
     'removeChoices'=>$removes,'nNotValidRates'=>$nNotValidRates,
     'schedules'=>$schedList,
     'privateDownloadLink'=>$privateDownloadLink,'downloadUsers'=>$downloadUsers,'siteIntro'=>$siteIntro,
     'varList_custom'=>$varList_custom,'schedulerType'=>$schedulerType,
     'schedulerShow'=>$schedulerShow_use,'schedulerNoShow'=>$schedulerNoShow_use,'schedulerShowAddAll'=>$schedulerShowAddAll,
     'membernameList'=>$membernameList,'basicStats'=>$basicStats ] ;


// save to cache
  $atime=time();
  $cacheFile=$curDir.'/data/'.$useProject.'/cache/cache'.$atime.'.csh';   // customVars, etc ...
  $fp=fopen($cacheFile,'w');
  $cacheVar=serialize($rets);
  $nBytesCache=fwrite($fp,$cacheVar);  // this is the one place where we do NOT remove cache file (since this is where it is created!)
  fclose($fp);
  $rets['cacheMessage']=$cacheMessage ;
  $rets['toCache']=$atime ;


  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($rets, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;

 exit;


//========================
// return most recent categories

function doReadCategories($useProject) {

 $useFiles=getFileByType('ctg','*',$useProject );    // get most recent .ctg file for all users
 $catList=[] ;

 foreach ($useFiles as $auser=>$alist) {            // read all .ctg files (storing submitted info). Each file is usnique to a user
    $catList[$auser]=[];
    $afile=$alist[0];             // [1] is count of files (returned file is most recent)
    $oof=file_get_contents($afile);
    $alines =explode("\n",$oof);
    $submitBy='';$darecs=[];$datime='';$dacomment='';
    foreach($alines as $aid=>$aline) {
       $cline=trim($aline);
       if ($cline=='') continue;
       if (substr($cline,0,1)==';') continue  ;
       $bsp=explode(':',$cline,2);

       $aid=trim($bsp[0]);
       if ($aid=='user' || $aid=='username') continue ;    // getFileByType got this!
       if ($aid=='date'  ) continue ;    // no need for this got this!
       if ($aid=='comment')  continue ;
       $acat=trim($bsp[1]);
       $catList[$auser][$aid]=$acat;
    }          // line
 }       // next file
//exit;
 return $catList ;
}

//==================
// get rates for all users & choices
function doGetRanks($useProject,$choiceList,$checkValidNames,$discardedSugg) {

  $rankList=['choiceRanks'=>[],'userTops'=>[],'userNexts'=>[],'trancheList'=>[],'comments'=>[],'file'=>'','userDiscards'=>[]];
  $commentList=[];
  $nRanksDiscard=0;
  $nRankersDiscard=0;
  $userTop9=[]; $userNext9=[];$userDiscards=[];

  $useFiles=getFileByType('rnk','*',$useProject);    // get most recent .rnk file for all rankers (for this project)

  $nRankers=count($useFiles);
  $nRankers2=max(1, ($nRankers/2)) ;

  $ranks=[];
  foreach ($useFiles as $auser=>$alist) {            // read all .rnk files (storing submitted info).
   if ($checkValidNames==1) {
       if (array_key_exists($auser,$discardedSugg)) {
         $nRankersDiscard++;             // user who submitted ranking that is not in validNames -- skip!
         continue;
       }
   }
    $userDiscards[$auser]=0;

    $ranks[$auser]=[];
    $afile=$alist[0];             // [1] is count of files (returned file is most recent)
    $ranks[$auser]['file']=$afile;
    $oof=file_get_contents($afile);
    $alines =explode("\n",$oof);
    $submitBy='';$darecs=[];$datime='';$dacomment='';$adate='';

    foreach($alines as $aid=>$aline) {
       $cline=trim($aline);
       if ($cline=='') continue;
       if (substr($cline,0,1)==';') continue  ;
       $bsp=explode(':',$cline,2);
       $aid=trim($bsp[0]);
       if ($aid=='user' || $aid=='username') continue ;    // getFileByType got this!
       if ($aid=='date'  ) {
          $adate=trim($bsp[1]);
          continue ;    // no need for this got this!
       }
       if ($aid=='comment') {
         $zcomment=[$auser,$adate,trim($bsp[1])];
         $commentList[]=$zcomment;
         continue ;
       }
       if ($aid!='top9' && $aid!='next9') continue ;   // only these are useful
       $rnks=trim($bsp[1]);
       $rnksa=explode(',',$rnks);

       $rnksb=[];
//       print "\n for $aid ".count($rnksa);
//       print_r($rnksa);
       if (count($rnksa)>0) {
        foreach ($rnksa as $ifoo=>$aaid) {
           if (trim($aaid)=='') continue ; // if nothing ranked, this could happen
           if (array_key_exists($aaid,$choiceList)) {  // an existing suggestion (not removed, not discarded)
             $rnksb[]=$rnksa[$ifoo];
           }   else {    // skip if not exist
              $userDiscards[$auser]++ ;
              $nRanksDiscard++      ;          //  a rank of a suggestion that is no longer avaiable (it was entered by someone not in validNames)
           }  // not in choicelist
         }    // each ranked (top9 or next 9)
       }      // count rnksa
       $ranks[$auser][$aid]=$rnksb;  //
    }          // line
 }       // next file

 $choiceRanks=[];
 foreach ($ranks as $auser=>$stuff) {
    $userTop9[$auser]=$stuff['top9'];
    if (array_key_exists('top9',$stuff)) {
      foreach ($stuff['top9'] as $ifoo=>$mvid) {
          if (!array_key_exists($mvid,$choiceRanks)) $choiceRanks[$mvid]=['top9'=>[],'next9'=>[]];
          $choiceRanks[$mvid]['top9'][]=$auser;
      }
    }
   if (array_key_exists('next9',$stuff)) {
     $userNext9[$auser]=$stuff['next9'];
      foreach ($stuff['next9'] as $ifoo=>$mvid) {
          if (!array_key_exists($mvid,$choiceRanks)) $choiceRanks[$mvid]=['top9'=>[],'next9'=>[]];
          $choiceRanks[$mvid]['next9'][]=$auser;
      }
    }
  }        // user in ranks

 $trancheList=[] ;    // indices will be choice ids
 foreach ($choiceRanks as $mvid=>$rlists) {
     $tranche=7  ;  // assume no ranking
     $nTop9=count($rlists['top9']);
     $nNext9=count($rlists['next9']);
     $nBoth=$nTop9+$nNext9 ;

// since lower values are better, 1 - fraction of users who ranked this either top or next

     if ($nTop9>0) {                  // tranches 1 to 3 (at least one top)
       $midFrac=min(0.99,1-($nBoth/$nRankers));
       if ($nTop9==$nRankers) {         // everyone who ranked... ranked in top9
           $tranche=1+$midFrac;
       } else if ($nTop9>=$nRankers2) {    // over half of rankers
           $tranche=2+$midFrac;
       } else {                            // more than one
          $tranche=3+$midFrac;
       }
      } elseif ($nNext9>0)  {     // tranches 4 to 6 (no tops, some nexts)
         if ($nNext9==$nRankers) {
           $tranche=4;
         } else if ($nNext9>=$nRankers2) {
           $tranche=5;
         } else {
          $tranche=6;
         }
     }      // else defualt 7
     $trancheList[$mvid]=$tranche;
  }


  $rankList=['choiceRanks'=>$choiceRanks,'userTops'=>$userTop9,'userNexts'=>$userNext9,'trancheList'=>$trancheList,
            'nRanksDiscard'=>$nRanksDiscard,'nRankersDiscard'=>$nRankersDiscard,'userDiscards'=>$userDiscards,
            'comments'=>$commentList];
//  print "\n reanklist ";
//  print_r($rankList);exit;
  return $rankList ;


}

//==================
// get rates for all users & choices
function doGetRates($useProject,$choiceList) {
  $filesInOrder= getFileByType_all('.rte',$useProject);
  $rateList=[];
  $nMissingRate=0;

  foreach ($filesInOrder as $ii=>$afile2) {        // read all rate files. Each file is usnique to a user. Older ones are first
    $afile=$afile2[0];
    $fnameTime=$afile2[1];
    $fnameDate=date('Y-M-d:H:i',$fnameTime);

    $oof=file_get_contents($afile);
    $alines =explode("\n",$oof);
    $auser='';                     // username is unique to a file
    $badUser=false;               //   7 april : could check that this name is valid
    foreach($alines as $aid=>$aline) {
       $cline=trim($aline);
       if ($cline=='') continue;
       if (substr($cline,0,1)==';') continue  ;
       $bsp=explode(':',$cline,2);
       $aid=trim($bsp[0]);
       if ($aid=='user' || $aid=='username') {
         $auser=trim($bsp[1]);
         if (!array_key_exists($auser,$rateList)) $rateList[$auser]=[];
         continue ;
       }
       if ($aid=='date'  ) continue ;    // no need for this
       if ($aid=='comment')  continue ;
       if ($auser=='' || $badUser===true) continue ;        // don't process entries if username not specified (above entries)  -- or if non validNames

// if here, an suggId:rateValue line -- check if suggestion has not been removed (or skipped due to validNames)
       if (!array_key_exists($aid,$choiceList)) {
          $nMissingRate++;
          continue;
       }
       $arate=trim($bsp[1]);
       $rateList[$auser][$aid]=$arate;    // can overwrite rates (for a suggestion) specified in an older file
    }          // line

  }       // next file
// could remove auser=[] (say users who only rated removed suggestions)
 return [$rateList,$nMissingRate] ;
}


//===============
// get links and info blurbs
function doGetLinks($useProject) {
  $filesInOrder= getFileByType_all('.ava',$useProject);
  $linksList=[];

  foreach ($filesInOrder as $ii=>$afile2) {        // read all  links/infoBlurbs files. Each is unique to a user, and available to all  users
    $afile=$afile2[0];
    $fnameTime=$afile2[1];
    $fnameDate=date('Y-M-d:H:i',$fnameTime);

    $oof=file_get_contents($afile);
    $alines =explode("\n",$oof);
    $auser='';                     // username is unique to a file

    foreach($alines as $aid=>$aline) {
       $cline=trim($aline);
       if ($cline=='') continue;
       if (substr($cline,0,1)==';') continue  ;
       $bsp=explode(':',$cline,2);
       $aid=trim($bsp[0]);
       if ($aid=='user' || $aid=='username') {
         $auser=trim($bsp[1]);
         continue ;
       }
       if ($aid=='date'  ) continue ;    // no need for this got this!
       if ($aid=='comment')  continue ;
       if ($auser=='') continue ;        // don't process entries if username not specified (above entries)
       $aLinky=trim($bsp[1]);
       if (!array_key_exists($aid,$linksList)) $linksList[$aid]=[];  // array of notes for each choice ([text,submitby])
       $goo=[$aLinky,$auser];
       $linksList[$aid][]=$goo;
    }          // line
  }       // next file

 return $linksList ;
}



//===============
// get links/infoBlurbs (cumulative over multipe submissions rom multiple users -- no overwrite, shared across all users
function doGetNotes($useProject)  {
   $filesInOrder= getFileByType_all('.nte',$useProject);
  $noteList=[];

  foreach ($filesInOrder as $ii=>$afile2) {
    $afile=$afile2[0];
    $fnameTime=$afile2[1];
    $fnameDate=date('Y-M-d:H:i',$fnameTime);

    $oof=file_get_contents($afile);
    $alines =explode("\n",$oof);
    $auser='';                     // username is unique to a file

    foreach($alines as $aid=>$aline) {
       $cline=trim($aline);
       if ($cline=='') continue;
       if (substr($cline,0,1)==';') continue  ;
       $bsp=explode(':',$cline,2);
       $aid=trim($bsp[0]);
       if ($aid=='user' || $aid=='username') {
         $auser=trim($bsp[1]);
         continue ;
       }
       if ($aid=='date'  ) continue ;    // no need for this got this!
       if ($aid=='comment')  continue ;
       if ($auser=='') continue ;        // don't process entries if username not specified (above entries)
       $aNote=trim($bsp[1]);
       if (!array_key_exists($aid,$noteList)) $noteList[$aid]=[];  // array of notes for each choice ([text,submitby])
       $goo=[$aNote,$auser];
       $noteList[$aid][]=$goo;
    }          // line
  }       // next file

 return $noteList ;
}

// ============
// retrieve all recommendations (most recent
function doReadRecommendations($cUser,$useProject,$choiceList,$checkValidNames,$discardedSugg) {

 $useFiles=getFileByType('rcm','*',$useProject );    // get most recent .rcm file for all users

 $recList=[] ;
 $recListW=[] ;
 $daComment=[];
 $daCommentW=[];
 $nRecoUsersDiscard=0;
 $nRecosDiscard=0;
 $userDiscards=[];

 foreach ($useFiles as $auser=>$a1) {            // read all .rcm  files (storing submitted info). Each file is usnique to a user

   if ($checkValidNames==1) {
       if (array_key_exists($auser,$discardedSugg)) {
         $nRankersDiscard++;             // user who submitted ranking that is not in validNames -- skip!
         continue;
       }
   }
   $userDiscards[$auser]=0;

    $afile=$a1[0];
    $oof=file_get_contents($afile);
    $alines =explode("\n",$oof);
    foreach($alines as $ii=>$aline) {
       $cline=trim($aline);
       if ($cline=='') continue;
       if (substr($cline,0,1)==';') continue  ;
       $bsp=explode(':',$cline,2);
       $aid=strtolower(trim($bsp[0]));
       if ($aid=='comment') {
          $daComment[$auser]=trim($bsp[1]);
       }
       if ($aid=='list') {
         $list1=trim($bsp[1]);
         $list1b=explode(',',$list1);
         $list1c=[];
         foreach ($list1b as $ii=>$mvid) {
            if (array_key_exists($mvid,$choiceList)) {
                $list1c[]=$mvid;
            } else {
                $userDiscards[$auser]++;
                $nRecosDiscard++;
            }
         }
          $recList[$auser]=implode(',',$list1c);
       }
    }
  }

// and now for draft -- but don't track discardeds

 $useFilesW=getFileByType('rcw','*',$useProject );    // get most recent .rcw file for all users
 $recListW=[] ;
 foreach ($useFilesW as $auser=>$a1) {            // read all .rcm  files (storing submitted info). Each file is usnique to a user
    $afile=$a1[0];
    $oof=file_get_contents($afile);
    $alines =explode("\n",$oof);
    foreach($alines as $ii=>$aline) {
       $cline=trim($aline);
       if ($cline=='') continue;
       if (substr($cline,0,1)==';') continue  ;
       $bsp=explode(':',$cline,2);
       $aid=strtolower(trim($bsp[0]));
       if ($aid=='comment') {
          $daCommentW[$auser]=trim($bsp[1]);
       }
       if ($aid=='list') {
          $recListW[$auser]=trim($bsp[1]);
       }
    }
  }       // next fiel

// read recoTableTopRow.html
  $curDir=getcwd();
  $daReco1=$curDir.'/includes/recoTableTopRow.html';
  $getStuff=file_get_contents($daReco1);

  $rr=['recList'=>$recList,'recListDraft'=>$recListW,
   'nRecoUsersDiscard'=>$nRecoUsersDiscard,
   'nRecosDiscard'=>$nRecosDiscard,
   'userDiscards'=>$userDiscards,
   'comment'=>$daComment,
   'commentDraft'=>$daCommentW,'recoTopRow'=>$getStuff];

  return $rr;

}

// ============

// retrieve all recommendations (most recent

function doReadSchedules($cUser,$useProject) {
  global $customSchedulerVar,$customSchedulerDefault, $varList_custom,$schedulerType,$schedulerShow,$schedulerNoShow;
  global $schedulerShow_use, $schedulerNoShow_use,$schedulerShowAddAll   ;
  global $customVars,$customVarsLength ;

  $schedulerShowAddAll=0;    // assume no '*All' in schedulerShow

  $scheduleShowDefault=['Name'=>15, 'Start'=>9,'rowNumber'=>2,'rowNumberChoice'=>2,
   'Name'=>15,  'Elapsed'=>9, 'totalDuration'=>7,
   'Links'=>      20 ,  'Desc'=>       20 ,
   'entryValueA'=> 6 ,   'firstNote'=> 30,   'Duration'=>  5,   'Pause'=>     5,
   'infoBlurbs'=>20,   'descNotes'=> 40,   'allLinks'=>  20
  ]   ;

  $schedulerTypeOkay=['time'=>1,'date'=>1,'quantity'=>1,'order'=>1];

  foreach ($varList_custom as $ccvar=>$vv1) {   // [$awidth,$arequired,$adesc2]
      $scheduleShowDefault[$ccvar]=$vv1[0] ;
  }

  $useFiles=getFileByType('sch','*',$useProject );    // get most recent .sch file for all users
  $daComment='n.a.';
  $schList=[] ;

  if (trim($customSchedulerDefault)==='') $customSchedulerDefault=0 ;  // catch a misspecification
  if (!is_numeric($customSchedulerDefault) || $customSchedulerDefault<0 ) $customSchedulerDefault=60 ; //  catch stupid errors

  $schedulerType=trim(strtolower($schedulerType));
  if (!array_key_exists($schedulerType,$schedulerTypeOkay)) {        // detect error
    $amess= "<br><br><b>Invalid value of  schedulerType: $schedulerType </b><p> ";
    print $amess ;
    exit;
  }

  $schedulerShow_use=['Name'=>15,'Start'=>9];    // a global
  $err1s=[];

  foreach ($schedulerShow as $avar=>$aval) {
     $cvar=trim($avar)  ;
     if ($cvar=='*All'){
         $schedulerShowAddAll=1;
         continue ; // special case
     }
     if (!array_key_exists($cvar,$scheduleShowDefault)) {
        if ($cvar==strtolower($cvar)) {
           $err1s[]="variable ($avar) does not exist. ";
        } else {
           $err1s[]="variable ($avar) does not exist. Perhaps the case is incorrect? ";
        }
        $oof=var_export($scheduleShowDefault,true);
        $err1s[]=$oof;


        continue;
     }
     $avalwas=$aval;
     if (trim($aval)==='*'){
         $aval=$scheduleShowDefault[$cvar];
     }
     if (!is_numeric($aval)) {
        $err1s[]="variable ($avar) has a non-numeric value: $aval " ;
        continue;
     }
     if ($cvar=='Name' ||$cvar=='Start') unset($schedulerShow_use[$cvar]) ;  // allow column of these to change
//     if ($aval!=0) $schedulerShow_use[$cvar]=$aval;   // 0 means "do not use" -- so  that means they are not enabled
       $schedulerShow_use[$cvar]=$aval;   // 0 means "do not use" -- so  that means they are not enabled
  }

  $t1=explode(',',$schedulerNoShow);

  foreach ($t1 as $jj1=>$nnvar ) {
    $nnvar=trim($nnvar);
    if (!array_key_exists($nnvar,$schedulerShow_use))  continue  ; // not in schedulerShow , so ignore ;
    $schedulerNoShow_use[$nnvar]=1;
   }

   if (count($err1s)>0) {                  // error? report and exit
     $emess='<p/><b>Errors found in  $schedulerShow   </b>... <ul><li>'.implode('<li>',$err1s).'</ul><p/>';
     print $emess;
     exit;
  }

  foreach ($useFiles as $auser=>$a1) {            // read all .sch  files (storing submitted info). Each file is usnique to a user
    $afile=$a1[0];
    $oof=file_get_contents($afile);
    $alines =explode("\n",$oof);
    $schList[$auser]=['file'=>$afile,'Date'=>'','Comment'=>'','schedulerType'=>0,
                        'nChoices'=>0,'nBreaks'=>0,'startValueAll'=>0,'endValueAll'=>0,
                       'recoList'=>'','recoFrom'=>'','defValueUse'=>0,'defAddBefore'=>0 ,
                      'doAmPm'=>0,'doShowDays'=>0,'doElapsed'=>0,
                      'doCalendar'=>0,'doShowWeek'=>0,'doShowYear'=>'','doShowWeekDay'=>'',
                      'doAddComma'=>0,'doUseK'=>0,'doPrefix'=>'','doPostFix'=>'',
                      'sortAsc'=>0,'sortDsc'=>0,'sortNumeric'=>'' ,
                      'maxHeight'=>2.5,'Header'=>'','fmtVars'=>[],'fmtVarsKeep'=>[],
                    ] ;
    $schList[$auser]['entries']=[];

    $useId='';
    $daEntry=[];
    foreach($alines as $ii=>$aline) {
       $cline=trim($aline);
       if ($cline=='') continue;
       if (substr($cline,0,1)==';') continue  ;
       $bsp=explode(':',$cline,2);
       $aid0= trim($bsp[0]);
       $aid=strtolower($aid0);
       $aval=trim($bsp[1]);

       if ($aid0=='Username') continue ;  // determiend above

       if ($aid0=='Date') {
          $schList[$auser]['Date']= $aval;
          continue ;
       }

       if ($aid0=='recoFrom') {
          $schList[$auser]['recoFrom']= $aval;
          continue ;
       }
       if ($aid0=='recoList') {
          $schList[$auser]['recoList']= $aval;
          continue ;
       }

       if ($aid0=='Comment') {
          $schList[$auser]['Comment']= $aval;
          continue ;
       }
       if ($aid0=='nChoices') {
          $schList[$auser]['nChoices']= $aval;
          continue ;
       }
       if ($aid0=='nBreaks') {
          $schList[$auser]['nBreaks']= $aval;
          continue ;
       }
       if ($aid0=='schedulerType') {
          $schList[$auser]['schedulerType']= $aval;
          continue ;
       }

       if ($aid0=='startValueAll') {
          $schList[$auser]['startValueAll']= $aval;
          continue ;
       }
       if ($aid0=='endValueAll') {
          $schList[$auser]['endValueAll']= $aval ;
          continue ;
       }
       if ($aid0=='defValueUse') {
          $schList[$auser]['defValueUse']= $aval;
          continue ;
       }
       if ($aid0=='defAddBefore') {
          $schList[$auser]['defAddBefore']= $aval;
          continue ;
       }

// formatting options  (varies by schedulerType

       if ($aid0=='doAmPm') {
          $schList[$auser]['doAmPm']= $aval;
          continue ;
       }
       if ($aid0=='doShowDays') {
          $schList[$auser]['doShowDays']= $aval;
          continue ;
       }
       if ($aid0=='doElapsed') {
          $schList[$auser]['doElapsed']= $aval;
          continue ;
       }


       if ($aid0=='doCalendar') {
          $schList[$auser]['doCalendar']= $aval;
          continue ;
       }
       if ($aid0=='doShowWeek') {
          $schList[$auser]['doShowWeek']= $aval;
          continue ;
       }
       if ($aid0=='doShowYear') {
          $schList[$auser]['doShowYear']= $aval;
          continue ;
       }
        if ($aid0=='doShowWeekDay') {
          $schList[$auser]['doShowWeekDay']= $aval;
          continue ;
       }

       if ($aid0=='doAddComma') {
          $schList[$auser]['doAddComma']= $aval;
          continue ;
       }
       if ($aid0=='doUseK') {
          $schList[$auser]['doUseK']= $aval;
          continue ;
       }
       if ($aid0=='doPrefix') {
          $schList[$auser]['doPrefix']= $aval;
          continue ;
       }
        if ($aid0=='doPostFix') {
          $schList[$auser]['doPostFix']= $aval;
          continue ;
       }

        if ($aid0=='maxHeight') {
          $schList[$auser]['maxHeight']= $aval;
          continue ;
       }
       if ($aid0=='Header') {
          $schList[$auser]['Header']= $aval ;
          continue ;
       }
       
       if ($aid0=='sortAsc') {
          $schList[$auser]['sortAsc']= $aval;
          continue ;
       }
       if ($aid0=='sortDsc') {
          $schList[$auser]['sortDsc']= $aval;
          continue ;
       }
       if ($aid0=='sortNumeric') {
          $schList[$auser]['sortNumeric']= $aval;
          continue ;
       }


//       if ($aid0.substr(0,7)=='$')  {   // schedule col var
       if (substr($aid0,0,7)=='$scVar_')  {   // schedule col var
           $avar2=substr($aid0,7);
           $schList[$auser]['fmtVars'][$avar2]=  $aval ;
          continue ;
       }

       if (substr($aid0,0,6)=='$keep_')  {   // schedule col var
           $avar2=substr($aid0,6);
           $schList[$auser]['fmtVarsKeep'][$avar2]=  $aval ;
          continue ;
       }

       if (substr($aid0,0,7)=='$width_')  {   // schedule col width
           $avar2=substr($aid0,7);
           $schList[$auser]['colWidths'][$avar2]=  $aval ;
          continue ;
       }


       if ($aid0=='Id') {         // start new entry
          if ($useId!=='') {   // save if prior one exists
             $schList[$auser]['entries'][]=$daEntry ;
          }
          $daEntry=[];
          $useId=$aval;
          $daEntry['Id']=$useId;
          continue;
       }

// If here, must be an attribute of a entryrow (with choiceid=ID). These
       if ($useId==='') continue ;   // should not happen

       $daEntry[$aid]=$aval ;       // use lowercase to save

    }          // this file (this user)

    if ($useId!=='') {   // save the one at the end
             $schList[$auser]['entries'][]=$daEntry ;
   }

  }    // allfiles

  $scvar=$customSchedulerVar ;
  $scvar=(array_key_exists($scvar,$customVars))  ? $scvar :  '' ;  // must be a customVars

  $rr=['schedules'=>$schList,'scheduleVar'=>$scvar,'scheduleDefault'=>$customSchedulerDefault] ;

  return $rr;

}

//================
// read all comments. Return as one array
// each element in the array is [user,text]
function  doReadComments($useProject) {
  $filesInOrder=getFileByType_all('.cmt',$useProject) ;
  $allComments=[];

  foreach ($filesInOrder as $ii=>$afile2) {        // read all  links/infoBlurb files. Each is unique to a user, and available to all  users
    $afile=$afile2[0];
    $fnameTime=$afile2[1];
    $fnameDate=date('Y-M-d:H:i',$fnameTime);

    $oof=file_get_contents($afile);
    $alines =explode("\n",$oof);
    $auser='';$adate='';$acomment='';                     // one comment per file (with username and date)

    foreach($alines as $aid=>$aline) {
       $cline=trim($aline);
       if ($cline=='') continue;
       if (substr($cline,0,1)==';') continue  ;
       $bsp=explode(':',$cline,2);
       $aid=trim($bsp[0]);
       if ($aid=='user' || $aid=='username') {
         $auser=trim($bsp[1]);
         continue ;
       }
       if ($aid=='date'  ){
         $adate=trim($bsp[1]);
         continue;
       }

       if ($aid=='comment' || $aid=='text') {
         $acomment=trim($bsp[1]);
         continue ;
       }
    }          // line
    $a1=[$auser,$adate,$acomment]  ;
    $allComments[]=$a1;
  }       // next file

 return $allComments ;
}


