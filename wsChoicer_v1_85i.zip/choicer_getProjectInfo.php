<?php
// get misc project info  with schedule  page.

session_start() ;
ob_start();

// add some php functions
$curDir=getcwd();
$libfile=$curDir.'/choicer_lib.php';
require_once($libfile);

$stuff=[];

$useProject=$_REQUEST['theProject'];
$curDir=getcwd();
$useParamsDir=$curDir.'/data/'.$useProject.'/params/';
$stuff['dir']=$useParamsDir;
$gotJs=file_exists($useParamsDir.'choicer_params.js');
$stuff['gotJs']= ($gotJs) ? 1  : 0 ;
$gotPhp=file_exists($useParamsDir.'choicer_params.php');
$stuff['gotPhp']= ($gotPhp) ? 1  : 0 ;
$gotPasswords=file_exists($useParamsDir.'choicer_passwords.php');
$stuff['gotPasswords']= ($gotPasswords) ? 1  : 0 ;

$gotViewPublish=file_exists($useParamsDir.'choicer_viewPublish.html');
if ($gotViewPublish) {
   $stuff['viewPublish']=file_get_contents($useParamsDir.'choicer_viewPublish.html');
} else {
   $stuff['viewPublish']='';
}


  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($stuff, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;


 exit;