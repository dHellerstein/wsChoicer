//================
// called by the Retrive the schedule button ... or indireclty via double click on Read a Schedule
// this is getScripted by applySelectSchedule (in choicer_sched.js)

// given a schedule, write its info to the "list or recommendations " and "table of schedule entries "
// a schedule is chosen  (a saved scheduled produced by aname or anameuse)
// typically from seleciton list
// but could be an explicit name (anameUse)

function applySelectScheduleUse(athis,anameUse) {
  if (arguments.length<2) anameUse=false;
  let ethis,aname;
  if (anameUse===false)   ethis=wsurvey.argJquery(athis);

  let goids={'time':'#schedulerList_mode_time','date':'#schedulerList_mode_date',
              'quantity':'#schedulerList_mode_quantity','order':'#schedulerList_mode_order'};
  let saydef={'time':'minutes','date':'days','quantity':'quantity','order':'order'};

  let eTable=$('#scheduleDivTable');
  let eList=$('#scheduleListDiv');

  schedule_removeAll(1);   // remove all rows in table, all buttons in list

  if (anameUse===false) {
    let e1=$('#iPeopleWithSchedList');
    let e2=e1.find("option");
     let aa=e2.filter(":selected");
     if (aa.length==0) return 0 ;   // should not hppen
     aname=$(aa[0]).val();
  } else {
    aname=anameUse;
  }

   if (!allScheds['schedules'].hasOwnProperty(aname)) {      // could happen if explciti call
       let errmess='No entry for '+aname+' in saved schedules ';
       if (anameUse!==false) return 'You do <u>not</u> have a saved schedule' ;
       alert(errmess);
       return 0;
   }

// apply this info toe the list and table
   let schList=allScheds['schedules'][aname];
   let daSchedulerType= schList['schedulerType'];
   if (daSchedulerType!=schedulerType)  {              // admin switched scheudle type
      writeStatusMessage('The most retrieved schedule  can not be used: <tt>'+daSchedulerType+'</tt> is not meant for the current (<em>'+schedulerType+')</em> schedule type',2,1,1);
      return false;
  }

  allScheds['using']=aname ;

   let updateDate0=schList['Date'];
   let updateDateStr='n.a.';
   if (jQuery.trim(updateDate0)!=='') {
       let adate= new Date(updateDate0*1000);       // php to js timestamp
       updateDateStr=adate.getHours() + ":" + adate.getMinutes() + ", "+ adate.toDateString();
   }
   let nBreaks=parseInt(schList['nBreaks']);
   let nChoices=parseInt(schList['nChoices']);
   let nEntries=nBreaks+nChoices ;
   let startValueAll=parseInt(schList['startValueAll']);
   let endValueAll=parseInt(schList['endValueAll']);
   let totDuration=endValueAll -startValueAll ;
   let defValueUse=parseInt(schList['defValueUse']);     // could be minutes, days, or quantity  -- not used if 'order' type
   let defAddBefore=parseInt(schList['defAddBefore']);           // could be minutes, days, or quantity   -- not used if 'order' type

//   alert(defValueUse+', gap='+defAddBefore);
   let daComment=schList['Comment'];
   let recoList=schList['recoList'].split(',');

   let cmess='Schedule from '+aname+' with '+nChoices +' recommendations &amp; '+nBreaks+' breaks. Total duration='+totDuration;
   cmess+=' (@ ' +updateDateStr+')<br><em>'+daComment+'</em>';
   scheduleAlert(cmess);

    if (aname==currentUserName) {
     hdrMessage='<span id="scheduleBasicInfoReco_nsched">'+nChoices+'</span> (of  ';
     hdrMessage+='<span id="scheduleBasicInfoReco_submitter"  style="font-weight:700">your</span>  '+recoList.length+') added ';
     hdrMessage+=' <span  id="scheduleBasicInfoReco_nbreak" class="cscheduleBasicInfoReco_nsched">['+nBreaks+' cbreaks]</span>';
   } else {
       hdrMessage='<span id="scheduleBasicInfoReco_nsched">'+nChoices+'</span> (of    ';
       hdrMessage+=' <span id="scheduleBasicInfoReco_submitter" style="font-weight:700">'+aname+'</span>  '+recoList.length+') added to schedule ';
       hdrMessage+=' <span id="scheduleBasicInfoReco_nbreak" class="cscheduleBasicInfoReco_nsched">['+nBreaks+' dbreaks]</span>';
   }
   $('#scheduleBasicInfoReco').html(hdrMessage);

// specify input parameters, using values saved in the retrieved schedule
  if (daSchedulerType=='time') {
      applySelectSchedule_time(schList)
  } else  if (daSchedulerType=='date') {
      applySelectSchedule_date(schList)
  } else  if (daSchedulerType=='quantity') {
      applySelectSchedule_quantity(schList)
  } else  if (daSchedulerType=='order') {
      applySelectSchedule_order(schList)
  } else {
     alert('unknown schedulerType: '+daSchedulerType);
     return 1;
  }



// add several "recommendation buttons" to the list
   let listLis0=makeSchedule_recoButtons(recoList) ;
   let  listLis=listLis0[0];     // [1] is hash table of ids, pointing to row in listLis
   let mvidHash=listLis0[1];

   nRecosAvail=listLis.length;
   let aliUse='<li class="schedule_listOfReos">';
   let tListSay=aliUse+listLis.join(aliUse);

   let eul=eList.find('[name="nschedule_recoList"]');
   eul.append(tListSay);

 // add the selected recommendations (and breaks) to the table
   let eRowFinal=eTable.find('.scheduleBottomRow');

  let elis=eList.find('.schedulerList_recommendation');   // span containing mvid (data-mvid) and name of suggestions insice of <span>..</span>
  let targetList={};
  for (let ili=0;ili<elis.length;ili++) {       // create a etarget lookup table -- mvid maps to button in list of reocmmendations
    let ff=elis[ili];
    let aeli=$(ff);
    let mvid0=aeli.attr('data-mvid');
    targetList[mvid0]=aeli ;
  }

  let useEntries=allScheds['schedules'][aname]['entries'];  // the entries in this schedule (including breaks)

//  ... add recos to table .. and adjust for actual values  used
  let nMissing=0;
  for (let ij in useEntries) {
      let aentry=useEntries[ij];
      let mvid=aentry['Id'];
      if (!targetList.hasOwnProperty(mvid)) {            // could happen if suggesiotn was Remvoed
          nMissing++;
          continue ;
     }
     let aline=schedule_blankRow('+');
      eRowFinal.before(aline);               // add before final row -- so as to append to existing rows
      let etargetB=targetList[mvid] ;
      let e10=scheduleDo_addReco(etargetB,mvid,1) ;
      if (e10===false) continue ;  // shouldn't happen
      let e1=e10[0];
      if (e1[1]>0) scheduleDo_markReco(e10[1],0) ;                    // unmark in list of recos
      if (mvid>0) scheduleDo_markReco(mvid,1) ;                    // mark in list of recos


// do the customizations...
      let ename=e1.find('[name="mvShortDesc"]');
      ename.val(aentry['desc']);
      let edura=e1.find('[name="mvScheduleVarCol"]');
      edura.attr('data-duration',aentry['duration']);
      let edura1=e1.find('[name="mvScheduleVarCol_1"]');
      edura1.html(aentry['duration']);
      edura.attr('data-pausebefore',aentry['pause']);
      let edura2=e1.find('[name="mvScheduleVarCol_2"]');
      edura2.html(aentry['pause']);
      edura.attr('data-isdefault',aentry['usedefaultduration']);
      let isemp=aentry['gotemphasis'];
      let ern=e1.find('.cschedule_rowNumber') ;
      ern.attr('data-emphasis',isemp);
      if (isemp==1) ern.addClass('schedule_buttonEmphasis');

      let eucol=e1.find('[name="updateCol"]');
      eucol.attr('data-scheduleval',aentry['startminute']);
      eucol.html(aentry['startminute']);
  }

 
// apply formatting info   specify Formatting Options

/*
  let doAmPm=schList['doAmPm'];

  let doShowDays=schList['doShowDays'];
  let doElapsed=schList['doElapsed'];

  let maxHeight=schList['maxHeight'];
  let Header=schList['Header'];
  let fmtVars=schList['fmtVars'];
  let fmtVarsKeep=schList['fmtVarsKeep'];
  let colWidths=schList['colWidths'];
  
  let isortAsc=schList['sortAsc'];
  let isortDsc=schList['sortDsc'];
  let isortNumeric=schList['sortNumeric'];

  let eFmtb=$('#mySchedule_format_b');
  eFmtb.find('[name="schedule_format_maxHeight"]').val(maxHeight);
  eFmtb.find('[name="schedule_format_Header"]').val(Header);


//data-timetype 24hr ampm or elapsed
 let ets=eFmtb.find('[name="schedule_format_type"]');
  ets.prop('checked',false);
  if (doElapsed==1) {
     let et1=ets.filter('[data-timetype="elapsed"]');
     et1.prop('checked',true);
  }  else {
     if (doAmPm==1) {
       let et1=ets.filter('[data-timetype="ampm"]');

       et1.prop('checked',true);
    } else {
       let et1=ets.filter('[data-timetype="24hr"]');
       et1.prop('checked',true);
    }

  }

  e1a= eFmtb.find('[name="schedule_format_showDays"]');
    if (doShowDays==1) {
      e1a.prop('checked',true);
    } else {
      e1a.prop('checked',false);
    }


  let ehhs=eFmtb.find('[name="schedule_headerName"]');
  for (let ih=0;ih<ehhs.length;ih++) {
      let aeh=$(ehhs[ih]);
      let vname=aeh.attr('data-varname');
      if (fmtVars.hasOwnProperty(vname)) {
          aeh.val(fmtVars[vname]);
      }
       let eli=aeh.closest('li');
       let ekeep=eli.find('[name="schedule_headerKeep"]');
       if (!fmtVarsKeep.hasOwnProperty(vname) || fmtVarsKeep[vname]==1) {   // default is to keep
       ekeep.prop('checked',true);
      } else {
       ekeep.prop('checked',false);
     }
  }

  let ewws=eFmtb.find('[name="schedule_colWidth"]');
  for (let ih=0;ih<ewws.length;ih++) {
      let aew=$(ewws[ih]);
      let vname=aew.attr('data-varname');
      if (colWidths.hasOwnProperty(vname)) {
          aew.val(colWidths[vname]);
      }
  }

// and on the list container
  let etimt=eList.find('[name="schedule_timeType"]') ;
  etimt.prop('checked',false);
//  alert(etimt.length+','+doElapsed+','+doAmPm);
  if (doElapsed==1) {
      let etimt1=etimt.filter('[data-timetype="elapsed"]');
      etimt1.prop('checked',true);
  } else {
    if (doAmPm==1) {
      let etimt1=etimt.filter('[data-timetype="ampm"]');
      etimt1.prop('checked',true);
    } else {
      let etimt1=etimt.filter('[data-timetype="24hr"]');
      etimt1.prop('checked',true);
    }
  }
  
    e1b= eList.find('[name="schedule_dayNumber"]');
    if (doShowDays==1) {
      e1b.prop('checked',true);
    } else {
      e1b.prop('checked',false);
    }

  //  alert(['oofof',isortAsc,isortDsc,iSortNumeric]);

  if (isortAsc==1) {
      let ess1=eList.find('[name="schedule_sortAsc"]');
      ess1.prop('checked',true);
  }
  if (isortDsc==1) {
      let ess1=eList.find('[name="schedule_sortDsc"]');
      ess1.prop('checked',true);
  }
  if (isortNumeric==1) {
      let ess1=eList.find('[name="schedule_numericSort"]');
      ess1.prop('checked',true);
  }

 */

// === almost ready to return ...

  applySelectSchedule_setPreviewFormats(schList) ;

  let epubs=$('[name="nschedulePublish_button"]');     // enable the publish button
  epubs.addClass('cscheduleSaveButton_on');

  scheduleDo_update(2)  ;  // wth, might as well show the timing...

  scheduleDo_updateButton(0) ;  //   unhighlight

  if (anameUse!==false) {

    let mmess=nChoices+' recommendations  and '+nBreaks+' <em>breaks</em> added to schedule (<em>'+daComment+'</em>) '  ;
    if (nMissing>0) {
       mmess+= ' || Note: '+nMissing+' recommendations were dropped (they probably have been removed). You should update the schedule!';
    }
    return   mmess;
  }

  showSchedule(0,0) ;
  if (nMissing>0) {
     writeStatusMessage('Note: '+nMissing+' recommendations were dropped (they probably have been removed. You should update the schedule!',2,1,1);

  } else {
     showStatusMessage(0) ; // close the window (where the "retreive ..." menu was displayed
  }

  return 1 ;
}


//===========================
// setup schedule for 'time' mode
function applySelectSchedule_time(schList) {

  let eTable=$('#scheduleDivTable');
  let eList=$('#scheduleListDiv');
  let eSpan=eList.find('#schedulerList_mode_time');

  let defValueUse=parseInt(schList['defValueUse']);     // could be minutes, days, or quantity  -- not used if 'order' type
  let defAddBefore=parseInt(schList['defAddBefore']);           // could be minutes, days, or quantity   -- not used if 'order' type

   let es1=eSpan.find('[name="schedule_gapLength"]');
   if (es1.length>0) es1.val(defAddBefore);

   let es2=eSpan.find('[name="schedule_defaultDuration"]');
   if (es2.length>0) es2.val(defValueUse);
   
 //doAmPm   doShowDays  doElapsed

   let eTimeTypes=eSpan.find('[name="schedule_timeType"]');
   eTimeTypes.prop('checked',false);
   if (schList['doAmPm']==1)  {       // which of the three buttons to check
      let ee1=eTimeTypes.filter('[data-timetype="ampm"]');
      ee1.prop('checked',true);
   } else if (schList['doElapsed']==1) {
      let ee1=eTimeTypes.filter('[data-timetype="elapsed"]');
      ee1.prop('checked',true);
   }   else   {
      let ee1=eTimeTypes.filter('[data-timetype="24hr"]');
      ee1.prop('checked',true);
   }

   let edn=$('[name="schedule_dayNumber"]');
   let qdn= (schList['doShowDays']==1) ?  true : false ;
   edn.prop('checked',qdn);

// and in the preview-format menu
  let ePreview1=$('#mySchedule_format');
  let eTimeTypesF=ePreview1.find('[name="schedule_format_type"]');
   eTimeTypesF.prop('checked',false);
   if (schList['doAmPm']==1)  {       // which of the three buttons to check
      let ee1=eTimeTypesF.filter('[data-timetype="ampm"]');
      ee1.prop('checked',true);
   } else if (schList['doElapsed']==1) {
      let ee1=eTimeTypesF.filter('[data-timetype="elapsed"]');
      ee1.prop('checked',true);
   }   else   {
      let ee1=eTimeTypesF.filter('[data-timetype="24hr"]');
      ee1.prop('checked',true);
   }
   let ednF=ePreview1.find('[name="schedule_format_showDays"]');
   ednF.prop('checked',qdn);

   let beginTime=parseInt(schList['startValueAll']);
   let x0=scheduleDo_convertMinutes1(beginTime,0,0,0) ;

   let eStartTimeAll= eTable.find('[name="scheduleStartTime"]');  // top row of table
   eStartTimeAll.attr('data-startvalue',beginTime);
   eStartTimeAll.html(x0[0]);

   let endTime=parseInt(schList['endValueAll']);     // last row of table

   let ebottomRow=eTable.find('.scheduleBottomRow');
   let eupdateCol=ebottomRow.find('[name="updateCol"]');
   eupdateCol.attr('data-scheduleval',endTime);
   if (schList['doElapsed']==1) {
      let deps=parseInt(endTime-beginTime);
      eupdateCol.html('<tt>'+deps+'</tt>');
   } else {
      let x1=scheduleDo_convertMinutes1(endTime,schList['doElapsed'],schList['doAmPm'],schList['doShowDays']) ;
      eupdateCol.html('<tt>'+x1[0]+'</tt>');
   }

 // customize "break" title
   let eul=eList.find('[name="nschedule_recoList"]');
   let ebreak1=eul.find('.cschedule_break');
   ebreak1.attr('title','Add a break -- of this many minutes. You can also specify a short description');
   let ebreak2=eul.find('.cschedule_sayBreak_icon');
   ebreak2.html('&#9202;');

}    //&#128197; calendar        &#128347; clock    9202 timer clock

//===========================
// setup schedule for 'date' mode
function applySelectSchedule_date(schList) {

  let eTable=$('#scheduleDivTable');
  let eList=$('#scheduleListDiv');
  let eSpan=eList.find('#schedulerList_mode_date');

  let defValueUse=parseInt(schList['defValueUse']);     // could be minutes, days, or quantity  -- not used if 'order' type
  let defAddBefore=parseInt(schList['defAddBefore']);           // could be minutes, days, or quantity   -- not used if 'order' type

   let es1=eSpan.find('[name="schedule_gapLength"]');
   if (es1.length>0) es1.val(defAddBefore);

   let es2=eSpan.find('[name="schedule_defaultDuration"]');
   if (es2.length>0) es2.val(defValueUse);

   let ecalendar=eSpan.find('[name="schedule_calendar"]');
   let eNthWeek=eSpan.find('[name="schedule_nthWeek"]');
   let eshowYear=eSpan.find('[name="schedule_showYear"]');
   let edayOfWeek=eSpan.find('[name="schedule_dayOfWeek"]');
   ecalendar.prop('checked',false);     // by default all options not checekd
   eNthWeek.prop('checked',false);    eshowYear.prop('checked',false);   edayOfWeek.prop('checked',false);

   if (schList['doCalendar']==1) {            // year & day of week only canbe checked in calendar mode
       ecalendar.prop('checked',true);
       if (schList['doShowYear']==1)  eshowYear.prop('checked',true);
       if (schList['doShowWeekDay']==1)  edayOfWeek.prop('checked',true);
   } else {
       if (schList['doShowWeek']==1)  eNthWeek.prop('checked',true);   // nth week only can be checked in non-calendar mode
   }

   let beginDate=parseInt(schList['startValueAll']);

   let eStartYear= eSpan.find('[name="schedule_startYear"]');
   let eStartMonth= eSpan.find('[name="schedule_startMonth"]');
   let eStartDay= eSpan.find('[name="schedule_startDay"]');

   let dnew=new Date(beginDate);

   let ayear=dnew.getFullYear();             // the starting year=month-day (in list)
   eStartYear.val(ayear);
   let amonth3=dnew.toLocaleString([], { month: 'short'});
   eStartMonth.val(amonth3);
   let aday=dnew.getDate() ;
   eStartDay.val(aday);

   let eStartTimeAll= eTable.find('[name="scheduleStartTime"]');  // top row of table
   eStartTimeAll.attr('data-startvalue',beginDate);
   eStartTimeAll.html(ayear+'-'+amonth3+'-'+aday);

   let  endDateAll=parseInt(schList['endValueAll']);     // last row of table
   let ebottomRow=eTable.find('.scheduleBottomRow');
   let eupdateCol=ebottomRow.find('[name="updateCol"]');
   eupdateCol.attr('data-scheduleval',endDateAll);
   if (schList['doCalendar']!=1) {
      let millis= endDateAll  -beginDate;
      let t1=millis/1000;
      let dd1=t1/(24*60*60);
      eupdateCol.html('<tt>'+dd1+'</tt>');
   } else {
      let dnew2=new Date(endDateAll);
      let byear=dnew2.getFullYear();
      let bmonth3=dnew2.toLocaleString([], { month: 'short'});
      let bday=dnew2.getDate() ;
      let tt1=byear+'-'+bmonth3+'-'+bday;
      eupdateCol.html('<tt>'+tt1+'</tt>');
   }

// customize "break" title
   let eul=eList.find('[name="nschedule_recoList"]');
   let ebreak1=eul.find('.cschedule_break');
   ebreak1.attr('title','Add a break -- of this many days. You can also specify a short description');

   let ebreak2=eul.find('.cschedule_sayBreak_icon');
   ebreak2.html('&#128197;');

//    //&#128197; calendar        &#128347; clock    9202 timer clock


  let ePreview1=$('#mySchedule_format');
  let ecalendarFmt=ePreview1.find('[name="schedule_format_calendar"]');
  let eNthWeekFmt=ePreview1.find('[name="schedule_format_nthWeek"]');
  let eshowYearFmt=ePreview1.find('[name="schedule_format_showYear"]');
  let edayOfWeekFmt=ePreview1.find('[name="schedule_format_dayOfWeek"]');
  ecalendarFmt.prop('checked',false);     // by default all options not checekd
  eNthWeekFmt.prop('checked',false);    eshowYearFmt.prop('checked',false);   edayOfWeekFmt.prop('checked',false);

   if (schList['doCalendar']==1) {            // year & day of week only canbe checked in calendar mode
       ecalendarFmt.prop('checked',true);
       if (schList['doShowYear']==1)  eshowYearFmt.prop('checked',true);
       if (schList['doShowWeekDay']==1)  edayOfWeekFmt.prop('checked',true);
   } else {
       if (schList['doShowWeek']==1)  eNthWeekFmt.prop('checked',true);   // nth week only can be checked in non-calendar mode
   }
   return 1;

}



//===========================
// setup schedule for 'quantity' mode
function applySelectSchedule_quantity(schList) {


  let eTable=$('#scheduleDivTable');
  let eList=$('#scheduleListDiv');
  let eSpan=eList.find('#schedulerList_mode_quantity');

  let defValueUse=parseInt(schList['defValueUse']);     // could be minutes, days, or quantity  -- not used if 'order' type
  let defAddBefore=parseInt(schList['defAddBefore']);           // could be minutes, days, or quantity   -- not used if 'order' type

   let es1=eSpan.find('[name="schedule_gapLength"]');
   if (es1.length>0) es1.val(defAddBefore);

   let es2=eSpan.find('[name="schedule_defaultDuration"]');
   if (es2.length>0) es2.val(defValueUse);

  let ecomma=eSpan.find('[name="schedule_addComma"]');
   let eUsek=eSpan.find('[name="schedule_useK"]');
   let eprefix=eSpan.find('[name="schedule_prefix"]');
   let epostfix=eSpan.find('[name="schedule_postfix"]');

  let ePreview1=$('#mySchedule_format');
   let ecommaF=ePreview1.find('[name="schedule_format_addComma"]');
   let eUsekF=ePreview1.find('[name="schedule_format_useK"]');
   let eprefixF=ePreview1.find('[name="schedule_format_prefix"]');
   let epostfixF=ePreview1.find('[name="schedule_format_postfix"]');


   ecomma.prop('checked',false);
   eUsek.prop('checked',false);
   ecommaF.prop('checked',false);
   eUsekF.prop('checked',false);

// doUseK  doAddComma    doPrefix    doPostFix

   if (schList['doUseK']==1) {
      eUsek.prop('checked',true);
      eUsekF.prop('checked',true);
   } else if (schList['doAddComma']) {
      ecomma.prop('checked',true);
      ecommaF.prop('checked',true);
   }  // else, nither are chekced
   eprefix.val(schList['doPrefix']);
   eprefixF.val(schList['doPrefix']);
   epostfix.val(schList['doPostFix']);
   epostfixF.val(schList['doPostFix']);

   let beginQ=parseInt(schList['startValueAll']);
    let eStartQ= eSpan.find('[name="schedule_startQuantity"]');
    eStartQ.val(beginQ);

   let eStartTimeAll= eTable.find('[name="scheduleStartTime"]');  // top row of table
   eStartTimeAll.attr('data-startvalue',beginQ);
   eStartTimeAll.html(beginQ);

   let endQ=parseInt(schList['endValueAll']);
   let ebottomRow=eTable.find('.scheduleBottomRow');
   let eupdateCol=ebottomRow.find('[name="updateCol"]');
   eupdateCol.attr('data-scheduleval',endQ);
   
   let sayval=endQ ;
   if (schList['doUseK']==1) {
        sayval=wsurvey.makeNumberK(endQ,10000,-1);
    } else if (iComma==1) {
        sayval=wsurvey.addComma(endQ);
   }
   eupdateCol.html('<tt>'+sayval+'</tt>');


 // customize "break" title
   let eul=eList.find('[name="nschedule_recoList"]');
   let ebreak1=eul.find('.cschedule_break');
   ebreak1.attr('title','Add an extra amount. You can also specify a short description');
   let ebreak2=eul.find('.cschedule_sayBreak_icon');
   ebreak2.html('&#128425;');     // pocket calculator

}

//===========================
// setup schedule for 'quantity' mode
function applySelectSchedule_order(schList) {

  let eTable=$('#scheduleDivTable');
  let eList=$('#scheduleListDiv');
  let eSpan=eList.find('#schedulerList_mode_order');

  let defValueUse= (schList['defValueUse']);     // could be minutes, days, or quantity  -- not used if 'order' type
  let es2=eSpan.find('[name="schedule_defaultDuration"]');

  if (es2.length>0) es2.val(defValueUse);
  

  let eAsc=eSpan.find('[name="schedule_sortAsc"]');
   let eDsc=eSpan.find('[name="schedule_sortDsc"]');
   let eNumber=eSpan.find('[name="schedule_numericSort"]');

// sortAsc  sortDsc  sortNumeric
   let ePreview1=$('#mySchedule_format');
   let eAscF=ePreview1.find('[name="schedule_sortAsc"]');
   let eDscF=ePreview1.find('[name="schedule_sortDsc"]');
   let eNumberF=ePreview1.find('[name="schedule_numericSort"]');

   eAsc.prop('checked',false);
   eDsc.prop('checked',false);
   eNumber.prop('checked',false);
   eAscF.prop('checked',false);
   eDscF.prop('checked',false);
   eNumberF.prop('checked',false);

   if (schList['sortAsc']==1) {
     eAsc.prop('checked',true);
     eAscF.prop('checked',true);
     if (schList['sortNumeric']==1)  {
       eNumber.prop('checked',true);
       eNumberF.prop('checked',true);
     }
   } else if  (schList['sortDsc']==1 ) {
     eDsc.prop('checked',true);
     eDscF.prop('checked',true);
     if (schList['sortNumeric']==1)  {
       eNumber.prop('checked',true);
       eNumberF.prop('checked',true);
     }
   }

   let eul=eList.find('[name="nschedule_recoList"]');
   let ebreak1=eul.find('.cschedule_break');
   ebreak1.attr('title','Add an entry with this orderValue (with a name of `break`). You can also specify a short description');
   let ebreak2=eul.find('.cschedule_sayBreak_icon');
   ebreak2.html('&#127994;');     // amphora
}



//=============
// set the parameters in the Preview-format window
function applySelectSchedule_setPreviewFormats(schList) {
  let ePreview1=$('#mySchedule_format');

   let emaxh=ePreview1.find('[name="schedule_format_maxHeight"]');
   emaxh.val(schList['maxHeight']);

   let eheader=ePreview1.find('[name="schedule_format_Header"]');
   eheader.val(schList['Header']);

   let ehNames=ePreview1.find('[name="schedule_headerName"]');

   let fmtVars=schList['fmtVars'];
   let fmtVarsKeep=schList['fmtVarsKeep'];
   let colWidths=schList['colWidths'];

   for (let ieh=0;ieh<ehNames.length;ieh++)  {
       aeh=$(ehNames[ieh]);
       let vname=aeh.attr('data-varname');
       if (!fmtVars.hasOwnProperty(vname)) continue ; // should never happen,
       aeh.val(fmtVars[vname]);
       aeh.attr('data-varnamehdr',fmtVars[vname]);
       let eeli=aeh.closest('li');         // find the width and keep inputs
       if (fmtVarsKeep.hasOwnProperty(vname)) {         // should always be true
         let ekeep=eeli.find('[name="schedule_headerKeep"]');
         let qcheck= (fmtVarsKeep[vname]==1) ? true : false ;
         ekeep.prop('checked',qcheck);
       }

       if (colWidths.hasOwnProperty(vname)) {         // should always be true
         let ewide=eeli.find('[name="schedule_colWidth"]');
         let t1=parseInt(colWidths[vname]);
         ewide.val(t1);
       }
  }        // all the "column header" stuff
  return 1;
}

