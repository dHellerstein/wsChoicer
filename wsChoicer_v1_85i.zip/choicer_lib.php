<?php


// functions included by choicer .php files

//=========================
// retrieve an array of all files of a type (an extension) that are valid choicer's data files (xxxNNNN.ext)
// oldest files are earlier in the array. Thus [0] is oldest
// unlike getFileByType, this does NOT check for username
// each array row is [fullFileName,timestamp]
// thus [0] has the smallest timestamp
// if basedir specified -- the directory to search for aext files   -- with useProject/*.aext appended
//  eg: et $useProject='cars'  -- $aext='foo' and basedir="d:/www/stuff'   yields d:/www/stuff/cars/*.foo
//  to NOT append useProject/, set $useProject=''  -- $aext='foo' and basedir="d:/www/stuff' yields d:/www/stuff/*.foo)
// If not specified (or===false), look in curdir/data/useProject/submits
//

function getFileByType_all($aext,$useProject="",$basedir=false) {
  $filelist=[];
  if (substr($aext,0,1)=='.') $aext=substr($aext,1);
  $useProject=str_replace('\\','/',$useProject);

  if ($basedir!==false) {               // use basddir/useProject/...  (useProject can be''
      $basedir=str_replace('\\','/',$basedir);
      $try=$basedir.'/'.$useProject.'/*.'.$aext ;
  }  else {     // use default/useProject/
    $curDir=getcwd();
    $try= $curDir.'/data/'.$useProject.'/submits/*.'.$aext;
  }

  $try=str_replace('//','/',$try);

 $files = glob($try);

  $filesOrig=[];
  $filesInOrder=[];
 foreach ($files as $ii=>$afile) {            // read all .sug files (storing submitted info). Each file is usnique to a user
    $oof=file_get_contents($afile);
    $fname=pathinfo($afile,PATHINFO_FILENAME);
    $fnameTime=getFileByType_time($afile);         // not a proper file
    if ($fnameTime===false) continue;
    $filesInOrder[$ii]=$fnameTime ;
    $filesOrig[$ii]=$afile;            // the non-proper files are not included in this array
 }
 asort($filesInOrder,SORT_NUMERIC );         // sort by value, keys move along with values (an index sort)  - oldest first
 $filesUse=[];
 foreach ($filesInOrder as $ii=>$fnameTime) {            // read all .sug files (storing submitted info). Each file is usnique to a user
     $afile=$filesOrig[$ii];
     $filesUse[]=[$afile,$fnameTime];
  }
  return $filesUse ;
}

//========================
// retrieve the most recent type of a data file, possibly by user
// returns array, each element is [filename,#files] - filename being the most recent (of #files for this user)
// if no match, returns []
// Note that this works with filenames of the form xxxNNNN.aext : xxx any non-digits, NNNN digits, aext as specified
//  If xxxNNxNN is specified, the file is skipped. Or if xxx.aext
//  AND if NNNN is a unix time stamp before jan 1 2023, it is skipped
// if basedir specified -- the directyory to search for aext files   (usePRoject is ignored)
//  if not specified (or===false), look in curdir/data/useProject/submits
//
function getFileByType($aext,$username="*",$useProject,$basedir=false) {
  $filelist=[];
  $actualFiles=[];

  if (substr($aext,0,1)=='.') $aext=substr($aext,1);
  $useProject=str_replace('\\','/',$useProject);

  if ($basedir!==false) {               // use basddir/useProject/...  (useProject can be''
       $basedir=str_replace('\\','/',$basedir);
      $try=$basedir.'/'.$useProject.'/*.'.$aext ;
  }  else {     // use default/useProject/
    $curDir=getcwd();
    $try= $directory=$curDir.'/data/'.$useProject.'/submits/*.'.$aext;
  }
  $try=str_replace('//','/',$try);


//  $curDir=getcwd();
//  $directory=$curDir.$subdir ;
//   $try=$directory.'/*.'.$aext;

  $files = glob($try);

  foreach ($files as $ii=>$afile) {            // read all .aext files (storing submitted info). Each file is usnique to a user

    $fname=pathinfo($afile,PATHINFO_FILENAME);
    $fnameTime=getFileByType_time($afile);  // retunrs false if a problem
    if ($fnameTime===false) continue ;  // not a proper file

    $oof=file_get_contents($afile);
    $alines =explode("\n",$oof);

    foreach ($alines as $ii=>$aline) {

       $cline=trim($aline);
       if ($cline=='') continue;
       if (substr($cline,0,1)==';') continue  ;
       $bsp=explode(':',$cline,2);

       $mvid=strtolower(trim($bsp[0]));

       if ($mvid!='user'  && $mvid!='username') continue ;

       $auser=  strtolower(preg_replace('/[^a-zA-Z0-9_\.]/','', $bsp[1]));  // only characters, digits, . _

       if ($username=='*' || $username==$auser) {
         if (!array_key_exists($auser,$filelist)) $filelist[$auser]=[];
         $dd1=[$fnameTime,$fname];
         $filelist[$auser][]=$dd1;
         $actualFiles[$fname]=$afile;
       }

    }   // lines

  } // files

// filelist contains all files (of type ext) that belong to each user. All users if username='*', only specified user otherwise
// now go through each user, sort by date, keep largest (most recent)
  $matches=[];

  if (count($filelist)==0) return $matches;     // [] signals no match
  foreach ($filelist as $auser=>$tryfiles) {
       $sortme=[];
       foreach ($tryfiles as $ii=>$v2) {
         $sortme[$v2[0]]=$v2[1];
       }
       krsort($sortme,SORT_NUMERIC);
       $goo=reset($sortme);  // reset pointer
       $aat=$actualFiles[$goo];
       $matches[$auser]=[$aat,count($tryfiles),$tryfiles];
 }
 return $matches ;

}


//==============
// parses a choicer data file (xxxNNNNN.xxx); extracting the NNN "timestamp"
// returns false if NNNN is not found, is not a valid timestamp,etc
// otherwise, returns NNN
//
function getFileByType_time($afile) {          // retunrs false if a problem
   $fname=pathinfo($afile,PATHINFO_FILENAME);      // strip out .ext
   $intAt=strcspn($fname,'0123456789');     // find first digit in string
    if ($intAt>=strlen($fname))  return false  ;        // no time stamp in filename
    $fnameTime=substr($fname,$intAt);     // time of creation embedded in filename (after 'rec)
    if (!is_numeric($fnameTime))  return false   ; // something between xxx and .
    if (!isTimestamp($fnameTime,'2020/1/1')) return false ;          // too wierd, or too early

    return $fnameTime ;
}


//===========
// https://stackoverflow.com/questions/2524680/check-whether-the-string-is-a-unix-timestamp
// checks if timestamp is a valid timestampe AND is after mindate
// timestamp: a number (or a string number). NOT a date string (i.e.; NOT '2022/01/12')
//  $mindate is optional. If specified (and not logical false, should be valid date format (i.e. '2020/01/01') or a unix string (i.e; 1641945600)
// returns: 1 if valid date, 0 if valid date but before mindate, -1 if not a valid date (perhaps because timestamp is non-numeric
function isTimestamp($timestamp,$mindate=false) {
  if ($mindate!==false) {
  if (is_string($mindate)) {
    if (is_numeric($mindate)) {
       $mindate=intval($mindate);
      } else {
          $mindate=strtotime($mindate);
       }
     }
  }
    if(is_numeric($timestamp) && strtotime(date('Y-m-d H:i:s',$timestamp)) === (int)$timestamp) {
      if (!$mindate || $timestamp>$mindate)     return 1 ;
      return 0 ;
    } else {
        return -1  ;
    }
}

//=======================
// returns logical true if no html errors. Or, an array with error messages (somewhat cryptic)
// This is stringent. THus, <br> yields an error.
// Adapted from https://stackoverflow.com/questions/3167074/which-function-in-php-validate-if-the-string-is-valid-html
function checkValidHtml($string){
    $start = strpos($string, '<');
    $end = strrpos($string, '>', $start);

    if ($end !== false) {
        $string = substr($string, $start);
    } else {
        $string = substr($string, $start, strlen($string) - $start);
    }

    // xml requires one root node
    $string = "<test>$string</test>";

    libxml_use_internal_errors(true);
    libxml_clear_errors();
    $doc=simplexml_load_string($string);

    $nerrs=count(libxml_get_errors());
    if ($nerrs==0) return true;

// errors -- return array of message
    $xml = explode("\n", $string);
    $errors =libxml_get_errors();
    $errA=json_decode(json_encode($errors), true);

    $errsay=[];
    foreach ($errA as $goo=>$arf) {
       $anerr=$arf['message'];
       $errsay[]=$anerr;
    }

    return $errsay ;

//    return count(libxml_get_errors()) == 0;

}


//========================
// a var_dump alternative
function dump_debug($input, $collapse=false) {
    $recursive = function($data, $level=0) use (&$recursive, $collapse) {
        global $argv;

        $isTerminal = isset($argv);

        if (!$isTerminal && $level == 0 && !defined("DUMP_DEBUG_SCRIPT")) {
            define("DUMP_DEBUG_SCRIPT", true);

            echo '<script language="Javascript">function toggleDisplay(id) {';
            echo 'var state = document.getElementById("container"+id).style.display;';
            echo 'document.getElementById("container"+id).style.display = state == "inline" ? "none" : "inline";';
            echo 'document.getElementById("plus"+id).style.display = state == "inline" ? "inline" : "none";';
            echo '}</script>'."\n";
        }

        $type = !is_string($data) && is_callable($data) ? "Callable" : ucfirst(gettype($data));
        $type_data = null;
        $type_color = null;
        $type_length = null;

        switch ($type) {
            case "String": 
                $type_color = "green";
                $type_length = strlen($data);
                $type_data = "\"" . htmlentities($data) . "\""; break;

            case "Double": 
            case "Float": 
                $type = "Float";
                $type_color = "#0099c5";
                $type_length = strlen($data);
                $type_data = htmlentities($data); break;

            case "Integer": 
                $type_color = "red";
                $type_length = strlen($data);
                $type_data = htmlentities($data); break;

            case "Boolean": 
                $type_color = "#92008d";
                $type_length = strlen($data);
                $type_data = $data ? "TRUE" : "FALSE"; break;

            case "NULL": 
                $type_length = 0; break;

            case "Array": 
                $type_length = count($data);
        }

        if (in_array($type, array("Object", "Array"))) {
            $notEmpty = false;

            foreach($data as $key => $value) {
                if (!$notEmpty) {
                    $notEmpty = true;

                    if ($isTerminal) {
                        echo $type . ($type_length !== null ? "(" . $type_length . ")" : "")."\n";

                    } else {
                        $id = substr(md5(rand().":".$key.":".$level), 0, 8);

                        echo "<a href=\"javascript:toggleDisplay('". $id ."');\" style=\"text-decoration:none\">";
                        echo "<span style='color:#666666'>" . $type . ($type_length !== null ? "(" . $type_length . ")" : "") . "</span>";
                        echo "</a>";
                        echo "<span id=\"plus". $id ."\" style=\"display: " . ($collapse ? "inline" : "none") . ";\">&nbsp;&#10549;</span>";
                        echo "<div id=\"container". $id ."\" style=\"display: " . ($collapse ? "" : "inline") . ";\">";
                        echo "<br />";
                    }

                    for ($i=0; $i <= $level; $i++) {
                        echo $isTerminal ? "|    " : "<span style='color:black'>|</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }

                    echo $isTerminal ? "\n" : "<br />";
                }

                for ($i=0; $i <= $level; $i++) {
                    echo $isTerminal ? "|    " : "<span style='color:black'>|</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                }

                echo $isTerminal ? "[" . $key . "] => " : "<span style='color:black'>[" . $key . "]&nbsp;=>&nbsp;</span>";

                call_user_func($recursive, $value, $level+1);
            }

            if ($notEmpty) {
                for ($i=0; $i <= $level; $i++) {
                    echo $isTerminal ? "|    " : "<span style='color:black'>|</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                }

                if (!$isTerminal) {
                    echo "</div>";
                }

            } else {
                echo $isTerminal ? 
                        $type . ($type_length !== null ? "(" . $type_length . ")" : "") . "  " : 
                        "<span style='color:#666666'>" . $type . ($type_length !== null ? "(" . $type_length . ")" : "") . "</span>&nbsp;&nbsp;";
            }

        } else {
            echo $isTerminal ? 
                    $type . ($type_length !== null ? "(" . $type_length . ")" : "") . "  " : 
                    "<span style='color:#666666'>" . $type . ($type_length !== null ? "(" . $type_length . ")" : "") . "</span>&nbsp;&nbsp;";

            if ($type_data != null) {
                echo $isTerminal ? $type_data : "<span style='color:" . $type_color . "'>" . $type_data . "</span>";
            }
        }

        echo $isTerminal ? "\n" : "<br />";
    };

    call_user_func($recursive, $input);
}

//====================
// make an html file and return to caller (for display in a new window)

function goMakeHtml($arr,$scheduleTopHeader,$notEncode=0,$rootSel='',$atitle="A schedule") {
 $oof=[];

 foreach ($arr as $avar=>$avalue) {
   $oof[$avar]=$avalue ;
 }
 if ($notEncode==0) {
  $linkIcons= json_decode($oof['linkIcons'],true); ;
 } else {
   $linkIcons=$oof['linkIcons'];
 }
 
 $suppressLocalDownload=$oof['suppressLocalDownload'];
  $dakey=$oof['keycode'];

$s2="<!DOCTYPE HTML> \n";
$s2.="<html><head><title>$atitle </title> \n";
$s2.='<meta charset="utf-8">'."\n";
if ($rootSel!='') {
  $s2.='<base href="'.$rootSel.'" >'."\n";
}
$s2.="\n";

$s2.='<script type="text/javascript" src="lib/jquery-3.6.0.min.js"></script>'."\n" ;
$s2.='<script type="text/javascript" src="lib/md5b.js"></script>'."\n" ;
$s2.='<script type="text/javascript" src="lib/wsurvey.utils1.js">  </script> '."\n" ;
$s2.='<script type="text/javascript" src="choicer_htmlSchedule.js"></script> '."\n" ;

$s2.='<script type="text/javascript">'."\n" ;
$s2.="window.onload=initHS0  \n" ;

$s2.="function initHS0() { \n ";
$s2.='  initHS(\''.$dakey.'\');'."\n";
$s2.="} \n ";
$s2.='</script>'."\n" ;


//$s2.='<script type="text/javascript" src="choicer_lib.js"></script> '."\n" ;
$s2.="\n";

$s2.='<link rel="stylesheet" type="text/css" href="css/choicer_htmlSchedule.css" />'."\n" ;;
$s2.="\n";

$s2.='</head>'."\n" ;
$s2.="\n";

$s2.='<body>'."\n" ;
$s2.="\n";

$s2.='<div id="scheduleDivMainHeader" class="cscheduleDivMainHeader"> '."\n" ;
$s2.='<span name="ischeduleHeaderName" style="font-weight:700">';
$s2.=$scheduleTopHeader   ;
$s2.='</span> '."\n" ;


// if download local NOT suppressed
if ($suppressLocalDownload==2) {
  $s2.='  <span id="askUnlockCode" style="margin:3em 2px 2em 3px">For full view, enter the unlock code:'."\n" ;
  $s2.='  <input type="text" size="12" title="Enter the unlock code provided by the admin" id="ischeduleUnlockCode">'."\n" ;
  $s2.='  and <button title="click after entering code" data-keycode="'.$dakey.'" onClick="scheduleUnlockCode(this)">Submit it </button>'."\n" ;
  $s2.='  </span>'."\n" ;
}

$s2.=' <span style="float:right;margin-right:3em;border:1px solid gray;height:1.5em"> '."\n" ;
$s2.=' <span class="cscheduleKey"> '."\n" ;
$s2.='   <b>Key:</b>  '."\n" ;
$s2.=' </span>'."\n" ;

$daSchedule=$oof['htmlSchedule'];
foreach ($linkIcons as $aname=>$img) {

// is this used
  $ispot=strpos($daSchedule,$img);
  $astyle='';
  if ($ispot===false) continue ; // not used in this schedule
  $s2.='<span class="cscheduleKey"> '. "\n" ;
  $s2.=' <img src="'.$img.'" '.$astyle.' alt="stream (or download) from ... " width="30" height="20"> <tt>'.$aname.'</tt>'."\n" ;
  $s2.='</span> '."\n" ;
}

$s2.='</span>'."\n" ;  // the float right set of images (the key)

$s2.='</div>'."\n" ;

$s2.='<br clear="all">'."\n" ;
$s2.="\n";

$s2.='<div id="scheduleDivMainBody">'."\n" ;
$s2.=$daSchedule ;
$s2.="\n";
$s2.='</div>';

$s2.="\n</body>\n</html>\n" ;

return $s2 ;
}

//===============
// remove the cache file -- this is called whenever any kind of new content is added/modified in a project

function removeCacheFile($useProject) {

  $curDir=getcwd();
  $cacheDir=$curDir.'/data/'.$useProject.'/cache';   // customVars, etc ...
  $cacheFiles=getFileByType_all('csh','',$cacheDir) ;
  foreach ($cacheFiles as $i1=>$ss) {
     $afile=$ss[0];
     unlink($afile);
  }
  return count($cacheFiles);


}