<?php
// works with ranks  page.

session_start() ;
ob_start();

// add some php functions
$curDir=getcwd();
$libfile=$curDir.'/choicer_lib.php';
require_once($libfile);


$username=$_REQUEST['username'];
$useProject=$_REQUEST['theProject'];
$todo=$_REQUEST['todo'];     //   updateRates is only one for now
 if ($todo=='saveRanks') {
      doSaveRanks($username,$useProject);
      exit;
  }
 exit;

 //=-=========================== _sortuse
// save rankings for a user
function doSaveRanks($currentUser,$useProject) {
 $atime=time();
 $updateDate=date("Y-m-d H:i") ;
 

$gotNext=0;$gotTop=0;
$top9=[]; $next9=[];
 if (array_key_exists('next9',$_REQUEST)) {
    $next9=$_REQUEST['next9'] ;
    $gotNext=1;
 }
 if (array_key_exists('top9',$_REQUEST)) {
    $top9=$_REQUEST['top9'] ;
    $gotTop=1;
 }
 $amess="; top9 and next9 rankings \n";
 $amess.="username: $currentUser \n";
 $amess.="date: $updateDate \n";

 if ($gotTop==1) {
   $amess.='top9: '.implode(',',$top9)."\n";
 } else {
   $amess.='top9: '."\n";
 }
 if ($gotNext==1) {
   $amess.='next9: '.implode(',',$next9)."\n";
 } else {
   $amess.='next9: '."\n";
 }

 $amess.="comment: ".$_REQUEST['comment']." \n";

   $curDir=getcwd();
   $doFile=$curDir.'/data/'.$useProject.'/submits/rank'.$atime.'.rnk';
   $fp=fopen($doFile,'w');
// $fp=fopen('submits/rank'.$atime.'.rnk','a');

  fwrite($fp,$amess);
  fclose($fp);
  removeCacheFile($useProject);  // remove the .csh file

 $asay= "Saved ".count($top9).' top9 entries, '.count($next9)." next9 entries.  @ $updateDate ";


  ob_end_clean();   // remove prints and other crap
  $vsuggests=json_encode($asay, JSON_UNESCAPED_UNICODE);  // encode for web transmission
  print $vsuggests;
  exit;

  exit;
}

