<?php

//  :::::::::::: admin settable parameters (php). Backup version  ::::::::::::
// params/choicer_params.php  in a data/projectName directory is the working version (that should be modified by the admin --
// typically using  choicer's on-line tools)
// This is meant for emergencies. And it is used when creating or modifiying a project



// ======================== begin  admin settable parameters ==========================


$checkValidNames=0;       // Set this to 1 to enable use of $validNames

$validNames=[];      // associative array of members allowed to access this site

$downloadUsers=['*'=>1];   // associative array of members allowed to do private downloads

$privateDownloadLink='';  // prefix used when forming links to download from the "local (private) server"


// custom variables (name=>description). Variables names MUST be lower case.
$customVars=[
  'duration'=>'Duration in minutes ',
] ;

// custom variables display width (name=>width in em)
$customVarsLength=[
  'duration'=>7,
];


// custom variables required (name=>requireCode of 1, 11 ,2, 3, or 4)
$customVarsRequired=[
  'duration'=>2,
];


// variable (in customVars) to use in scheduler. Ignored if not match (must be lower case)
$customSchedulerVar='duration';
$customSchedulerDefault=60;

$schedulerType='time';               // type of schedule: time,date,quantity,order

// variables to display in formated schedule. varname:columnWidth%
// Specify in column order (first is leftmost column)
$schedulerShow=[
  'rowNumberChoice'=>2,
  'Name'=>15,
  'Start'=>9,
  'Links'=>15,
  'descNotes'=>40
] ;

$schedulerNoShow='' ;

// a string to show at the top of published schedules
$scheduleTopHeader="A simple schedule "  ;


// A long string (without " characters).

$siteIntro="
This is a site intro.
";


// ======================== end of admin changable parameters ==========================

 ?>