<?php

  //md5 of the Admin user password
 //  set =false to invoke `wsChoicer initialzation` as the home page -- where you can specify a new admin password 
$adminPwd=false ;

// '*' means `by default: show list of projects` 
// ?project=projectName in a url will override this  

$defaultProject="*" ;

?> 

