<?php
// choicer_params : password (MD5) parameters.
// This is used when wsChoicer creates a new project -- a modified copy of it is 
// written to a project specific params/ directory
// This file should NOT be modified!

// md5 of the membername password (rerquired if passwordUse=1 (set in choicer_params.js)
$memberPassword='' ;

// md5 of keycode used to enable local download. Used if suppressLocalDownload=2 (set in choicer_params.js)
$localDownloadKeycode='' ;


 ?>