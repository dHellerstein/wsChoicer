//  :::::::::::: admin settable parameters (javascript). Backup version  ::::::::::::
// params/choicer_params.js (in a data/projectName) are the working versions (that should be modified by the admin --
//   typically using  choicer's on-line tools)!
// This is meant for emergencies. ANd it is used when a project is created or modified


//
// ::::::::::::::::::::::::::::::::::::::::::::::::::::


//  Start of admin settable parameters  ........................

var autoShowHelp= 0  ;          //  0/1 : 1 to display general help box on logon
var autoShowIntro= 0  ;          //  0/1 : 1 to display introduction on logon
var autoStatusMessages= 0 ;      // 0/1 : 1 to display status messages (on logon), 2: display if messages were written, >2 to display and fadeout
var compressHeaderRow=0  ;      // 0/1 : 1 display compressed header row
var defaultRate=2;              // 1/2/3/4
var disableNewSuggestions=0 ;   // 0/1   : 0 to enable, 1  to disable : adding   new suggestions
var enableAlertRate=0  ;         //  0/ n>0 :  >0 to if not this many alerts
var enableAlertRank=0  ;         // 0/ n>0 : >0 if not this many rankings
var enableNewUserCheck=0 ;       // 0/1/2/3 : 1 to enable new user check
var enterToDo='sugg' ;           // 'sugg','rank','rankAll','none','comm' : 'sugg' is used if not one of these

var noSubmitterInNotes=0;         // 0/1  : 1 suppress display  on suggestions page
var passwordUse=0;               // 0/1 (1 to enable)
var rankingsLinearMenu='b' ;     // a b or c: chose how to display personal ranking choices. 'a'  is used if not recognize
var reco_ranksOn_1Line=0 ;            // 0/1/2 : display top9 and middle9  on 2, 1, or 1 if possible lines

var skipBlankCategories=1    ;  // 0/1 :   1 to retain current categories (not set to '')

var suppressLocalDownload=1 ;    // 0: display, 1: do not, 'md5OfKeycode' : md5 of a keycode to  allow user to continue . eg '1a54c1036ccb10069e9c06281d52007a' if keyCode='keycode'

// Some text strings: to customize headers, etc
var choiceNameSay='Choice';                       // What are being chosen. Signgular. For example: "Choice", or "Book"
var choiceNameSay2='Choices';                    // What are being chosen. Plural For exaale: "Choices", or "Books"
var documentTitle="Choicer: solicit suggestions ... rate ... rank ...  recommend  ... schedule! "  // title displayed at top of browser

var siteAdminContact="admin name";               // contact info for the site administrator
var thisSiteName='Our site'
var welcomeGroupName="The choice club "  ;       // the name of this group. Can have html. Should be short (<20 characters). I.e.; "The <b>2023</b> Choices "

var logonBox_otherLinks=''      ;   // a string with links to related sites. Can be multiple lines long
    logonBox_otherLinks+=' ';

var helpBox_otherLinks=''     ;    // a string with links to related sites. Can be multiple lines long
  helpBox_otherLinks+='';



// ...............  DO NOT CHANGE BELOW HERE

// a quality control check. DO NOT CHANGE!
var choicerParams_read=1;
