// show main (and other) containers functions

//===============
// this is called by the show mainContainer functions
// data-infobox should also be closed (they might be info, or help that is a child of the document (so
// sibling to a mainContainer), but are associated with a data=content (a mainContainer)
// They should be closed!
// detailsRating  ihelpRecoDescribe  ihelpRecoSort iSuggestionsHelpMore   whatIsDraftReco
// ishowLinkMenu_popupReportDesc ishowLinkMenu_popupReportDesc   showLinkMenu
// inewUserMessage statusDiv


function showMainContainer(i1,mainId,buttonId,todoName) {

   if (arguments.length<4) {
      alert('showMainContainer does not have 4 arguments');
      return  false ;
   }

   let eUse=$(mainId);
   let isVis=eUse.is(':visible');   // used below (a hack to deal with toggle)
   let ehelpb= $(buttonId);

   if (i1!=4) {                      // 4 means "open 2nd page, that complements a currently visible one. So no cleanup!
     $('[name="mainContainer"]').hide();  // hide all maincontainers
     $('[data-infobox]').hide();  // hide all "infoboxes" (non mainContainer children of body) -- do NOT hide helpboxes!
     let eTopRows=$('.cTopRowButton');
     eTopRows.removeClass('cTopRowButtonChosen');
   }

   if (i1==0) eUse.hide();                // off
   if (i1==1) {
      if (isVis==false)   eUse.toggle();               // toggle back on
   }
   if (i1==2) eUse.show();                // turn on
   if (i1===4) {
       eUse.toggle();         // toggle
       let nowVis=eUse.is(':visible')    ; // doesn't get here if i1=4
       return nowVis;
   }

   let nowVis=eUse.is(':visible')    ; // doesn't get here if i1=4
   if (nowVis) {   // now it is visible
      lastToDo=todoName ;
      $(document).data('showingMain',[eUse,todoName,0]) ;
      ehelpb.addClass('cTopRowButtonChosen');
   }

    return nowVis;

}



//===================
// show suggestions container
// 0: close, 1 : toggle, 2: show  , 4: special -- toggle view but do NOT remove other views or touch the buttons
// doreset=1. Reset size of table. i1 is ignored. If not specified, or anything but 1, use i1
function showCurrentSuggestions(i1,doreset) {

   if (arguments.length<1) i1=0;
   if (arguments.length<2) doreset=false;

   if (doreset!==false)   {        // reset sizes (check for visiblity first)
      let ediv=$('#suggestionsDiv') ;
      if (!ediv.is(':visible')) return 0  ;  // not shown so do nothing. This should never happen
      xx=wsurvey.fitInParent('#existingEntriesDivTableOuter',{'desiredHeight':'100%','padding':'6em'});
      return 1 ;
   }

// hide/toggle/show...
   let astatus= showMainContainer(i1,'#suggestionsDiv','#topRowButton_view','view') ;
   window.scrollTo(0, 0);   // top of screen..
   if (!astatus) return 0 ; // nowhidden

   $('.cDivNavi').show();   // view 
  $('.cSideButtonsV2').prop('disabled',false);

// resize
    xx=wsurvey.fitInParent('#existingEntriesDivTableOuter',{'desiredHeight':'100%','padding':'6em'});

    return 1;

}

//===================
// show ratings container
// 0: close, 1 : toggle, 2: show
function showRatings(i1,doreset) {
   let headerheight=$('#ratingsDivMainHeader').height();

   if (arguments.length<1) i1=0;
   if (arguments.length<2) doreset=false;
 ;
   if (doreset!==false)   {        // reset sizes (check for visiblity first)
      let ediv=$('#ratingsDiv') ;
      if (!ediv.is(':visible')) return 0  ;  // not shown so do nothing. This should never happen
      xx=wsurvey.fitInParent('#ratingsDivTableOuter',{'desiredHeight':'100%','padding':'7em'});
      return 1;
   }

// else clear and view
   astatus= showMainContainer(i1,'#ratingsDiv','#topRowButton_rate','rate') ;
   window.scrollTo(0, 0);   // top of screen..
   if (!astatus) return 0 ; // nowhidden

   $('.cDivNavi').show();   //rate
     $('.cSideButtonsV2').prop('disabled',false);

// resize
    xx=wsurvey.fitInParent('#ratingsDivTableOuter',{'desiredHeight':'100%','padding':'7em'});

    return 1;

}

//===================
// show rankings container  -- if not visible, retrieve latest rankings
// 0: close, 1 : toggle, 2: show

function showRankings(i1,doreset) {
   if (arguments.length<1) i1=0;
   if (arguments.length<2) doreset=false;
   let  listSizes=[0.20,0.28,0.36];
   let tableSizes=[0.78,0.70,0.62];

   if (doreset!==false)   {        // reset sizes (check for visiblity first)
     let elist=$('#myRankingsListDiv');
     let eouter= $('#rankingsDivTableOuter');
     if (!eouter.is(':visible')) return 0  ;  // not shown so do nothing. This should never happen

     let scHeight=parseInt($(window).height());
     let topList=parseInt(elist.offset().top);
     let canuse=(scHeight-topList)-40;   // 40 to deal with padding etc

     let listFrac=listSizes[doreset];
     let tableFrac=tableSizes[doreset];

     let heightList=Math.max(parseInt(canuse*listFrac),36);
     elist.height(heightList+'px');

     let heightTable=Math.max(parseInt(canuse*tableFrac),56);
     eouter.height(heightTable+'px');

     return 1;
   }

// else, clear and view
   let isvis=showMainContainer(i1,'#rankingsDiv','#topRowButton_rank','rank') ;
   window.scrollTo(0, 0);   // top of screen..
   if (!isvis) return 0;

   let elist=$('#myRankingsListDiv');
   let eouter= $('#rankingsDivTableOuter');
   if (!eouter.is(':visible')) return 0  ;  // not shown so do nothing. This should never happen

   let scHeight=parseInt($(window).height());
   let topList=parseInt(elist.offset().top);
   let canuse=(scHeight-topList)-70;   // 70 to deal with padding etc

     let listFrac=listSizes[0];
     let tableFrac=tableSizes[0];

   let heightList=Math.max(parseInt(canuse*listFrac),36);
   elist.height(heightList+'px');

   let heightTable=Math.max(parseInt(canuse*tableFrac),56);
   eouter.height(heightTable+'px');
   $('.cDivNavi').show();   //rank
     $('.cSideButtonsV2').prop('disabled',false);

}


//======================
// show the reocmmendations page

function showRecommendations(i1,doreset ) {

   if (arguments.length<1) i1=0;
   if (arguments.length<2) doreset=false;

   let  listSizes=[0.20,0.32,0.40];
   let tableSizes=[0.78,0.65,0.57];

   if (doreset!==false)   {        // reset sizes (check for visiblity first)
      let elist=$('#myRecommendationsListDiv');
      let eouter= $('#theRecommendationsTableOuter');
      if (!eouter.is(':visible')) return 0  ;  // not shown so do nothing. This should never happen

      let scHeight=parseInt($(window).height());
      let topList=parseInt(elist.offset().top);
      let canuse=(scHeight-topList)-40;   // 40 to deal with padding etc

     let listFrac=listSizes[doreset];
     let tableFrac=tableSizes[doreset];

     let heightList=Math.max(parseInt(canuse*listFrac),36);
     elist.height(heightList+'px');

     let heightTable=Math.max(parseInt(canuse*tableFrac),56);
     eouter.height(heightTable+'px');
     return 1;
   }

// if here, clear and view
   let isvis=showMainContainer(i1,'#recommendationsDiv','#topRowButton_recommendation','reco') ;
   window.scrollTo(0, 0);   // top of screen..
   if (!isvis) return 0;
   showRecommendations_check1(reco_ranksOn_1Line=2 )  ;   // check if can fit on one line

  let elist=$('#myRecommendationsListDiv');
   let eouter= $('#theRecommendationsTableOuter');

   let scHeight=parseInt($(window).height());
   let topList=parseInt(elist.offset().top);
   let canuse=(scHeight-topList)-70;   // 70 to deal with padding etc

   let listFrac=listSizes[0];
   let tableFrac=tableSizes[0];

   let heightList=Math.max(parseInt(canuse*listFrac),36);
   elist.height(heightList+'px');

   let heightTable=Math.max(parseInt(canuse*tableFrac),50);
   eouter.height(heightTable+'px');
   $('.cDivNavi').show();   //reco
     $('.cSideButtonsV2').prop('disabled',false);

}


//===================
// show ratings container
// 0: close, 1 : toggle, 2: show
function showSchedule(i1,doreset) {
      //  wsurvey.dumpObj(allRecos,1,'allr2');
   if (arguments.length<1) i1=0;
   if (arguments.length<2) doreset=false;

// make sure choicer_schedule.js is loaded.. if not, load it
  let ttype=typeof(makeSchedule);
  if (ttype!='function')  {
   let daJs='choicer_sched.js';
   $.getScript(daJs)
     .done(function(a,b,c) {
       makeSchedule(2);
       let esched1=$('#scheduleDivTableOuter');
       esched1.on('click',scheduleTableEventHandler);
       let esched2=$('#scheduleListDiv');
       esched2.on('click',scheduleListEventHandler);
       showSchedule(i1,doreset);  // call again -- it will skip this section (since sched.js is now loaded!)
       return 0;
   })
   .fail(function(a,b,c) {
       initJsReadFail(a,b,c,daJs);
        return 1;
   });
   return 1;   // loading _schedule.js.

 }

// if here, choicer_schedule.js has already been loaded

   if (doreset!==false)   {        // reset sizes (check for visiblity first)

      let  listSizes=[0.30,0.40,0.20,];
      let tableSizes=[0.68,0.57,0.78];
      let elist=$('#scheduleListDiv');
      let eouter= $('#scheduleDivTableOuter');
      if (!eouter.is(':visible')) return 0  ;  // not shown so do nothing. This should never happen

      let scHeight=parseInt($(window).height());
      let topList=parseInt(elist.offset().top);
      let canuse=(scHeight-topList)-40;   // 40 to deal with padding etc

     let listFrac=listSizes[doreset];
     let tableFrac=tableSizes[doreset];

     let heightList=Math.max(parseInt(canuse*listFrac),36);
     elist.height(heightList+'px');


//  14 maRCH -- fitInParent still a bit flakey
 //   xx=wsurvey.fitInParent('#scheduleDivTableOuter',{'desiredHeight':'110%','padding':'6em'});
//    window.scrollTo(0, 0);   // top of screen..

     let heightTable=Math.max(parseInt(canuse*tableFrac),56);
     eouter.height(heightTable+'px');
     return 1;
   }



// else clear and view
   astatus= showMainContainer(i1,'#scheduleDiv','#topRowButton_rate','sched') ;
   window.scrollTo(0, 0);   // top of screen..
   if (!astatus) return 0 ; // nowhidden

   $('.cDivNavi').show();   //sched
     $('.cSideButtonsV2').prop('disabled',false);

// resize

    xx=wsurvey.fitInParent('#scheduleDivTableOuter',{'desiredHeight':'100%','padding':'7em'});

    return 1;

}




//-===============
// show the generic comments container
// 0: close, 1 : toggle, 2: show
function showComments(i1) {

   if (arguments.length<1) i1=0;
   let isvis=showMainContainer(i1,'#genericComments','#topRowButton_comm','comm') ;
   window.scrollTo(0, 0);   // top of screen..
   if (i1==4) {
     $('.genericComments_canhide').hide();
   } else {
     $('.genericComments_canhide').show();
   }
   
   $('.cDivNavi').show();   //rank
     $('.cSideButtonsV2').prop('disabled',true);  // these are not applicable to comments view

   return isvis ;

}


//-===============
// show the generic comments container BELOW the view suggestions table. Add or remove a "scroll down" button
// 0: close, 1 : toggle, 2: show
function showCommentsInView(i1) {
    let qq=showComments(4) ;
    if (qq) {
       $('#iscrollToComments').show();
       $('[name="commentGoTopButton"]').show();
    } else {
       $('#iscrollToComments').hide();
       $('[name="commentGoTopButton"]').hide();
    }
}


//==========
// scroll down to 'generic comments under view table '
function scrollToComments(ii,iduration) {
  if (arguments.length<2) iduration=251;
  let e1=$('#genericComments');
  let ape=e1.offset().top;
  let ape2=parseInt(ape)-20;
   $('html, body').animate({'scrollTop':ape2+'px'},iduration);
}

// ==================
// show the add a suggestions table
// 0: close, 1 : toggle, 2: show

function showNewSuggestions(i1) {

   if (arguments.length<1) i1=0;
   let isvis=showMainContainer(i1,'#newSuggestionsDiv','#topRowButton_add','new') ;
   window.scrollTo(0, 0);   // top of screen..
   $('.cDivNavi').hide();  // for new suggestions, the navi bar is not used



}

//==========================
// not main content, but in top bar


//===================
// show main help
// 0: close, 1 : toggle, 2: show  , >2 show and fade out in i1 milliseconds
// this can coexist with main content (it floats on top)

function showMainHelp(i1) {

   let ehelpb= $('#topRowButton_help');

   let xx= $('#mainHelp');
   if (i1==0) {
       ehelpb.removeClass('cTopRowButtonChosen');
       xx.hide();
       return 1;  
   }

   if (i1>2)  {           // a fadeout
      ehelpb.removeClass('cTopRowButtonChosen');
      xx.show();
      xx.fadeOut(i1,function(){ });         // could do a completeion function if need be
  }

// toggle, or explcit show
   let qvis=xx.is(':visible') ;
   if (i1==1)  {              // toggle
     if (qvis) {                  // visible .. so hide
         ehelpb.removeClass('cTopRowButtonChosen');
         xx.hide();
         return 1;  
     }
   }

// not visible. show...
   wsurvey.wsShow.show('#mainHelp'); 

   ehelpb.addClass('cTopRowButtonChosen');

   window.scrollTo(0, 0);   // top of screen..
}

//==================
// show info on submissions, etc
function showMemberInfo(i1,i2) {
  let qvis;
  if (arguments.length<2) i2=0;
  let eStatus=$('#memberInfoDiv');
  eStatus.stop(true,true);  // stop any current animation
  if (i1==0)  {
    wsurvey.wsShow.hide(estatus); // eStatus.hide();  
    return 1;
  }
  if (i1==1) {
    qvis=eStatus.is(':visible');
    if (qvis) {
      wsurvey.wsShow.hide(estatus); // eStatus.hide();
 //     eStatus.hide();
      return 1;
    }
  }

// else show
    wsurvey.wsShow.show('#memberInfoDiv',1);

   if (i2==0) i2=1;  // basics
   showMemberInfoMore(2,i2)   ;

}

//====== more member info
// ido: 0=hide, 1=toggle, 2=show
// iwhich: 1 = basics usageStats_basic
//         2  = user basics  usageStats_members
//         3 = choices  usageStats_choices

 function showMemberInfoMore(ido,iwhich) {

    let emores=$('.cmemberInfoDivMore');
    emores.hide();

   let divids=['','#usageStats_basic','#usageStats_members','#usageStats_choices'];
   let ado=divids[iwhich];
   let eMore=$(ado);
     eMore.show(); 

 }

// =======================
// show  the add general comments box
// xx=0 : hide.
// otherwise, toggle
function showAddGeneralComment(xx) {
  let e1=$('#addGeneralComment');
  if (xx==0) {
    e1.hide();
  } else {
    e1.toggle();
  }
}


//====================
// hints on navigation buttons
function showNaviHelp(ith,doclose) {
  if (arguments.length<2) doclose=0;
   if (ith==1) {
     let e1=$('#naviButtonHelpS');
     if (doclose==0){
       e1.toggle();
     } else {
        e1.hide();
     }
   } else {
     let e1=$('#naviButtonHelpR');
     if (doclose==0){
       e1.toggle();
     } else {
        e1.hide();
     }
   }
 }


 //=================
// status box
// 0: close, 1 : toggle, 2: show, >2 : show, then fade out over this duration (milliscecones)
// if justFirst=1, only show the most recent status mesage
function showStatusMessage(i1,justFirst) {
  if (arguments.length<2) justFirst=0;
// hide is simple. ..
    if (i1==0)  {
      wsurvey.wsShow.hide('#statusDiv');
      return 1;
    }

 let amess='<ul id="istatusMessageUL" class="boxList" data-got1="0"> ';
 //    let a1={'message':amessage,'onlyOnce':onlyOnce, 'time':nowtime};
 let iend= statusMessageList.length-1 ;

 for (let im=iend;im>=0;im--) {
    let a1=statusMessageList[im];
    let ali;
    let amessage=a1['message'];

    if (im==iend)  {             // most recent message can be special
       if (justFirst==1) {
         ali='<li class="statusMessage_line1" title="@ '+a1['time']+'">'+amessage+'</li>'; 
       } else {
         ali='<li   title="@ '+a1['time']+'">'+amessage+'</li>';
       }
    } else {   // not the first... maybe suppress?
        if (a1['onlyOnce']==1) {     // only display if is the most recent message?
          ali='<li  class="justOnce" style="display:none"" title="@ '+a1['time']+'">'+amessage+'</li>';
        } else {
           if (justFirst==1) {    // always display UNLESS justFirst is enabled
              ali='<li  class="justOnce" style="display:none"" title="@ '+a1['time']+'">'+amessage+'</li>';   //just first on, don't dispplay (but display otherwise)
           } else {
              ali='<li title="@ '+a1['time']+'">'+amessage+'</li>';
           }
        }     // onlyonce
     }       // not most recent
     amess+=ali;
  }
  amess+='</ul>';

  let eStatusMess= $('#statusMessage_message');
  eStatusMess.html(amess);

  let eStatus=$('#statusDiv');
  eStatus.stop(true,true);  // stop any current animation

   if (i1==0)   wsurvey.wsShow.hide(eStatus);
   if (i1==1)   wsurvey.wsShow.show(eStatus,1);    // toggle
   if (i1>=2)   wsurvey.wsShow.show(eStatus,2);   // show

   if (eStatus.is(':visible')) eStatusMess.focus();

   if (i1>3)  wsurvey.wsShow.hide(eStatus,i1);       // fadeout

 
}


//==========================
// resize status message box
function statusMessageResize(ido) {
  if (ido==1) {
     let ess=$('#statusDiv');
     ess.toggleClass('cStatusDivBig');
     return 1;
  }
  if (ido==3) {
    let e2=$('#statusMessage_message');
    let egoo=e2.find('.justOnce');
    egoo.toggle();
    return 1;
  }

  wsurvey.displayInNewWindow('#statusDiv' );
}

// =================== schedule stuff


//============
// show admin menu
function showAdminMenu(ido) {
 
  let eAdmin=$('#myadminMenu');
  eAdmin.stop(true,true);  // stop any current animation

  if (ido==0)   eAdmin.hide();
  if (ido==1)   eAdmin.toggle();
  if (ido==2)   eAdmin.show();

  if (eAdmin.is(':visible')) {
     let arfRemove=wsurvey.dumpObj(removeChoices,'var','Removed choices');
    let arfDiscard=wsurvey.dumpObj(discardedChoices,'var','Discarded users (they are not in validNames) -- their suggestions are NOT used  ');
    let amess='<hr><pre>'+arfRemove+'</pre><hr><pre>'+arfDiscard+'</pre>';
    amess+='<hr> # ratings dropped (of discarded, or removed, suggestions) =<tt> '+nMissingRates+'</tt> ' ;

    let nRanksDiscard=allRanks['nRanksDiscard'];
    let nRankersDiscard=allRanks['nRankersDiscard'];
    amess+='<hr>'+nRankersDiscard+' users had their rankings discarded.  '+nRanksDiscard+' ranks were discarded from valid users';

    let nRecosUserDiscard=allRecos['nRecoUsersDiscard']  ;
    let nRecosDiscard=allRecos['nRecosDiscard']  ;
    amess+='<hr>'+nRecosUserDiscard+' users had their recommendations discarded.  '+nRecosDiscard+' recommendations were discarded from valid users';

    amess+='<hr>';
    let eremoves=$('#admin_gotRemoves_show');
    eremoves.html(amess);

    let ee1=$('#myadminMenu_choices');

    if (useProject===false)  { // generic logon -- create a project okay, but not the others
       let ea1x=ee1.find('[name="always0"]');
       ea1x.css({'opacity':0.5});
       ea1x.prop('disabled',true);
       ea1x.attr('title','Not enabled: a project was not chosen');

       let ea2x=ee1.find('[name="always"]');
       ea2x.css({'opacity':1.0});
       ea2x.attr('title','Create a project!');
       let ebutt=ea2x.find('button');
       ebutt.prop('disabled',false);

    } else {
       let ea1x=ee1.find('[name="always0"]');
       ea1x.css({'opacity':1.0});
       ea1x.prop('disabled',false);
       ea1x.attr('title','Enabled for project: '+useProject);

       let ea2x=ee1.find('[name="always"]');
       ea2x.css({'opacity':0.5});
       ea2x.attr('title','To create a new project: from home page, click gear button in upper left corner');
       let ebutt=ea2x.find('button');
       ebutt.prop('disabled',true);

    }     // ea1 is visible

  }



}